# STRACT Programming Language

## Overview

STRACT is a modern programming language that combines simplicity with powerful features. It aims to provide an accessible syntax similar to Python while incorporating advanced capabilities including AI integration, web development tools, and code analysis features.

The language is implemented in Python and includes:
- Interactive REPL mode for live coding
- File execution capabilities
- Code analysis and checking tools
- Modular architecture with AI integration, web framework, compiler, and developer tools

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Language Components

**Lexer and Parser**
- Token-based lexical analysis with support for integers, floats, strings, booleans, and identifiers
- Recursive descent parser generating Abstract Syntax Trees (AST)
- Support for arithmetic, comparison, and logical operators
- Multiple token types including keywords (let, const, func, if, else, for, while, class, import, etc.)

**Interpreter Design**
- Tree-walking interpreter that executes AST nodes directly
- Environment-based variable scoping with support for nested scopes
- Built-in functions: print, input, len, range, sum, min, max, map, filter, reduce, sorted, reversed
- Lambda expressions and first-class functions
- Exception handling with try/catch/finally blocks

**Type System**
- Dynamic typing with runtime type checking
- Support for primitive types: integers, floats, strings, booleans
- Composite types: lists, dictionaries
- Future support planned for refinement types and type constraints

### Module Architecture

**CLI Interface (stract_cli.py)**
- Primary entry point for the language
- Commands: repl (interactive mode), run (execute files), check (syntax validation), analyze (AI-powered analysis), commands (list available commands)
- Wrapper around core interpreter with enhanced error reporting

**AI Integration Module**
- OpenAI GPT-5 integration for code generation, analysis, and explanation
- Features include: code generation from natural language, error explanation, code optimization suggestions
- Fallback mechanisms when AI services are unavailable
- API key management through environment variables

**Web Framework Module**
- HTTP server implementation with routing capabilities
- Request/Response objects for handling web traffic
- RESTful API support with JSON serialization
- Database integration layer (planned/partial implementation)
- Route decorators for GET, POST, PUT, DELETE methods (design phase)

**Compiler and Optimizer**
- Bytecode compilation system with OpCode enumeration
- Optimization passes: dead code elimination, constant folding, loop optimization
- Virtual machine for bytecode execution
- Caching mechanisms for compiled modules

**Developer Tools**
- Code formatter with configurable indentation
- Linter for code quality checks
- Profiler for performance analysis
- Interactive debugger with breakpoints and watchpoints

### Data Flow

1. Source code enters through CLI or REPL
2. Lexer tokenizes input into token stream
3. Parser builds AST from tokens
4. Interpreter walks AST and executes in environment context
5. Results returned to user or error handling triggered

### Design Patterns

**Visitor Pattern**: Used in AST traversal during interpretation
**Factory Pattern**: Module initialization and component creation
**Singleton Pattern**: Global interpreter instance management
**Strategy Pattern**: Multiple execution modes (REPL, file execution, analysis)

## External Dependencies

### Required Python Packages
- **Python 3.11+**: Core runtime requirement
- **OpenAI SDK**: For AI integration features (optional but recommended)
- **Standard Library**: json, re, sys, os, time, math, random, hashlib, pathlib, dataclasses, enum, typing

### Development Environment
- Designed to run on Replit with zero configuration
- Cross-platform support (Windows, macOS, Linux)
- No database currently required (in-memory data structures used)

### Future Integration Points
- PostgreSQL/SQLite for persistent storage (prepared for but not implemented)
- WebAssembly compilation target (architectural planning)
- GPU/TPU support for tensor operations (design documents exist)
- Blockchain and distributed systems features (conceptual phase)

### File Structure
```
STRACTPROGRAM/
├── stract_cli.py                 # Main CLI interface
├── STRACTPROGRAMzip/
│   └── SystemRefactor/
│       ├── main.py              # Core interpreter
│       ├── AI_INTEGRATION/      # AI features module
│       ├── WEB_SERVER/          # Web framework
│       ├── COMPILER/            # Bytecode compiler
│       ├── DEVELOPER_TOOLS/     # Linting, formatting, debugging
│       └── TESTS/               # Unit tests
├── examples/                    # Sample programs
└── docs/                        # Documentation files
```

### Note on Implementation Status
Many advanced features (web routing, AI-native syntax, temporal programming, contractual safety) exist in documentation and design phases but are not fully implemented in the current codebase. The working implementation focuses on core language features with extensibility points for future enhancements.