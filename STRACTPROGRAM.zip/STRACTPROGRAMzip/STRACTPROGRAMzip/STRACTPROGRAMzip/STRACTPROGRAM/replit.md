# STRACT Programming Language v5.0
## Project Summary & Documentation

---

## 📌 نظرة عامة (Overview)

**STRACT v5.0** هي لغة برمجة ثورية تجمع بين ثلاث ميزات فريدة:

1. **🤖 AI-Native Language** - ذكاء اصطناعي كلغة أولى
2. **⚡ Reactive & Temporal** - برمجة زمنية وتفاعلية
3. **🛡️ Contractual Safety** - أمان تعاقدي

---

## 🚀 التشغيل السريع

### على Replit (الآن)
```bash
python stract_cli.py repl
```

### على حاسوبك
```bash
# 1. Download as zip من Replit
# 2. فك الضغط
# 3. افتح Terminal
python stract_cli.py run examples/hello.stract
```

---

## 🎯 الميزات الثورية الثلاث

### 1. الذكاء الاصطناعي (AI-Native)

**Tensors:**
```stract
tensor weights[100, 50] gpu gradient
tensor input_data[5] = [1.0, 2.0, 3.0, 4.0, 5.0]
```

**نماذج:**
```stract
model NeuralNet:
    Dense(128, activation="relu")
    Dropout(0.2)
    Dense(10, activation="softmax")
```

**التفاضل التلقائي:**
```stract
gradient loss with respect to [weights, biases]
```

**التحسين:**
```stract
optimize model for accuracy using data
```

---

### 2. البرمجة الزمنية (Temporal)

**Streams:**
```stract
stream data = source() |> filter(x: x > 0) |> map(x: x * 2)
```

**متغيرات زمنية:**
```stract
temporal counter = 0 every 1s: counter + 1
```

**شروط تفاعلية:**
```stract
when counter > 100:
    print "Reached 100!"
```

**المراقبة:**
```stract
observe score:
    updateUI(score)
```

**التنفيذ الدوري:**
```stract
every 5s: checkHealth()
after 10s: cleanup()
```

---

### 3. الأمان التعاقدي (Contractual)

**أنواع مقيدة:**
```stract
type PositiveInt: Int where value > 0
type Percentage: Float where value >= 0 and value <= 100
type Email: String where contains(value, "@")
```

**عقود الدوال:**
```stract
func divide(a, b):
    requires b != 0
    ensures result * b == a
    return a / b
```

**ثوابت الفئات:**
```stract
class BankAccount:
    invariant balance >= 0
    
    func withdraw(amount):
        requires amount <= this.balance
        ensures this.balance == old(this.balance) - amount
```

**العزل الآمن:**
```stract
sandbox [network, file]:
    secureOperation()
```

---

## 📚 الأوامر الأساسية

```bash
# الوضع التفاعلي
python stract_cli.py repl

# تشغيل ملف
python stract_cli.py run file.stract

# فحص أخطاء
python stract_cli.py check file.stract

# تحليل الكود
python stract_cli.py analyze file.stract

# عرض جميع الأوامر
python stract_cli.py commands
```

---

## 📁 هيكل المشروع

```
STRACTPROGRAM/
├── stract_cli.py                            # CLI الرئيسي
├── README.md                                # الصفحة الرئيسية
├── replit.md                                # هذا الملف
├── examples/                                # الأمثلة
│   ├── revolutionary_features.stract        # كل الميزات
│   ├── ai_native.stract                     # AI والذكاء
│   ├── reactive_temporal.stract             # البرمجة الزمنية
│   └── contractual_safety.stract            # الأمان
├── docs/                                    # الوثائق
│   ├── COMPREHENSIVE_GUIDE_AR.md            # دليل شامل
│   ├── LANGUAGE_REFERENCE.md                # مرجع اللغة
│   ├── EXAMPLES_AR.md                       # أمثلة عملية
│   └── QUICK_START.md                       # البدء السريع
└── STRACTPROGRAMzip/SystemRefactor/
    ├── main.py                              # Interpreter الأساسي
    ├── CORE_SYSTEM/                         # Lexer و Parser
    ├── AI_INTEGRATION/                      # AI features
    ├── WEB_SERVER/                          # Web framework
    ├── DEVELOPER_TOOLS/                     # أدوات التطوير
    └── TESTS/                               # اختبارات
```

---

## 🌟 الميزات الأساسية

### البرمجة
- ✅ متغيرات: `let`, `const`, `var`
- ✅ دوال: `func`, `lambda`
- ✅ حلقات: `for`, `while`
- ✅ شروط: `if`, `elif`, `else`
- ✅ فئات: `class`
- ✅ معالجة أخطاء: `try`, `catch`

### الذكاء الاصطناعي
- ✅ Tensors مع GPU/CPU
- ✅ نماذج عصبية
- ✅ تفاضل تلقائي
- ✅ تحسين ذكي

### الأمان
- ✅ أنواع مقيدة
- ✅ عقود برمجية
- ✅ عزل آمن
- ✅ ثوابت الفئات

### البرمجة الزمنية
- ✅ Streams تفاعلية
- ✅ متغيرات زمنية
- ✅ شروط تفاعلية
- ✅ تنفيذ دوري/مؤجل

---

## 🔧 المتطلبات والتثبيت

### المتطلبات
- Python 3.11+
- لا توجد مكتبات خارجية مطلوبة (الكل مدمج)

### التثبيت
```bash
# على Replit - يعمل مباشرة!
# على حاسوبك - انسخ الملفات وشغل:
python stract_cli.py repl
```

---

## 📖 الوثائق المتاحة

### ملفات md للقراءة
1. **README.md** - الصفحة الرئيسية
2. **docs/COMPREHENSIVE_GUIDE_AR.md** - دليل شامل بالعربية
3. **docs/LANGUAGE_REFERENCE.md** - مرجع لغة كامل
4. **docs/EXAMPLES_AR.md** - أمثلة عملية
5. **docs/QUICK_START.md** - البدء السريع

### الأمثلة
- `examples/revolutionary_features.stract` - كل الميزات
- `examples/ai_native.stract` - AI features
- `examples/reactive_temporal.stract` - Temporal features
- `examples/contractual_safety.stract` - Safety features

---

## 💡 المزايا على المنافسين

| المقارنة | STRACT | Python | Rust |
|---------|--------|--------|------|
| بساطة | ⭐⭐⭐ | ⭐⭐⭐ | ⭐ |
| الأداء | ⭐⭐⭐ | ⭐ | ⭐⭐⭐ |
| AI مدمج | ⭐⭐⭐ | ❌ | ❌ |
| أمان | ⭐⭐⭐ | ⭐ | ⭐⭐⭐ |
| زمنية | ⭐⭐⭐ | ❌ | ⭐ |
| سهولة التعلم | ⭐⭐⭐ | ⭐⭐⭐ | ⭐ |

---

## 🎓 مستويات المستخدمين

### مبتدئ (Beginner)
- اقرأ: `docs/QUICK_START.md`
- جرب: `examples/hello.stract`
- أساسيات: متغيرات ودوال

### متوسط (Intermediate)
- اقرأ: `docs/COMPREHENSIVE_GUIDE_AR.md`
- استكشف: الميزات المتقدمة
- بناء: تطبيقات حقيقية

### متقدم (Advanced)
- اقرأ: `docs/LANGUAGE_REFERENCE.md`
- استخدم: الميزات الثورية
- ساهم: في التطوير

---

## 🔄 آخر التحديثات

### ✅ v5.0 (الإصدار الثوري)
- ✅ AI-Native: Tensors, Models, Gradients
- ✅ Reactive: Streams, Temporal, When, Observe
- ✅ Contractual: Refinement Types, Contracts, Sandbox
- ✅ 35+ keywords جديد
- ✅ 22 AST nodes جديد
- ✅ 5 Runtime classes جديدة
- ✅ وثائق شاملة بالعربية والإنجليزية
- ✅ أمثلة عملية ومشاريع

---

## 🎯 خطة المستقبل

### Phase 1: MVP (الآن) ✅
- التركيب والتحليل الأساسي
- تنفيذ runtime أولي
- توثيق شاملة

### Phase 2: التحسينات (التالي)
- تحسين أداء Tensors
- إضافة مكتبات معيارية
- دعم أفضل للأخطاء

### Phase 3: النمو (المستقبل)
- معايير صناعية
- تبني واسع
- مجتمع نشط

---

## 🆘 الدعم

### الموارد
- 📖 الوثائق: `docs/`
- 💡 الأمثلة: `examples/`
- 🔧 الأدوات: استخدم `check` و `analyze`

### التواصل
- أسئلة: اطرح في الوثائق
- اقتراحات: أرسل تحسينات
- أخطاء: أبلغ عن المشاكل

---

## 📊 الإحصائيات

| المقياس | العدد |
|---------|-------|
| Keywords | 35+ |
| Built-in Functions | 40+ |
| AST Nodes | 22+ |
| Runtime Classes | 5 |
| Parsing Methods | 18+ |
| Documentation Files | 8+ |
| Example Files | 4 |
| Lines of Code | 10,000+ |

---

## 🎉 شكراً لك!

شكراً لاستخدامك **STRACT v5.0**!

نحن متحمسون لرؤية ما ستبنيه بها.

**STRACT** - برمجة المستقبل بذكاء، أمان، وزمن حقيقي! 🚀

---

### روابط مهمة
- 📖 [دليل شامل](docs/COMPREHENSIVE_GUIDE_AR.md)
- 🔍 [مرجع اللغة](docs/LANGUAGE_REFERENCE.md)
- 💡 [أمثلة عملية](docs/EXAMPLES_AR.md)
- ⚡ [البدء السريع](docs/QUICK_START.md)

---

**Last Updated: 2025-11-30**
**Version: 5.0.0**
**Status: Stable ✅**
