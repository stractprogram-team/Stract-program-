#!/usr/bin/env python3
"""
Advanced tests for STRACT interpreter
"""

import unittest
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from main import STRACT

class TestSTRACTAdvanced(unittest.TestCase):
    
    def setUp(self):
        self.stract = STRACT()
    
    def test_recursive_functions(self):
        code = '''
func factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)
print factorial(5)
'''
        result = self.stract.run_source(code)
    
    def test_list_methods(self):
        code = '''
let numbers = [1, 2, 3]
numbers.append(4)
print numbers
print numbers.sum()
print numbers.max()
'''
        result = self.stract.run_source(code)
    
    def test_string_methods(self):
        code = '''
let text = "  hello world  "
print text.strip()
print text.upper()
print text.split()
'''
        result = self.stract.run_source(code)
    
    def test_nested_loops(self):
        code = '''
for i in range(1, 3):
    for j in range(1, 3):
        print i, j
'''
        result = self.stract.run_source(code)
    
    def test_error_handling(self):
        # Test undefined variable
        with self.assertRaises(Exception):
            self.stract.run_source('print undefined_var')
        
        # Test division by zero
        with self.assertRaises(Exception):
            self.stract.run_source('print 10 / 0')

if __name__ == '__main__':
    unittest.main()