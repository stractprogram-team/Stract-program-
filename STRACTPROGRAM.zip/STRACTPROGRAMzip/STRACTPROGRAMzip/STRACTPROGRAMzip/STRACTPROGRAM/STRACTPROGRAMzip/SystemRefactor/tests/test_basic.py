#!/usr/bin/env python3
"""
Unit tests for STRACT interpreter
"""

import unittest
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from main import STRACT

class TestSTRACTBasic(unittest.TestCase):
    
    def setUp(self):
        self.stract = STRACT()
    
    def test_variables(self):
        result = self.stract.run_source('let x = 5')
        self.assertEqual(result, 5)
        
        result = self.stract.run_source('const PI = 3.14')
        self.assertEqual(result, 3.14)
    
    def test_arithmetic(self):
        result = self.stract.run_source('print 2 + 3')
        result = self.stract.run_source('print 10 - 4')
        result = self.stract.run_source('print 3 * 4')
        result = self.stract.run_source('print 15 / 3')
    
    def test_strings(self):
        result = self.stract.run_source('let name = "STRACT"')
        self.assertEqual(result, "STRACT")
    
    def test_lists(self):
        result = self.stract.run_source('let lst = [1, 2, 3]')
        self.assertEqual(result, [1, 2, 3])
    
    def test_conditionals(self):
        code = '''
let x = 10
if x > 5:
    print "Greater"
else:
    print "Smaller"
'''
        result = self.stract.run_source(code)
    
    def test_loops(self):
        code = '''
let sum = 0
for i in range(1, 4):
    sum += i
print sum
'''
        result = self.stract.run_source(code)
    
    def test_functions(self):
        code = '''
func add(a, b):
    return a + b
print add(2, 3)
'''
        result = self.stract.run_source(code)

if __name__ == '__main__':
    unittest.main()