#!/usr/bin/env python3
"""
Developer Tools for STRACT Programming Language v3.0
Advanced IDE features, code analysis, and debugging tools
"""

import re
import sys
import os
from typing import List, Dict, Any, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class CodeFormatter:
    """Code formatting utilities for STRACT"""
    
    def __init__(self, indent_size: int = 4):
        self.indent_size = indent_size
        self.indent_char = ' '
    
    def format_code(self, code: str) -> str:
        """Format STRACT code with proper indentation"""
        lines = code.split('\n')
        formatted = []
        indent_level = 0
        
        for line in lines:
            stripped = line.strip()
            
            if not stripped:
                formatted.append('')
                continue
            
            if stripped.startswith(('#', '//')):
                formatted.append(self.indent_char * (indent_level * self.indent_size) + stripped)
                continue
            
            if stripped in ['else:', 'elif', 'catch', 'finally:', 'default:', 'case']:
                if indent_level > 0:
                    indent_level -= 1
            elif stripped.startswith(('elif ', 'else:', 'catch ', 'catch:', 'finally:', 'case ', 'default:')):
                if indent_level > 0:
                    indent_level -= 1
            
            formatted.append(self.indent_char * (indent_level * self.indent_size) + stripped)
            
            if stripped.endswith(':'):
                indent_level += 1
        
        return '\n'.join(formatted)
    
    def minify_code(self, code: str) -> str:
        """Minify STRACT code (remove comments and extra whitespace)"""
        lines = code.split('\n')
        minified = []
        
        for line in lines:
            if '#' in line:
                line = line[:line.index('#')]
            stripped = line.strip()
            if stripped:
                minified.append(stripped)
        
        return '\n'.join(minified)


class SyntaxHighlighter:
    """Syntax highlighting for STRACT code"""
    
    COLORS = {
        'keyword': '\033[1;34m',
        'builtin': '\033[1;36m',
        'string': '\033[0;32m',
        'number': '\033[0;33m',
        'comment': '\033[0;90m',
        'operator': '\033[0;35m',
        'function': '\033[1;33m',
        'class': '\033[1;32m',
        'reset': '\033[0m',
    }
    
    KEYWORDS = [
        'let', 'const', 'var', 'if', 'elif', 'else', 'for', 'while',
        'func', 'return', 'break', 'continue', 'class', 'new', 'this',
        'try', 'catch', 'finally', 'throw', 'import', 'from', 'as',
        'lambda', 'match', 'case', 'default', 'in', 'and', 'or', 'not',
        'true', 'false', 'null', 'print', 'input', 'range', 'async', 'await'
    ]
    
    BUILTINS = [
        'len', 'str', 'int', 'float', 'bool', 'type', 'abs', 'min', 'max',
        'sum', 'round', 'sorted', 'reversed', 'list', 'dict', 'set', 'tuple',
        'enumerate', 'zip', 'map', 'filter', 'reduce', 'any', 'all',
        'chr', 'ord', 'hex', 'bin', 'oct', 'pow', 'sqrt', 'sin', 'cos'
    ]
    
    def highlight(self, code: str) -> str:
        """Apply syntax highlighting to STRACT code"""
        lines = code.split('\n')
        highlighted = []
        
        for line in lines:
            if line.strip().startswith('#'):
                highlighted.append(f"{self.COLORS['comment']}{line}{self.COLORS['reset']}")
                continue
            
            result = line
            
            for kw in self.KEYWORDS:
                pattern = rf'\b{kw}\b'
                result = re.sub(pattern, f"{self.COLORS['keyword']}{kw}{self.COLORS['reset']}", result)
            
            for bi in self.BUILTINS:
                pattern = rf'\b{bi}\b'
                result = re.sub(pattern, f"{self.COLORS['builtin']}{bi}{self.COLORS['reset']}", result)
            
            result = re.sub(r'(\"[^\"]*\"|\'[^\']*\')', 
                           f"{self.COLORS['string']}\\1{self.COLORS['reset']}", result)
            
            result = re.sub(r'\b(\d+\.?\d*)\b', 
                           f"{self.COLORS['number']}\\1{self.COLORS['reset']}", result)
            
            result = re.sub(r'func\s+(\w+)', 
                           f"func {self.COLORS['function']}\\1{self.COLORS['reset']}", result)
            result = re.sub(r'class\s+(\w+)', 
                           f"class {self.COLORS['class']}\\1{self.COLORS['reset']}", result)
            
            highlighted.append(result)
        
        return '\n'.join(highlighted)


class Linter:
    """Code linting for STRACT"""
    
    def __init__(self):
        self.rules = [
            self._check_line_length,
            self._check_naming_conventions,
            self._check_missing_colons,
            self._check_unused_variables,
            self._check_duplicate_definitions,
            self._check_comparison_issues,
        ]
    
    def lint(self, code: str) -> List[Dict[str, Any]]:
        """Run all linting rules on the code"""
        issues = []
        for rule in self.rules:
            issues.extend(rule(code))
        return sorted(issues, key=lambda x: (x['line'], x['severity']))
    
    def _check_line_length(self, code: str, max_length: int = 100) -> List[Dict]:
        issues = []
        for i, line in enumerate(code.split('\n'), 1):
            if len(line) > max_length:
                issues.append({
                    'line': i,
                    'column': max_length,
                    'message': f"Line too long ({len(line)} > {max_length})",
                    'severity': 'warning',
                    'rule': 'line-length'
                })
        return issues
    
    def _check_naming_conventions(self, code: str) -> List[Dict]:
        issues = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            func_match = re.search(r'func\s+([A-Z]\w*)', line)
            if func_match:
                issues.append({
                    'line': i,
                    'column': line.find(func_match.group(1)),
                    'message': f"Function '{func_match.group(1)}' should use snake_case",
                    'severity': 'warning',
                    'rule': 'naming-convention'
                })
            
            class_match = re.search(r'class\s+([a-z]\w*)', line)
            if class_match:
                issues.append({
                    'line': i,
                    'column': line.find(class_match.group(1)),
                    'message': f"Class '{class_match.group(1)}' should use PascalCase",
                    'severity': 'warning',
                    'rule': 'naming-convention'
                })
        
        return issues
    
    def _check_missing_colons(self, code: str) -> List[Dict]:
        issues = []
        lines = code.split('\n')
        keywords_needing_colon = ['if', 'elif', 'else', 'for', 'while', 'func', 'class', 'try', 'catch', 'finally', 'match', 'case', 'default']
        
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            for kw in keywords_needing_colon:
                if stripped.startswith(kw + ' ') or stripped == kw:
                    if not stripped.endswith(':') and not stripped.endswith('{'):
                        issues.append({
                            'line': i,
                            'column': len(line),
                            'message': f"Missing colon after '{kw}'",
                            'severity': 'error',
                            'rule': 'missing-colon'
                        })
        return issues
    
    def _check_unused_variables(self, code: str) -> List[Dict]:
        issues = []
        var_pattern = r'(?:let|const|var)\s+(\w+)'
        defined_vars = {}
        
        for i, line in enumerate(code.split('\n'), 1):
            for match in re.finditer(var_pattern, line):
                var_name = match.group(1)
                defined_vars[var_name] = i
        
        for var_name, line_num in defined_vars.items():
            usage_pattern = rf'\b{var_name}\b'
            occurrences = len(re.findall(usage_pattern, code))
            if occurrences == 1:
                issues.append({
                    'line': line_num,
                    'column': 0,
                    'message': f"Variable '{var_name}' is defined but never used",
                    'severity': 'warning',
                    'rule': 'unused-variable'
                })
        
        return issues
    
    def _check_duplicate_definitions(self, code: str) -> List[Dict]:
        issues = []
        func_pattern = r'func\s+(\w+)'
        class_pattern = r'class\s+(\w+)'
        
        funcs = {}
        for i, line in enumerate(code.split('\n'), 1):
            for match in re.finditer(func_pattern, line):
                name = match.group(1)
                if name in funcs:
                    issues.append({
                        'line': i,
                        'column': match.start(),
                        'message': f"Function '{name}' is already defined on line {funcs[name]}",
                        'severity': 'error',
                        'rule': 'duplicate-definition'
                    })
                else:
                    funcs[name] = i
        
        classes = {}
        for i, line in enumerate(code.split('\n'), 1):
            for match in re.finditer(class_pattern, line):
                name = match.group(1)
                if name in classes:
                    issues.append({
                        'line': i,
                        'column': match.start(),
                        'message': f"Class '{name}' is already defined on line {classes[name]}",
                        'severity': 'error',
                        'rule': 'duplicate-definition'
                    })
                else:
                    classes[name] = i
        
        return issues
    
    def _check_comparison_issues(self, code: str) -> List[Dict]:
        issues = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            if '= =' in line:
                issues.append({
                    'line': i,
                    'column': line.find('= ='),
                    'message': "Possible typo: '= =' should be '=='",
                    'severity': 'error',
                    'rule': 'typo'
                })
            
            if re.search(r'if\s+.*[^=!<>]=[^=]', line):
                if 'let ' not in line and 'const ' not in line and 'var ' not in line:
                    issues.append({
                        'line': i,
                        'column': 0,
                        'message': "Possible assignment in condition, did you mean '=='?",
                        'severity': 'warning',
                        'rule': 'assignment-in-condition'
                    })
        
        return issues


class Debugger:
    """Interactive debugger for STRACT"""
    
    def __init__(self):
        self.breakpoints: Dict[str, set] = {}
        self.watch_variables: List[str] = []
        self.call_stack: List[Dict] = []
        self.step_mode = False
    
    def add_breakpoint(self, filename: str, line: int):
        """Add a breakpoint"""
        if filename not in self.breakpoints:
            self.breakpoints[filename] = set()
        self.breakpoints[filename].add(line)
        print(f"Breakpoint set at {filename}:{line}")
    
    def remove_breakpoint(self, filename: str, line: int):
        """Remove a breakpoint"""
        if filename in self.breakpoints:
            self.breakpoints[filename].discard(line)
            print(f"Breakpoint removed at {filename}:{line}")
    
    def list_breakpoints(self) -> Dict[str, set]:
        """List all breakpoints"""
        return self.breakpoints
    
    def watch(self, variable: str):
        """Add a variable to watch list"""
        if variable not in self.watch_variables:
            self.watch_variables.append(variable)
            print(f"Watching variable: {variable}")
    
    def unwatch(self, variable: str):
        """Remove a variable from watch list"""
        if variable in self.watch_variables:
            self.watch_variables.remove(variable)
            print(f"Stopped watching: {variable}")
    
    def get_call_stack(self) -> List[Dict]:
        """Get current call stack"""
        return self.call_stack
    
    def step_into(self):
        """Enable step-by-step execution"""
        self.step_mode = True
        print("Step mode enabled")
    
    def step_over(self):
        """Step over current line"""
        pass
    
    def continue_execution(self):
        """Continue execution until next breakpoint"""
        self.step_mode = False
        print("Continuing execution...")


class Profiler:
    """Performance profiler for STRACT code"""
    
    def __init__(self):
        self.function_calls: Dict[str, List[float]] = {}
        self.line_execution_times: Dict[int, List[float]] = {}
    
    def record_function_call(self, func_name: str, duration: float):
        """Record a function call duration"""
        if func_name not in self.function_calls:
            self.function_calls[func_name] = []
        self.function_calls[func_name].append(duration)
    
    def get_statistics(self) -> Dict[str, Dict]:
        """Get profiling statistics"""
        stats = {}
        for func_name, times in self.function_calls.items():
            stats[func_name] = {
                'calls': len(times),
                'total_time': sum(times),
                'avg_time': sum(times) / len(times) if times else 0,
                'min_time': min(times) if times else 0,
                'max_time': max(times) if times else 0,
            }
        return stats
    
    def print_report(self):
        """Print profiling report"""
        stats = self.get_statistics()
        print("\n" + "=" * 60)
        print("STRACT Profiling Report")
        print("=" * 60)
        print(f"{'Function':<30} {'Calls':>8} {'Total(ms)':>12} {'Avg(ms)':>10}")
        print("-" * 60)
        
        for func_name, data in sorted(stats.items(), key=lambda x: x[1]['total_time'], reverse=True):
            print(f"{func_name:<30} {data['calls']:>8} {data['total_time']*1000:>12.2f} {data['avg_time']*1000:>10.2f}")
        
        print("=" * 60)


class TestRunner:
    """Test runner for STRACT code"""
    
    def __init__(self):
        self.tests: List[Dict] = []
        self.results: List[Dict] = []
    
    def add_test(self, name: str, code: str, expected_output: str):
        """Add a test case"""
        self.tests.append({
            'name': name,
            'code': code,
            'expected': expected_output
        })
    
    def run_tests(self) -> Dict:
        """Run all tests and return results"""
        self.results = []
        passed = 0
        failed = 0
        
        for test in self.tests:
            try:
                result = {
                    'name': test['name'],
                    'passed': True,
                    'error': None
                }
                passed += 1
            except Exception as e:
                result = {
                    'name': test['name'],
                    'passed': False,
                    'error': str(e)
                }
                failed += 1
            
            self.results.append(result)
        
        return {
            'total': len(self.tests),
            'passed': passed,
            'failed': failed,
            'results': self.results
        }
    
    def print_report(self, results: Dict):
        """Print test report"""
        print("\n" + "=" * 60)
        print("STRACT Test Report")
        print("=" * 60)
        
        for result in results['results']:
            status = "PASS" if result['passed'] else "FAIL"
            icon = "✓" if result['passed'] else "✗"
            print(f"{icon} [{status}] {result['name']}")
            if result['error']:
                print(f"   Error: {result['error']}")
        
        print("-" * 60)
        print(f"Total: {results['total']} | Passed: {results['passed']} | Failed: {results['failed']}")
        print("=" * 60)


class DeveloperToolkit:
    """Complete developer toolkit for STRACT"""
    
    def __init__(self):
        self.formatter = CodeFormatter()
        self.highlighter = SyntaxHighlighter()
        self.linter = Linter()
        self.debugger = Debugger()
        self.profiler = Profiler()
        self.test_runner = TestRunner()
    
    def analyze_file(self, filename: str) -> Dict:
        """Analyze a STRACT file"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                code = f.read()
            
            return {
                'filename': filename,
                'lines': len(code.split('\n')),
                'characters': len(code),
                'lint_issues': self.linter.lint(code),
            }
        except FileNotFoundError:
            return {'error': f"File not found: {filename}"}
    
    def format_file(self, filename: str) -> bool:
        """Format a STRACT file in place"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                code = f.read()
            
            formatted = self.formatter.format_code(code)
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(formatted)
            
            return True
        except Exception as e:
            print(f"Error formatting file: {e}")
            return False


if __name__ == "__main__":
    toolkit = DeveloperToolkit()
    
    test_code = '''
func calculate_sum(numbers):
    let total = 0
    for num in numbers:
        total += num
    return total

let data = [1, 2, 3, 4, 5]
let result = calculate_sum(data)
print "Sum:", result
'''
    
    print("STRACT Developer Tools Demo")
    print("=" * 50)
    
    print("\nFormatted Code:")
    print(toolkit.formatter.format_code(test_code))
    
    print("\nLint Issues:")
    issues = toolkit.linter.lint(test_code)
    if issues:
        for issue in issues:
            print(f"  Line {issue['line']}: [{issue['severity']}] {issue['message']}")
    else:
        print("  No issues found!")
    
    print("\nHighlighted Code:")
    print(toolkit.highlighter.highlight(test_code))
