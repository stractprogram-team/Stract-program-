#!/usr/bin/env python3
"""
Advanced Debugger for STRACT Programming Language
"""

import sys
import inspect
from typing import Any, Dict, List, Optional
from main import STRACT, Interpreter, Environment, ASTNode

class STRACTDebugger:
    """Interactive debugger for STRACT programs"""
    
    def __init__(self, interpreter: Interpreter):
        self.interpreter = interpreter
        self.breakpoints = set()
        self.watchpoints = {}
        self.step_mode = False
        self.call_stack = []
        
    def set_breakpoint(self, line: int):
        """Set breakpoint at specific line"""
        self.breakpoints.add(line)
        print(f"Breakpoint set at line {line}")
    
    def remove_breakpoint(self, line: int):
        """Remove breakpoint"""
        if line in self.breakpoints:
            self.breakpoints.remove(line)
            print(f"Breakpoint removed at line {line}")
        else:
            print(f"No breakpoint at line {line}")
    
    def set_watchpoint(self, variable: str):
        """Watch for variable changes"""
        self.watchpoints[variable] = True
        print(f"Watching variable: {variable}")
    
    def execute_with_debug(self, node: ASTNode, env: Environment, line: int) -> Any:
        """Execute node with debugger support"""
        
        # Check for breakpoints
        if line in self.breakpoints:
            self.interactive_debug(line, env)
        
        # Check watchpoints
        self.check_watchpoints(env)
        
        # Execute the node
        try:
            return self.interpreter.execute(node, env)
        except Exception as e:
            print(f"🚨 Runtime Error at line {line}: {e}")
            self.interactive_debug(line, env, error=True)
            raise
    
    def interactive_debug(self, line: int, env: Environment, error: bool = False):
        """Start interactive debugging session"""
        print(f"\n{'🚨' if error else '🔍'} Debugger activated at line {line}")
        
        while True:
            try:
                cmd = input("(debug) ").strip().split()
                
                if not cmd:
                    continue
                
                if cmd[0] == 'c':  # continue
                    break
                elif cmd[0] == 's':  # step
                    self.step_mode = True
                    break
                elif cmd[0] == 'p':  # print variable
                    if len(cmd) > 1:
                        var_name = cmd[1]
                        try:
                            value = env.get(var_name)
                            print(f"{var_name} = {value}")
                        except:
                            print(f"Variable '{var_name}' not found")
                    else:
                        print("Usage: p <variable>")
                elif cmd[0] == 'l':  # list variables
                    self.list_variables(env)
                elif cmd[0] == 'bt':  # backtrace
                    self.show_backtrace()
                elif cmd[0] == 'b':  # set breakpoint
                    if len(cmd) > 1:
                        self.set_breakpoint(int(cmd[1]))
                    else:
                        print("Usage: b <line>")
                elif cmd[0] == 'w':  # watch variable
                    if len(cmd) > 1:
                        self.set_watchpoint(cmd[1])
                    else:
                        print("Usage: w <variable>")
                elif cmd[0] == 'h':  # help
                    self.show_debug_help()
                elif cmd[0] == 'q':  # quit
                    print("Debugging session ended")
                    sys.exit(0)
                else:
                    print("Unknown command. Type 'h' for help.")
            
            except (EOFError, KeyboardInterrupt):
                print("\nDebugging session ended")
                sys.exit(0)
    
    def list_variables(self, env: Environment):
        """List all variables in current scope"""
        print("\n📋 Current Variables:")
        print("-" * 40)
        
        # Get variables from current environment
        current_vars = {}
        if hasattr(env, 'variables'):
            current_vars.update(env.variables)
        
        for name, value in current_vars.items():
            const_flag = " (const)" if name in getattr(env, 'constants', set()) else ""
            print(f"{name}{const_flag} = {value}")
    
    def check_watchpoints(self, env: Environment):
        """Check if watched variables have changed"""
        # Implementation for tracking variable changes
        pass
    
    def show_backtrace(self):
        """Show function call stack"""
        if not self.call_stack:
            print("Call stack is empty")
            return
        
        print("\n📞 Call Stack:")
        print("-" * 40)
        for i, frame in enumerate(reversed(self.call_stack)):
            print(f"#{i}: {frame}")
    
    def show_debug_help(self):
        """Show debugger commands"""
        print("""
Debugger Commands:
─────────────────────────────────────────────────────────────────
  c        - Continue execution
  s        - Step to next line
  p <var>  - Print variable value
  l        - List all variables
  bt       - Show call stack (backtrace)
  b <line> - Set breakpoint at line
  w <var>  - Watch variable for changes
  h        - Show this help
  q        - Quit debugging session
─────────────────────────────────────────────────────────────────
""")

# Monkey patch the interpreter to add debugger support
original_execute = Interpreter.execute

def debug_execute(self, node: ASTNode, env: Environment = None) -> Any:
    if hasattr(self, 'debugger') and self.debugger:
        line = getattr(node, 'line', 0)
        return self.debugger.execute_with_debug(node, env, line)
    else:
        return original_execute(self, node, env)

Interpreter.execute = debug_execute