#!/usr/bin/env python3
"""
Module system for STRACT Programming Language
"""

import os
import sys
from typing import Dict, Any
from main import STRACT, Interpreter, Environment

class ModuleSystem:
    """Module system for STRACT language"""
    
    def __init__(self, interpreter: Interpreter):
        self.interpreter = interpreter
        self.loaded_modules: Dict[str, Dict[str, Any]] = {}
        self.module_paths = ['modules', '.']
    
    def import_module(self, module_name: str, env: Environment) -> Dict[str, Any]:
        """Import a STRACT module"""
        
        if module_name in self.loaded_modules:
            return self.loaded_modules[module_name]
        
        # Find module file
        module_file = self.find_module_file(module_name)
        if not module_file:
            raise RuntimeError(f"Module not found: {module_name}")
        
        # Create new environment for module
        module_env = Environment()
        
        # Execute module code
        with open(module_file, 'r', encoding='utf-8') as f:
            module_code = f.read()
        
        # Store original functions
        original_functions = self.interpreter.functions.copy()
        
        try:
            # Execute module in its own environment
            stract = STRACT()
            stract.run_source(module_code)
            
            # Extract exported functions and variables
            module_exports = {}
            
            # Get functions defined in module
            for func_name, func_node in stract.interpreter.functions.items():
                if func_name not in original_functions:
                    module_exports[func_name] = func_node
            
            # Store module exports
            self.loaded_modules[module_name] = module_exports
            
            # Import into current environment
            for name, value in module_exports.items():
                if isinstance(value, type(lambda: None)):
                    env.define(name, value)
                else:
                    self.interpreter.functions[name] = value
            
            return module_exports
            
        except Exception as e:
            raise RuntimeError(f"Error importing module {module_name}: {e}")
    
    def find_module_file(self, module_name: str) -> str:
        """Find module file in search paths"""
        for path in self.module_paths:
            # Check for .stract extension
            module_file = os.path.join(path, f"{module_name}.stract")
            if os.path.exists(module_file):
                return module_file
            
            # Check for .st extension
            module_file = os.path.join(path, f"{module_name}.st")
            if os.path.exists(module_file):
                return module_file
        
        return None

# Built-in modules

# Math module
MATH_MODULE = """
const PI = 3.141592653589793
const E = 2.718281828459045

func sqrt(x):
    return x ** 0.5

func pow(base, exponent):
    return base ** exponent

func sin(x):
    # Simple sine approximation
    return x - (x**3)/6 + (x**5)/120

func cos(x):
    # Simple cosine approximation  
    return 1 - (x**2)/2 + (x**4)/24
"""

# String module
STRING_MODULE = """
func is_alpha(s):
    return s.upper() != s.lower()

func is_digit(s):
    return s in "0123456789"

func repeat(s, n):
    let result = ""
    for i in range(n):
        result += s
    return result

func capitalize(s):
    if len(s) == 0:
        return s
    return s.upper()[0] + s.lower()[1:]
"""

# File module  
FILE_MODULE = """
# Note: These would need to be implemented in Python and exposed
func read_file(path):
    # To be implemented in host language
    return ""

func write_file(path, content):
    # To be implemented in host language
    return true

func file_exists(path):
    # To be implemented in host language
    return false
"""