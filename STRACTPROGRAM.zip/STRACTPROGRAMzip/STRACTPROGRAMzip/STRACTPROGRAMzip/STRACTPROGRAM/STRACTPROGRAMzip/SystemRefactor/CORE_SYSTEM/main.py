#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STRACT Programming Language Interpreter v2.0
A modern, powerful, and extensible programming language for 2027 and beyond.
Designed with AI integration capabilities in mind.

Author: STRACT Development Team
License: MIT
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
import sys

# ============================================================================
# PART 1: TOKEN DEFINITIONS
# Defines all token types used in the STRACT language
# ============================================================================

class TokenType(Enum):
    """All token types supported by STRACT"""
    # Literals
    INTEGER = auto()
    FLOAT = auto()
    STRING = auto()
    BOOLEAN = auto()
    IDENTIFIER = auto()
    
    # Arithmetic Operators
    PLUS = auto()          # +
    MINUS = auto()         # -
    MULTIPLY = auto()      # *
    DIVIDE = auto()        # /
    MODULO = auto()        # %
    POWER = auto()         # **
    
    # Comparison Operators
    EQUAL = auto()         # ==
    NOT_EQUAL = auto()     # !=
    LESS = auto()          # <
    GREATER = auto()       # >
    LESS_EQUAL = auto()    # <=
    GREATER_EQUAL = auto() # >=
    
    # Logical Operators
    AND = auto()           # and
    OR = auto()            # or
    NOT = auto()           # not
    
    # Assignment
    ASSIGN = auto()        # =
    PLUS_ASSIGN = auto()   # +=
    MINUS_ASSIGN = auto()  # -=
    
    # Delimiters
    LPAREN = auto()        # (
    RPAREN = auto()        # )
    LBRACKET = auto()      # [
    RBRACKET = auto()      # ]
    LBRACE = auto()        # {
    RBRACE = auto()        # }
    COMMA = auto()         # ,
    COLON = auto()         # :
    DOT = auto()           # .
    NEWLINE = auto()
    
    # Keywords
    LET = auto()
    CONST = auto()
    IF = auto()
    ELIF = auto()
    ELSE = auto()
    WHILE = auto()
    FOR = auto()
    IN = auto()
    FUNC = auto()
    RETURN = auto()
    BREAK = auto()
    CONTINUE = auto()
    PRINT = auto()
    INPUT = auto()
    TRUE = auto()
    FALSE = auto()
    NULL = auto()
    RANGE = auto()
    
    # Special
    EOF = auto()
    INDENT = auto()
    DEDENT = auto()


@dataclass
class Token:
    """Represents a single token with position information"""
    type: TokenType
    value: Any
    line: int
    column: int
    
    def __repr__(self):
        return f"Token({self.type.name}, {repr(self.value)}, line={self.line})"


# ============================================================================
# PART 2: LEXER (Tokenizer)
# Converts source code into a stream of tokens
# ============================================================================

class LexerError(Exception):
    """Exception raised for lexer errors"""
    def __init__(self, message: str, line: int, column: int):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Lexer Error at line {line}, column {column}: {message}")


class Lexer:
    """Tokenizes STRACT source code"""
    
    KEYWORDS = {
        'let': TokenType.LET,
        'const': TokenType.CONST,
        'if': TokenType.IF,
        'elif': TokenType.ELIF,
        'else': TokenType.ELSE,
        'while': TokenType.WHILE,
        'for': TokenType.FOR,
        'in': TokenType.IN,
        'func': TokenType.FUNC,
        'return': TokenType.RETURN,
        'break': TokenType.BREAK,
        'continue': TokenType.CONTINUE,
        'print': TokenType.PRINT,
        'input': TokenType.INPUT,
        'true': TokenType.TRUE,
        'false': TokenType.FALSE,
        'null': TokenType.NULL,
        'and': TokenType.AND,
        'or': TokenType.OR,
        'not': TokenType.NOT,
        'range': TokenType.RANGE,
    }
    
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.indent_stack = [0]
        
    def error(self, message: str):
        raise LexerError(message, self.line, self.column)
    
    def peek(self, offset: int = 0) -> str:
        pos = self.pos + offset
        if pos >= len(self.source):
            return '\0'
        return self.source[pos]
    
    def advance(self) -> str:
        char = self.peek()
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char
    
    def skip_whitespace(self):
        while self.peek() in ' \t' and self.peek() != '\0':
            self.advance()
    
    def skip_comment(self):
        if self.peek() == '#':
            while self.peek() != '\n' and self.peek() != '\0':
                self.advance()
    
    def read_string(self) -> Token:
        quote = self.advance()
        start_line = self.line
        start_col = self.column - 1
        value = ""
        
        while self.peek() != quote:
            if self.peek() == '\0':
                self.error("Unterminated string")
            if self.peek() == '\\':
                self.advance()
                escape_char = self.advance()
                escape_map = {'n': '\n', 't': '\t', 'r': '\r', '\\': '\\', '"': '"', "'": "'"}
                value += escape_map.get(escape_char, escape_char)
            else:
                value += self.advance()
        
        self.advance()  # closing quote
        return Token(TokenType.STRING, value, start_line, start_col)
    
    def read_number(self) -> Token:
        start_line = self.line
        start_col = self.column
        value = ""
        is_float = False
        
        while self.peek().isdigit() or self.peek() == '.':
            if self.peek() == '.':
                if is_float:
                    break
                is_float = True
            value += self.advance()
        
        if is_float:
            return Token(TokenType.FLOAT, float(value), start_line, start_col)
        return Token(TokenType.INTEGER, int(value), start_line, start_col)
    
    def read_identifier(self) -> Token:
        start_line = self.line
        start_col = self.column
        value = ""
        
        while self.peek().isalnum() or self.peek() == '_':
            value += self.advance()
        
        # Check for keywords
        token_type = self.KEYWORDS.get(value.lower())
        if token_type:
            if token_type == TokenType.TRUE:
                return Token(TokenType.BOOLEAN, True, start_line, start_col)
            elif token_type == TokenType.FALSE:
                return Token(TokenType.BOOLEAN, False, start_line, start_col)
            return Token(token_type, value.lower(), start_line, start_col)
        
        return Token(TokenType.IDENTIFIER, value, start_line, start_col)
    
    def handle_indentation(self):
        """Handle Python-style indentation for blocks"""
        if self.column != 1:
            return
        
        indent = 0
        while self.peek() == ' ':
            self.advance()
            indent += 1
        while self.peek() == '\t':
            self.advance()
            indent += 4
        
        if self.peek() == '\n' or self.peek() == '#':
            return  # Empty line or comment-only line
        
        current_indent = self.indent_stack[-1]
        
        if indent > current_indent:
            self.indent_stack.append(indent)
            self.tokens.append(Token(TokenType.INDENT, indent, self.line, 1))
        elif indent < current_indent:
            while self.indent_stack and self.indent_stack[-1] > indent:
                self.indent_stack.pop()
                self.tokens.append(Token(TokenType.DEDENT, indent, self.line, 1))
    
    def tokenize(self) -> List[Token]:
        """Convert source code to tokens"""
        while self.pos < len(self.source):
            # Handle start of line indentation
            if self.column == 1:
                self.handle_indentation()
            
            char = self.peek()
            
            # Skip whitespace (but not at start of line)
            if char in ' \t':
                self.skip_whitespace()
                continue
            
            # Skip comments
            if char == '#':
                self.skip_comment()
                continue
            
            # Newlines
            if char == '\n':
                self.tokens.append(Token(TokenType.NEWLINE, '\\n', self.line, self.column))
                self.advance()
                continue
            
            # Strings
            if char in '"\'':
                self.tokens.append(self.read_string())
                continue
            
            # Numbers
            if char.isdigit():
                self.tokens.append(self.read_number())
                continue
            
            # Identifiers and keywords
            if char.isalpha() or char == '_':
                self.tokens.append(self.read_identifier())
                continue
            
            # Operators and delimiters
            start_line = self.line
            start_col = self.column
            
            # Two-character operators
            two_char = self.peek() + self.peek(1)
            if two_char == '**':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.POWER, '**', start_line, start_col))
                continue
            elif two_char == '==':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.EQUAL, '==', start_line, start_col))
                continue
            elif two_char == '!=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.NOT_EQUAL, '!=', start_line, start_col))
                continue
            elif two_char == '<=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.LESS_EQUAL, '<=', start_line, start_col))
                continue
            elif two_char == '>=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.GREATER_EQUAL, '>=', start_line, start_col))
                continue
            elif two_char == '+=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.PLUS_ASSIGN, '+=', start_line, start_col))
                continue
            elif two_char == '-=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.MINUS_ASSIGN, '-=', start_line, start_col))
                continue
            
            # Single-character operators
            single_char_ops = {
                '+': TokenType.PLUS,
                '-': TokenType.MINUS,
                '*': TokenType.MULTIPLY,
                '/': TokenType.DIVIDE,
                '%': TokenType.MODULO,
                '=': TokenType.ASSIGN,
                '<': TokenType.LESS,
                '>': TokenType.GREATER,
                '(': TokenType.LPAREN,
                ')': TokenType.RPAREN,
                '[': TokenType.LBRACKET,
                ']': TokenType.RBRACKET,
                '{': TokenType.LBRACE,
                '}': TokenType.RBRACE,
                ',': TokenType.COMMA,
                ':': TokenType.COLON,
                '.': TokenType.DOT,
            }
            
            if char in single_char_ops:
                self.advance()
                self.tokens.append(Token(single_char_ops[char], char, start_line, start_col))
                continue
            
            self.error(f"Unexpected character: '{char}'")
        
        # Close any remaining indentation
        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self.tokens.append(Token(TokenType.DEDENT, 0, self.line, 1))
        
        self.tokens.append(Token(TokenType.EOF, None, self.line, self.column))
        return self.tokens


# ============================================================================
# PART 3: AST (Abstract Syntax Tree) NODES
# Defines the structure of parsed code
# ============================================================================

@dataclass
class ASTNode:
    """Base class for all AST nodes"""
    line: int = 0
    column: int = 0


@dataclass
class NumberNode(ASTNode):
    value: Union[int, float] = 0


@dataclass
class StringNode(ASTNode):
    value: str = ""


@dataclass
class BooleanNode(ASTNode):
    value: bool = False


@dataclass
class NullNode(ASTNode):
    pass


@dataclass
class IdentifierNode(ASTNode):
    name: str = ""


@dataclass
class ListNode(ASTNode):
    elements: List[ASTNode] = field(default_factory=list)


@dataclass
class IndexNode(ASTNode):
    obj: ASTNode = None
    index: ASTNode = None


@dataclass
class BinaryOpNode(ASTNode):
    left: ASTNode = None
    operator: str = ""
    right: ASTNode = None


@dataclass
class UnaryOpNode(ASTNode):
    operator: str = ""
    operand: ASTNode = None


@dataclass
class AssignNode(ASTNode):
    name: str = ""
    value: ASTNode = None
    is_const: bool = False


@dataclass
class CompoundAssignNode(ASTNode):
    name: str = ""
    operator: str = ""
    value: ASTNode = None


@dataclass
class IndexAssignNode(ASTNode):
    obj: ASTNode = None
    index: ASTNode = None
    value: ASTNode = None


@dataclass
class PrintNode(ASTNode):
    expressions: List[ASTNode] = field(default_factory=list)


@dataclass
class InputNode(ASTNode):
    prompt: Optional[ASTNode] = None


@dataclass
class IfNode(ASTNode):
    condition: ASTNode = None
    then_block: List[ASTNode] = field(default_factory=list)
    elif_blocks: List[tuple] = field(default_factory=list)
    else_block: List[ASTNode] = field(default_factory=list)


@dataclass
class WhileNode(ASTNode):
    condition: ASTNode = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class ForNode(ASTNode):
    variable: str = ""
    iterable: ASTNode = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class RangeNode(ASTNode):
    start: ASTNode = None
    end: ASTNode = None
    step: Optional[ASTNode] = None


@dataclass
class FunctionDefNode(ASTNode):
    name: str = ""
    params: List[str] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class FunctionCallNode(ASTNode):
    name: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class MethodCallNode(ASTNode):
    obj: ASTNode = None
    method: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class ReturnNode(ASTNode):
    value: Optional[ASTNode] = None


@dataclass
class BreakNode(ASTNode):
    pass


@dataclass
class ContinueNode(ASTNode):
    pass


@dataclass
class ProgramNode(ASTNode):
    statements: List[ASTNode] = field(default_factory=list)


# ============================================================================
# PART 4: PARSER
# Converts tokens into an Abstract Syntax Tree
# ============================================================================

class ParserError(Exception):
    """Exception raised for parser errors"""
    def __init__(self, message: str, token: Token):
        self.message = message
        self.token = token
        super().__init__(f"Parser Error at line {token.line}, column {token.column}: {message}")


class Parser:
    """Parses STRACT tokens into an AST"""
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
    
    def error(self, message: str):
        raise ParserError(message, self.current())
    
    def current(self) -> Token:
        if self.pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[self.pos]
    
    def peek(self, offset: int = 0) -> Token:
        pos = self.pos + offset
        if pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[pos]
    
    def advance(self) -> Token:
        token = self.current()
        self.pos += 1
        return token
    
    def match(self, *types: TokenType) -> bool:
        return self.current().type in types
    
    def expect(self, token_type: TokenType, message: str = None) -> Token:
        if self.current().type != token_type:
            msg = message or f"Expected {token_type.name}, got {self.current().type.name}"
            self.error(msg)
        return self.advance()
    
    def skip_newlines(self):
        while self.match(TokenType.NEWLINE):
            self.advance()
    
    def parse(self) -> ProgramNode:
        """Parse the entire program"""
        statements = []
        self.skip_newlines()
        
        while not self.match(TokenType.EOF):
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            self.skip_newlines()
        
        return ProgramNode(statements=statements)
    
    def parse_statement(self) -> Optional[ASTNode]:
        """Parse a single statement"""
        self.skip_newlines()
        
        token = self.current()
        
        if token.type == TokenType.LET:
            return self.parse_variable_declaration(is_const=False)
        elif token.type == TokenType.CONST:
            return self.parse_variable_declaration(is_const=True)
        elif token.type == TokenType.PRINT:
            return self.parse_print()
        elif token.type == TokenType.IF:
            return self.parse_if()
        elif token.type == TokenType.WHILE:
            return self.parse_while()
        elif token.type == TokenType.FOR:
            return self.parse_for()
        elif token.type == TokenType.FUNC:
            return self.parse_function_def()
        elif token.type == TokenType.RETURN:
            return self.parse_return()
        elif token.type == TokenType.BREAK:
            self.advance()
            return BreakNode(line=token.line, column=token.column)
        elif token.type == TokenType.CONTINUE:
            self.advance()
            return ContinueNode(line=token.line, column=token.column)
        elif token.type == TokenType.IDENTIFIER:
            return self.parse_identifier_statement()
        elif token.type in (TokenType.INDENT, TokenType.DEDENT):
            self.advance()
            return None
        else:
            return self.parse_expression()
    
    def parse_variable_declaration(self, is_const: bool) -> AssignNode:
        """Parse variable declaration: let x = value"""
        token = self.advance()  # consume let/const
        name_token = self.expect(TokenType.IDENTIFIER, "Expected variable name")
        self.expect(TokenType.ASSIGN, "Expected '=' after variable name")
        value = self.parse_expression()
        
        return AssignNode(
            name=name_token.value,
            value=value,
            is_const=is_const,
            line=token.line,
            column=token.column
        )
    
    def parse_identifier_statement(self) -> ASTNode:
        """Parse statement starting with identifier (assignment or expression)"""
        expr = self.parse_expression()
        
        # Check for assignment
        if self.match(TokenType.ASSIGN):
            self.advance()
            value = self.parse_expression()
            
            if isinstance(expr, IdentifierNode):
                return AssignNode(
                    name=expr.name,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            elif isinstance(expr, IndexNode):
                return IndexAssignNode(
                    obj=expr.obj,
                    index=expr.index,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            else:
                self.error("Invalid assignment target")
        
        # Check for compound assignment
        if self.match(TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN):
            op_token = self.advance()
            value = self.parse_expression()
            
            if isinstance(expr, IdentifierNode):
                return CompoundAssignNode(
                    name=expr.name,
                    operator='+=' if op_token.type == TokenType.PLUS_ASSIGN else '-=',
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
        
        return expr
    
    def parse_print(self) -> PrintNode:
        """Parse print statement"""
        token = self.advance()  # consume print
        
        expressions = []
        if not self.match(TokenType.NEWLINE, TokenType.EOF):
            expressions.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                self.advance()
                expressions.append(self.parse_expression())
        
        return PrintNode(expressions=expressions, line=token.line, column=token.column)
    
    def parse_if(self) -> IfNode:
        """Parse if/elif/else statement"""
        token = self.advance()  # consume if
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after if condition")
        
        then_block = self.parse_block()
        elif_blocks = []
        else_block = []
        
        self.skip_newlines()
        
        # Parse elif blocks
        while self.match(TokenType.ELIF):
            self.advance()
            elif_condition = self.parse_expression()
            self.expect(TokenType.COLON, "Expected ':' after elif condition")
            elif_body = self.parse_block()
            elif_blocks.append((elif_condition, elif_body))
            self.skip_newlines()
        
        # Parse else block
        if self.match(TokenType.ELSE):
            self.advance()
            self.expect(TokenType.COLON, "Expected ':' after else")
            else_block = self.parse_block()
        
        return IfNode(
            condition=condition,
            then_block=then_block,
            elif_blocks=elif_blocks,
            else_block=else_block,
            line=token.line,
            column=token.column
        )
    
    def parse_while(self) -> WhileNode:
        """Parse while loop"""
        token = self.advance()  # consume while
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after while condition")
        body = self.parse_block()
        
        return WhileNode(
            condition=condition,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_for(self) -> ForNode:
        """Parse for loop"""
        token = self.advance()  # consume for
        var_token = self.expect(TokenType.IDENTIFIER, "Expected variable name in for loop")
        self.expect(TokenType.IN, "Expected 'in' after variable in for loop")
        iterable = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after for loop declaration")
        body = self.parse_block()
        
        return ForNode(
            variable=var_token.value,
            iterable=iterable,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_function_def(self) -> FunctionDefNode:
        """Parse function definition"""
        token = self.advance()  # consume func
        name_token = self.expect(TokenType.IDENTIFIER, "Expected function name")
        self.expect(TokenType.LPAREN, "Expected '(' after function name")
        
        params = []
        if not self.match(TokenType.RPAREN):
            params.append(self.expect(TokenType.IDENTIFIER, "Expected parameter name").value)
            while self.match(TokenType.COMMA):
                self.advance()
                params.append(self.expect(TokenType.IDENTIFIER, "Expected parameter name").value)
        
        self.expect(TokenType.RPAREN, "Expected ')' after parameters")
        self.expect(TokenType.COLON, "Expected ':' after function declaration")
        body = self.parse_block()
        
        return FunctionDefNode(
            name=name_token.value,
            params=params,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_return(self) -> ReturnNode:
        """Parse return statement"""
        token = self.advance()  # consume return
        
        value = None
        if not self.match(TokenType.NEWLINE, TokenType.EOF, TokenType.DEDENT):
            value = self.parse_expression()
        
        return ReturnNode(value=value, line=token.line, column=token.column)
    
    def parse_block(self) -> List[ASTNode]:
        """Parse an indented block of statements"""
        statements = []
        self.skip_newlines()
        
        if self.match(TokenType.INDENT):
            self.advance()
            
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                stmt = self.parse_statement()
                if stmt:
                    statements.append(stmt)
                self.skip_newlines()
            
            if self.match(TokenType.DEDENT):
                self.advance()
        else:
            # Single-line block
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
        
        return statements
    
    def parse_expression(self) -> ASTNode:
        """Parse an expression (entry point)"""
        return self.parse_or()
    
    def parse_or(self) -> ASTNode:
        """Parse OR expression"""
        left = self.parse_and()
        
        while self.match(TokenType.OR):
            op = self.advance()
            right = self.parse_and()
            left = BinaryOpNode(left=left, operator='or', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_and(self) -> ASTNode:
        """Parse AND expression"""
        left = self.parse_not()
        
        while self.match(TokenType.AND):
            op = self.advance()
            right = self.parse_not()
            left = BinaryOpNode(left=left, operator='and', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_not(self) -> ASTNode:
        """Parse NOT expression"""
        if self.match(TokenType.NOT):
            op = self.advance()
            operand = self.parse_not()
            return UnaryOpNode(operator='not', operand=operand, line=op.line, column=op.column)
        
        return self.parse_comparison()
    
    def parse_comparison(self) -> ASTNode:
        """Parse comparison expression"""
        left = self.parse_additive()
        
        while self.match(TokenType.EQUAL, TokenType.NOT_EQUAL, TokenType.LESS,
                        TokenType.GREATER, TokenType.LESS_EQUAL, TokenType.GREATER_EQUAL):
            op = self.advance()
            right = self.parse_additive()
            op_str = {
                TokenType.EQUAL: '==',
                TokenType.NOT_EQUAL: '!=',
                TokenType.LESS: '<',
                TokenType.GREATER: '>',
                TokenType.LESS_EQUAL: '<=',
                TokenType.GREATER_EQUAL: '>=',
            }[op.type]
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_additive(self) -> ASTNode:
        """Parse addition/subtraction"""
        left = self.parse_multiplicative()
        
        while self.match(TokenType.PLUS, TokenType.MINUS):
            op = self.advance()
            right = self.parse_multiplicative()
            op_str = '+' if op.type == TokenType.PLUS else '-'
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_multiplicative(self) -> ASTNode:
        """Parse multiplication/division/modulo"""
        left = self.parse_power()
        
        while self.match(TokenType.MULTIPLY, TokenType.DIVIDE, TokenType.MODULO):
            op = self.advance()
            right = self.parse_power()
            op_str = {
                TokenType.MULTIPLY: '*',
                TokenType.DIVIDE: '/',
                TokenType.MODULO: '%',
            }[op.type]
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_power(self) -> ASTNode:
        """Parse power expression (right associative)"""
        left = self.parse_unary()
        
        if self.match(TokenType.POWER):
            op = self.advance()
            right = self.parse_power()  # Right associative
            left = BinaryOpNode(left=left, operator='**', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_unary(self) -> ASTNode:
        """Parse unary operators"""
        if self.match(TokenType.MINUS):
            op = self.advance()
            operand = self.parse_unary()
            return UnaryOpNode(operator='-', operand=operand, line=op.line, column=op.column)
        
        return self.parse_postfix()
    
    def parse_postfix(self) -> ASTNode:
        """Parse postfix operations (function calls, indexing, method calls)"""
        left = self.parse_primary()
        
        while True:
            if self.match(TokenType.LPAREN):
                # Function call
                self.advance()
                args = []
                if not self.match(TokenType.RPAREN):
                    args.append(self.parse_expression())
                    while self.match(TokenType.COMMA):
                        self.advance()
                        args.append(self.parse_expression())
                self.expect(TokenType.RPAREN, "Expected ')' after arguments")
                
                if isinstance(left, IdentifierNode):
                    left = FunctionCallNode(name=left.name, args=args, line=left.line, column=left.column)
                else:
                    self.error("Invalid function call")
            
            elif self.match(TokenType.LBRACKET):
                # Indexing
                self.advance()
                index = self.parse_expression()
                self.expect(TokenType.RBRACKET, "Expected ']' after index")
                left = IndexNode(obj=left, index=index, line=left.line, column=left.column)
            
            elif self.match(TokenType.DOT):
                # Method call
                self.advance()
                method_token = self.expect(TokenType.IDENTIFIER, "Expected method name")
                
                if self.match(TokenType.LPAREN):
                    self.advance()
                    args = []
                    if not self.match(TokenType.RPAREN):
                        args.append(self.parse_expression())
                        while self.match(TokenType.COMMA):
                            self.advance()
                            args.append(self.parse_expression())
                    self.expect(TokenType.RPAREN, "Expected ')' after method arguments")
                    left = MethodCallNode(obj=left, method=method_token.value, args=args, line=left.line, column=left.column)
                else:
                    # Property access (treated as method with no args for now)
                    left = MethodCallNode(obj=left, method=method_token.value, args=[], line=left.line, column=left.column)
            
            else:
                break
        
        return left
    
    def parse_primary(self) -> ASTNode:
        """Parse primary expressions"""
        token = self.current()
        
        if token.type == TokenType.INTEGER or token.type == TokenType.FLOAT:
            self.advance()
            return NumberNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.STRING:
            self.advance()
            return StringNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.BOOLEAN:
            self.advance()
            return BooleanNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.NULL:
            self.advance()
            return NullNode(line=token.line, column=token.column)
        
        elif token.type == TokenType.IDENTIFIER:
            self.advance()
            return IdentifierNode(name=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.RANGE:
            return self.parse_range()
        
        elif token.type == TokenType.INPUT:
            return self.parse_input()
        
        elif token.type == TokenType.LPAREN:
            self.advance()
            expr = self.parse_expression()
            self.expect(TokenType.RPAREN, "Expected ')' after expression")
            return expr
        
        elif token.type == TokenType.LBRACKET:
            return self.parse_list()
        
        else:
            self.error(f"Unexpected token: {token.type.name}")
    
    def parse_range(self) -> RangeNode:
        """Parse range expression: range(start, end) or range(start, end, step)"""
        token = self.advance()  # consume range
        self.expect(TokenType.LPAREN, "Expected '(' after range")
        
        start = self.parse_expression()
        self.expect(TokenType.COMMA, "Expected ',' in range")
        end = self.parse_expression()
        
        step = None
        if self.match(TokenType.COMMA):
            self.advance()
            step = self.parse_expression()
        
        self.expect(TokenType.RPAREN, "Expected ')' after range")
        
        return RangeNode(start=start, end=end, step=step, line=token.line, column=token.column)
    
    def parse_input(self) -> InputNode:
        """Parse input expression"""
        token = self.advance()  # consume input
        self.expect(TokenType.LPAREN, "Expected '(' after input")
        
        prompt = None
        if not self.match(TokenType.RPAREN):
            prompt = self.parse_expression()
        
        self.expect(TokenType.RPAREN, "Expected ')' after input")
        
        return InputNode(prompt=prompt, line=token.line, column=token.column)
    
    def parse_list(self) -> ListNode:
        """Parse list literal"""
        token = self.advance()  # consume [
        
        elements = []
        if not self.match(TokenType.RBRACKET):
            elements.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                self.advance()
                if self.match(TokenType.RBRACKET):
                    break
                elements.append(self.parse_expression())
        
        self.expect(TokenType.RBRACKET, "Expected ']' after list elements")
        
        return ListNode(elements=elements, line=token.line, column=token.column)


# ============================================================================
# PART 5: RUNTIME ENVIRONMENT
# Manages variables, scopes, and execution state
# ============================================================================

class RuntimeError(Exception):
    """Exception raised for runtime errors"""
    def __init__(self, message: str, line: int = 0, column: int = 0):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Runtime Error at line {line}: {message}")


class BreakException(Exception):
    """Control flow for break statements"""
    pass


class ContinueException(Exception):
    """Control flow for continue statements"""
    pass


class ReturnException(Exception):
    """Control flow for return statements"""
    def __init__(self, value: Any):
        self.value = value
        super().__init__()


class Environment:
    """Manages variable scopes"""
    
    def __init__(self, parent: Optional['Environment'] = None):
        self.variables: Dict[str, Any] = {}
        self.constants: set = set()
        self.parent = parent
    
    def define(self, name: str, value: Any, is_const: bool = False):
        """Define a new variable in current scope"""
        self.variables[name] = value
        if is_const:
            self.constants.add(name)
    
    def get(self, name: str) -> Any:
        """Get variable value, searching parent scopes"""
        if name in self.variables:
            return self.variables[name]
        if self.parent:
            return self.parent.get(name)
        raise RuntimeError(f"Undefined variable: '{name}'")
    
    def set(self, name: str, value: Any):
        """Set variable value, searching parent scopes"""
        if name in self.variables:
            if name in self.constants:
                raise RuntimeError(f"Cannot reassign constant: '{name}'")
            self.variables[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        raise RuntimeError(f"Undefined variable: '{name}'")
    
    def exists(self, name: str) -> bool:
        """Check if variable exists in any scope"""
        if name in self.variables:
            return True
        if self.parent:
            return self.parent.exists(name)
        return False


# ============================================================================
# PART 6: INTERPRETER (Evaluator)
# Executes the AST and produces results
# ============================================================================

class Interpreter:
    """Executes STRACT programs"""
    
    def __init__(self):
        self.global_env = Environment()
        self.functions: Dict[str, FunctionDefNode] = {}
        self.setup_builtins()
    
    def setup_builtins(self):
        """Setup built-in functions"""
        self.builtins = {
            'len': self.builtin_len,
            'str': self.builtin_str,
            'int': self.builtin_int,
            'float': self.builtin_float,
            'bool': self.builtin_bool,
            'type': self.builtin_type,
            'abs': self.builtin_abs,
            'min': self.builtin_min,
            'max': self.builtin_max,
            'sum': self.builtin_sum,
            'round': self.builtin_round,
            'list': self.builtin_list,
            'append': self.builtin_append,
            'pop': self.builtin_pop,
            'reverse': self.builtin_reverse,
            'sort': self.builtin_sort,
            'upper': self.builtin_upper,
            'lower': self.builtin_lower,
            'strip': self.builtin_strip,
            'split': self.builtin_split,
            'join': self.builtin_join,
            'replace': self.builtin_replace,
            'find': self.builtin_find,
            'contains': self.builtin_contains,
            'startswith': self.builtin_startswith,
            'endswith': self.builtin_endswith,
            'substring': self.builtin_substring,
        }
    
    # Built-in function implementations
    def builtin_len(self, args):
        if len(args) != 1:
            raise RuntimeError("len() takes exactly 1 argument")
        val = args[0]
        if isinstance(val, (list, str)):
            return len(val)
        raise RuntimeError(f"len() not supported for type {type(val).__name__}")
    
    def builtin_str(self, args):
        if len(args) != 1:
            raise RuntimeError("str() takes exactly 1 argument")
        return self.to_string(args[0])
    
    def builtin_int(self, args):
        if len(args) != 1:
            raise RuntimeError("int() takes exactly 1 argument")
        try:
            return int(float(args[0]))
        except:
            raise RuntimeError(f"Cannot convert {args[0]} to int")
    
    def builtin_float(self, args):
        if len(args) != 1:
            raise RuntimeError("float() takes exactly 1 argument")
        try:
            return float(args[0])
        except:
            raise RuntimeError(f"Cannot convert {args[0]} to float")
    
    def builtin_bool(self, args):
        if len(args) != 1:
            raise RuntimeError("bool() takes exactly 1 argument")
        return self.is_truthy(args[0])
    
    def builtin_type(self, args):
        if len(args) != 1:
            raise RuntimeError("type() takes exactly 1 argument")
        val = args[0]
        if isinstance(val, bool):
            return "boolean"
        elif isinstance(val, int):
            return "integer"
        elif isinstance(val, float):
            return "float"
        elif isinstance(val, str):
            return "string"
        elif isinstance(val, list):
            return "list"
        elif val is None:
            return "null"
        return "unknown"
    
    def builtin_abs(self, args):
        if len(args) != 1:
            raise RuntimeError("abs() takes exactly 1 argument")
        return abs(args[0])
    
    def builtin_min(self, args):
        if len(args) == 1 and isinstance(args[0], list):
            return min(args[0])
        return min(args)
    
    def builtin_max(self, args):
        if len(args) == 1 and isinstance(args[0], list):
            return max(args[0])
        return max(args)
    
    def builtin_sum(self, args):
        if len(args) != 1:
            raise RuntimeError("sum() takes exactly 1 argument (a list)")
        if not isinstance(args[0], list):
            raise RuntimeError("sum() requires a list argument")
        return sum(args[0])
    
    def builtin_round(self, args):
        if len(args) == 1:
            return round(args[0])
        elif len(args) == 2:
            return round(args[0], int(args[1]))
        raise RuntimeError("round() takes 1 or 2 arguments")
    
    def builtin_list(self, args):
        if len(args) == 0:
            return []
        if len(args) == 1:
            val = args[0]
            if isinstance(val, str):
                return list(val)
            if isinstance(val, list):
                return val.copy()
        return list(args)
    
    def builtin_append(self, args):
        if len(args) != 2:
            raise RuntimeError("append() takes exactly 2 arguments (list, item)")
        lst, item = args
        if not isinstance(lst, list):
            raise RuntimeError("First argument to append() must be a list")
        lst.append(item)
        return lst
    
    def builtin_pop(self, args):
        if len(args) < 1 or len(args) > 2:
            raise RuntimeError("pop() takes 1 or 2 arguments")
        lst = args[0]
        if not isinstance(lst, list):
            raise RuntimeError("First argument to pop() must be a list")
        if len(args) == 2:
            return lst.pop(int(args[1]))
        return lst.pop()
    
    def builtin_reverse(self, args):
        if len(args) != 1:
            raise RuntimeError("reverse() takes exactly 1 argument")
        val = args[0]
        if isinstance(val, list):
            return val[::-1]
        if isinstance(val, str):
            return val[::-1]
        raise RuntimeError("reverse() requires a list or string")
    
    def builtin_sort(self, args):
        if len(args) != 1:
            raise RuntimeError("sort() takes exactly 1 argument")
        if not isinstance(args[0], list):
            raise RuntimeError("sort() requires a list argument")
        return sorted(args[0])
    
    def builtin_upper(self, args):
        if len(args) != 1:
            raise RuntimeError("upper() takes exactly 1 argument")
        return str(args[0]).upper()
    
    def builtin_lower(self, args):
        if len(args) != 1:
            raise RuntimeError("lower() takes exactly 1 argument")
        return str(args[0]).lower()
    
    def builtin_strip(self, args):
        if len(args) != 1:
            raise RuntimeError("strip() takes exactly 1 argument")
        return str(args[0]).strip()
    
    def builtin_split(self, args):
        if len(args) == 1:
            return str(args[0]).split()
        elif len(args) == 2:
            return str(args[0]).split(str(args[1]))
        raise RuntimeError("split() takes 1 or 2 arguments")
    
    def builtin_join(self, args):
        if len(args) != 2:
            raise RuntimeError("join() takes exactly 2 arguments (separator, list)")
        sep, lst = args
        if not isinstance(lst, list):
            raise RuntimeError("Second argument to join() must be a list")
        return str(sep).join(str(x) for x in lst)
    
    def builtin_replace(self, args):
        if len(args) != 3:
            raise RuntimeError("replace() takes exactly 3 arguments (string, old, new)")
        return str(args[0]).replace(str(args[1]), str(args[2]))
    
    def builtin_find(self, args):
        if len(args) != 2:
            raise RuntimeError("find() takes exactly 2 arguments (string, substring)")
        return str(args[0]).find(str(args[1]))
    
    def builtin_contains(self, args):
        if len(args) != 2:
            raise RuntimeError("contains() takes exactly 2 arguments")
        container, item = args
        if isinstance(container, (list, str)):
            return item in container
        raise RuntimeError("First argument to contains() must be list or string")
    
    def builtin_startswith(self, args):
        if len(args) != 2:
            raise RuntimeError("startswith() takes exactly 2 arguments")
        return str(args[0]).startswith(str(args[1]))
    
    def builtin_endswith(self, args):
        if len(args) != 2:
            raise RuntimeError("endswith() takes exactly 2 arguments")
        return str(args[0]).endswith(str(args[1]))
    
    def builtin_substring(self, args):
        if len(args) < 2 or len(args) > 3:
            raise RuntimeError("substring() takes 2 or 3 arguments (string, start, [end])")
        s = str(args[0])
        start = int(args[1])
        if len(args) == 3:
            end = int(args[2])
            return s[start:end]
        return s[start:]
    
    def to_string(self, value: Any) -> str:
        """Convert value to string representation"""
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, list):
            return "[" + ", ".join(self.to_string(x) for x in value) + "]"
        return str(value)
    
    def is_truthy(self, value: Any) -> bool:
        """Determine truthiness of a value"""
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, str):
            return len(value) > 0
        if isinstance(value, list):
            return len(value) > 0
        return True
    
    def execute(self, node: ASTNode, env: Environment = None) -> Any:
        """Execute an AST node"""
        if env is None:
            env = self.global_env
        
        method_name = f"execute_{type(node).__name__}"
        executor = getattr(self, method_name, None)
        
        if executor is None:
            raise RuntimeError(f"Unknown node type: {type(node).__name__}", node.line, node.column)
        
        try:
            return executor(node, env)
        except (RuntimeError, ReturnException, BreakException, ContinueException):
            raise
        except Exception as e:
            raise RuntimeError(str(e), node.line, node.column)
    
    def execute_ProgramNode(self, node: ProgramNode, env: Environment) -> Any:
        result = None
        for stmt in node.statements:
            result = self.execute(stmt, env)
        return result
    
    def execute_NumberNode(self, node: NumberNode, env: Environment) -> Union[int, float]:
        return node.value
    
    def execute_StringNode(self, node: StringNode, env: Environment) -> str:
        return node.value
    
    def execute_BooleanNode(self, node: BooleanNode, env: Environment) -> bool:
        return node.value
    
    def execute_NullNode(self, node: NullNode, env: Environment) -> None:
        return None
    
    def execute_IdentifierNode(self, node: IdentifierNode, env: Environment) -> Any:
        try:
            return env.get(node.name)
        except RuntimeError as e:
            raise RuntimeError(e.message, node.line, node.column)
    
    def execute_ListNode(self, node: ListNode, env: Environment) -> list:
        return [self.execute(elem, env) for elem in node.elements]
    
    def execute_IndexNode(self, node: IndexNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        index = self.execute(node.index, env)
        
        if isinstance(obj, (list, str)):
            try:
                return obj[int(index)]
            except IndexError:
                raise RuntimeError(f"Index {index} out of range", node.line, node.column)
        
        raise RuntimeError("Cannot index non-list/string value", node.line, node.column)
    
    def execute_BinaryOpNode(self, node: BinaryOpNode, env: Environment) -> Any:
        left = self.execute(node.left, env)
        
        # Short-circuit evaluation for logical operators
        if node.operator == 'and':
            if not self.is_truthy(left):
                return left
            return self.execute(node.right, env)
        
        if node.operator == 'or':
            if self.is_truthy(left):
                return left
            return self.execute(node.right, env)
        
        right = self.execute(node.right, env)
        
        # Arithmetic operators
        if node.operator == '+':
            if isinstance(left, str) or isinstance(right, str):
                return self.to_string(left) + self.to_string(right)
            if isinstance(left, list) and isinstance(right, list):
                return left + right
            return left + right
        elif node.operator == '-':
            return left - right
        elif node.operator == '*':
            if isinstance(left, str) and isinstance(right, int):
                return left * right
            if isinstance(left, list) and isinstance(right, int):
                return left * right
            return left * right
        elif node.operator == '/':
            if right == 0:
                raise RuntimeError("Division by zero", node.line, node.column)
            return left / right
        elif node.operator == '%':
            if right == 0:
                raise RuntimeError("Modulo by zero", node.line, node.column)
            return left % right
        elif node.operator == '**':
            return left ** right
        
        # Comparison operators
        elif node.operator == '==':
            return left == right
        elif node.operator == '!=':
            return left != right
        elif node.operator == '<':
            return left < right
        elif node.operator == '>':
            return left > right
        elif node.operator == '<=':
            return left <= right
        elif node.operator == '>=':
            return left >= right
        
        raise RuntimeError(f"Unknown operator: {node.operator}", node.line, node.column)
    
    def execute_UnaryOpNode(self, node: UnaryOpNode, env: Environment) -> Any:
        operand = self.execute(node.operand, env)
        
        if node.operator == '-':
            return -operand
        elif node.operator == 'not':
            return not self.is_truthy(operand)
        
        raise RuntimeError(f"Unknown unary operator: {node.operator}", node.line, node.column)
    
    def execute_AssignNode(self, node: AssignNode, env: Environment) -> Any:
        value = self.execute(node.value, env)
        
        if env.exists(node.name):
            env.set(node.name, value)
        else:
            env.define(node.name, value, node.is_const)
        
        return value
    
    def execute_CompoundAssignNode(self, node: CompoundAssignNode, env: Environment) -> Any:
        current = env.get(node.name)
        value = self.execute(node.value, env)
        
        if node.operator == '+=':
            if isinstance(current, str):
                new_value = current + self.to_string(value)
            elif isinstance(current, list):
                new_value = current + [value]
            else:
                new_value = current + value
        elif node.operator == '-=':
            new_value = current - value
        else:
            raise RuntimeError(f"Unknown compound operator: {node.operator}", node.line, node.column)
        
        env.set(node.name, new_value)
        return new_value
    
    def execute_IndexAssignNode(self, node: IndexAssignNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        index = self.execute(node.index, env)
        value = self.execute(node.value, env)
        
        if isinstance(obj, list):
            try:
                obj[int(index)] = value
                return value
            except IndexError:
                raise RuntimeError(f"Index {index} out of range", node.line, node.column)
        
        raise RuntimeError("Cannot index assign to non-list value", node.line, node.column)
    
    def execute_PrintNode(self, node: PrintNode, env: Environment) -> None:
        values = [self.to_string(self.execute(expr, env)) for expr in node.expressions]
        print(" ".join(values))
    
    def execute_InputNode(self, node: InputNode, env: Environment) -> str:
        prompt = ""
        if node.prompt:
            prompt = self.to_string(self.execute(node.prompt, env))
        return input(prompt)
    
    def execute_IfNode(self, node: IfNode, env: Environment) -> Any:
        condition = self.execute(node.condition, env)
        
        if self.is_truthy(condition):
            result = None
            for stmt in node.then_block:
                result = self.execute(stmt, env)
            return result
        
        for elif_condition, elif_body in node.elif_blocks:
            if self.is_truthy(self.execute(elif_condition, env)):
                result = None
                for stmt in elif_body:
                    result = self.execute(stmt, env)
                return result
        
        if node.else_block:
            result = None
            for stmt in node.else_block:
                result = self.execute(stmt, env)
            return result
        
        return None
    
    def execute_WhileNode(self, node: WhileNode, env: Environment) -> Any:
        result = None
        while self.is_truthy(self.execute(node.condition, env)):
            try:
                for stmt in node.body:
                    result = self.execute(stmt, env)
            except BreakException:
                break
            except ContinueException:
                continue
        return result
    
    def execute_ForNode(self, node: ForNode, env: Environment) -> Any:
        iterable = self.execute(node.iterable, env)
        result = None
        
        if isinstance(iterable, range):
            iterable = list(iterable)
        
        if not isinstance(iterable, (list, str)):
            raise RuntimeError("For loop requires an iterable (list, string, or range)", node.line, node.column)
        
        for item in iterable:
            env.define(node.variable, item)
            try:
                for stmt in node.body:
                    result = self.execute(stmt, env)
            except BreakException:
                break
            except ContinueException:
                continue
        
        return result
    
    def execute_RangeNode(self, node: RangeNode, env: Environment) -> range:
        start = int(self.execute(node.start, env))
        end = int(self.execute(node.end, env))
        
        if node.step:
            step = int(self.execute(node.step, env))
            return range(start, end, step)
        
        return range(start, end)
    
    def execute_FunctionDefNode(self, node: FunctionDefNode, env: Environment) -> None:
        self.functions[node.name] = node
    
    def execute_FunctionCallNode(self, node: FunctionCallNode, env: Environment) -> Any:
        # Check for built-in functions
        if node.name in self.builtins:
            args = [self.execute(arg, env) for arg in node.args]
            return self.builtins[node.name](args)
        
        # Check for user-defined functions
        if node.name not in self.functions:
            raise RuntimeError(f"Undefined function: '{node.name}'", node.line, node.column)
        
        func = self.functions[node.name]
        
        if len(node.args) != len(func.params):
            raise RuntimeError(
                f"Function '{node.name}' expects {len(func.params)} arguments, got {len(node.args)}",
                node.line, node.column
            )
        
        # Create new environment for function
        func_env = Environment(self.global_env)
        
        # Bind arguments to parameters
        for param, arg in zip(func.params, node.args):
            value = self.execute(arg, env)
            func_env.define(param, value)
        
        # Execute function body
        try:
            for stmt in func.body:
                self.execute(stmt, func_env)
        except ReturnException as ret:
            return ret.value
        
        return None
    
    def execute_MethodCallNode(self, node: MethodCallNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        args = [self.execute(arg, env) for arg in node.args]
        
        # String methods
        if isinstance(obj, str):
            if node.method == 'upper':
                return obj.upper()
            elif node.method == 'lower':
                return obj.lower()
            elif node.method == 'strip':
                return obj.strip()
            elif node.method == 'split':
                return obj.split() if not args else obj.split(args[0])
            elif node.method == 'replace':
                if len(args) != 2:
                    raise RuntimeError("replace() requires 2 arguments", node.line, node.column)
                return obj.replace(args[0], args[1])
            elif node.method == 'find':
                if len(args) != 1:
                    raise RuntimeError("find() requires 1 argument", node.line, node.column)
                return obj.find(args[0])
            elif node.method == 'startswith':
                if len(args) != 1:
                    raise RuntimeError("startswith() requires 1 argument", node.line, node.column)
                return obj.startswith(args[0])
            elif node.method == 'endswith':
                if len(args) != 1:
                    raise RuntimeError("endswith() requires 1 argument", node.line, node.column)
                return obj.endswith(args[0])
            elif node.method == 'length' or node.method == 'len':
                return len(obj)
            elif node.method == 'reverse':
                return obj[::-1]
            elif node.method == 'contains':
                if len(args) != 1:
                    raise RuntimeError("contains() requires 1 argument", node.line, node.column)
                return args[0] in obj
        
        # List methods
        elif isinstance(obj, list):
            if node.method == 'append':
                if len(args) != 1:
                    raise RuntimeError("append() requires 1 argument", node.line, node.column)
                obj.append(args[0])
                return obj
            elif node.method == 'pop':
                if len(args) == 0:
                    return obj.pop()
                return obj.pop(int(args[0]))
            elif node.method == 'length' or node.method == 'len':
                return len(obj)
            elif node.method == 'reverse':
                return obj[::-1]
            elif node.method == 'sort':
                return sorted(obj)
            elif node.method == 'contains':
                if len(args) != 1:
                    raise RuntimeError("contains() requires 1 argument", node.line, node.column)
                return args[0] in obj
            elif node.method == 'join':
                if len(args) != 1:
                    raise RuntimeError("join() requires 1 argument (separator)", node.line, node.column)
                return str(args[0]).join(str(x) for x in obj)
            elif node.method == 'first':
                return obj[0] if obj else None
            elif node.method == 'last':
                return obj[-1] if obj else None
            elif node.method == 'sum':
                return sum(obj)
            elif node.method == 'min':
                return min(obj)
            elif node.method == 'max':
                return max(obj)
        
        raise RuntimeError(f"Unknown method '{node.method}' for type {type(obj).__name__}", node.line, node.column)
    
    def execute_ReturnNode(self, node: ReturnNode, env: Environment) -> None:
        value = None
        if node.value:
            value = self.execute(node.value, env)
        raise ReturnException(value)
    
    def execute_BreakNode(self, node: BreakNode, env: Environment) -> None:
        raise BreakException()
    
    def execute_ContinueNode(self, node: ContinueNode, env: Environment) -> None:
        raise ContinueException()


# ============================================================================
# PART 7: STRACT INTERPRETER FACADE
# Main interface for running STRACT code
# ============================================================================

class STRACT:
    """Main STRACT interpreter class"""
    
    VERSION = "2.0.0"
    
    def __init__(self):
        self.interpreter = Interpreter()
    
    def run_source(self, source: str) -> Any:
        """Execute STRACT source code"""
        try:
            lexer = Lexer(source)
            tokens = lexer.tokenize()
            
            parser = Parser(tokens)
            ast = parser.parse()
            
            return self.interpreter.execute(ast)
        
        except (LexerError, ParserError, RuntimeError) as e:
            print(f"\n{'='*50}")
            print(f"STRACT Error: {e}")
            print(f"{'='*50}\n")
            return None
    
    def run_file(self, filename: str) -> Any:
        """Execute STRACT code from a file"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                source = f.read()
            return self.run_source(source)
        except FileNotFoundError:
            print(f"Error: File not found: {filename}")
            return None
        except Exception as e:
            print(f"Error reading file: {e}")
            return None
    
    def repl(self):
        """Interactive REPL mode"""
        print(f"""
╔══════════════════════════════════════════════════════════════════╗
║     ███████╗████████╗██████╗  █████╗  ██████╗████████╗           ║
║     ██╔════╝╚══██╔══╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝           ║
║     ███████╗   ██║   ██████╔╝███████║██║        ██║              ║
║     ╚════██║   ██║   ██╔══██╗██╔══██║██║        ██║              ║
║     ███████║   ██║   ██║  ██║██║  ██║╚██████╗   ██║              ║
║     ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝   ╚═╝              ║
╠══════════════════════════════════════════════════════════════════╣
║  STRACT Programming Language v{self.VERSION}                            ║
║  A Modern Language for 2027 and Beyond                          ║
║  Type 'help' for commands, 'exit' to quit                        ║
╚══════════════════════════════════════════════════════════════════╝
""")
        
        multiline_buffer = []
        in_block = False
        
        while True:
            try:
                prompt = "... " if in_block else ">>> "
                line = input(prompt)
                
                # Handle special commands
                if line.strip().lower() == 'exit' and not in_block:
                    print("Goodbye! Thanks for using STRACT.")
                    break
                
                if line.strip().lower() == 'help' and not in_block:
                    self.show_help()
                    continue
                
                if line.strip().lower() == 'examples' and not in_block:
                    self.show_examples()
                    continue
                
                if line.strip().lower() == 'clear' and not in_block:
                    self.interpreter = Interpreter()
                    print("Environment cleared.")
                    continue
                
                # Handle multi-line input
                if line.endswith(':') or in_block:
                    multiline_buffer.append(line)
                    if line.endswith(':'):
                        in_block = True
                    elif line.strip() == '' and in_block:
                        # Empty line ends block
                        source = '\n'.join(multiline_buffer)
                        multiline_buffer = []
                        in_block = False
                        self.run_source(source)
                    continue
                
                # Single line execution
                if line.strip():
                    self.run_source(line)
            
            except EOFError:
                print("\nGoodbye!")
                break
            except KeyboardInterrupt:
                print("\nUse 'exit' to quit.")
                multiline_buffer = []
                in_block = False
    
    def show_help(self):
        """Show help information"""
        print("""
STRACT Language Commands:
─────────────────────────────────────────────────────────────────

  VARIABLES:
    let x = 10              # Create variable
    const PI = 3.14         # Create constant
    x = 20                  # Reassign variable

  DATA TYPES:
    42, 3.14                # Numbers (integer, float)
    "hello", 'world'        # Strings
    true, false             # Booleans
    null                    # Null value
    [1, 2, 3]               # Lists

  OPERATORS:
    +, -, *, /, %, **       # Arithmetic
    ==, !=, <, >, <=, >=    # Comparison
    and, or, not            # Logical

  CONTROL FLOW:
    if condition:           # Conditionals
    elif condition:
    else:

    while condition:        # While loop
    for i in range(0, 10):  # For loop
    break, continue         # Loop control

  FUNCTIONS:
    func name(arg1, arg2):  # Define function
        return value

  BUILT-IN FUNCTIONS:
    print(value)            # Output
    input("prompt")         # Input
    len(list/string)        # Length
    str(), int(), float()   # Type conversion
    type(value)             # Get type
    abs(), min(), max()     # Math functions
    sum(), round()          # More math
    
  STRING METHODS:
    .upper(), .lower()      # Case conversion
    .strip(), .split()      # String manipulation
    .replace(old, new)      # Replace text
    .find(substring)        # Find position
    .startswith(), .endswith()

  LIST METHODS:
    .append(item)           # Add item
    .pop([index])           # Remove item
    .reverse(), .sort()     # Modify list
    .first(), .last()       # Access elements
    .sum(), .min(), .max()  # Aggregations

REPL Commands:
─────────────────────────────────────────────────────────────────
    help     - Show this help
    examples - Show example programs
    clear    - Clear all variables
    exit     - Exit STRACT
""")
    
    def show_examples(self):
        """Show example programs"""
        print("""
STRACT Example Programs:
═════════════════════════════════════════════════════════════════

1. Variables and Print:
────────────────────────
let name = "STRACT"
let version = 2.0
let is_modern = true
print "Welcome to", name, "v" + str(version)
print "Modern:", is_modern

2. Arithmetic:
────────────────────────
let a = 10
let b = 3
print "Addition:", a + b
print "Power:", a ** b
print "Modulo:", a % b

3. Functions:
────────────────────────
func factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

print "5! =", factorial(5)

4. Loops:
────────────────────────
for i in range(1, 6):
    print "Count:", i

let sum = 0
let n = 1
while n <= 10:
    sum += n
    n += 1
print "Sum 1-10:", sum

5. Lists:
────────────────────────
let numbers = [1, 2, 3, 4, 5]
numbers.append(6)
print "List:", numbers
print "Sum:", numbers.sum()
print "Max:", numbers.max()
print "Reversed:", numbers.reverse()

6. Strings:
────────────────────────
let text = "  Hello STRACT World  "
print "Original:", text
print "Stripped:", text.strip()
print "Upper:", text.upper()
print "Words:", text.strip().split()

7. Conditionals:
────────────────────────
let score = 85
if score >= 90:
    print "Grade: A"
elif score >= 80:
    print "Grade: B"
elif score >= 70:
    print "Grade: C"
else:
    print "Grade: F"

═════════════════════════════════════════════════════════════════
""")


# ============================================================================
# PART 8: MAIN ENTRY POINT
# ============================================================================

def main():
    """Main entry point"""
    stract = STRACT()
    
    # Check for command line arguments
    if len(sys.argv) > 1:
        filename = sys.argv[1]
        if filename.endswith('.stract') or filename.endswith('.st'):
            stract.run_file(filename)
        else:
            print(f"Warning: Running non-standard file extension: {filename}")
            stract.run_file(filename)
    else:
        # Run interactive REPL
        stract.repl()
# ============================================================================
# CLI ENHANCEMENTS - تحسينات واجهة سطر الأوامر
# ============================================================================

def cli_main():
    """CLI entry point for installed version"""
    stract = STRACT()
    
    if len(sys.argv) == 1:
        # REPL mode
        stract.repl()
    elif len(sys.argv) == 2:
        # File execution
        filename = sys.argv[1]
        stract.run_file(filename)
    else:
        print("Usage: stract [filename]")

# جعل الملف قابلاً للاستيراد والتنفيذ
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--cli":
        # وضع CLI عند التثبيت
        cli_main()
    else:
        # الوضع العادي
        main()

if __name__ == "__main__":
    main()
