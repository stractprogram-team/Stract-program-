#!/usr/bin/env python3
"""
AI Integration for STRACT Programming Language v3.0
Advanced AI-powered code analysis, suggestions, and auto-completion
"""

import re
import sys
import os
from typing import List, Dict, Any, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class STRACTAI:
    """AI-powered features for STRACT language"""
    
    def __init__(self):
        self.code_patterns = {
            'loop': r'(for\s+\w+\s+in|while\s+)',
            'conditional': r'if\s+.+:',
            'function': r'func\s+\w+\s*\(',
            'class': r'class\s+\w+',
            'lambda': r'lambda\s+',
            'try': r'try\s*:',
            'import': r'import\s+\w+',
        }
        
        self.complexity_weights = {
            'loop': 2,
            'conditional': 1,
            'function': 3,
            'class': 5,
            'lambda': 2,
            'try': 2,
            'import': 1,
        }
    
    def analyze_code(self, code: str) -> Dict[str, Any]:
        """Comprehensive code analysis with AI insights"""
        lines = code.split('\n')
        non_empty_lines = [l for l in lines if l.strip() and not l.strip().startswith('#')]
        
        constructs = {}
        for name, pattern in self.code_patterns.items():
            constructs[name] = len(re.findall(pattern, code))
        
        complexity_score = sum(
            constructs[name] * self.complexity_weights[name]
            for name in constructs
        )
        
        if complexity_score >= 20:
            complexity = 'high'
        elif complexity_score >= 10:
            complexity = 'medium'
        else:
            complexity = 'low'
        
        analysis = {
            'total_lines': len(lines),
            'code_lines': len(non_empty_lines),
            'blank_lines': len(lines) - len(non_empty_lines),
            'comment_lines': len([l for l in lines if l.strip().startswith('#')]),
            'constructs': constructs,
            'complexity': complexity,
            'complexity_score': complexity_score,
            'suggestions': self._generate_suggestions(code, constructs),
            'potential_issues': self._find_issues(code),
            'optimization_opportunities': self._find_optimizations(code),
            'code_quality_score': self._calculate_quality_score(code, constructs),
        }
        
        return analysis
    
    def _generate_suggestions(self, code: str, constructs: Dict[str, int]) -> List[str]:
        """Generate intelligent suggestions based on code analysis"""
        suggestions = []
        
        if constructs['function'] == 0 and len(code.split('\n')) > 20:
            suggestions.append("Consider organizing code into functions for better maintainability")
        
        if constructs['loop'] > 5:
            suggestions.append("Multiple loops detected - consider using list comprehensions or map/filter")
        
        if constructs['conditional'] > 10:
            suggestions.append("Complex conditional logic - consider using pattern matching (match/case)")
        
        if constructs['class'] == 0 and constructs['function'] > 10:
            suggestions.append("Many functions detected - consider grouping related functions into classes")
        
        if 'global' in code.lower():
            suggestions.append("Avoid using global variables - consider passing values as parameters")
        
        if code.count('print') > 10:
            suggestions.append("Multiple print statements - consider using logging for better control")
        
        return suggestions
    
    def _find_issues(self, code: str) -> List[Dict[str, Any]]:
        """Find potential issues in the code"""
        issues = []
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            
            if '= =' in line:
                issues.append({
                    'line': i,
                    'message': "Possible typo: '= =' should be '==' for comparison",
                    'severity': 'warning'
                })
            
            if '/ 0' in line or '/0' in line:
                issues.append({
                    'line': i,
                    'message': "Possible division by zero",
                    'severity': 'error'
                })
            
            if 'input(' in line and 'int(' not in line and 'float(' not in line:
                if any(op in line for op in ['+', '-', '*', '/', '%']):
                    issues.append({
                        'line': i,
                        'message': "Input used in arithmetic - remember to convert with int() or float()",
                        'severity': 'warning'
                    })
            
            if len(line) > 120:
                issues.append({
                    'line': i,
                    'message': f"Line too long ({len(line)} chars) - consider breaking it up",
                    'severity': 'info'
                })
            
            if stripped.startswith('if ') or stripped.startswith('elif '):
                if '=' in stripped and '==' not in stripped and '!=' not in stripped:
                    if '<=' not in stripped and '>=' not in stripped:
                        issues.append({
                            'line': i,
                            'message': "Assignment in conditional - did you mean '=='?",
                            'severity': 'warning'
                        })
        
        return issues
    
    def _find_optimizations(self, code: str) -> List[str]:
        """Find optimization opportunities"""
        optimizations = []
        
        if re.search(r'for\s+\w+\s+in\s+range\(0,\s*len\(', code):
            optimizations.append("Use direct iteration: 'for item in list:' instead of 'for i in range(len(list)):'")
        
        if re.search(r'\+ "" \+|\+ \'\' \+', code):
            optimizations.append("Use f-strings or format() for string concatenation")
        
        if '== true' in code.lower() or '== false' in code.lower():
            optimizations.append("Use direct boolean: 'if flag:' instead of 'if flag == true:'")
        
        if re.search(r'let\s+\w+\s*=\s*\[\]\s*\n.*for.*append', code, re.DOTALL):
            optimizations.append("Consider using list comprehension or map() instead of loop with append")
        
        if code.count('if ') > 5 and 'match' not in code:
            optimizations.append("Multiple if statements - consider using match/case for cleaner code")
        
        return optimizations
    
    def _calculate_quality_score(self, code: str, constructs: Dict[str, int]) -> int:
        """Calculate a code quality score (0-100)"""
        score = 100
        lines = code.split('\n')
        non_empty = [l for l in lines if l.strip()]
        
        comment_ratio = len([l for l in lines if l.strip().startswith('#')]) / max(len(non_empty), 1)
        if comment_ratio < 0.1:
            score -= 10
        
        if constructs['function'] == 0 and len(non_empty) > 30:
            score -= 15
        
        for line in lines:
            if len(line) > 100:
                score -= 2
        
        long_functions = len(re.findall(r'func\s+\w+.*?(?=func|\Z)', code, re.DOTALL))
        if long_functions > 0:
            avg_function_lines = len(non_empty) / long_functions
            if avg_function_lines > 50:
                score -= 10
        
        return max(0, min(100, score))
    
    def explain_error(self, error_message: str, code: str = "") -> str:
        """Provide AI-powered error explanations"""
        explanations = {
            'Undefined variable': {
                'explanation': "You're trying to use a variable that hasn't been defined.",
                'suggestion': "Use 'let' or 'const' to define variables before using them.",
                'example': "let x = 10  # Define variable first\nprint x     # Then use it"
            },
            'Division by zero': {
                'explanation': "You're trying to divide by zero, which is mathematically undefined.",
                'suggestion': "Check if the denominator is zero before dividing.",
                'example': "if divisor != 0:\n    result = value / divisor"
            },
            'Index out of range': {
                'explanation': "You're trying to access an element that doesn't exist in the list.",
                'suggestion': "Check the list length before accessing elements.",
                'example': "if index < len(list):\n    value = list[index]"
            },
            'Cannot index': {
                'explanation': "You're trying to use indexing on a type that doesn't support it.",
                'suggestion': "Only lists, strings, and dictionaries can be indexed.",
                'example': "let list = [1, 2, 3]\nlet first = list[0]  # This works"
            },
            'Missing colon': {
                'explanation': "Control structures and function definitions need a colon at the end.",
                'suggestion': "Add ':' at the end of if, for, while, func, and class statements.",
                'example': "if condition:  # Add colon here\n    print 'yes'"
            },
            'Unexpected token': {
                'explanation': "The parser found something it didn't expect.",
                'suggestion': "Check for typos, missing operators, or incorrect syntax.",
                'example': "let x = 10  # Correct\nlet = 10    # Wrong - missing variable name"
            },
        }
        
        for key, info in explanations.items():
            if key.lower() in error_message.lower():
                result = f"\n📚 Explanation: {info['explanation']}\n"
                result += f"💡 Suggestion: {info['suggestion']}\n"
                result += f"📝 Example:\n{info['example']}\n"
                return result
        
        return f"\n🔍 Error: {error_message}\n💡 Check your syntax and variable names.\n"
    
    def generate_code(self, description: str) -> str:
        """Generate STRACT code from natural language description"""
        templates = {
            'loop': '''# Loop from 1 to n
for i in range(1, n + 1):
    print i''',
            
            'function': '''# Function definition
func function_name(param1, param2):
    # Function body
    let result = param1 + param2
    return result''',
            
            'class': '''# Class definition
class ClassName:
    func init(value):
        this.value = value
    
    func get_value():
        return this.value
    
    func set_value(new_value):
        this.value = new_value''',
            
            'list': '''# List operations
let items = [1, 2, 3, 4, 5]
let doubled = items.map(lambda x: x * 2)
let evens = items.filter(lambda x: x % 2 == 0)
let total = items.sum()''',
            
            'dictionary': '''# Dictionary operations
let data = {"name": "Alice", "age": 30}
print data.keys()
print data.values()
let name = data.get("name")''',
            
            'error_handling': '''# Error handling
try:
    let result = risky_operation()
catch error:
    print "Error:", error
finally:
    print "Cleanup"''',
            
            'pattern_matching': '''# Pattern matching
match value:
    case 1:
        print "One"
    case 2:
        print "Two"
    default:
        print "Other"''',
        }
        
        desc_lower = description.lower()
        for key, template in templates.items():
            if key in desc_lower:
                return template
        
        return f"# TODO: Implement {description}\npass"
    
    def suggest_completion(self, code: str, position: int) -> List[str]:
        """Provide intelligent auto-completion suggestions"""
        line_start = code.rfind('\n', 0, position) + 1
        current_line = code[line_start:position]
        current_word = re.split(r'[\s\(\)\[\]\{\}\,\.\=\+\-\*\/]', current_line)[-1]
        
        suggestions = []
        
        keywords = [
            'let', 'const', 'var', 'if', 'elif', 'else', 'for', 'while',
            'func', 'return', 'break', 'continue', 'class', 'new', 'this',
            'try', 'catch', 'finally', 'throw', 'import', 'from', 'as',
            'lambda', 'match', 'case', 'default', 'in', 'and', 'or', 'not',
            'true', 'false', 'null', 'print', 'input', 'range'
        ]
        
        builtins = [
            'len', 'str', 'int', 'float', 'bool', 'type', 'abs', 'min', 'max',
            'sum', 'round', 'sorted', 'reversed', 'list', 'dict', 'set', 'tuple',
            'enumerate', 'zip', 'map', 'filter', 'reduce', 'any', 'all',
            'chr', 'ord', 'hex', 'bin', 'oct', 'pow', 'sqrt', 'sin', 'cos',
            'tan', 'log', 'exp', 'floor', 'ceil', 'random', 'choice', 'shuffle',
            'time', 'sleep', 'keys', 'values', 'items', 'append', 'pop',
            'insert', 'remove', 'extend', 'clear', 'copy', 'upper', 'lower',
            'strip', 'split', 'join', 'replace', 'find', 'startswith', 'endswith',
            'contains', 'capitalize', 'title', 'format', 'substring', 'reverse',
            'sort', 'unique', 'flatten', 'exit', 'assert'
        ]
        
        defined_vars = re.findall(r'(?:let|const|var)\s+(\w+)', code[:position])
        defined_funcs = re.findall(r'func\s+(\w+)', code[:position])
        defined_classes = re.findall(r'class\s+(\w+)', code[:position])
        
        all_suggestions = keywords + builtins + defined_vars + defined_funcs + defined_classes
        
        for item in all_suggestions:
            if item.startswith(current_word) and item != current_word:
                suggestions.append(item)
        
        return suggestions[:10]
    
    def auto_fix(self, code: str, error: str) -> Tuple[str, List[str]]:
        """Attempt to automatically fix common errors"""
        fixes_applied = []
        fixed_code = code
        
        lines = fixed_code.split('\n')
        new_lines = []
        for i, line in enumerate(lines):
            stripped = line.strip()
            if any(stripped.startswith(kw) for kw in ['if', 'elif', 'else', 'for', 'while', 'func', 'class', 'try', 'catch', 'finally', 'match', 'case', 'default']):
                if stripped and not stripped.endswith(':') and not stripped.endswith('{'):
                    new_lines.append(line + ':')
                    fixes_applied.append(f"Line {i+1}: Added missing colon")
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)
        fixed_code = '\n'.join(new_lines)
        
        if ';' in fixed_code:
            fixed_code = fixed_code.replace(';', '')
            fixes_applied.append("Removed unnecessary semicolons")
        
        fixed_code = re.sub(r'print\s*\(\s*(.*?)\s*\)', r'print \1', fixed_code)
        if 'print(' in code:
            fixes_applied.append("Fixed print function syntax")
        
        return fixed_code, fixes_applied


def create_ai_assistant():
    """Create and return an AI assistant instance"""
    return STRACTAI()


if __name__ == "__main__":
    ai = STRACTAI()
    
    test_code = '''
let x = 10
let y = 20

func add(a, b):
    return a + b

for i in range(1, 5):
    print i

if x > 5:
    print "x is greater than 5"
'''
    
    print("STRACT AI Code Analysis")
    print("=" * 50)
    
    analysis = ai.analyze_code(test_code)
    print(f"\nCode Lines: {analysis['code_lines']}")
    print(f"Complexity: {analysis['complexity']} (score: {analysis['complexity_score']})")
    print(f"Quality Score: {analysis['code_quality_score']}/100")
    
    if analysis['suggestions']:
        print("\nSuggestions:")
        for s in analysis['suggestions']:
            print(f"  - {s}")
    
    if analysis['optimization_opportunities']:
        print("\nOptimizations:")
        for o in analysis['optimization_opportunities']:
            print(f"  - {o}")
