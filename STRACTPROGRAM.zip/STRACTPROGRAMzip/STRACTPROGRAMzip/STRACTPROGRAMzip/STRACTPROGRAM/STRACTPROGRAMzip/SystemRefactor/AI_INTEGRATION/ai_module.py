#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STRACT AI Module v3.0
Complete AI Integration for STRACT Programming Language

Features:
- Code Generation from natural language
- Code Analysis and Optimization
- Error Explanation
- Smart Autocomplete
- Documentation Generation
- Code Translation

# the newest OpenAI model is "gpt-5" which was released August 7, 2025.
# do not change this unless explicitly requested by the user
"""

import os
import json
import re
from typing import Any, Dict, List, Optional
from dataclasses import dataclass

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


@dataclass
class AIResponse:
    """AI Response container"""
    success: bool
    content: str
    metadata: Dict[str, Any] = None
    error: str = None


class STRACTAIEngine:
    """
    STRACT AI Engine - Powerful AI Integration
    Uses OpenAI GPT-5 for advanced code intelligence
    """
    
    def __init__(self):
        self.api_key = os.environ.get("OPENAI_API_KEY")
        self.client = None
        self.model = "gpt-5"
        self.initialized = False
        
        if OPENAI_AVAILABLE and self.api_key:
            try:
                self.client = OpenAI(api_key=self.api_key)
                self.initialized = True
            except Exception as e:
                print(f"Warning: Could not initialize OpenAI client: {e}")
    
    def is_available(self) -> bool:
        """Check if AI is available"""
        return self.initialized and self.client is not None
    
    def generate_code(self, description: str, language: str = "stract") -> AIResponse:
        """Generate code from natural language description"""
        if not self.is_available():
            return self._local_generate_code(description, language)
        
        try:
            prompt = f"""You are an expert STRACT programming language developer.
STRACT is a modern programming language with Python-like syntax but enhanced features.

Generate {language.upper()} code for the following description:
{description}

STRACT Language Features:
- Variables: let x = 10, const PI = 3.14
- Functions: func name(params): ... return value
- Classes: class Name: ... func init(self): ...
- Control flow: if/elif/else, for/while loops
- Print: print "text" or print expression
- Lists: [1, 2, 3], Dicts: {{"key": "value"}}
- Pattern matching: match value: case 1: ... default: ...
- Error handling: try: ... catch e: ... finally: ...

Generate clean, well-documented STRACT code:"""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                max_completion_tokens=2048
            )
            
            code = response.choices[0].message.content
            code = self._extract_code(code)
            
            return AIResponse(
                success=True,
                content=code,
                metadata={"model": self.model, "language": language}
            )
            
        except Exception as e:
            return AIResponse(
                success=False,
                content="",
                error=str(e)
            )
    
    def analyze_code(self, code: str) -> AIResponse:
        """Analyze code for issues, suggestions, and improvements"""
        if not self.is_available():
            return self._local_analyze_code(code)
        
        try:
            prompt = f"""Analyze this STRACT code and provide:
1. Code Quality Score (1-10)
2. Potential Issues
3. Performance Suggestions
4. Best Practice Recommendations
5. Security Concerns (if any)

Respond in JSON format:
{{"score": number, "issues": [], "suggestions": [], "recommendations": [], "security": []}}

Code:
```stract
{code}
```"""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"},
                max_completion_tokens=1024
            )
            
            analysis = response.choices[0].message.content
            
            return AIResponse(
                success=True,
                content=analysis,
                metadata={"model": self.model, "type": "analysis"}
            )
            
        except Exception as e:
            return AIResponse(
                success=False,
                content="",
                error=str(e)
            )
    
    def explain_error(self, error_message: str, code: str = "") -> AIResponse:
        """Explain an error and suggest fixes"""
        if not self.is_available():
            return self._local_explain_error(error_message, code)
        
        try:
            prompt = f"""Explain this STRACT programming error in simple terms and suggest fixes:

Error: {error_message}

{"Code context:" + chr(10) + code if code else ""}

Provide:
1. What the error means
2. Why it occurred
3. How to fix it
4. Example of correct code"""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                max_completion_tokens=1024
            )
            
            explanation = response.choices[0].message.content
            
            return AIResponse(
                success=True,
                content=explanation,
                metadata={"model": self.model, "type": "error_explanation"}
            )
            
        except Exception as e:
            return AIResponse(
                success=False,
                content="",
                error=str(e)
            )
    
    def optimize_code(self, code: str) -> AIResponse:
        """Optimize code for performance"""
        if not self.is_available():
            return self._local_optimize_code(code)
        
        try:
            prompt = f"""Optimize this STRACT code for better performance:

```stract
{code}
```

Provide:
1. Optimized code
2. Explanation of changes
3. Expected performance improvement"""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                max_completion_tokens=2048
            )
            
            optimized = response.choices[0].message.content
            
            return AIResponse(
                success=True,
                content=optimized,
                metadata={"model": self.model, "type": "optimization"}
            )
            
        except Exception as e:
            return AIResponse(
                success=False,
                content="",
                error=str(e)
            )
    
    def generate_docs(self, code: str) -> AIResponse:
        """Generate documentation for code"""
        if not self.is_available():
            return self._local_generate_docs(code)
        
        try:
            prompt = f"""Generate comprehensive documentation for this STRACT code:

```stract
{code}
```

Include:
1. Overview
2. Function/Class descriptions
3. Parameter documentation
4. Return value descriptions
5. Usage examples"""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                max_completion_tokens=2048
            )
            
            docs = response.choices[0].message.content
            
            return AIResponse(
                success=True,
                content=docs,
                metadata={"model": self.model, "type": "documentation"}
            )
            
        except Exception as e:
            return AIResponse(
                success=False,
                content="",
                error=str(e)
            )
    
    def translate_code(self, code: str, from_lang: str, to_lang: str) -> AIResponse:
        """Translate code between languages"""
        if not self.is_available():
            return AIResponse(
                success=False,
                content="",
                error="AI not available for code translation"
            )
        
        try:
            prompt = f"""Translate this code from {from_lang} to {to_lang}:

```{from_lang}
{code}
```

Provide equivalent {to_lang} code that maintains the same functionality."""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                max_completion_tokens=2048
            )
            
            translated = response.choices[0].message.content
            translated = self._extract_code(translated)
            
            return AIResponse(
                success=True,
                content=translated,
                metadata={"model": self.model, "from": from_lang, "to": to_lang}
            )
            
        except Exception as e:
            return AIResponse(
                success=False,
                content="",
                error=str(e)
            )
    
    def _extract_code(self, text: str) -> str:
        """Extract code from markdown code blocks"""
        code_pattern = r'```(?:\w+)?\n(.*?)```'
        matches = re.findall(code_pattern, text, re.DOTALL)
        if matches:
            return matches[0].strip()
        return text.strip()
    
    def _local_generate_code(self, description: str, language: str) -> AIResponse:
        """Local code generation without AI"""
        templates = {
            "hello": '''# Generated by STRACT AI
print "Hello, World!"
''',
            "function": '''# Generated function
func example(param):
    # Your code here
    return param
''',
            "class": '''# Generated class
class Example:
    func init(self):
        self.value = 0
    
    func get_value(self):
        return self.value
''',
            "loop": '''# Generated loop
for i in range(10):
    print i
''',
            "calculator": '''# Calculator
func add(a, b):
    return a + b

func subtract(a, b):
    return a - b

func multiply(a, b):
    return a * b

func divide(a, b):
    if b == 0:
        print "Error: Division by zero"
        return null
    return a / b

# Usage
print add(10, 5)
print subtract(10, 5)
print multiply(10, 5)
print divide(10, 5)
'''
        }
        
        desc_lower = description.lower()
        for key, template in templates.items():
            if key in desc_lower:
                return AIResponse(
                    success=True,
                    content=template,
                    metadata={"source": "local", "template": key}
                )
        
        return AIResponse(
            success=True,
            content=f'''# Generated code for: {description}
# Add your implementation here

func main():
    print "TODO: Implement {description}"

main()
''',
            metadata={"source": "local", "template": "default"}
        )
    
    def _local_analyze_code(self, code: str) -> AIResponse:
        """Local code analysis without AI"""
        issues = []
        suggestions = []
        
        lines = code.split('\n')
        
        for i, line in enumerate(lines, 1):
            if len(line) > 100:
                issues.append(f"Line {i}: Line too long ({len(line)} chars)")
            
            if re.search(r'/\s*0\b', line):
                issues.append(f"Line {i}: Potential division by zero")
            
            if 'print' in line and 'debug' in line.lower():
                suggestions.append(f"Line {i}: Remove debug print statement")
        
        func_count = len(re.findall(r'\bfunc\b', code))
        class_count = len(re.findall(r'\bclass\b', code))
        
        score = 8
        if len(issues) > 5:
            score -= 2
        if func_count == 0 and len(lines) > 20:
            score -= 1
            suggestions.append("Consider breaking code into functions")
        
        analysis = {
            "score": max(1, score),
            "issues": issues,
            "suggestions": suggestions,
            "metrics": {
                "lines": len(lines),
                "functions": func_count,
                "classes": class_count
            }
        }
        
        return AIResponse(
            success=True,
            content=json.dumps(analysis, indent=2),
            metadata={"source": "local"}
        )
    
    def _local_explain_error(self, error_message: str, code: str) -> AIResponse:
        """Local error explanation without AI"""
        explanations = {
            "undefined variable": "The variable was used before being defined. Use 'let' to declare it first.",
            "syntax error": "There's a typo or incorrect syntax in your code. Check parentheses, colons, and spelling.",
            "type error": "You're trying to use an operation on incompatible types.",
            "index out of range": "You're trying to access a list element that doesn't exist.",
            "division by zero": "You're dividing a number by zero, which is undefined.",
        }
        
        error_lower = error_message.lower()
        for key, explanation in explanations.items():
            if key in error_lower:
                return AIResponse(
                    success=True,
                    content=f"Error Explanation:\n{explanation}\n\nSuggestion: Review the error location and fix the issue.",
                    metadata={"source": "local"}
                )
        
        return AIResponse(
            success=True,
            content=f"Error: {error_message}\n\nThis error typically indicates a problem with your code. Check the line mentioned in the error for issues.",
            metadata={"source": "local"}
        )
    
    def _local_optimize_code(self, code: str) -> AIResponse:
        """Local code optimization without AI"""
        optimizations = []
        optimized = code
        
        if re.search(r'for\s+\w+\s+in\s+range\(len\(', code):
            optimizations.append("Consider using direct iteration instead of range(len())")
        
        if re.search(r'(\w+)\s*=\s*\1\s*\+', code):
            optimizations.append("Use += for incrementing: x += value")
        
        if len(re.findall(r'\bprint\b', code)) > 10:
            optimizations.append("Consider reducing print statements for better performance")
        
        return AIResponse(
            success=True,
            content=f"Optimization Suggestions:\n" + "\n".join(f"- {o}" for o in optimizations) if optimizations else "Code looks optimized!",
            metadata={"source": "local", "optimizations": len(optimizations)}
        )
    
    def _local_generate_docs(self, code: str) -> AIResponse:
        """Local documentation generation without AI"""
        docs = ["# Documentation\n"]
        
        functions = re.findall(r'func\s+(\w+)\s*\(([^)]*)\)', code)
        if functions:
            docs.append("## Functions\n")
            for name, params in functions:
                docs.append(f"### {name}({params})")
                docs.append(f"Function that takes {len(params.split(',')) if params else 0} parameter(s).\n")
        
        classes = re.findall(r'class\s+(\w+)', code)
        if classes:
            docs.append("## Classes\n")
            for cls in classes:
                docs.append(f"### {cls}")
                docs.append(f"Class definition for {cls}.\n")
        
        return AIResponse(
            success=True,
            content="\n".join(docs),
            metadata={"source": "local"}
        )


_ai_engine = None

def get_ai_engine() -> STRACTAIEngine:
    """Get the global AI engine instance"""
    global _ai_engine
    if _ai_engine is None:
        _ai_engine = STRACTAIEngine()
    return _ai_engine


def ai_generate(description: str) -> str:
    """Generate code from description"""
    engine = get_ai_engine()
    response = engine.generate_code(description)
    return response.content if response.success else f"Error: {response.error}"


def ai_analyze(code: str) -> str:
    """Analyze code"""
    engine = get_ai_engine()
    response = engine.analyze_code(code)
    return response.content if response.success else f"Error: {response.error}"


def ai_explain(error: str, code: str = "") -> str:
    """Explain error"""
    engine = get_ai_engine()
    response = engine.explain_error(error, code)
    return response.content if response.success else f"Error: {response.error}"


def ai_optimize(code: str) -> str:
    """Optimize code"""
    engine = get_ai_engine()
    response = engine.optimize_code(code)
    return response.content if response.success else f"Error: {response.error}"


def ai_docs(code: str) -> str:
    """Generate documentation"""
    engine = get_ai_engine()
    response = engine.generate_docs(code)
    return response.content if response.success else f"Error: {response.error}"


if __name__ == "__main__":
    print("STRACT AI Module v3.0")
    print("=" * 50)
    
    engine = get_ai_engine()
    print(f"AI Available: {engine.is_available()}")
    
    print("\nTesting local code generation:")
    result = engine.generate_code("create a calculator")
    print(result.content)
    
    print("\nTesting local code analysis:")
    test_code = '''
func add(a, b):
    return a + b

let result = add(10, 5)
print result
'''
    result = engine.analyze_code(test_code)
    print(result.content)
