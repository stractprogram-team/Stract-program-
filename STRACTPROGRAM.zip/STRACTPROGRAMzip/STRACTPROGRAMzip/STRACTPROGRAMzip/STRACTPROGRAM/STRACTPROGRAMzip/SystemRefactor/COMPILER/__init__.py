"""Compiler and Optimizer module for STRACT"""

from .compiler import (
    Compiler,
    Optimizer,
    BytecodeVM,
    OpCode,
    Instruction,
    CompiledModule,
    CompiledFunction,
    CompiledClass,
    compile_source,
    optimize_module,
    run_compiled,
    get_compiler,
    get_optimizer,
    get_vm,
)

__all__ = [
    "Compiler",
    "Optimizer",
    "BytecodeVM",
    "OpCode",
    "Instruction",
    "CompiledModule",
    "CompiledFunction",
    "CompiledClass",
    "compile_source",
    "optimize_module",
    "run_compiled",
    "get_compiler",
    "get_optimizer",
    "get_vm",
]
