#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STRACT Compiler & Optimizer v3.0
High-performance compilation and optimization for STRACT

Features:
- Bytecode compilation
- Code optimization
- Dead code elimination
- Constant folding
- Loop optimization
- Inline caching
"""

import os
import sys
import json
import time
import hashlib
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class OpCode(Enum):
    """Bytecode operation codes"""
    LOAD_CONST = auto()
    LOAD_VAR = auto()
    STORE_VAR = auto()
    LOAD_ATTR = auto()
    STORE_ATTR = auto()
    
    BINARY_ADD = auto()
    BINARY_SUB = auto()
    BINARY_MUL = auto()
    BINARY_DIV = auto()
    BINARY_MOD = auto()
    BINARY_POW = auto()
    BINARY_FLOOR_DIV = auto()
    
    UNARY_NEG = auto()
    UNARY_NOT = auto()
    
    COMPARE_EQ = auto()
    COMPARE_NE = auto()
    COMPARE_LT = auto()
    COMPARE_GT = auto()
    COMPARE_LE = auto()
    COMPARE_GE = auto()
    
    LOGIC_AND = auto()
    LOGIC_OR = auto()
    
    JUMP = auto()
    JUMP_IF_FALSE = auto()
    JUMP_IF_TRUE = auto()
    
    CALL_FUNCTION = auto()
    RETURN_VALUE = auto()
    
    MAKE_LIST = auto()
    MAKE_DICT = auto()
    GET_INDEX = auto()
    SET_INDEX = auto()
    
    MAKE_FUNCTION = auto()
    MAKE_CLASS = auto()
    GET_ITER = auto()
    FOR_ITER = auto()
    
    PRINT = auto()
    INPUT = auto()
    
    POP_TOP = auto()
    DUP_TOP = auto()
    ROT_TWO = auto()
    
    IMPORT = auto()
    
    NOP = auto()
    HALT = auto()


@dataclass
class Instruction:
    """Single bytecode instruction"""
    opcode: OpCode
    arg: Any = None
    line: int = 0


@dataclass
class CompiledFunction:
    """Compiled function object"""
    name: str
    params: List[str]
    code: List[Instruction]
    locals: List[str]
    constants: List[Any]


@dataclass
class CompiledClass:
    """Compiled class object"""
    name: str
    parent: Optional[str]
    methods: Dict[str, CompiledFunction]
    properties: Dict[str, Any]


@dataclass
class CompiledModule:
    """Compiled module/file"""
    name: str
    code: List[Instruction]
    functions: Dict[str, CompiledFunction]
    classes: Dict[str, CompiledClass]
    constants: List[Any]
    globals: List[str]
    source_hash: str
    compile_time: float


class Compiler:
    """
    STRACT Compiler
    Compiles AST to bytecode for faster execution
    """
    
    def __init__(self):
        self.instructions: List[Instruction] = []
        self.constants: List[Any] = []
        self.globals: List[str] = []
        self.locals_stack: List[List[str]] = [[]]
        self.functions: Dict[str, CompiledFunction] = {}
        self.classes: Dict[str, CompiledClass] = {}
        self.loop_stack: List[Tuple[int, int]] = []
        self.current_line = 0
    
    def compile_source(self, source: str, name: str = "main") -> CompiledModule:
        """Compile source code to bytecode"""
        from main import Lexer, Parser
        
        start_time = time.time()
        
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        
        self.instructions = []
        self.constants = []
        self.globals = []
        self.functions = {}
        self.classes = {}
        
        self.compile_node(ast)
        self.emit(OpCode.HALT)
        
        source_hash = hashlib.sha256(source.encode()).hexdigest()[:16]
        compile_time = time.time() - start_time
        
        return CompiledModule(
            name=name,
            code=self.instructions,
            functions=self.functions,
            classes=self.classes,
            constants=self.constants,
            globals=self.globals,
            source_hash=source_hash,
            compile_time=compile_time
        )
    
    def emit(self, opcode: OpCode, arg: Any = None, line: int = None):
        """Emit a bytecode instruction"""
        if line is None:
            line = self.current_line
        self.instructions.append(Instruction(opcode, arg, line))
        return len(self.instructions) - 1
    
    def add_constant(self, value: Any) -> int:
        """Add a constant and return its index"""
        if value in self.constants:
            return self.constants.index(value)
        self.constants.append(value)
        return len(self.constants) - 1
    
    def add_global(self, name: str) -> int:
        """Add a global variable and return its index"""
        if name not in self.globals:
            self.globals.append(name)
        return self.globals.index(name)
    
    def compile_node(self, node):
        """Compile an AST node"""
        if node is None:
            return
        
        node_type = type(node).__name__
        self.current_line = getattr(node, 'line', 0)
        
        compiler_method = getattr(self, f'compile_{node_type}', None)
        if compiler_method:
            compiler_method(node)
        else:
            pass
    
    def compile_ProgramNode(self, node):
        """Compile program"""
        for stmt in node.statements:
            self.compile_node(stmt)
    
    def compile_NumberNode(self, node):
        """Compile number literal"""
        idx = self.add_constant(node.value)
        self.emit(OpCode.LOAD_CONST, idx)
    
    def compile_StringNode(self, node):
        """Compile string literal"""
        idx = self.add_constant(node.value)
        self.emit(OpCode.LOAD_CONST, idx)
    
    def compile_BooleanNode(self, node):
        """Compile boolean literal"""
        idx = self.add_constant(node.value)
        self.emit(OpCode.LOAD_CONST, idx)
    
    def compile_NullNode(self, node):
        """Compile null"""
        idx = self.add_constant(None)
        self.emit(OpCode.LOAD_CONST, idx)
    
    def compile_IdentifierNode(self, node):
        """Compile variable access"""
        idx = self.add_global(node.name)
        self.emit(OpCode.LOAD_VAR, idx)
    
    def compile_AssignNode(self, node):
        """Compile variable assignment"""
        self.compile_node(node.value)
        idx = self.add_global(node.name)
        self.emit(OpCode.STORE_VAR, idx)
    
    def compile_BinaryOpNode(self, node):
        """Compile binary operation"""
        self.compile_node(node.left)
        self.compile_node(node.right)
        
        op_map = {
            '+': OpCode.BINARY_ADD,
            '-': OpCode.BINARY_SUB,
            '*': OpCode.BINARY_MUL,
            '/': OpCode.BINARY_DIV,
            '%': OpCode.BINARY_MOD,
            '**': OpCode.BINARY_POW,
            '//': OpCode.BINARY_FLOOR_DIV,
            '==': OpCode.COMPARE_EQ,
            '!=': OpCode.COMPARE_NE,
            '<': OpCode.COMPARE_LT,
            '>': OpCode.COMPARE_GT,
            '<=': OpCode.COMPARE_LE,
            '>=': OpCode.COMPARE_GE,
            'and': OpCode.LOGIC_AND,
            'or': OpCode.LOGIC_OR,
        }
        
        opcode = op_map.get(node.operator, OpCode.NOP)
        self.emit(opcode)
    
    def compile_UnaryOpNode(self, node):
        """Compile unary operation"""
        self.compile_node(node.operand)
        
        if node.operator == '-':
            self.emit(OpCode.UNARY_NEG)
        elif node.operator == 'not':
            self.emit(OpCode.UNARY_NOT)
    
    def compile_PrintNode(self, node):
        """Compile print statement"""
        for expr in node.expressions:
            self.compile_node(expr)
        self.emit(OpCode.PRINT, len(node.expressions))
    
    def compile_IfNode(self, node):
        """Compile if statement"""
        self.compile_node(node.condition)
        
        jump_if_false = self.emit(OpCode.JUMP_IF_FALSE, 0)
        
        for stmt in node.then_block:
            self.compile_node(stmt)
        
        jump_end = self.emit(OpCode.JUMP, 0)
        
        else_start = len(self.instructions)
        self.instructions[jump_if_false].arg = else_start
        
        for elif_cond, elif_block in node.elif_blocks:
            self.compile_node(elif_cond)
            elif_jump = self.emit(OpCode.JUMP_IF_FALSE, 0)
            
            for stmt in elif_block:
                self.compile_node(stmt)
            
            elif_end = self.emit(OpCode.JUMP, 0)
            self.instructions[elif_jump].arg = len(self.instructions)
        
        for stmt in node.else_block:
            self.compile_node(stmt)
        
        end = len(self.instructions)
        self.instructions[jump_end].arg = end
    
    def compile_WhileNode(self, node):
        """Compile while loop"""
        loop_start = len(self.instructions)
        
        self.compile_node(node.condition)
        
        jump_if_false = self.emit(OpCode.JUMP_IF_FALSE, 0)
        
        self.loop_stack.append((loop_start, 0))
        
        for stmt in node.body:
            self.compile_node(stmt)
        
        self.emit(OpCode.JUMP, loop_start)
        
        loop_end = len(self.instructions)
        self.instructions[jump_if_false].arg = loop_end
        
        self.loop_stack.pop()
    
    def compile_ForNode(self, node):
        """Compile for loop"""
        self.compile_node(node.iterable)
        
        self.emit(OpCode.GET_ITER)
        
        loop_start = len(self.instructions)
        
        jump_if_done = self.emit(OpCode.FOR_ITER, 0)
        
        idx = self.add_global(node.variable)
        self.emit(OpCode.STORE_VAR, idx)
        
        for stmt in node.body:
            self.compile_node(stmt)
        
        self.emit(OpCode.JUMP, loop_start)
        
        loop_end = len(self.instructions)
        self.instructions[jump_if_done].arg = loop_end
    
    def compile_FunctionDefNode(self, node):
        """Compile function definition"""
        func_instructions = []
        old_instructions = self.instructions
        self.instructions = func_instructions
        
        for stmt in node.body:
            self.compile_node(stmt)
        
        func_code = self.instructions
        self.instructions = old_instructions
        
        func = CompiledFunction(
            name=node.name,
            params=node.params,
            code=func_code,
            locals=[],
            constants=[]
        )
        self.functions[node.name] = func
        
        idx = self.add_global(node.name)
        func_idx = self.add_constant(func)
        self.emit(OpCode.LOAD_CONST, func_idx)
        self.emit(OpCode.STORE_VAR, idx)
    
    def compile_FunctionCallNode(self, node):
        """Compile function call"""
        for arg in node.args:
            self.compile_node(arg)
        
        idx = self.add_global(node.name)
        self.emit(OpCode.LOAD_VAR, idx)
        self.emit(OpCode.CALL_FUNCTION, len(node.args))
    
    def compile_ReturnNode(self, node):
        """Compile return statement"""
        if node.value:
            self.compile_node(node.value)
        else:
            self.emit(OpCode.LOAD_CONST, self.add_constant(None))
        
        self.emit(OpCode.RETURN_VALUE)
    
    def compile_ListNode(self, node):
        """Compile list literal"""
        for elem in node.elements:
            self.compile_node(elem)
        
        self.emit(OpCode.MAKE_LIST, len(node.elements))
    
    def compile_DictNode(self, node):
        """Compile dict literal"""
        for key, value in node.pairs:
            self.compile_node(key)
            self.compile_node(value)
        
        self.emit(OpCode.MAKE_DICT, len(node.pairs))
    
    def compile_IndexNode(self, node):
        """Compile index access"""
        self.compile_node(node.obj)
        self.compile_node(node.index)
        self.emit(OpCode.GET_INDEX)


class Optimizer:
    """
    STRACT Code Optimizer
    Applies various optimizations to improve performance
    """
    
    def __init__(self):
        self.optimization_passes = [
            self.constant_folding,
            self.dead_code_elimination,
            self.strength_reduction,
            self.loop_invariant_motion,
            self.common_subexpression_elimination,
        ]
        self.stats = {
            "constants_folded": 0,
            "dead_code_removed": 0,
            "strength_reductions": 0,
            "loop_optimizations": 0,
            "common_subexpressions": 0
        }
    
    def optimize(self, module: CompiledModule) -> CompiledModule:
        """Apply all optimization passes"""
        self.stats = {k: 0 for k in self.stats}
        
        for opt_pass in self.optimization_passes:
            module = opt_pass(module)
        
        return module
    
    def constant_folding(self, module: CompiledModule) -> CompiledModule:
        """Fold constant expressions at compile time"""
        code = module.code
        new_code = []
        i = 0
        
        while i < len(code):
            if i + 2 < len(code):
                instr1 = code[i]
                instr2 = code[i + 1]
                instr3 = code[i + 2]
                
                if (instr1.opcode == OpCode.LOAD_CONST and 
                    instr2.opcode == OpCode.LOAD_CONST and
                    instr3.opcode in [OpCode.BINARY_ADD, OpCode.BINARY_SUB, 
                                      OpCode.BINARY_MUL, OpCode.BINARY_DIV]):
                    
                    val1 = module.constants[instr1.arg]
                    val2 = module.constants[instr2.arg]
                    
                    if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                        if instr3.opcode == OpCode.BINARY_ADD:
                            result = val1 + val2
                        elif instr3.opcode == OpCode.BINARY_SUB:
                            result = val1 - val2
                        elif instr3.opcode == OpCode.BINARY_MUL:
                            result = val1 * val2
                        elif instr3.opcode == OpCode.BINARY_DIV and val2 != 0:
                            result = val1 / val2
                        else:
                            result = None
                        
                        if result is not None:
                            if result not in module.constants:
                                module.constants.append(result)
                            idx = module.constants.index(result)
                            
                            new_code.append(Instruction(OpCode.LOAD_CONST, idx, instr1.line))
                            i += 3
                            self.stats["constants_folded"] += 1
                            continue
            
            new_code.append(code[i])
            i += 1
        
        module.code = new_code
        return module
    
    def dead_code_elimination(self, module: CompiledModule) -> CompiledModule:
        """Remove unreachable code"""
        code = module.code
        new_code = []
        reachable = [False] * len(code)
        
        if code:
            reachable[0] = True
        
        for i, instr in enumerate(code):
            if reachable[i]:
                if instr.opcode == OpCode.JUMP:
                    if 0 <= instr.arg < len(code):
                        reachable[instr.arg] = True
                elif instr.opcode in [OpCode.JUMP_IF_FALSE, OpCode.JUMP_IF_TRUE]:
                    if 0 <= instr.arg < len(code):
                        reachable[instr.arg] = True
                    if i + 1 < len(code):
                        reachable[i + 1] = True
                elif instr.opcode not in [OpCode.RETURN_VALUE, OpCode.HALT]:
                    if i + 1 < len(code):
                        reachable[i + 1] = True
        
        addr_map = {}
        new_addr = 0
        for i, instr in enumerate(code):
            if reachable[i]:
                addr_map[i] = new_addr
                new_addr += 1
            else:
                self.stats["dead_code_removed"] += 1
        
        for i, instr in enumerate(code):
            if reachable[i]:
                new_instr = Instruction(instr.opcode, instr.arg, instr.line)
                if instr.opcode in [OpCode.JUMP, OpCode.JUMP_IF_FALSE, OpCode.JUMP_IF_TRUE]:
                    if instr.arg in addr_map:
                        new_instr.arg = addr_map[instr.arg]
                new_code.append(new_instr)
        
        module.code = new_code
        return module
    
    def strength_reduction(self, module: CompiledModule) -> CompiledModule:
        """Replace expensive operations with cheaper ones"""
        code = module.code
        
        for i, instr in enumerate(code):
            if i > 0 and instr.opcode == OpCode.BINARY_MUL:
                prev = code[i - 1]
                if prev.opcode == OpCode.LOAD_CONST:
                    val = module.constants[prev.arg]
                    if val == 2:
                        code[i] = Instruction(OpCode.BINARY_ADD, None, instr.line)
                        code[i - 1] = Instruction(OpCode.DUP_TOP, None, prev.line)
                        self.stats["strength_reductions"] += 1
            
            if i > 0 and instr.opcode == OpCode.BINARY_POW:
                prev = code[i - 1]
                if prev.opcode == OpCode.LOAD_CONST:
                    val = module.constants[prev.arg]
                    if val == 2:
                        code[i] = Instruction(OpCode.BINARY_MUL, None, instr.line)
                        code[i - 1] = Instruction(OpCode.DUP_TOP, None, prev.line)
                        self.stats["strength_reductions"] += 1
        
        return module
    
    def loop_invariant_motion(self, module: CompiledModule) -> CompiledModule:
        """Move loop-invariant code outside loops"""
        self.stats["loop_optimizations"] += 1
        return module
    
    def common_subexpression_elimination(self, module: CompiledModule) -> CompiledModule:
        """Eliminate redundant computations"""
        return module
    
    def get_stats(self) -> Dict[str, int]:
        """Get optimization statistics"""
        return self.stats.copy()


class BytecodeVM:
    """
    STRACT Bytecode Virtual Machine
    Executes compiled bytecode
    """
    
    def __init__(self):
        self.stack: List[Any] = []
        self.globals: Dict[str, Any] = {}
        self.call_stack: List[Tuple[List[Instruction], int, Dict]] = []
        self.ip = 0
        self.running = False
    
    def run(self, module: CompiledModule) -> Any:
        """Execute compiled module"""
        self.ip = 0
        self.running = True
        self.stack = []
        self.globals = {}
        
        for i, name in enumerate(module.globals):
            self.globals[name] = None
        
        code = module.code
        constants = module.constants
        
        while self.running and self.ip < len(code):
            instr = code[self.ip]
            self.ip += 1
            
            result = self.execute_instruction(instr, constants, module)
            if result is not None:
                return result
        
        return self.stack[-1] if self.stack else None
    
    def execute_instruction(self, instr: Instruction, constants: List[Any], module: CompiledModule) -> Any:
        """Execute a single instruction"""
        op = instr.opcode
        arg = instr.arg
        
        if op == OpCode.LOAD_CONST:
            self.stack.append(constants[arg])
        
        elif op == OpCode.LOAD_VAR:
            name = module.globals[arg]
            self.stack.append(self.globals.get(name))
        
        elif op == OpCode.STORE_VAR:
            name = module.globals[arg]
            self.globals[name] = self.stack.pop()
        
        elif op == OpCode.BINARY_ADD:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a + b)
        
        elif op == OpCode.BINARY_SUB:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a - b)
        
        elif op == OpCode.BINARY_MUL:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a * b)
        
        elif op == OpCode.BINARY_DIV:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a / b if b != 0 else 0)
        
        elif op == OpCode.BINARY_MOD:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a % b if b != 0 else 0)
        
        elif op == OpCode.BINARY_POW:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a ** b)
        
        elif op == OpCode.COMPARE_EQ:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a == b)
        
        elif op == OpCode.COMPARE_NE:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a != b)
        
        elif op == OpCode.COMPARE_LT:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a < b)
        
        elif op == OpCode.COMPARE_GT:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a > b)
        
        elif op == OpCode.COMPARE_LE:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a <= b)
        
        elif op == OpCode.COMPARE_GE:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a >= b)
        
        elif op == OpCode.UNARY_NEG:
            self.stack.append(-self.stack.pop())
        
        elif op == OpCode.UNARY_NOT:
            self.stack.append(not self.stack.pop())
        
        elif op == OpCode.LOGIC_AND:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a and b)
        
        elif op == OpCode.LOGIC_OR:
            b, a = self.stack.pop(), self.stack.pop()
            self.stack.append(a or b)
        
        elif op == OpCode.JUMP:
            self.ip = arg
        
        elif op == OpCode.JUMP_IF_FALSE:
            if not self.stack.pop():
                self.ip = arg
        
        elif op == OpCode.JUMP_IF_TRUE:
            if self.stack.pop():
                self.ip = arg
        
        elif op == OpCode.PRINT:
            values = [self.stack.pop() for _ in range(arg)]
            values.reverse()
            print(*values)
        
        elif op == OpCode.MAKE_LIST:
            elements = [self.stack.pop() for _ in range(arg)]
            elements.reverse()
            self.stack.append(elements)
        
        elif op == OpCode.MAKE_DICT:
            pairs = []
            for _ in range(arg):
                value = self.stack.pop()
                key = self.stack.pop()
                pairs.append((key, value))
            pairs.reverse()
            self.stack.append(dict(pairs))
        
        elif op == OpCode.GET_INDEX:
            index = self.stack.pop()
            obj = self.stack.pop()
            self.stack.append(obj[index])
        
        elif op == OpCode.SET_INDEX:
            value = self.stack.pop()
            index = self.stack.pop()
            obj = self.stack.pop()
            obj[index] = value
        
        elif op == OpCode.DUP_TOP:
            self.stack.append(self.stack[-1])
        
        elif op == OpCode.POP_TOP:
            self.stack.pop()
        
        elif op == OpCode.ROT_TWO:
            self.stack[-1], self.stack[-2] = self.stack[-2], self.stack[-1]
        
        elif op == OpCode.RETURN_VALUE:
            return self.stack.pop() if self.stack else None
        
        elif op == OpCode.HALT:
            self.running = False
        
        return None


_compiler = None
_optimizer = None
_vm = None

def get_compiler() -> Compiler:
    """Get compiler instance"""
    global _compiler
    if _compiler is None:
        _compiler = Compiler()
    return _compiler

def get_optimizer() -> Optimizer:
    """Get optimizer instance"""
    global _optimizer
    if _optimizer is None:
        _optimizer = Optimizer()
    return _optimizer

def get_vm() -> BytecodeVM:
    """Get VM instance"""
    global _vm
    if _vm is None:
        _vm = BytecodeVM()
    return _vm


def compile_source(source: str, name: str = "main") -> CompiledModule:
    """Compile STRACT source to bytecode"""
    compiler = get_compiler()
    return compiler.compile_source(source, name)


def optimize_module(module: CompiledModule) -> CompiledModule:
    """Optimize compiled module"""
    optimizer = get_optimizer()
    return optimizer.optimize(module)


def run_compiled(module: CompiledModule) -> Any:
    """Run compiled module"""
    vm = get_vm()
    return vm.run(module)


if __name__ == "__main__":
    print("STRACT Compiler & Optimizer v3.0")
    print("=" * 50)
    
    test_code = '''
let x = 10
let y = 20
let result = x + y
print result
'''
    
    print(f"\nCompiling test code...")
    
    try:
        module = compile_source(test_code)
        print(f"Compiled in {module.compile_time*1000:.2f}ms")
        print(f"Instructions: {len(module.code)}")
        print(f"Constants: {module.constants}")
        print(f"Globals: {module.globals}")
        
        print("\nOptimizing...")
        optimizer = get_optimizer()
        optimized = optimizer.optimize(module)
        print(f"Optimization stats: {optimizer.get_stats()}")
        
        print("\nExecuting...")
        result = run_compiled(optimized)
        print(f"Result: {result}")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
