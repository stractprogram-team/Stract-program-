"""
STRACT Web Framework Package
Complete web server and REST API framework
"""

from .web_framework import (
    Request,
    Response,
    Router,
    StratWebApp,
    Database,
    create_app,
    get_app,
)

__version__ = "1.0.0"
__all__ = [
    "Request",
    "Response",
    "Router",
    "StratWebApp",
    "Database",
    "create_app",
    "get_app",
]
