#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STRACT Web Framework - Complete Web Server & REST API Framework
Built for speed and simplicity with enterprise features
"""

import json
import re
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from typing import Dict, List, Callable, Any, Optional, Tuple
import threading
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Request:
    """HTTP Request object"""
    def __init__(self, method: str, path: str, headers: Dict, body: str = ""):
        self.method = method
        self.path = path
        self.headers = headers
        self.body = body
        self.query_params = self._parse_query()
        self.json_data = self._parse_json()
    
    def _parse_query(self) -> Dict:
        parsed = urlparse(self.path)
        return parse_qs(parsed.query) if parsed.query else {}
    
    def _parse_json(self) -> Dict:
        try:
            return json.loads(self.body) if self.body else {}
        except:
            return {}

class Response:
    """HTTP Response object"""
    def __init__(self, status: int = 200, body: str = "", headers: Dict = None):
        self.status = status
        self.body = body
        self.headers = headers or {}
        self.headers.setdefault('Content-Type', 'text/plain')
    
    def json(self, data: Dict) -> 'Response':
        self.body = json.dumps(data, indent=2)
        self.headers['Content-Type'] = 'application/json'
        return self
    
    def html(self, content: str) -> 'Response':
        self.body = content
        self.headers['Content-Type'] = 'text/html'
        return self
    
    def redirect(self, url: str) -> 'Response':
        self.status = 302
        self.headers['Location'] = url
        return self

class Router:
    """URL Router for handling different routes"""
    def __init__(self):
        self.routes = {}
        self.middleware_stack = []
    
    def add_route(self, method: str, path: str, handler: Callable):
        key = f"{method} {path}"
        self.routes[key] = handler
        logger.info(f"Route registered: {key}")
    
    def get(self, path: str, handler: Callable):
        self.add_route("GET", path, handler)
    
    def post(self, path: str, handler: Callable):
        self.add_route("POST", path, handler)
    
    def put(self, path: str, handler: Callable):
        self.add_route("PUT", path, handler)
    
    def delete(self, path: str, handler: Callable):
        self.add_route("DELETE", path, handler)
    
    def patch(self, path: str, handler: Callable):
        self.add_route("PATCH", path, handler)
    
    def add_middleware(self, middleware: Callable):
        self.middleware_stack.append(middleware)
    
    def match_route(self, method: str, path: str) -> Optional[Tuple[Callable, Dict]]:
        """Match URL path to route with parameter extraction"""
        clean_path = path.split('?')[0]
        
        # Exact match
        key = f"{method} {clean_path}"
        if key in self.routes:
            return self.routes[key], {}
        
        # Pattern matching with parameters
        for route_key, handler in self.routes.items():
            route_method, route_path = route_key.split(' ', 1)
            if route_method != method:
                continue
            
            params = self._extract_params(route_path, clean_path)
            if params is not None:
                return handler, params
        
        return None, {}
    
    def _extract_params(self, pattern: str, path: str) -> Optional[Dict]:
        """Extract URL parameters from path"""
        pattern_parts = pattern.split('/')
        path_parts = path.split('/')
        
        if len(pattern_parts) != len(path_parts):
            return None
        
        params = {}
        for pattern_part, path_part in zip(pattern_parts, path_parts):
            if pattern_part.startswith('<') and pattern_part.endswith('>'):
                param_name = pattern_part[1:-1]
                params[param_name] = path_part
            elif pattern_part != path_part:
                return None
        
        return params

class StratWebApp:
    """STRACT Web Application Framework"""
    def __init__(self, host: str = '0.0.0.0', port: int = 5000):
        self.host = host
        self.port = port
        self.router = Router()
        self.middleware = []
        self.config = {
            'DEBUG': False,
            'JSON_SORT_KEYS': False,
            'JSONIFY_PRETTYPRINT_REGULAR': True,
        }
    
    def route(self, path: str, methods: List[str] = None):
        """Decorator for registering routes"""
        if methods is None:
            methods = ['GET']
        
        def decorator(func):
            for method in methods:
                self.router.add_route(method, path, func)
            return func
        return decorator
    
    def get(self, path: str):
        def decorator(func):
            self.router.get(path, func)
            return func
        return decorator
    
    def post(self, path: str):
        def decorator(func):
            self.router.post(path, func)
            return func
        return decorator
    
    def put(self, path: str):
        def decorator(func):
            self.router.put(path, func)
            return func
        return decorator
    
    def delete(self, path: str):
        def decorator(func):
            self.router.delete(path, func)
            return func
        return decorator
    
    def middleware(self, func: Callable):
        """Add middleware"""
        self.middleware.append(func)
        self.router.add_middleware(func)
        return func
    
    def handle_request(self, request: Request) -> Response:
        """Process incoming request"""
        handler, params = self.router.match_route(request.method, request.path)
        
        if not handler:
            return Response(404, "Not Found")
        
        try:
            # Execute middleware
            for mw in self.middleware:
                mw(request)
            
            # Call handler
            result = handler(request, **params)
            
            if isinstance(result, Response):
                return result
            elif isinstance(result, dict):
                return Response(200).json(result)
            else:
                return Response(200, str(result))
        
        except Exception as e:
            logger.error(f"Error: {e}")
            return Response(500, f"Internal Server Error: {e}")
    
    def run(self, debug: bool = False, port: int = None):
        """Run the web server"""
        if port:
            self.port = port
        
        self.config['DEBUG'] = debug
        
        server_address = (self.host, self.port)
        
        class RequestHandler(BaseHTTPRequestHandler):
            app = self
            
            def do_GET(self):
                self.handle_request('GET')
            
            def do_POST(self):
                self.handle_request('POST')
            
            def do_PUT(self):
                self.handle_request('PUT')
            
            def do_DELETE(self):
                self.handle_request('DELETE')
            
            def do_PATCH(self):
                self.handle_request('PATCH')
            
            def handle_request(self, method):
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length).decode('utf-8')
                
                request = Request(method, self.path, dict(self.headers), body)
                response = self.app.handle_request(request)
                
                self.send_response(response.status)
                for header, value in response.headers.items():
                    self.send_header(header, value)
                self.end_headers()
                
                if response.body:
                    self.wfile.write(response.body.encode('utf-8'))
            
            def log_message(self, format, *args):
                logger.info(f"{self.client_address[0]} - {format%args}")
        
        httpd = HTTPServer(server_address, RequestHandler)
        logger.info(f"🚀 STRACT Web Server running on {self.host}:{self.port}")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            logger.info("\n📛 Server stopped")
            httpd.shutdown()

class Database:
    """Simple In-Memory Database with File Persistence"""
    def __init__(self, name: str = "default"):
        self.name = name
        self.tables = {}
        self.id_counter = {}
    
    def create_table(self, table_name: str, columns: List[str]):
        """Create a new table"""
        self.tables[table_name] = []
        self.id_counter[table_name] = 1
        logger.info(f"Table created: {table_name}")
    
    def insert(self, table_name: str, data: Dict) -> int:
        """Insert record"""
        if table_name not in self.tables:
            raise ValueError(f"Table {table_name} not found")
        
        record = {'id': self.id_counter[table_name], **data}
        self.tables[table_name].append(record)
        self.id_counter[table_name] += 1
        
        return record['id']
    
    def find_all(self, table_name: str) -> List[Dict]:
        """Get all records"""
        if table_name not in self.tables:
            return []
        return self.tables[table_name]
    
    def find_by_id(self, table_name: str, record_id: int) -> Optional[Dict]:
        """Find record by ID"""
        for record in self.tables.get(table_name, []):
            if record['id'] == record_id:
                return record
        return None
    
    def update(self, table_name: str, record_id: int, data: Dict):
        """Update record"""
        for record in self.tables.get(table_name, []):
            if record['id'] == record_id:
                record.update(data)
                return True
        return False
    
    def delete(self, table_name: str, record_id: int):
        """Delete record"""
        self.tables[table_name] = [
            r for r in self.tables.get(table_name, [])
            if r['id'] != record_id
        ]

# Global app instance
_app_instance = None

def create_app(host: str = '0.0.0.0', port: int = 5000) -> StratWebApp:
    """Create and return STRACT web app"""
    global _app_instance
    _app_instance = StratWebApp(host, port)
    return _app_instance

def get_app() -> StratWebApp:
    """Get current app instance"""
    global _app_instance
    if _app_instance is None:
        _app_instance = create_app()
    return _app_instance

if __name__ == "__main__":
    # Example usage
    app = create_app()
    
    @app.get("/")
    def index(request):
        return Response(200).json({"message": "Welcome to STRACT Web Framework!"})
    
    @app.get("/api/users/<user_id>")
    def get_user(request, user_id):
        return Response(200).json({"user_id": user_id, "name": "User"})
    
    @app.post("/api/users")
    def create_user(request):
        data = request.json_data
        return Response(201).json({"id": 1, **data})
    
    app.run(debug=True, port=5000)
