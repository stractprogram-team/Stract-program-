#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STRACT Programming Language - Command Line Interface v5.0
Revolutionary Language with AI-Native, Reactive & Contractual Safety Features
"""

import sys
import os
import argparse
import time
import json
from typing import Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STRACT_DIR = os.path.join(BASE_DIR, 'STRACTPROGRAMzip', 'SystemRefactor')
sys.path.insert(0, STRACT_DIR)

try:
    from main import Lexer, Parser, Interpreter, LexerError, ParserError, RuntimeError as STRACTRuntimeError
except ImportError as e:
    print(f"Error importing STRACT modules: {e}")
    print("Please ensure the STRACT interpreter is properly installed.")
    sys.exit(1)

VERSION = "5.0.0"
STRACT_LOGO = """
╔═══════════════════════════════════════════════════════════╗
║   ███████╗████████╗██████╗  █████╗  ██████╗████████╗     ║
║   ██╔════╝╚══██╔══╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝     ║
║   ███████╗   ██║   ██████╔╝███████║██║        ██║        ║
║   ╚════██║   ██║   ██╔══██╗██╔══██║██║        ██║        ║
║   ███████║   ██║   ██║  ██║██║  ██║╚██████╗   ██║        ║
║   ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝   ╚═╝        ║
║                                                           ║
║   Programming Language v5.0 - Revolutionary               ║
║   AI-Native • Reactive • Contractual Safety               ║
╚═══════════════════════════════════════════════════════════╝
"""

class STRACTInterpreterWrapper:
    """Wrapper for STRACT interpreter with enhanced features"""
    
    def __init__(self):
        self.interpreter = Interpreter()
        self.history = []
        self.debug_mode = False
        self.show_tokens = False
        self.show_ast = False
    
    def run_code(self, code: str, filename: str = "<input>") -> bool:
        """Run STRACT code and return success status"""
        try:
            if self.show_tokens:
                print("\n[TOKENS]")
                lexer = Lexer(code)
                tokens = lexer.tokenize()
                for tok in tokens[:50]:
                    print(f"  {tok}")
                if len(tokens) > 50:
                    print(f"  ... ({len(tokens) - 50} more tokens)")
                print()
            
            lexer = Lexer(code)
            tokens = lexer.tokenize()
            parser = Parser(tokens)
            ast = parser.parse()
            
            if self.show_ast:
                print("\n[AST]")
                print(f"  Program with {len(ast.statements)} statements")
                print()
            
            self.interpreter.execute(ast)
            return True
            
        except LexerError as e:
            self._print_error("Lexer Error", str(e), filename)
            return False
        except ParserError as e:
            self._print_error("Parser Error", str(e), filename)
            return False
        except STRACTRuntimeError as e:
            self._print_error("Runtime Error", str(e), filename)
            return False
        except Exception as e:
            self._print_error("Error", str(e), filename)
            if self.debug_mode:
                import traceback
                traceback.print_exc()
            return False
    
    def _print_error(self, error_type: str, message: str, filename: str):
        """Print formatted error message"""
        print(f"\n{'='*60}")
        print(f"Error in {filename}")
        print(f"{'='*60}")
        print(f"{error_type}: {message}")
        print(f"{'='*60}\n")
        
        try:
            ai_path = os.path.join(STRACT_DIR, 'AI_INTEGRATION')
            if ai_path not in sys.path:
                sys.path.insert(0, ai_path)
            from ai_integration import STRACTAI
            ai = STRACTAI()
            explanation = ai.explain_error(message)
            print(explanation)
        except Exception:
            pass

def run_file(filepath: str, debug: bool = False, show_tokens: bool = False, show_ast: bool = False):
    """Run a STRACT file"""
    if not os.path.exists(filepath):
        print(f"Error: File '{filepath}' not found")
        return False
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            code = f.read()
    except Exception as e:
        print(f"Error reading file: {e}")
        return False
    
    wrapper = STRACTInterpreterWrapper()
    wrapper.debug_mode = debug
    wrapper.show_tokens = show_tokens
    wrapper.show_ast = show_ast
    
    start_time = time.time()
    success = wrapper.run_code(code, filepath)
    end_time = time.time()
    
    if debug:
        print(f"\nExecution time: {end_time - start_time:.4f}s")
    
    return success

def run_repl():
    """Run interactive REPL"""
    print(STRACT_LOGO)
    print("Type 'help' for commands, 'exit' to quit\n")
    
    wrapper = STRACTInterpreterWrapper()
    multiline_mode = False
    multiline_buffer = []
    
    while True:
        try:
            if multiline_mode:
                prompt = "...   "
            else:
                prompt = "stract> "
            
            line = input(prompt)
            
            if multiline_mode:
                if line.strip() == "":
                    code = "\n".join(multiline_buffer)
                    multiline_mode = False
                    multiline_buffer = []
                    wrapper.run_code(code)
                else:
                    multiline_buffer.append(line)
                continue
            
            line_stripped = line.strip()
            
            if not line_stripped:
                continue
            
            if line_stripped in ('exit', 'quit', 'q'):
                print("Goodbye!")
                break
            
            if line_stripped == 'help':
                print_repl_help()
                continue
            
            if line_stripped == 'clear':
                os.system('clear' if os.name != 'nt' else 'cls')
                print(STRACT_LOGO)
                continue
            
            if line_stripped == 'debug':
                wrapper.debug_mode = not wrapper.debug_mode
                print(f"Debug mode: {'ON' if wrapper.debug_mode else 'OFF'}")
                continue
            
            if line_stripped == 'tokens':
                wrapper.show_tokens = not wrapper.show_tokens
                print(f"Show tokens: {'ON' if wrapper.show_tokens else 'OFF'}")
                continue
            
            if line_stripped == 'ast':
                wrapper.show_ast = not wrapper.show_ast
                print(f"Show AST: {'ON' if wrapper.show_ast else 'OFF'}")
                continue
            
            if line_stripped == 'version':
                print(f"STRACT v{VERSION}")
                continue
            
            if line_stripped.startswith('run '):
                filepath = line_stripped[4:].strip()
                run_file(filepath, wrapper.debug_mode)
                continue
            
            if line_stripped.startswith('load '):
                filepath = line_stripped[5:].strip()
                try:
                    with open(filepath, 'r') as f:
                        code = f.read()
                    print(f"Loaded: {filepath}")
                    wrapper.run_code(code, filepath)
                except Exception as e:
                    print(f"Error: {e}")
                continue
            
            if line_stripped == 'multi':
                print("Enter multi-line code (empty line to execute):")
                multiline_mode = True
                continue
            
            if line_stripped.endswith(':'):
                multiline_mode = True
                multiline_buffer = [line]
                continue
            
            wrapper.run_code(line)
            
        except KeyboardInterrupt:
            print("\nUse 'exit' to quit")
        except EOFError:
            print("\nGoodbye!")
            break

def print_repl_help():
    """Print REPL help"""
    print("""
STRACT REPL Commands:
=====================
  help      - Show this help
  exit/quit - Exit REPL
  clear     - Clear screen
  debug     - Toggle debug mode
  tokens    - Toggle token display
  ast       - Toggle AST display
  version   - Show version
  run FILE  - Run a file
  load FILE - Load and run file
  multi     - Enter multi-line mode

Language Basics:
================
  let x = 10              - Variable declaration
  const PI = 3.14         - Constant
  func add(a, b):         - Function
      return a + b
  print "Hello"           - Print output
  if x > 5:               - Conditionals
      print "big"
  for i in range(5):      - Loops
      print i
""")

def print_commands_reference():
    """Print complete command reference"""
    print("""
STRACT COMPLETE COMMAND REFERENCE
=================================

1. TERMINAL COMMANDS (CLI)
--------------------------
  stract run <file>          Run a STRACT file
  stract repl                Start interactive REPL
  stract version             Show version
  stract help                Show help
  stract check <file>        Check syntax without running
  stract fmt <file>          Format code
  stract new <project>       Create new project
  stract web <file>          Run web application
  stract test <file>         Run tests
  stract analyze <file>      AI code analysis
  stract docs                Open documentation

2. VARIABLE DECLARATION
-----------------------
  let x = 10                 Mutable variable
  const PI = 3.14            Constant (immutable)
  var name = "Ali"           Alternative syntax

3. DATA TYPES
-------------
  10, 3.14                   Numbers (int, float)
  "Hello"                    String
  true, false                Boolean
  null                       Null value
  [1, 2, 3]                  List
  {"key": "value"}           Dictionary

4. OPERATORS
------------
  + - * / %                  Arithmetic
  **                         Power
  //                         Floor division
  == != < > <= >=            Comparison
  and or not                 Logical
  in                         Membership
  += -= *= /=                Compound assignment

5. CONTROL FLOW
---------------
  if condition:
      # code
  elif condition:
      # code
  else:
      # code

  for item in list:
      # code

  for i in range(10):
      # code

  while condition:
      # code

  match value:
      case 1:
          # code
      case 2:
          # code
      default:
          # code

6. FUNCTIONS
------------
  func name(param1, param2):
      return result

  func greet(name="World"):
      print "Hello, " + name

  lambda x: x * 2

7. CLASSES & OBJECTS
--------------------
  class Person:
      func init(name):
          this.name = name
      
      func greet():
          print "Hello, " + this.name

  let p = new Person("Ali")
  p.greet()

8. ERROR HANDLING
-----------------
  try:
      risky_code()
  catch error:
      print "Error:", error
  finally:
      cleanup()

  throw "Custom error message"

9. MODULES
----------
  import math
  import http as web
  from utils import helper

10. BUILT-IN FUNCTIONS
----------------------
  print(value)               Output to console
  input(prompt)              Get user input
  len(obj)                   Length
  str(value)                 Convert to string
  int(value)                 Convert to integer
  float(value)               Convert to float
  bool(value)                Convert to boolean
  type(value)                Get type
  range(start, end, step)    Generate range
  abs(num)                   Absolute value
  min(a, b, ...)             Minimum
  max(a, b, ...)             Maximum
  sum(list)                  Sum of list
  sorted(list)               Sort list
  reversed(list)             Reverse list
  enumerate(list)            Enumerate list
  zip(list1, list2)          Zip lists
  map(func, list)            Map function
  filter(func, list)         Filter list
  reduce(func, list)         Reduce list
  any(list)                  Any true
  all(list)                  All true
  round(num, digits)         Round number
  floor(num)                 Floor
  ceil(num)                  Ceiling
  sqrt(num)                  Square root
  pow(base, exp)             Power
  sin(x), cos(x), tan(x)     Trigonometry
  log(x), exp(x)             Logarithm/Exponential
  random()                   Random 0-1
  randint(min, max)          Random integer
  choice(list)               Random choice
  shuffle(list)              Shuffle list
  time()                     Current time
  sleep(seconds)             Sleep
  exit()                     Exit program
  assert(condition, msg)     Assert

11. STRING METHODS
------------------
  s.upper()                  Uppercase
  s.lower()                  Lowercase
  s.strip()                  Remove whitespace
  s.split(sep)               Split string
  s.join(list)               Join list
  s.replace(old, new)        Replace
  s.find(sub)                Find substring
  s.startswith(prefix)       Check start
  s.endswith(suffix)         Check end
  s.contains(sub)            Contains
  s.capitalize()             Capitalize
  s.title()                  Title case
  s.isdigit()                Is digit
  s.isalpha()                Is alpha
  s.reverse()                Reverse
  s.format(...)              Format string

12. LIST METHODS
----------------
  l.append(item)             Add item
  l.pop(index)               Remove item
  l.insert(index, item)      Insert at index
  l.remove(item)             Remove by value
  l.extend(list)             Extend list
  l.clear()                  Clear list
  l.copy()                   Copy list
  l.index(item)              Find index
  l.count(item)              Count items
  l.sort()                   Sort list
  l.reverse()                Reverse list
  l.first()                  First item
  l.last()                   Last item
  l.sum()                    Sum
  l.min()                    Minimum
  l.max()                    Maximum
  l.avg()                    Average
  l.map(func)                Map function
  l.filter(func)             Filter
  l.reduce(func)             Reduce
  l.unique()                 Unique items
  l.flatten()                Flatten nested

13. DICT METHODS
----------------
  d.keys()                   Get keys
  d.values()                 Get values
  d.items()                  Get items
  d.get(key, default)        Get with default
  d.pop(key)                 Remove key
  d.update(dict)             Update dict
  d.clear()                  Clear dict
  d.copy()                   Copy dict

14. WEB DEVELOPMENT
-------------------
  import web

  let app = web.create_app()

  @app.get("/")
  func index(request):
      return {"message": "Hello!"}

  @app.post("/api/users")
  func create_user(request):
      let data = request.json_data
      return {"id": 1, ...data}

  @app.get("/users/<id>")
  func get_user(request, id):
      return {"user_id": id}

  app.run(port=5000)

15. AI INTEGRATION
------------------
  import ai

  let analysis = ai.analyze(code)
  let suggestions = ai.suggest(code, position)
  let explanation = ai.explain_error(error)
  let generated = ai.generate("description")
  let fixed = ai.auto_fix(code, error)

16. FILE OPERATIONS
-------------------
  import file

  let content = file.read("path.txt")
  file.write("path.txt", content)
  file.append("path.txt", content)
  let exists = file.exists("path.txt")
  file.delete("path.txt")
  file.copy("src", "dest")
  file.move("src", "dest")
  let files = file.list("directory")

17. MATH OPERATIONS
-------------------
  import math

  math.PI                    3.14159...
  math.E                     2.71828...
  math.sqrt(x)               Square root
  math.pow(x, y)             Power
  math.sin(x), cos(x)        Trigonometry
  math.log(x), exp(x)        Logarithm
  math.floor(x), ceil(x)     Rounding
  math.abs(x)                Absolute value
  math.factorial(n)          Factorial
  math.gcd(a, b)             GCD
  math.lcm(a, b)             LCM

18. HTTP/NETWORKING
-------------------
  import http

  let response = http.get("url")
  let response = http.post("url", data)
  let response = http.put("url", data)
  let response = http.delete("url")

  print response.status
  print response.body
  print response.json()

19. JSON OPERATIONS
-------------------
  import json

  let data = json.parse(string)
  let string = json.stringify(data)
  let data = json.load("file.json")
  json.save("file.json", data)

20. DECORATORS
--------------
  @decorator
  func my_func():
      # code

  @app.route("/path")
  func handler(request):
      # code

EXAMPLES
========

Hello World:
  print "Hello, World!"

Calculator:
  let a = int(input("Enter first number: "))
  let b = int(input("Enter second number: "))
  print "Sum:", a + b

Fibonacci:
  func fib(n):
      if n <= 1:
          return n
      return fib(n-1) + fib(n-2)
  
  for i in range(10):
      print fib(i)

Web API:
  import web
  
  let app = web.create_app()
  let db = []
  
  @app.get("/api/items")
  func get_items(request):
      return {"items": db}
  
  @app.post("/api/items")
  func add_item(request):
      db.append(request.json_data)
      return {"success": true}
  
  app.run(port=5000)
""")

def analyze_code(filepath: str):
    """Analyze code with AI"""
    if not os.path.exists(filepath):
        print(f"Error: File '{filepath}' not found")
        return
    
    with open(filepath, 'r') as f:
        code = f.read()
    
    try:
        ai_module_path = os.path.join(STRACT_DIR, 'AI_INTEGRATION')
        if ai_module_path not in sys.path:
            sys.path.insert(0, ai_module_path)
        from ai_integration import STRACTAI
        
        ai = STRACTAI()
        analysis = ai.analyze_code(code)
        
        print(f"\nSTRACT AI Code Analysis: {filepath}")
        print("=" * 60)
        print(f"Total Lines: {analysis['total_lines']}")
        print(f"Code Lines: {analysis['code_lines']}")
        print(f"Complexity: {analysis['complexity']} (score: {analysis['complexity_score']})")
        print(f"Quality Score: {analysis['code_quality_score']}/100")
        
        if analysis['suggestions']:
            print("\nSuggestions:")
            for s in analysis['suggestions']:
                print(f"  - {s}")
        
        if analysis['potential_issues']:
            print("\nPotential Issues:")
            for issue in analysis['potential_issues']:
                print(f"  Line {issue['line']}: [{issue['severity']}] {issue['message']}")
        
        if analysis['optimization_opportunities']:
            print("\nOptimizations:")
            for o in analysis['optimization_opportunities']:
                print(f"  - {o}")
    except Exception as e:
        print(f"Error in analysis: {e}")

def check_syntax(filepath: str):
    """Check file syntax without running"""
    if not os.path.exists(filepath):
        print(f"Error: File '{filepath}' not found")
        return False
    
    with open(filepath, 'r') as f:
        code = f.read()
    
    try:
        lexer = Lexer(code)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        parser.parse()
        print(f"Syntax OK: {filepath}")
        return True
    except LexerError as e:
        print(f"Lexer Error: {e}")
        return False
    except ParserError as e:
        print(f"Parser Error: {e}")
        return False

def run_web_server(filepath: str, port: int = 5000):
    """Run a web server from STRACT file"""
    if not os.path.exists(filepath):
        print(f"Error: File '{filepath}' not found")
        return
    
    print(f"Starting STRACT Web Server on port {port}...")
    print(f"Loading: {filepath}")
    
    try:
        with open(filepath, 'r') as f:
            code = f.read()
        
        wrapper = STRACTInterpreterWrapper()
        print("\n--- Executing STRACT file ---")
        wrapper.run_code(code, filepath)
        print("--- STRACT execution complete ---\n")
        
        web_module_path = os.path.join(STRACT_DIR, 'WEB_SERVER')
        if web_module_path not in sys.path:
            sys.path.insert(0, web_module_path)
        from web_framework import create_app
        
        app = create_app(port=port)
        
        @app.get("/")
        def index(request):
            return {"message": "STRACT Web Server v4.0", "status": "running", "file": filepath}
        
        @app.get("/health")
        def health(request):
            return {"status": "ok"}
        
        print(f"\nWeb server running at http://0.0.0.0:{port}")
        print("Press Ctrl+C to stop")
        app.run(port=port)
    except Exception as e:
        print(f"Error starting web server: {e}")

def create_new_project(name: str):
    """Create a new STRACT project"""
    if os.path.exists(name):
        print(f"Error: Directory '{name}' already exists")
        return
    
    os.makedirs(name)
    os.makedirs(os.path.join(name, 'src'))
    os.makedirs(os.path.join(name, 'tests'))
    
    main_content = '''# Main STRACT Application
# Project: {name}

print "Welcome to {name}!"

func main():
    print "Starting application..."
    # Add your code here
    return 0

main()
'''.format(name=name)
    
    with open(os.path.join(name, 'src', 'main.stract'), 'w') as f:
        f.write(main_content)
    
    config_content = {
        "name": name,
        "version": "1.0.0",
        "main": "src/main.stract",
        "scripts": {
            "start": "stract run src/main.stract",
            "test": "stract test tests/",
            "build": "stract build"
        }
    }
    
    with open(os.path.join(name, 'stract.json'), 'w') as f:
        json.dump(config_content, f, indent=2)
    
    readme_content = f'''# {name}

A STRACT programming language project.

## Getting Started

```bash
cd {name}
stract run src/main.stract
```

## Commands

- `stract run src/main.stract` - Run the application
- `stract repl` - Interactive mode
- `stract test tests/` - Run tests
'''
    
    with open(os.path.join(name, 'README.md'), 'w') as f:
        f.write(readme_content)
    
    print(f"Created new project: {name}")
    print(f"  cd {name}")
    print(f"  stract run src/main.stract")

def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='STRACT Programming Language v4.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  stract run program.stract     Run a STRACT program
  stract repl                   Start interactive REPL
  stract check file.stract      Check syntax
  stract analyze file.stract    AI code analysis
  stract web app.stract         Run web server
  stract new myproject          Create new project
  stract commands               Show all commands
        """
    )
    
    parser.add_argument('command', nargs='?', default='repl',
                        help='Command to run (run, repl, check, analyze, web, new, version, commands)')
    parser.add_argument('file', nargs='?', help='File to run or project name')
    parser.add_argument('-d', '--debug', action='store_true', help='Enable debug mode')
    parser.add_argument('-t', '--tokens', action='store_true', help='Show tokens')
    parser.add_argument('-a', '--ast', action='store_true', help='Show AST')
    parser.add_argument('-p', '--port', type=int, default=5000, help='Port for web server')
    parser.add_argument('-v', '--version', action='store_true', help='Show version')
    
    args = parser.parse_args()
    
    if args.version:
        print(f"STRACT v{VERSION}")
        return
    
    command = args.command.lower()
    
    if command == 'version':
        print(f"STRACT v{VERSION}")
    
    elif command == 'repl':
        run_repl()
    
    elif command == 'run':
        if not args.file:
            print("Error: Please specify a file to run")
            print("Usage: stract run <file.stract>")
            return
        run_file(args.file, args.debug, args.tokens, args.ast)
    
    elif command == 'check':
        if not args.file:
            print("Error: Please specify a file to check")
            return
        check_syntax(args.file)
    
    elif command == 'analyze':
        if not args.file:
            print("Error: Please specify a file to analyze")
            return
        analyze_code(args.file)
    
    elif command == 'web':
        filepath = args.file or 'app.stract'
        run_web_server(filepath, args.port)
    
    elif command == 'new':
        if not args.file:
            print("Error: Please specify a project name")
            return
        create_new_project(args.file)
    
    elif command == 'commands':
        print_commands_reference()
    
    elif command == 'help':
        parser.print_help()
    
    elif command.endswith('.stract'):
        run_file(command, args.debug, args.tokens, args.ast)
    
    else:
        if os.path.exists(command):
            run_file(command, args.debug, args.tokens, args.ast)
        else:
            print(f"Unknown command: {command}")
            parser.print_help()

if __name__ == "__main__":
    main()
