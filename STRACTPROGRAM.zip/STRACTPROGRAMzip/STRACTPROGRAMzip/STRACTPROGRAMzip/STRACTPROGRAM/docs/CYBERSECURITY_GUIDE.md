# 🔒 دليل الأمن السبراني - STRACT
# Cybersecurity Guide - STRACT

---

## ⚠️ تحذير مهم:

**هذا الملف يحتوي على أمثلة نظرية تعليمية!**

الدوال والأوامر في هذا الملف **ليست موجودة** في اللغة STRACT الحالية.

👉 **للأوامر التي تعمل فعلاً:** [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)

---

## 📚 المحتويات

1. **أساسيات الأمن السبراني**
2. **معرفة الشبكات والـ WiFi**
3. **الحصول على معلومات IP**
4. **اختبار الأمان**
5. **المراقبة الشبكية**
6. **اختبار كلمات المرور**
7. **تحليل البيانات**
8. **أدوات متقدمة**
9. **أمثلة عملية كاملة**

---

## 1️⃣ أساسيات الأمن السبراني

### ما هو الأمن السبراني؟
حماية الأنظمة والشبكات من الهجمات والتسرب.

### أنواع الهجمات:
- 🔴 **Scanning** - البحث عن نقاط ضعف
- 🔴 **Spoofing** - تزوير الهوية
- 🔴 **DDoS** - إغلاق الخدمات
- 🔴 **Man in the Middle** - التجسس على البيانات
- 🔴 **Brute Force** - محاولة كلمات مرور

### أنواع الاختبارات:
- ✅ **Port Scanning** - فحص المنافذ
- ✅ **Vulnerability Testing** - البحث عن الثغرات
- ✅ **Network Monitoring** - مراقبة الشبكة
- ✅ **Password Testing** - اختبار كلمات المرور

---

## 2️⃣ معرفة الشبكات والـ WiFi

### مثال 1: قائمة الأجهزة على الشبكة

```stract
import network
import ip

let network_scanner = network.create_scanner()

func scan_network(subnet):
    print "🔍 جاري البحث عن الأجهزة على: " + subnet
    
    let devices = []
    let range = ip.generate_range(subnet)
    
    for ip_address in range:
        if network_scanner.ping(ip_address):
            let info = {
                "ip": ip_address,
                "mac": network_scanner.get_mac(ip_address),
                "status": "online",
                "hostname": network_scanner.get_hostname(ip_address)
            }
            devices.append(info)
            print "✅ وجدت جهاز: " + ip_address
    
    return devices

let found_devices = scan_network("192.168.1.0/24")
print "عدد الأجهزة: " + str(len(found_devices))
for device in found_devices:
    print "IP: " + device.ip + " MAC: " + device.mac
```

### مثال 2: كشف شبكات WiFi

```stract
import wifi

let wifi_scanner = wifi.create_scanner()

func find_wifi_networks():
    print "📡 البحث عن شبكات WiFi..."
    
    let networks = wifi_scanner.scan()
    
    print "وجدت " + str(len(networks)) + " شبكة:"
    
    for network in networks:
        print "━━━━━━━━━━━━━━━━━━━━"
        print "الاسم: " + network.ssid
        print "القوة: " + str(network.signal_strength) + "%"
        print "التشفير: " + network.encryption
        print "القناة: " + str(network.channel)
        print "MAC: " + network.bssid
    
    return networks

let networks = find_wifi_networks()
```

### مثال 3: فحص جودة الشبكة

```stract
import network
import time

func check_network_quality(ssid):
    print "🔍 فحص جودة شبكة: " + ssid
    
    let signal_readings = []
    let start_time = time.now()
    
    # جمع قراءات الإشارة
    for i in range(10):
        let signal = network.get_signal_strength(ssid)
        signal_readings.append(signal)
        print "القراءة " + str(i+1) + ": " + str(signal) + "%"
        time.sleep(1)
    
    let avg_signal = sum(signal_readings) / len(signal_readings)
    let min_signal = min(signal_readings)
    let max_signal = max(signal_readings)
    
    print "━━━━━━━━━━━━━━━━━━━━"
    print "متوسط الإشارة: " + str(avg_signal) + "%"
    print "أضعف قراءة: " + str(min_signal) + "%"
    print "أقوى قراءة: " + str(max_signal) + "%"
    
    if avg_signal > 70:
        print "✅ الشبكة قوية"
    elif avg_signal > 40:
        print "⚠️ الشبكة متوسطة"
    else:
        print "❌ الشبكة ضعيفة"

check_network_quality("MyWiFi")
```

---

## 3️⃣ الحصول على معلومات IP

### مثال 1: معلومات IP المحلي

```stract
import ip_tools

func get_local_ip():
    print "📍 معلومات IP المحلي"
    
    let ip_info = ip_tools.get_local_info()
    
    print "━━━━━━━━━━━━━━━━━━━━"
    print "عنوان IP: " + ip_info.ip
    print "Subnet Mask: " + ip_info.subnet_mask
    print "Default Gateway: " + ip_info.gateway
    print "MAC Address: " + ip_info.mac
    print "DNS Server: " + ip_info.dns
    
    return ip_info

let local_info = get_local_ip()
```

### مثال 2: معلومات IP عام (مثل موقعك الجغرافي)

```stract
import ip_geo

func get_public_ip_info():
    print "🌍 معلومات IP العام"
    
    let public_ip = ip_geo.get_public_ip()
    let info = ip_geo.get_geo_info(public_ip)
    
    print "━━━━━━━━━━━━━━━━━━━━"
    print "عنوان IP: " + public_ip
    print "الدولة: " + info.country
    print "المدينة: " + info.city
    print "ISP: " + info.isp
    print "خط العرض: " + str(info.latitude)
    print "خط الطول: " + str(info.longitude)
    
    return info

let public_info = get_public_ip_info()
```

### مثال 3: معلومات عن نطاق محدد

```stract
import dns
import ip_tools

func get_domain_ips(domain):
    print "🔎 معلومات نطاق: " + domain
    
    let ips = dns.resolve(domain)
    
    print "عناوين IP:"
    for ip_addr in ips:
        let info = ip_tools.get_info(ip_addr)
        print "━━━━━━━━━━━━━━━━━━━━"
        print "IP: " + ip_addr
        print "ISP: " + info.isp
        print "النوع: " + info.type
        print "رمز البلد: " + info.country_code
    
    return ips

let ips = get_domain_ips("example.com")
```

---

## 4️⃣ فحص المنافذ والخدمات

### مثال 1: Port Scanning بسيط

```stract
import port_scan
import time

func scan_ports(target_ip, start_port, end_port):
    print "🔍 فحص المنافذ على: " + target_ip
    print "من المنفذ: " + str(start_port) + " إلى: " + str(end_port)
    
    let open_ports = []
    
    for port in range(start_port, end_port + 1):
        if port_scan.is_open(target_ip, port):
            let service = port_scan.get_service(port)
            let info = {
                "port": port,
                "service": service,
                "status": "open"
            }
            open_ports.append(info)
            print "✅ منفذ مفتوح: " + str(port) + " (" + service + ")"
        
        # تأخير لتجنب الكشف
        time.sleep(0.5)
    
    print "━━━━━━━━━━━━━━━━━━━━"
    print "عدد المنافذ المفتوحة: " + str(len(open_ports))
    
    return open_ports

let open = scan_ports("192.168.1.1", 1, 1000)
```

### مثال 2: معرفة الخدمات على المنافذ

```stract
import port_scan

func identify_services(target_ip):
    print "🔧 تحديد الخدمات على: " + target_ip
    
    let common_ports = [
        21,    # FTP
        22,    # SSH
        25,    # SMTP
        53,    # DNS
        80,    # HTTP
        110,   # POP3
        143,   # IMAP
        443,   # HTTPS
        3306,  # MySQL
        3389,  # RDP
        5432   # PostgreSQL
    ]
    
    let services = []
    
    for port in common_ports:
        if port_scan.is_open(target_ip, port):
            let service_name = port_scan.get_service(port)
            let version = port_scan.detect_version(target_ip, port)
            
            services.append({
                "port": port,
                "name": service_name,
                "version": version,
                "status": "open"
            })
            
            print "✅ " + str(port) + " - " + service_name + " v" + version
    
    return services

let services = identify_services("192.168.1.1")
```

---

## 5️⃣ اختبار كلمات المرور

### مثال 1: اختبار قوة كلمة مرور

```stract
func check_password_strength(password):
    print "🔐 اختبار قوة كلمة المرور"
    
    let score = 0
    let feedback = []
    
    # الطول
    if len(password) >= 8:
        score += 20
    else:
        feedback.append("❌ يجب أن تكون 8 أحرف على الأقل")
    
    # الأحرف الكبيرة
    if password.has_uppercase():
        score += 20
    else:
        feedback.append("❌ أضف أحرف كبيرة (A-Z)")
    
    # الأحرف الصغيرة
    if password.has_lowercase():
        score += 20
    else:
        feedback.append("❌ أضف أحرف صغيرة (a-z)")
    
    # الأرقام
    if password.has_digits():
        score += 20
    else:
        feedback.append("❌ أضف أرقام (0-9)")
    
    # الرموز
    if password.has_symbols():
        score += 20
    else:
        feedback.append("❌ أضف رموز خاصة (!@#$%)")
    
    print "━━━━━━━━━━━━━━━━━━━━"
    print "الدرجة: " + str(score) + "/100"
    
    if score >= 80:
        print "✅ كلمة مرور قوية جداً"
    elif score >= 60:
        print "⚠️ كلمة مرور متوسطة"
    else:
        print "❌ كلمة مرور ضعيفة"
    
    for msg in feedback:
        print msg
    
    return score

check_password_strength("MyP@ssw0rd!")
```

### مثال 2: Brute Force Attack (للاختبار فقط!)

```stract
import time

func brute_force_test(target_password, max_attempts):
    print "⚠️ اختبار Brute Force (للتعليم فقط)"
    print "كلمة المرور الحقيقية: " + target_password
    
    let passwords = [
        "password",
        "123456",
        "qwerty",
        "admin",
        "letmein",
        target_password
    ]
    
    let attempts = 0
    let start_time = time.now()
    
    for attempt_pwd in passwords:
        attempts += 1
        print "محاولة #" + str(attempts) + ": " + attempt_pwd + "..."
        
        if attempt_pwd == target_password:
            let elapsed = time.now() - start_time
            print "━━━━━━━━━━━━━━━━━━━━"
            print "✅ وجدت كلمة المرور!"
            print "بعد " + str(attempts) + " محاولة"
            print "في " + str(elapsed) + " ثانية"
            return true
        
        time.sleep(1)
    
    print "❌ لم أجد كلمة المرور"
    return false

brute_force_test("P@ssw0rd", 100)
```

---

## 6️⃣ المراقبة الشبكية

### مثال 1: مراقبة حركة الشبكة

```stract
import packet_sniffer
import time

func monitor_network(duration):
    print "📊 مراقبة حركة الشبكة"
    print "المدة: " + str(duration) + " ثواني"
    
    let sniffer = packet_sniffer.create_sniffer()
    let packets = []
    let start = time.now()
    
    while time.now() - start < duration:
        let packet = sniffer.capture()
        
        if packet:
            packets.append({
                "source": packet.source_ip,
                "destination": packet.dest_ip,
                "protocol": packet.protocol,
                "size": packet.size,
                "timestamp": time.now()
            })
            
            print "📦 " + packet.protocol + ": " + packet.source_ip + " → " + packet.dest_ip
        
        time.sleep(0.1)
    
    print "━━━━━━━━━━━━━━━━━━━━"
    print "عدد الحزم المقبوضة: " + str(len(packets))
    
    return packets

monitor_network(10)
```

### مثال 2: تحليل حركة الشبكة

```stract
import network

func analyze_traffic():
    print "📈 تحليل حركة الشبكة"
    
    let stats = network.get_statistics()
    
    print "━━━━━━━━━━━━━━━━━━━━"
    print "البيانات المرسلة: " + str(stats.bytes_sent) + " بايت"
    print "البيانات المستقبلة: " + str(stats.bytes_received) + " بايت"
    print "الحزم المرسلة: " + str(stats.packets_sent)
    print "الحزم المستقبلة: " + str(stats.packets_received)
    print "معدل الخطأ: " + str(stats.error_rate) + "%"
    print "معدل الفقدان: " + str(stats.loss_rate) + "%"
    
    let total_data = stats.bytes_sent + stats.bytes_received
    print "━━━━━━━━━━━━━━━━━━━━"
    print "إجمالي البيانات: " + format_size(total_data)
    
    return stats

func format_size(bytes):
    let sizes = ["B", "KB", "MB", "GB"]
    let size = float(bytes)
    let index = 0
    
    while size > 1024 and index < len(sizes) - 1:
        size = size / 1024
        index = index + 1
    
    return str(round(size, 2)) + " " + sizes[index]

analyze_traffic()
```

---

## 7️⃣ تحليل البيانات والتشفير

### مثال 1: التشفير الأساسي

```stract
import crypto

func encrypt_decrypt():
    print "🔐 التشفير والفك"
    
    let message = "السلام عليكم ورحمة الله"
    let key = "MySecretKey123"
    
    # التشفير
    let encrypted = crypto.encrypt(message, key)
    print "الرسالة الأصلية: " + message
    print "الرسالة المشفرة: " + encrypted
    
    # الفك
    let decrypted = crypto.decrypt(encrypted, key)
    print "الرسالة المفكوكة: " + decrypted
    
    if decrypted == message:
        print "✅ التشفير يعمل بشكل صحيح"
    else:
        print "❌ خطأ في التشفير"

encrypt_decrypt()
```

### مثال 2: التجزئة (Hashing)

```stract
import hash_lib

func hash_passwords():
    print "🔐 تجزئة كلمات المرور"
    
    let passwords = [
        "password123",
        "SecurePass@2024",
        "MyP@ssw0rd"
    ]
    
    for pwd in passwords:
        let md5 = hash_lib.md5(pwd)
        let sha1 = hash_lib.sha1(pwd)
        let sha256 = hash_lib.sha256(pwd)
        
        print "━━━━━━━━━━━━━━━━━━━━"
        print "كلمة المرور: " + pwd
        print "MD5: " + md5
        print "SHA-1: " + sha1
        print "SHA-256: " + sha256

hash_passwords()
```

### مثال 3: كشف البيانات الحساسة

```stract
import data_scanner

func find_sensitive_data(text):
    print "🔍 البحث عن بيانات حساسة"
    
    let findings = []
    
    # البحث عن أرقام بطاقات الائتمان
    if data_scanner.has_credit_card(text):
        findings.append("❌ وجدت رقم بطاقة ائتمان!")
    
    # البحث عن أرقام هوية
    if data_scanner.has_ssn(text):
        findings.append("❌ وجدت رقم هوية!")
    
    # البحث عن كلمات المرور
    if data_scanner.has_password(text):
        findings.append("❌ وجدت كلمات مرور مكشوفة!")
    
    # البحث عن عناوين البريد
    if data_scanner.has_email(text):
        let emails = data_scanner.extract_emails(text)
        for email in emails:
            findings.append("⚠️ عنوان بريد: " + email)
    
    # البحث عن أرقام هاتف
    if data_scanner.has_phone(text):
        let phones = data_scanner.extract_phones(text)
        for phone in phones:
            findings.append("⚠️ رقم هاتف: " + phone)
    
    print "عدد النتائج: " + str(len(findings))
    for finding in findings:
        print finding
    
    return findings

find_sensitive_data("My password is P@ss123 and email is test@example.com")
```

---

## 8️⃣ أدوات متقدمة

### مثال 1: أداة فحص شاملة

```stract
import security

func full_security_scan(target):
    print "🛡️ فحص أمان شامل للـ: " + target
    
    let report = {
        "target": target,
        "timestamp": time.now(),
        "results": []
    }
    
    # 1. فحص المنافذ
    print "⏳ فحص المنافذ..."
    let ports = scan_ports(target, 1, 65535)
    report.results.append({"type": "ports", "count": len(ports), "data": ports})
    
    # 2. فحص الخدمات
    print "⏳ تحديد الخدمات..."
    let services = identify_services(target)
    report.results.append({"type": "services", "count": len(services), "data": services})
    
    # 3. فحص الثغرات
    print "⏳ البحث عن الثغرات..."
    let vulns = find_vulnerabilities(target, services)
    report.results.append({"type": "vulnerabilities", "count": len(vulns), "data": vulns})
    
    print "━━━━━━━━━━━━━━━━━━━━"
    print "✅ انتهى الفحص"
    print "عدد المشاكل المكتشفة: " + str(len(vulns))
    
    return report

func find_vulnerabilities(target, services):
    let vulns = []
    
    for service in services:
        if service.name == "FTP":
            vulns.append({"service": "FTP", "risk": "high", "fix": "حدّث إلى SFTP"})
        elif service.name == "Telnet":
            vulns.append({"service": "Telnet", "risk": "high", "fix": "استخدم SSH"})
        elif service.name == "HTTP":
            vulns.append({"service": "HTTP", "risk": "medium", "fix": "استخدم HTTPS"})
    
    return vulns

full_security_scan("192.168.1.1")
```

### مثال 2: مراقب الأمان المستمر

```stract
import time

func continuous_monitoring(interval):
    print "🔒 مراقب الأمان المستمر"
    print "الفاصل الزمني: " + str(interval) + " ثانية"
    
    let alerts = []
    let is_running = true
    
    while is_running:
        let timestamp = time.now()
        
        # فحص الشبكة
        let status = check_network_status()
        if not status.is_healthy:
            let alert = {
                "timestamp": timestamp,
                "type": "network",
                "severity": "high",
                "message": status.message
            }
            alerts.append(alert)
            print "🚨 تنبيه: " + status.message
        
        # فحص المنافذ المفتوحة غير المتوقعة
        let ports = get_open_ports()
        for port in ports:
            if not is_expected_port(port):
                let alert = {
                    "timestamp": timestamp,
                    "type": "port",
                    "port": port,
                    "severity": "medium"
                }
                alerts.append(alert)
                print "⚠️ منفذ غير متوقع: " + str(port)
        
        # التأخير
        time.sleep(interval)
    
    return alerts

func check_network_status():
    return {
        "is_healthy": true,
        "message": "الشبكة صحية"
    }

func get_open_ports():
    return []

func is_expected_port(port):
    return port in [22, 80, 443]

# continuous_monitoring(60)  # كل دقيقة
```

---

## 9️⃣ أمثلة عملية كاملة

### مثال 1: لوحة قيادة الأمان

```stract
import time
import web

let app = web.create_app()

let security_status = {
    "ports_open": 0,
    "threats_detected": 0,
    "last_scan": "",
    "network_health": "good"
}

@app.get("/")
func dashboard(request):
    return {
        "title": "لوحة قيادة الأمان",
        "status": security_status
    }

@app.get("/scan")
func start_scan(request):
    print "🔍 بدء الفحص..."
    let results = {
        "ports": 5,
        "services": 3,
        "threats": 2,
        "timestamp": time.now()
    }
    return results

@app.get("/alerts")
func get_alerts(request):
    return {
        "alerts": [
            {"type": "port", "port": 23, "severity": "high"},
            {"type": "service", "service": "FTP", "severity": "high"}
        ]
    }

app.run(port=5000)
```

### مثال 2: أداة فحص كاملة

```stract
func main():
    print "╔════════════════════════════════╗"
    print "║  أداة فحص الأمان - STRACT     ║"
    print "║  Security Scanner v1.0         ║"
    print "╚════════════════════════════════╝"
    print ""
    
    while true:
        print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        print "الخيارات:"
        print "1. فحص المنافذ"
        print "2. معرفة الشبكات"
        print "3. معرفة معلومات IP"
        print "4. فحص قوة كلمة المرور"
        print "5. مراقبة حركة الشبكة"
        print "6. فحص شامل"
        print "0. خروج"
        print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        
        let choice = input("اختر: ")
        
        if choice == "1":
            let ip = input("أدخل IP: ")
            scan_ports(ip, 1, 1000)
        elif choice == "2":
            find_wifi_networks()
        elif choice == "3":
            get_public_ip_info()
        elif choice == "4":
            let pwd = input("أدخل كلمة المرور: ")
            check_password_strength(pwd)
        elif choice == "5":
            monitor_network(30)
        elif choice == "6":
            let target = input("أدخل الهدف: ")
            full_security_scan(target)
        elif choice == "0":
            print "وداعاً!"
            break
        else:
            print "❌ خيار غير صحيح"
        
        print ""

main()
```

---

## 🔟 الأمان والأخلاقيات

### ⚠️ تحذيرات مهمة:

```
❌ لا تفحص أجهزة لا تملكها
❌ لا تحاول اختراق أي نظام
❌ لا تستخدم هذه الأدوات بشكل ضار
❌ احصل على إذن قبل الاختبار

✅ استخدم هذه الأدوات للتعلم فقط
✅ اختبر على أجهزتك الخاصة
✅ احترم الخصوصية
✅ التزم بالقوانين
```

### أفضل الممارسات:

```stract
func ethical_hacking():
    print "ما يجب فعله:"
    print "✅ احصل على إذن كتابي"
    print "✅ اختبر في بيئة آمنة"
    print "✅ وثّق كل النتائج"
    print "✅ أخبر المالك بالثغرات"
    print "✅ امنح وقتاً لإصلاح"
    print "✅ احترم السرية"
    
    print ""
    print "ما لا يجب فعله:"
    print "❌ اختبر بدون إذن"
    print "❌ استخدم في أغراض ضارة"
    print "❌ شارك الثغرات علناً"
    print "❌ احفظ بيانات حساسة"
    print "❌ تلف الأنظمة"

ethical_hacking()
```

---

## 1️⃣1️⃣ الموارد الإضافية

### كتب مشهورة:
- "The Web Application Hacker's Handbook"
- "Penetration Testing"
- "The Hacker Playbook"

### أدوات مشهورة:
- Nmap - فحص المنافذ
- Wireshark - تحليل الحزم
- Metasploit - اختبار الثغرات
- Burp Suite - اختبار التطبيقات

### منصات تعليمية:
- HackTheBox - تحديات عملية
- TryHackMe - دورات تفاعلية
- PicoCTF - منافسات أمان

---

## 📝 ملخص سريع

| المهمة | الأمر |
|-------|-------|
| فحص المنافذ | `scan_ports(ip, 1, 1000)` |
| كشف WiFi | `find_wifi_networks()` |
| معرفة IP | `get_public_ip_info()` |
| قوة كلمة المرور | `check_password_strength(pwd)` |
| مراقبة الشبكة | `monitor_network(duration)` |
| فحص شامل | `full_security_scan(target)` |

---

## 📚 ملفات إضافية

- [START_HERE.md](START_HERE.md) - البدء السريع
- [QUICK_START.md](QUICK_START.md) - أمثلة بسيطة
- [WEB_ROUTING_GUIDE.md](WEB_ROUTING_GUIDE.md) - بناء مواقع ويب

---

**⚠️ استخدم هذه المعرفة بحكمة وأخلاق! 🔒**

**Happy Hacking! (Ethically) 🎯**
