# تحميل وتشغيل STRACT على حاسوبك
# Download and Run STRACT on Your Computer

---

## ⚠️ ملاحظة مهمة:

**في Replit الآن**: لا تحتاج للتحميل! جرّب مباشرة:
```bash
python stract_cli.py repl
```

👉 **للأوامر الفعلية: [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)**

---

## 📥 الخطوة 1: تحميل الملفات من Replit

### أ) افتح Replit وانقر على الملفات

**الخطوة 1:** افتح https://replit.com (أنت موجود هنا الآن)

**الخطوة 2:** انقر على أيقونة الملفات في اليسار
```
📁 Files
```

**الخطوة 3:** ستظهر قائمة الملفات:
```
stract_cli.py
examples/
docs/
STRACTPROGRAMzip/
...
```

---

### ب) تحميل المجلد كاملاً (الطريقة الأسهل)

**الخطوة 1:** انقر على المجلد الرئيسي (STRACT)

**الخطوة 2:** انقر على الثلاث نقاط ⋮

**الخطوة 3:** اختر **"Download as zip"**

**الخطوة 4:** الملف سيبدأ في التحميل تلقائياً
```
stract-language.zip (تقريباً 50 MB)
```

**الخطوة 5:** انتظر حتى ينتهي التحميل

---

### ج) أو تحميل ملفات محددة فقط

إذا كنت تريد ملفات معينة فقط:

**الملفات المهمة:**
```
✅ stract_cli.py (مهم جداً)
✅ examples/ (الأمثلة)
✅ STRACTPROGRAMzip/ (محرك STRACT)
✅ docs/ (الوثائق - اختياري)
```

---

## 💾 الخطوة 2: فك الضغط على حاسوبك

### على Windows:

**الخطوة 1:** افتح "Downloads" (ملف التحميل)

**الخطوة 2:** اجد الملف `stract-language.zip`

**الخطوة 3:** انقر عليه بزر الفأرة الأيمن

**الخطوة 4:** اختر **"Extract All"** أو **"استخراج الكل"**

**الخطوة 5:** اختر مكان لحفظ الملفات
```
C:\Users\YourName\STRACT
```

**الخطوة 6:** اضغط "Extract"

---

### على Mac:

**الخطوة 1:** افتح "Downloads"

**الخطوة 2:** ابحث عن `stract-language.zip`

**الخطوة 3:** انقر عليه مرتين (ينفك الضغط تلقائياً)

**الخطوة 4:** الملفات تظهر في نفس المجلد

---

### على Linux:

**الخطوة 1:** افتح Terminal

**الخطوة 2:** انتقل إلى مجلد التحميل
```bash
cd ~/Downloads
```

**الخطوة 3:** فك الضغط
```bash
unzip stract-language.zip
cd stract-language
```

---

## 🖥️ الخطوة 3: فتح Terminal في المجلد

### على Windows:

**الطريقة 1 (الأسهل):**
1. افتح مجلد `STRACT`
2. انقر على شريط العنوان (الأعلى)
3. اكتب `cmd` واضغط Enter
4. Terminal يفتح في هذا المجلد

**الطريقة 2:**
1. اضغط `Windows + R`
2. اكتب `cmd`
3. اضغط Enter
4. اكتب:
```bash
cd C:\Users\YourName\STRACT
```

---

### على Mac:

**الطريقة 1:**
1. افتح Terminal (Spotlight + اكتب Terminal)
2. اكتب:
```bash
cd ~/stract-language
```

**الطريقة 2 (أسهل):**
1. افتح Finder
2. انقر على المجلد بزر الفأرة الأيمن
3. اختر "New Terminal at Folder"

---

### على Linux:

1. افتح Terminal
2. انتقل للمجلد:
```bash
cd ~/stract-language
```

أو اضغط كليك يمين في المجلد وختر "Open Terminal Here"

---

## ✅ الخطوة 4: تحقق من التثبيت

اكتب هذا الأمر في Terminal:

```bash
python --version
```

**يجب أن تظهر:**
```
Python 3.11.x
```

إذا لم تظهر أي شيء أو ظهر خطأ، اكتب:
```bash
python3 --version
```

---

## 🚀 الخطوة 5: شغل STRACT!

### الوضع التفاعلي (الأسهل):

اكتب في Terminal:
```bash
python stract_cli.py repl
```

**يجب أن تظهر:**
```
╔═══════════════════════════════════╗
║   STRACT Programming Language     ║
╚═══════════════════════════════════╝

Type 'help' for commands, 'exit' to quit
stract>
```

**الآن اكتب:**
```
stract> print "مرحبا من حاسوبي!"
stract> exit
```

---

### تشغيل مثال:

اكتب في Terminal:
```bash
python stract_cli.py run examples/hello.stract
```

**يجب أن تظهر:**
```
Welcome to STRACT v4.0!
========================================
...
```

---

## 🎯 مثال عملي كامل

### على Windows:

**الخطوة 1:** فك الملف
```
C:\Users\YourName\Downloads\stract-language.zip
→ استخراج إلى: C:\Users\YourName\STRACT
```

**الخطوة 2:** افتح Terminal في المجلد
```
انقر على شريط العنوان
اكتب: cmd
اضغط: Enter
```

**الخطوة 3:** تحقق من Python
```bash
python --version
```

**الخطوة 4:** شغل STRACT
```bash
python stract_cli.py repl
```

**الخطوة 5:** اكتب برنامج
```
stract> print "Hello World"
stract> exit
```

---

### على Mac:

**الخطوة 1:** فك الملف (تلقائي)

**الخطوة 2:** افتح Terminal
```bash
cd ~/stract-language
```

**الخطوة 3:** تحقق من Python
```bash
python3 --version
```

**الخطوة 4:** شغل STRACT
```bash
python3 stract_cli.py repl
```

**الخطوة 5:** اكتب برنامج
```
stract> print "Hello from Mac"
stract> exit
```

---

## 📊 جدول الأوامر (نفس الأوامر على جميع الأنظمة)

| الأمر | الوصف |
|------|-------|
| `python stract_cli.py repl` | وضع تفاعلي |
| `python stract_cli.py run file.stract` | تشغيل ملف |
| `python stract_cli.py check file.stract` | فحص أخطاء |
| `python stract_cli.py analyze file.stract` | تحليل AI |
| `python stract_cli.py commands` | عرض الأوامر |

---

## 🆘 حل المشاكل الشائعة

### مشكلة: "python: command not found"

**الحل:** استخدم `python3` بدلاً من `python`

```bash
# بدلاً من:
python stract_cli.py repl

# استخدم:
python3 stract_cli.py repl
```

---

### مشكلة: "File not found"

**الحل:** تأكد أنك في المجلد الصحيح

```bash
# اعرض الملفات الموجودة
dir    # على Windows
ls     # على Mac/Linux

# يجب أن تظهر:
stract_cli.py
examples
docs
...
```

---

### مشكلة: "No such file or directory"

**الحل:** تأكد من المسار

```bash
# تحقق من مكانك الآن
pwd    # على Mac/Linux
cd     # على Windows

# ثم انتقل للمجلد الصحيح
cd ~/stract-language      # Mac
cd C:\Users\YourName\STRACT  # Windows
```

---

### مشكلة: "Permission denied"

**على Mac/Linux:**
```bash
chmod +x stract_cli.py
python3 stract_cli.py repl
```

---

## 📝 أول برنامج لك!

### أنشئ ملف جديد باسم `my_first.stract`

**على Windows:**
1. افتح Notepad
2. اكتب:
```stract
print "برنامجي الأول!"

let name = "محمد"
print "اسمي: " + name

func greet(person):
    return "مرحبا " + person

print greet("علي")
```
3. احفظ باسم: `my_first.stract` (في مجلد STRACT)

**على Mac:**
1. افتح TextEdit
2. اختر: Format → Plain Text
3. اكتب الكود أعلاه
4. احفظ باسم: `my_first.stract`

**على Linux:**
```bash
nano my_first.stract
# اكتب الكود
# اضغط: Ctrl + X ثم Y ثم Enter
```

### شغله:

```bash
python stract_cli.py run my_first.stract
```

**النتيجة:**
```
برنامجي الأول!
اسمي: محمد
مرحبا علي
```

---

## 🎉 الآن أنت جاهز!

```bash
# 1. الوضع التفاعلي
python stract_cli.py repl

# 2. تشغيل مثال
python stract_cli.py run examples/hello.stract

# 3. تشغيل برنامجك
python stract_cli.py run my_first.stract

# 4. تحليل الكود
python stract_cli.py analyze examples/hello.stract
```

---

**Happy coding! 🚀**
