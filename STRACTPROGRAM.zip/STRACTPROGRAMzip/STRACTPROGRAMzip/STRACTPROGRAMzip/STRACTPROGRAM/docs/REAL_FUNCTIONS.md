# ✅ الدوال الفعلية في STRACT - الأوامر التي تعمل حقاً
# Real Available Functions - What Actually Works in STRACT

---

## ⚠️ تحذير مهم:

**الملفات الأخرى (CYBERSECURITY_GUIDE.md و SYNTAX_GUIDE.md) تحتوي على أمثلة نظرية**

هذا الملف يشرح **الدوال الفعلية فقط** التي توجد في اللغة STRACT الآن وتعمل حقاً!

---

## 📚 المحتويات

1. **الدوال المدمجة الأساسية**
2. **دوال التحويل**
3. **دوال الرياضيات**
4. **دوال القوائس والبيانات**
5. **دوال المنطق**
6. **دوال متقدمة**
7. **أوامر الطباعة والإدخال**
8. **أمثلة عملية تعمل فعلاً**

---

## 1️⃣ الدوال المدمجة الأساسية

### `len()` - الطول:

```stract
# قوائس
let list = [1, 2, 3, 4, 5]
print len(list)  # 5

# نصوص
let text = "مرحبا"
print len(text)  # 5

# معاجم
let dict = {"name": "أحمد", "age": 25}
print len(dict)  # 2
```

### `range()` - نطاق:

```stract
# من 0 إلى 4
for i in range(5):
    print i
# النتيجة: 0, 1, 2, 3, 4

# من 1 إلى 5
for i in range(1, 6):
    print i

# من 0 إلى 10 بخطوة 2
for i in range(0, 10, 2):
    print i
```

---

## 2️⃣ دوال التحويل

### `str()` - تحويل إلى نص:

```stract
print str(42)       # "42"
print str(3.14)     # "3.14"
print str(true)     # "true"
```

### `int()` - تحويل إلى عدد صحيح:

```stract
print int(3.14)     # 3
print int("42")     # 42
print int(true)     # 1
print int(false)    # 0
```

### `float()` - تحويل إلى عدد عشري:

```stract
print float(42)     # 42.0
print float("3.14") # 3.14
```

### `bool()` - تحويل إلى منطقي:

```stract
print bool(1)       # true
print bool(0)       # false
print bool("")      # false
print bool("hello") # true
```

### `type()` - معرفة النوع:

```stract
print type(42)      # "number"
print type("hello") # "string"
print type(true)    # "boolean"
print type([1,2])   # "list"
print type({})      # "dict"
```

---

## 3️⃣ دوال الرياضيات

### `abs()` - القيمة المطلقة:

```stract
print abs(-5)       # 5
print abs(3.14)     # 3.14
```

### `min()` - الأصغر:

```stract
# في قائمة
print min([5, 2, 8, 1, 9])  # 1

# عدة أرقام
print min(5, 2, 8, 1, 9)    # 1
```

### `max()` - الأكبر:

```stract
# في قائمة
print max([5, 2, 8, 1, 9])  # 9

# عدة أرقام
print max(5, 2, 8, 1, 9)    # 9
```

### `sum()` - الجمع:

```stract
print sum([1, 2, 3, 4, 5])  # 15
```

### `round()` - التقريب:

```stract
print round(3.14159)        # 3
print round(3.14159, 2)     # 3.14
print round(3.5)            # 4
```

### `pow()` - الأس:

```stract
print pow(2, 3)             # 8 (2^3)
print pow(2, 3, 5)          # 3 (2^3 mod 5)
```

### `sqrt()` - الجذر التربيعي:

```stract
print sqrt(16)              # 4.0
print sqrt(2)               # 1.414...
```

---

## 4️⃣ دوال القوائس والبيانات

### `sorted()` - الترتيب:

```stract
let list = [5, 2, 8, 1, 9]
print sorted(list)          # [1, 2, 5, 8, 9]
```

### `reversed()` - العكس:

```stract
let list = [1, 2, 3, 4, 5]
print reversed(list)        # [5, 4, 3, 2, 1]
```

### `enumerate()` - مع الفهرس:

```stract
let fruits = ["تفاح", "برتقال", "موز"]
for index, fruit in enumerate(fruits):
    print index + ": " + fruit
# النتيجة:
# 0: تفاح
# 1: برتقال
# 2: موز
```

### `zip()` - دمج القوائس:

```stract
let names = ["أحمد", "فاطمة", "علي"]
let ages = [25, 30, 28]

for name, age in zip(names, ages):
    print name + " (" + str(age) + ")"
# النتيجة:
# أحمد (25)
# فاطمة (30)
# علي (28)
```

### `map()` - تطبيق دالة:

```stract
let numbers = [1, 2, 3, 4, 5]

# مضاعفة كل عنصر
let doubled = map(lambda x: x * 2, numbers)
print doubled  # [2, 4, 6, 8, 10]
```

### `filter()` - تصفية:

```stract
let numbers = [1, 2, 3, 4, 5, 6]

# الأعداد الزوجية فقط
let even = filter(lambda x: x % 2 == 0, numbers)
print even  # [2, 4, 6]
```

### `reduce()` - التجميع:

```stract
let numbers = [1, 2, 3, 4, 5]

# جمع جميع الأرقام
let total = reduce(lambda a, b: a + b, numbers)
print total  # 15

# ضرب جميع الأرقام
let product = reduce(lambda a, b: a * b, numbers)
print product  # 120
```

### `any()` - إذا كان أي عنصر صحيح:

```stract
print any([false, false, true])   # true
print any([false, false, false])  # false
```

### `all()` - إذا كانت جميع العناصر صحيحة:

```stract
print all([true, true, true])     # true
print all([true, false, true])    # false
```

### `list()` - إنشاء قائمة:

```stract
print list()        # []
print list([1,2,3]) # [1, 2, 3]
```

### `dict()` - إنشاء معجم:

```stract
print dict()        # {}
```

### `set()` - إنشاء مجموعة:

```stract
print set([1, 1, 2, 2, 3])  # [1, 2, 3] (بدون تكرار)
```

### `tuple()` - إنشاء صف:

```stract
print tuple([1, 2, 3])  # (1, 2, 3)
```

---

## 5️⃣ دوال المنطق والنصوص

### `chr()` - حرف من رمز:

```stract
print chr(65)       # "A"
print chr(1575)     # "أ" (حرف عربي)
```

### `ord()` - رمز من حرف:

```stract
print ord("A")      # 65
print ord("أ")      # 1575
```

### `hex()` - إلى سادسة عشرية:

```stract
print hex(255)      # "0xff"
print hex(16)       # "0x10"
```

### `bin()` - إلى ثنائي:

```stract
print bin(8)        # "0b1000"
print bin(5)        # "0b101"
```

### `oct()` - إلى ثماني:

```stract
print oct(8)        # "0o10"
print oct(10)       # "0o12"
```

---

## 6️⃣ الأوامر الأساسية

### `print()` - طباعة:

```stract
print "مرحبا"
print 42
print [1, 2, 3]
print {"name": "أحمد"}

# طباعة متعددة
print "الاسم:" + " أحمد"
```

### `input()` - إدخال:

```stract
let name = input "اسمك: "
print "مرحبا " + name

let age = input "عمرك: "
print "عمرك: " + age
```

---

## 7️⃣ دوال متقدمة

### Lambda (دالة بدون اسم):

```stract
# دالة بسيطة
let double = lambda x: x * 2
print double(5)  # 10

# دالة بمعاملين
let add = lambda x, y: x + y
print add(3, 5)  # 8

# مع filter و map
let numbers = [1, 2, 3, 4, 5]
let even = filter(lambda x: x % 2 == 0, numbers)
print even  # [2, 4]
```

### دوال بقيم مرتجعة:

```stract
func add(a, b):
    return a + b

func multiply(a, b):
    return a * b

print add(5, 3)        # 8
print multiply(5, 3)   # 15
```

### دوال بدون معاملات:

```stract
func greet():
    return "مرحبا بك"

print greet()  # "مرحبا بك"
```

---

## 8️⃣ أمثلة عملية تعمل فعلاً

### مثال 1: حساب المتوسط:

```stract
let numbers = [10, 20, 30, 40, 50]

let total = sum(numbers)
let count = len(numbers)
let average = total / count

print "الإجمالي: " + str(total)
print "العدد: " + str(count)
print "المتوسط: " + str(average)
```

**النتيجة:**
```
الإجمالي: 150
العدد: 5
المتوسط: 30
```

---

### مثال 2: فحص الأرقام الزوجية:

```stract
let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

let even_numbers = filter(lambda x: x % 2 == 0, numbers)

print "الأرقام الزوجية:"
for num in even_numbers:
    print num
```

**النتيجة:**
```
الأرقام الزوجية:
2
4
6
8
10
```

---

### مثال 3: تحويل درجات إلى نصوص:

```stract
func get_grade(score):
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    else:
        return "F"

let grades = [85, 92, 78, 95, 88]

for grade in grades:
    print str(grade) + " -> " + get_grade(grade)
```

**النتيجة:**
```
85 -> B
92 -> A
78 -> C
95 -> A
88 -> B
```

---

### مثال 4: إنشاء جدول:

```stract
let students = [
    {"name": "أحمد", "score": 85},
    {"name": "فاطمة", "score": 92},
    {"name": "علي", "score": 78}
]

print "الطالب | الدرجة"
print "━━━━━━━━━━━━━━"

for student in students:
    print student["name"] + " | " + str(student["score"])
```

**النتيجة:**
```
الطالب | الدرجة
━━━━━━━━━━━━━━
أحمد | 85
فاطمة | 92
علي | 78
```

---

### مثال 5: حساب العاملي (Factorial):

```stract
func factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

print factorial(5)   # 120
print factorial(6)   # 720
print factorial(10)  # 3628800
```

**النتيجة:**
```
120
720
3628800
```

---

### مثال 6: فرز وتصفية:

```stract
let numbers = [5, 2, 8, 1, 9, 3, 7]

# فرز
let sorted_nums = sorted(numbers)
print "مرتب: " + str(sorted_nums)

# أكبر من 5
let big = filter(lambda x: x > 5, numbers)
print "أكبر من 5: " + str(big)

# تضاعيف
let doubled = map(lambda x: x * 2, numbers)
print "مضاعف: " + str(doubled)
```

**النتيجة:**
```
مرتب: [1, 2, 3, 5, 7, 8, 9]
أكبر من 5: [8, 9, 7]
مضاعف: [10, 4, 16, 2, 18, 6, 14]
```

---

### مثال 7: برنامج حقيقي - آلة حاسبة:

```stract
func calculate(a, b, op):
    if op == "+":
        return a + b
    elif op == "-":
        return a - b
    elif op == "*":
        return a * b
    elif op == "/" and b != 0:
        return a / b
    else:
        return 0

print "حاسبة بسيطة"
print "━━━━━━━━━━━━━"

let x = 10
let y = 3

print str(x) + " + " + str(y) + " = " + str(calculate(x, y, "+"))
print str(x) + " - " + str(y) + " = " + str(calculate(x, y, "-"))
print str(x) + " * " + str(y) + " = " + str(calculate(x, y, "*"))
print str(x) + " / " + str(y) + " = " + str(round(calculate(x, y, "/"), 2))
```

**النتيجة:**
```
حاسبة بسيطة
━━━━━━━━━━━━━
10 + 3 = 13
10 - 3 = 7
10 * 3 = 30
10 / 3 = 3.33
```

---

### مثال 8: معالجة الأخطاء:

```stract
try:
    let x = 10
    let y = 0
    let result = x / y
    print result
catch error:
    print "خطأ: لا يمكن القسمة على صفر"
```

**النتيجة:**
```
خطأ: لا يمكن القسمة على صفر
```

---

## 📝 ملخص الدوال الفعلية:

| الفئة | الدوال |
|------|-------|
| **أساسي** | print, input, len, range |
| **تحويل** | str, int, float, bool, type |
| **رياضيات** | abs, min, max, sum, round, pow, sqrt |
| **قوائس** | sorted, reversed, enumerate, zip, map, filter, reduce |
| **منطق** | any, all |
| **إنشاء** | list, dict, set, tuple |
| **نصوص** | chr, ord, hex, bin, oct |
| **دوال** | func, lambda, return |
| **معالجة أخطاء** | try, catch, finally |

---

## ⚠️ تنبيهات مهمة:

### ❌ دوال **غير متاحة** (لا تحاول استخدامها):

```
scan_network()
find_wifi_networks()
get_public_ip_info()
port_scan.is_open()
monitor_network()
network.get_signal_strength()
crypto.encrypt()
hash_lib.md5()
import web
import network
import ip_tools
```

هذه الدوال **نظرية فقط** وليست مطبقة في اللغة الحالية!

### ✅ استخدم الدوال المتاحة فقط:

```stract
# ✅ صحيح
let numbers = [1, 2, 3]
let sum = sum(numbers)
print sum

# ❌ خطأ
let devices = scan_network("192.168.1.0/24")  # غير موجود!
```

---

## 📚 ملفات أخرى:

- [START_HERE.md](START_HERE.md) - البدء السريع
- [SYNTAX_GUIDE.md](SYNTAX_GUIDE.md) - البناء الجملي (يحتوي على أمثلة نظرية)
- [CYBERSECURITY_GUIDE.md](CYBERSECURITY_GUIDE.md) - أمن سبراني (أمثلة نظرية)
- [QUICK_START.md](QUICK_START.md) - بدء سريع

---

**استخدم **هذا الملف فقط** للدوال التي تعمل حقاً! 🚀**
