# دليل بناء المواقع والروتر في STRACT
# Web Routing Guide in STRACT

---

## ⚠️ تحذير مهم:

**الأمثلة في هذا الملف نظرية تعليمية!**

الدوال التالية **غير موجودة** في اللغة الحالية:
- `import web`
- `@app.get()`, `@app.post()`, `@app.put()`, `@app.delete()`
- `request.json_data`

👉 **للأوامر التي تعمل فعلاً: [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)**

---

## 📖 مقدمة

هذا الدليل يوضح **كيف يمكن** بناء تطبيقات الويب في المستقبل.

الأمثلة التالية توضح الرؤية والتصميم (نظري)

---

## 1. مثال موقع ويب بسيط

### التطبيق الأساسي

```stract
# موقع ويب بسيط باستخدام STRACT
# Simple Website Example

import web

# إنشاء تطبيق الويب
let app = web.create_app()

# قاعدة بيانات مؤقتة للمستخدمين
let users = [
    {"id": 1, "name": "علي", "email": "ali@example.com", "age": 25},
    {"id": 2, "name": "أحمد", "email": "ahmed@example.com", "age": 30},
    {"id": 3, "name": "سارة", "email": "sara@example.com", "age": 28}
]

let posts = [
    {"id": 1, "title": "مرحبا بك", "content": "هذا أول منشور", "author_id": 1},
    {"id": 2, "title": "STRACT رائعة", "content": "لغة برمجة قوية", "author_id": 2}
]

# ==========================================
# الصفحة الرئيسية
# ==========================================
@app.get("/")
func home(request):
    return {
        "message": "مرحبا بك في موقعنا",
        "site": "STRACT Website v1.0",
        "status": "running"
    }

# ==========================================
# عرض جميع المستخدمين
# ==========================================
@app.get("/users")
func get_users(request):
    return {
        "total": len(users),
        "users": users
    }

# ==========================================
# عرض مستخدم بناءً على الـ ID
# ==========================================
@app.get("/users/:id")
func get_user(request, id):
    for user in users:
        if user.id == int(id):
            return {
                "success": true,
                "user": user
            }
    return {
        "success": false,
        "error": "المستخدم غير موجود"
    }

# ==========================================
# إضافة مستخدم جديد
# ==========================================
@app.post("/users")
func create_user(request):
    let data = request.json_data
    let new_id = len(users) + 1
    
    let new_user = {
        "id": new_id,
        "name": data.name,
        "email": data.email,
        "age": data.age
    }
    
    users.append(new_user)
    
    return {
        "success": true,
        "message": "تم إضافة المستخدم",
        "user": new_user
    }

# ==========================================
# تحديث بيانات المستخدم
# ==========================================
@app.put("/users/:id")
func update_user(request, id):
    let data = request.json_data
    
    for user in users:
        if user.id == int(id):
            if data.name:
                user.name = data.name
            if data.email:
                user.email = data.email
            if data.age:
                user.age = data.age
            
            return {
                "success": true,
                "message": "تم تحديث البيانات",
                "user": user
            }
    
    return {
        "success": false,
        "error": "المستخدم غير موجود"
    }

# ==========================================
# حذف مستخدم
# ==========================================
@app.delete("/users/:id")
func delete_user(request, id):
    let user_id = int(id)
    
    for i in range(len(users)):
        if users[i].id == user_id:
            let deleted = users[i]
            users.remove_at(i)
            
            return {
                "success": true,
                "message": "تم حذف المستخدم",
                "deleted_user": deleted
            }
    
    return {
        "success": false,
        "error": "المستخدم غير موجود"
    }

# ==========================================
# عرض جميع المنشورات
# ==========================================
@app.get("/posts")
func get_posts(request):
    return {
        "total": len(posts),
        "posts": posts
    }

# ==========================================
# عرض منشور معين
# ==========================================
@app.get("/posts/:id")
func get_post(request, id):
    for post in posts:
        if post.id == int(id):
            # البحث عن صاحب المنشور
            let author = null
            for user in users:
                if user.id == post.author_id:
                    author = user
                    break
            
            return {
                "success": true,
                "post": post,
                "author": author
            }
    
    return {
        "success": false,
        "error": "المنشور غير موجود"
    }

# ==========================================
# معلومات الموقع
# ==========================================
@app.get("/info")
func site_info(request):
    return {
        "site_name": "STRACT Website",
        "version": "1.0.0",
        "language": "STRACT v4.0",
        "total_users": len(users),
        "total_posts": len(posts),
        "created_at": "2025-11-29"
    }

# ==========================================
# بدء تشغيل الموقع
# ==========================================
print "🚀 بدء تشغيل موقع STRACT..."
print "📍 الموقع متاح على: http://0.0.0.0:5000"
print "📊 عدد المستخدمين:" + str(len(users))
print "📝 عدد المنشورات:" + str(len(posts))
print "⏸️  اضغط Ctrl+C للإيقاف"

app.run(port=5000)
```

---

## 2. شرح الروتر (Routes)

### ما هو الروتر؟
الروتر هو المسار الذي يحدد الطلب (Request) من العميل والاستجابة (Response) من الخادم.

### أنواع الطلبات (HTTP Methods):

```stract
# GET - الحصول على البيانات
@app.get("/users")
func get_all_users(request):
    return {"users": all_users_list}

# POST - إضافة بيانات جديدة
@app.post("/users")
func create_user(request):
    let new_user = request.json_data
    return {"success": true, "user": new_user}

# PUT - تحديث البيانات
@app.put("/users/:id")
func update_user(request, id):
    let updated_data = request.json_data
    return {"success": true, "user": updated_data}

# DELETE - حذف البيانات
@app.delete("/users/:id")
func delete_user(request, id):
    return {"success": true, "message": "تم الحذف"}

# PATCH - تحديث جزئي
@app.patch("/users/:id")
func patch_user(request, id):
    return {"success": true}
```

---

## 3. معامل الروتر (Route Parameters)

### المعاملات الديناميكية

```stract
import web
let app = web.create_app()

# ===================================
# معامل بسيط
# ===================================
@app.get("/users/:id")
func get_user(request, id):
    # id سيكون قيمة من الرابط
    # مثال: /users/5 -> id = "5"
    return {
        "user_id": id,
        "name": "محمد"
    }

# ===================================
# معاملات متعددة
# ===================================
@app.get("/users/:user_id/posts/:post_id")
func get_user_post(request, user_id, post_id):
    return {
        "user_id": user_id,
        "post_id": post_id,
        "content": "محتوى المنشور"
    }

# ===================================
# معامل مع بيانات الاستعلام (Query)
# ===================================
@app.get("/search")
func search(request):
    # الاستعلام: /search?q=stract&limit=10
    let query = request.get_query("q")
    let limit = request.get_query("limit")
    
    return {
        "search_term": query,
        "limit": limit,
        "results": []
    }

# ===================================
# تحويل المعامل إلى رقم
# ===================================
@app.get("/products/:id")
func get_product(request, id):
    let product_id = int(id)  # تحويل من نص إلى رقم
    
    return {
        "id": product_id,
        "price": 99.99
    }

app.run(port=5000)
```

---

## 4. بيانات الروتر (Route Data)

### كائن Request

```stract
import web
let app = web.create_app()

# ===================================
# الحصول على بيانات من الطلب
# ===================================
@app.post("/api/users")
func create_user(request):
    # البيانات المرسلة في الـ Body
    let body_data = request.json_data
    
    # معلومات الطلب
    let method = request.method      # GET, POST, PUT, DELETE
    let url = request.url            # الرابط الكامل
    let path = request.path          # المسار فقط
    let headers = request.headers    # معلومات الرأس
    
    return {
        "received_data": body_data,
        "request_method": method,
        "request_path": path
    }

# ===================================
# قراءة Headers
# ===================================
@app.get("/secure")
func secure_route(request):
    let auth = request.get_header("Authorization")
    let content_type = request.get_header("Content-Type")
    
    if auth:
        return {"authorized": true}
    else:
        return {"authorized": false, "error": "Missing token"}

# ===================================
# استقبال JSON
# ===================================
@app.post("/data")
func receive_json(request):
    let data = request.json_data
    
    # الوصول للخصائص
    let name = data.name
    let email = data.email
    let age = data.age
    
    return {
        "success": true,
        "received": {
            "name": name,
            "email": email,
            "age": age
        }
    }

# ===================================
# معالجة الأخطاء
# ===================================
@app.post("/validate")
func validate_data(request):
    try:
        let data = request.json_data
        
        if not data.name:
            return {
                "success": false,
                "error": "الاسم مطلوب"
            }
        
        if not data.email:
            return {
                "success": false,
                "error": "البريد الإلكتروني مطلوب"
            }
        
        return {
            "success": true,
            "message": "البيانات صحيحة"
        }
    catch error:
        return {
            "success": false,
            "error": str(error)
        }

app.run(port=5000)
```

---

## 5. مثال متقدم: API كاملة

```stract
import web

let app = web.create_app()

# قاعدة بيانات مؤقتة
let database = {
    "users": [
        {"id": 1, "name": "علي", "role": "admin"},
        {"id": 2, "name": "أحمد", "role": "user"}
    ],
    "products": [
        {"id": 1, "name": "كتاب", "price": 50},
        {"id": 2, "name": "قلم", "price": 5}
    ]
}

# ===================================
# وظائف مساعدة
# ===================================
func find_user(id):
    for user in database.users:
        if user.id == id:
            return user
    return null

func is_admin(user_id):
    let user = find_user(user_id)
    return user and user.role == "admin"

# ===================================
# التحقق من الصلاحيات
# ===================================
@app.post("/admin/users")
func admin_create_user(request):
    # التحقق من التفويض
    let admin_id = request.get_header("X-Admin-ID")
    
    if not is_admin(int(admin_id)):
        return {"error": "غير مصرح"}
    
    let data = request.json_data
    let new_id = len(database.users) + 1
    
    let new_user = {
        "id": new_id,
        "name": data.name,
        "role": data.role
    }
    
    database.users.append(new_user)
    
    return {"success": true, "user": new_user}

# ===================================
# إحصائيات
# ===================================
@app.get("/stats")
func get_stats(request):
    return {
        "total_users": len(database.users),
        "total_products": len(database.products),
        "api_version": "1.0",
        "status": "healthy"
    }

# ===================================
# البحث المتقدم
# ===================================
@app.get("/search/users")
func search_users(request):
    let query = request.get_query("q")
    let results = []
    
    for user in database.users:
        if query in user.name:
            results.append(user)
    
    return {"results": results, "count": len(results)}

print "✅ API جاهزة على http://0.0.0.0:5000"
app.run(port=5000)
```

---

## 6. كيفية الاستخدام

### تشغيل الموقع
```bash
python stract_cli.py run web_example.stract
```

### اختبار الروتر باستخدام curl

```bash
# GET - الحصول على البيانات
curl http://localhost:5000/users

# GET - الحصول على مستخدم معين
curl http://localhost:5000/users/1

# POST - إضافة مستخدم
curl -X POST http://localhost:5000/users \
  -H "Content-Type: application/json" \
  -d '{"name":"محمود","email":"mahmoud@example.com","age":35}'

# PUT - تحديث
curl -X PUT http://localhost:5000/users/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"علي محمد","age":26}'

# DELETE - حذف
curl -X DELETE http://localhost:5000/users/1

# مع معاملات الاستعلام
curl "http://localhost:5000/search?q=stract&limit=5"
```

---

## 7. ملخص

| الميزة | الوصف |
|--------|-------|
| `@app.get()` | الحصول على البيانات |
| `@app.post()` | إضافة بيانات جديدة |
| `@app.put()` | تحديث البيانات |
| `@app.delete()` | حذف البيانات |
| `:id` | معامل ديناميكي |
| `request.json_data` | بيانات JSON من الطلب |
| `request.get_query()` | معاملات الاستعلام |
| `request.get_header()` | معلومات الرأس |

---

**Happy coding with STRACT! 🚀**
