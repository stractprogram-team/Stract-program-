# 🚀 ابدأ هنا - دليل شامل لـ STRACT
# START HERE - Complete STRACT Guide

---

## ⚠️ تحذير مهم:

**لاحظ:** بعض الأمثلة في هذا الملف نظرية (خاصة في قسم برمجة المواقع والأمن السبراني)

👉 **للأوامر التي تعمل فعلاً، انقر هنا:** [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)

---

## 📌 محتويات هذا الدليل

1. **ما هي STRACT؟**
2. **التشغيل على Replit الآن**
3. **تحميل على حاسوبك**
4. **التثبيت على Windows/Mac/Linux**
5. **أول برنامج لك**
6. **كيفية عمل الأوامر**
7. **شرح الأمثلة**
8. **بناء موقع ويب**
9. **نشر على الإنترنت**

---

## 1️⃣ ما هي STRACT؟

### تعريف بسيط
**STRACT** هي لغة برمجة حديثة تجمع بين:
- ✅ بساطة Python
- ✅ تنظيم JavaScript
- ✅ ميزات الويب المدمجة
- ✅ تحليل الذكاء الاصطناعي

### الميزات:
```
✔️ برمجة سهلة وقوية
✔️ موقع ويب بدون تعقيد
✔️ تحليل الكود التلقائي
✔️ وتوثيق شاملة
```

---

## 2️⃣ التشغيل على Replit الآن (الأسهل)

### الخطوة الأولى: الوضع التفاعلي

اكتب في Terminal (أسفل الشاشة):
```bash
python stract_cli.py repl
```

### ستظهر هذه الشاشة:
```
╔════════════════════════════════╗
║   STRACT v4.0                  ║
║   Programming Language         ║
╚════════════════════════════════╝

stract>
```

### اكتب برنامجك:
```
stract> print "مرحبا"
مرحبا

stract> let x = 10
stract> print x
10

stract> exit
Goodbye!
```

### النتيجة: ✅ برنامج يعمل فوراً!

---

## 3️⃣ تحميل على حاسوبك

### الخطوة 1: تحميل الملفات

**من Replit:**
1. انقر على الملفات 📁 (يسار الشاشة)
2. انقر على الثلاث نقاط ⋮
3. اختر **"Download as zip"**
4. الملف يتحمل (stract-language.zip)

---

### الخطوة 2: فك الضغط

#### على Windows:
1. افتح **Downloads**
2. انقر يمين على الملف
3. اختر **"Extract All"**
4. احفظ في: `C:\Users\YourName\STRACT`

#### على Mac:
1. افتح **Downloads**
2. انقر مرتين على الملف (ينفك تلقائياً)
3. انقل المجلد إلى: `~/stract`

#### على Linux:
```bash
cd ~/Downloads
unzip stract-language.zip
cd stract-language
```

---

### الخطوة 3: فتح Terminal

#### Windows:
1. افتح مجلد STRACT
2. انقر على شريط العنوان (الأعلى)
3. اكتب: `cmd`
4. اضغط: Enter

#### Mac:
```bash
cd ~/stract
```

#### Linux:
```bash
cd ~/stract-language
```

---

### الخطوة 4: شغل STRACT!

اكتب:
```bash
python stract_cli.py repl
```

إذا لم يعمل، جرب:
```bash
python3 stract_cli.py repl
```

---

## 4️⃣ التثبيت على نظام التشغيل الخاص بك

### Windows 10/11

#### أ) تثبيت Python:
1. اذهب إلى https://www.python.org/downloads/
2. حمل **Python 3.11**
3. اشغل الملف
4. ✅ **أهم خطوة:** حدد ✓ "Add Python to PATH"
5. اضغط "Install Now"

#### ب) التحقق:
```bash
python --version
```

يجب أن تظهر: `Python 3.11.x`

#### ج) تحميل STRACT:
1. حمل ZIP من Replit
2. فك الضغط: `C:\Users\YourName\STRACT`
3. افتح Terminal في المجلد
4. اكتب: `python stract_cli.py repl`

---

### Mac

#### أ) تثبيت Python (إذا لم يكن موجوداً):

**الطريقة الأسهل - استخدام Homebrew:**
```bash
# 1. ثبت Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 2. ثبت Python
brew install python@3.11

# 3. تحقق
python3 --version
```

**أو من الموقع:**
1. https://www.python.org/downloads/macos/
2. حمل Python 3.11
3. اشغل الملف

#### ب) تحميل STRACT:
```bash
cd ~/stract
python3 stract_cli.py repl
```

---

### Linux (Ubuntu/Debian)

#### أ) تثبيت Python:
```bash
sudo apt-get update
sudo apt-get install python3.11 python3-pip
```

#### ب) التحقق:
```bash
python3 --version
```

#### ج) تحميل STRACT:
```bash
cd ~/stract-language
python3 stract_cli.py repl
```

---

### Linux (Fedora/RHEL)

```bash
sudo dnf install python3.11 python3-pip
python3 stract_cli.py repl
```

---

## 5️⃣ أول برنامج لك

### مثال 1: Hello World

**اكتب في Terminal:**
```bash
python stract_cli.py repl
```

**ثم اكتب:**
```
stract> print "Hello, STRACT!"
stract> exit
```

### مثال 2: متغيرات وحسابات

**في REPL:**
```
stract> let x = 10
stract> let y = 20
stract> print x + y
30

stract> exit
```

### مثال 3: دالة بسيطة

**في REPL:**
```
stract> func add(a, b):
...     return a + b
stract> print add(5, 3)
8

stract> exit
```

### مثال 4: قائمة

**في REPL:**
```
stract> let numbers = [1, 2, 3, 4, 5]
stract> let doubled = numbers.map(lambda x: x * 2)
stract> print doubled
[2, 4, 6, 8, 10]

stract> exit
```

---

## 6️⃣ أول ملف لك

### إنشاء الملف

**على Windows:**
1. افتح Notepad
2. اكتب الكود:
```stract
print "برنامجي الأول!"

func greet(name):
    return "مرحبا " + name

print greet("محمد")

let numbers = [1, 2, 3, 4, 5]
print "المجموع: " + str(sum(numbers))
```

3. احفظ باسم: `my_program.stract`
4. في مجلد STRACT

**على Mac/Linux:**
```bash
nano my_program.stract
# اكتب الكود
# Ctrl + X ثم Y ثم Enter
```

### تشغيله

```bash
python stract_cli.py run my_program.stract
```

### النتيجة:
```
برنامجي الأول!
مرحبا محمد
المجموع: 15
```

---

## 7️⃣ الأوامر الأساسية

### الأمر `repl` (الوضع التفاعلي)
```bash
python stract_cli.py repl
```
- اكتب أوامر مباشرة
- رؤية النتيجة فوراً
- اختبار سريع

### الأمر `run` (تشغيل ملف)
```bash
python stract_cli.py run file.stract
```
- يقرأ الملف
- يشغل جميع الأوامر
- يعرض النتيجة

### الأمر `check` (فحص الأخطاء)
```bash
python stract_cli.py check file.stract
```
- بدون تشغيل الملف
- يوجد الأخطاء فقط
- سريع وآمن

### الأمر `analyze` (تحليل AI)
```bash
python stract_cli.py analyze file.stract
```
- يحلل الكود
- درجة جودة
- اقتراحات للتحسين

### الأمر `web` (موقع ويب)
```bash
python stract_cli.py web website.stract
```
- يشغل موقع ويب
- على المنفذ 5000
- اختبر بـ curl

---

## 8️⃣ شرح كل أمر بمثال

### مثال 1: `repl`

```bash
python stract_cli.py repl
```

**ما يحدث:**
```
1. يفتح وضع تفاعلي
2. تكتب: print "مرحبا"
3. يعرض النتيجة: مرحبا
4. تكتب: exit
5. يغلق
```

---

### مثال 2: `run`

**ملف `hello.stract`:**
```stract
print "Hello"
let x = 5
print x
```

**الأمر:**
```bash
python stract_cli.py run hello.stract
```

**النتيجة:**
```
Hello
5
```

---

### مثال 3: `check`

**ملف خاطئ `error.stract`:**
```stract
print "مرحبا
let x = [1, 2, 3
```

**الأمر:**
```bash
python stract_cli.py check error.stract
```

**النتيجة:**
```
Parser Error: Missing closing quote
```

---

### مثال 4: `analyze`

**الأمر:**
```bash
python stract_cli.py analyze hello.stract
```

**النتيجة:**
```
STRACT AI Code Analysis
========================
Total Lines: 3
Code Lines: 3
Complexity: low
Quality Score: 95/100
```

---

### مثال 5: `web`

**ملف `website.stract`:**
```stract
import web

let app = web.create_app()

@app.get("/")
func home(request):
    return {"message": "مرحبا"}

app.run(port=5000)
```

**الأمر (Terminal 1):**
```bash
python stract_cli.py web website.stract
```

**النتيجة:**
```
Web server running at http://0.0.0.0:5000
```

**الاختبار (Terminal 2):**
```bash
curl http://localhost:5000
```

**النتيجة:**
```json
{"message": "مرحبا"}
```

---

## 9️⃣ شرح الأمثلة الموجودة

### `examples/hello.stract` (الشامل)

```bash
python stract_cli.py run examples/hello.stract
```

**يحتوي على:**
- متغيرات
- دوال
- حلقات
- شروط
- قوائم
- معاجم

---

### `examples/simple_website.stract` (موقع بسيط)

```bash
python stract_cli.py run examples/simple_website.stract
```

**ثم اختبر:**
```bash
curl http://localhost:5000
```

---

### `examples/web_example.stract` (موقع متقدم)

```bash
python stract_cli.py run examples/web_example.stract
```

---

## 🔟 بناء موقع ويب

### خطوة 1: أنشئ ملف `website.stract`

```stract
import web

let app = web.create_app()

let posts = [
    {"id": 1, "title": "منشور 1"}
]

@app.get("/")
func home(request):
    return {"message": "أهلا وسهلا"}

@app.get("/posts")
func get_posts(request):
    return {"posts": posts}

@app.post("/posts")
func create_post(request):
    let data = request.json_data
    posts.append({"id": len(posts) + 1, "title": data.title})
    return {"success": true}

app.run(port=5000)
```

### خطوة 2: شغله

**Terminal 1:**
```bash
python stract_cli.py web website.stract
```

### خطوة 3: اختبره

**Terminal 2:**
```bash
# الصفحة الرئيسية
curl http://localhost:5000

# الحصول على المنشورات
curl http://localhost:5000/posts

# إضافة منشور جديد
curl -X POST http://localhost:5000/posts \
  -H "Content-Type: application/json" \
  -d '{"title":"منشور جديد"}'
```

---

## 1️⃣1️⃣ نشر على الإنترنت

### الطريقة 1: Replit (الأسهل)

1. شغل الموقع على Replit
2. انقر زر **"Publish"** (أعلى الشاشة)
3. استنسخ الرابط
4. شاركه مع أي شخص!

**الآن الموقع متاح على الإنترنت 24/7 ✅**

---

### الطريقة 2: على جهازك (نفس الشبكة)

**خطوة 1: ابحث عن IP**
```bash
# Windows
ipconfig

# Mac/Linux
ifconfig
```

**مثال IP:** `192.168.1.100`

**خطوة 2: شارك:**
```
http://192.168.1.100:5000
```

---

### الطريقة 3: VPS (موقع دائم)

```bash
# 1. استأجر VPS من DigitalOcean
# 2. ثبت Python 3.11
# 3. حمل الملفات
# 4. شغل الموقع
python stract_cli.py web website.stract
```

---

## 📚 الملفات الإضافية

اقرأ هذه الملفات للمزيد من التفاصيل:

| الملف | الموضوع |
|------|---------|
| [QUICK_START.md](QUICK_START.md) | بدء سريع مع أمثلة |
| [HOW_COMMANDS_WORK.md](HOW_COMMANDS_WORK.md) | شرح كل أمر بالتفصيل |
| [EXAMPLES_EXPLAINED.md](EXAMPLES_EXPLAINED.md) | شرح الأمثلة الموجودة |
| [WEB_ROUTING_GUIDE.md](WEB_ROUTING_GUIDE.md) | برمجة مواقع متقدمة |
| [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md) | تثبيت على أنظمة مختلفة |
| [DOWNLOAD_AND_RUN.md](DOWNLOAD_AND_RUN.md) | تحميل وتشغيل بالتفصيل |
| [INDEX.md](INDEX.md) | فهرس شامل |

---

## ⚡ الخطوات السريعة

### 1. الآن على Replit:
```bash
python stract_cli.py repl
```

### 2. على حاسوبك:
```bash
# حمل الملفات
# فك الضغط
# افتح Terminal
python stract_cli.py run examples/hello.stract
```

### 3. أول موقع ويب:
```bash
python stract_cli.py web examples/simple_website.stract
```

### 4. نشر:
- اضغط "Publish" في Replit
- أو استخدم جهازك
- أو استأجر VPS

---

## ❓ الأسئلة الشائعة

**س: هل STRACT مجانية؟**
نعم، تماماً مجانية! ✅

**س: هل يمكن استخدامها في مشاريع حقيقية؟**
نعم، يمكنك بناء APIs كاملة ومواقع ويب!

**س: هل تعمل على جميع الأنظمة؟**
نعم: Windows, Mac, Linux ✅

**س: كيف أحصل على الدعم؟**
اقرأ الملفات في مجلد `docs/`

---

## 🎉 أنت الآن جاهز!

```bash
# ابدأ الآن
python stract_cli.py repl
```

**Happy coding! 🚀**

---

## 📝 ملخص سريع

| المهمة | الأمر |
|-------|-------|
| وضع تفاعلي | `python stract_cli.py repl` |
| تشغيل ملف | `python stract_cli.py run file.stract` |
| فحص أخطاء | `python stract_cli.py check file.stract` |
| تحليل AI | `python stract_cli.py analyze file.stract` |
| موقع ويب | `python stract_cli.py web site.stract` |

---

**هذا هو دليلك الشامل - اقرأه واستمتع! 🎓**
