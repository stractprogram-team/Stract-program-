# 📝 دليل شامل لكتابة الكود في STRACT
## How to Write Code in STRACT - Complete Guide

---

## ⚠️ تحذير مهم (Important Notice)

**الفرق بين النظري والعملي:**

STRACT v5.0 لديها:
- ✅ **Syntax & Parsing كامل** - اللغة تفهم كل الكود
- ⚠️ **Runtime Implementation جزئي** - بعض الميزات تعمل، بعضها لا تزال قيد التطوير

---

## 1️⃣ الكود الذي يعمل فعلاً (Working Code)

### أ) الأساسيات (Basics) ✅

```stract
# متغيرات
let x = 10
const PI = 3.14
var y = 20

print x + y
```

### ب) الدوال (Functions) ✅

```stract
func add(a, b):
    return a + b

print add(5, 3)  # 8

func greet(name):
    return "Hello " + name

print greet("Ahmed")  # Hello Ahmed
```

### ج) الحلقات (Loops) ✅

```stract
# For loop
for i in range(1, 6):
    print i * i

# While loop
let counter = 0
while counter < 5:
    print counter
    counter = counter + 1
```

### د) الشروط (Conditions) ✅

```stract
let age = 25

if age >= 18:
    print "بالغ"
else:
    print "قاصر"

# Match/Case
match age:
    case 25:
        print "عمرك 25"
    default:
        print "عمر آخر"
```

### هـ) القوائس والقواامس (Lists & Dicts) ✅

```stract
# القوائس
let numbers = [1, 2, 3, 4, 5]
print numbers[0]        # 1
print len(numbers)      # 5

let doubled = numbers.map(lambda x: x * 2)
print doubled           # [2, 4, 6, 8, 10]

# القواامس
let person = {"name": "Ahmed", "age": 25}
print person["name"]    # Ahmed
```

### و) الفئات (Classes) ✅

```stract
class Person:
    func init(name, age):
        this.name = name
        this.age = age
    
    func greet():
        print "Hello, I'm " + this.name
    
    func haveBirthday():
        this.age = this.age + 1

let person = Person("Ahmed", 25)
person.greet()          # Hello, I'm Ahmed
person.haveBirthday()
print person.age        # 26
```

### ز) معالجة الأخطاء (Error Handling) ✅

```stract
try:
    let result = 10 / 2
    print result
catch error:
    print "Error: " + error
finally:
    print "Done"
```

---

## 2️⃣ الكود الذي لا يعمل بعد (Not Yet Implemented)

### ❌ Tensors و AI (لم تُطبَّق Runtime)

```stract
# هذا يعمل PARSING فقط، لكن لا ينفذ
tensor weights[100, 50] gpu gradient
```

**السبب:** الـ Parser يفهم الكود، لكن الـ Interpreter لم يُطبِّق logic التنفيذ الفعلي.

### ❌ النماذج (Models)

```stract
# هذا يعمل PARSING فقط
model NeuralNet:
    Dense(128, activation="relu")
    Dense(10, activation="softmax")
```

**السبب:** تم فقط إنشاء AST nodes، لكن لم تُطبَّق خطوات التنفيذ.

### ❌ التدريب (Training)

```stract
# هذا لا يعمل
train model using training_data epochs=10
```

**السبب:** لا توجد محرك تدريب فعلي بعد.

### ❌ البرمجة الزمنية (Streams & Temporal) ⚠️

```stract
# Parsing يعمل، لكن Runtime جزئي
stream data = source() |> filter(x: x > 0)

temporal counter = 0 every 1s: counter + 1

when counter > 100:
    print "Reached 100!"
```

**السبب:** Event loop و Scheduler لم يُطبَّقا بالكامل.

### ❌ الأنواع المقيدة (Refinement Types) ⚠️

```stract
# Definition يعمل، لكن Enforcement ضعيف
type PositiveInt: Int where value > 0

let x: PositiveInt = -5  # قد لا يعطي خطأ كما متوقع
```

**السبب:** لم يتم تطبيق Validation runtime كامل.

---

## 3️⃣ خريطة طريق الميزات (Features Roadmap)

| الميزة | المرحلة الحالية | ماذا يعمل | ماذا لا يعمل |
|--------|---------|----------|----------|
| **أساسيات** | ✅ نهائي | كل شيء | - |
| **الدوال** | ✅ نهائي | كل شيء | - |
| **الفئات** | ✅ نهائي | كل شيء | - |
| **الأنواع** | 🔄 جزئي | Definition | Enforcement كامل |
| **العقود** | 🔄 جزئي | Parsing | Runtime Check |
| **Tensors** | 🔄 جزئي | Parsing | Actual Math |
| **Models** | 🔄 جزئي | Parsing | Training Logic |
| **Streams** | 🔄 جزئي | Parsing | Event Loop |
| **Sandbox** | 🔄 جزئي | Parsing | Isolation |

---

## 4️⃣ كيفية البدء (Getting Started)

### للمبتدئين - ابدأ بـ Basics

```stract
# 1. متغيرات
let name = "أحمد"
let age = 25

# 2. دوال
func isAdult(age):
    return age >= 18

# 3. حلقات
for i in range(1, 6):
    print i

# 4. شروط
if isAdult(age):
    print "بالغ"

# 5. فئات
class Student:
    func init(name):
        this.name = name
    
    func study():
        print this.name + " is studying"

let student = Student(name)
student.study()
```

### للمحترفين - استخدم الميزات الآمنة

```stract
# 1. أنواع مقيدة
type Age: Int where value >= 0 and value <= 150

# 2. عقود برمجية
func calculateGrade(score):
    requires score >= 0 and score <= 100
    ensures result in ["A", "B", "C", "D", "F"]
    
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    else:
        return "F"

# 3. فئات آمنة مع invariants
class SafeCounter:
    invariant count >= 0
    
    func init():
        this.count = 0
    
    func increment():
        ensures this.count > old(this.count)
        this.count = this.count + 1

let counter = SafeCounter()
counter.increment()
print counter.count
```

---

## 5️⃣ أمثلة عملية (Practical Examples)

### مثال 1: حاسبة بسيطة ✅

```stract
func calculate(a, op, b):
    if op == "add":
        return a + b
    elif op == "subtract":
        return a - b
    elif op == "multiply":
        return a * b
    elif op == "divide":
        if b == 0:
            return null
        return a / b
    else:
        return null

print calculate(10, "add", 5)       # 15
print calculate(10, "subtract", 3)  # 7
print calculate(10, "multiply", 2)  # 20
print calculate(10, "divide", 2)    # 5
```

### مثال 2: نظام التقييمات ✅

```stract
class Grade:
    invariant score >= 0 and score <= 100
    
    func init(score):
        requires score >= 0 and score <= 100
        this.score = score
    
    func getGrade():
        if this.score >= 90:
            return "A"
        elif this.score >= 80:
            return "B"
        elif this.score >= 70:
            return "C"
        elif this.score >= 60:
            return "D"
        else:
            return "F"

let grade1 = Grade(85)
print grade1.getGrade()             # B

let grade2 = Grade(92)
print grade2.getGrade()             # A
```

### مثال 3: معالجة البيانات ✅

```stract
func processNumbers(numbers):
    let filtered = numbers.filter(lambda x: x > 0)
    let squared = filtered.map(lambda x: x * x)
    let sum = 0
    for num in squared:
        sum = sum + num
    return sum

let data = [1, -2, 3, -4, 5]
let result = processNumbers(data)
print result    # 1 + 9 + 25 = 35
```

### مثال 4: إدارة المطاعم (محاكاة) ✅

```stract
class Restaurant:
    func init(name, tables):
        this.name = name
        this.tables = tables
        this.orders = []
    
    func addOrder(order):
        this.orders.push(order)
    
    func totalOrders():
        return len(this.orders)

let rest = Restaurant("مطعمي", 10)
rest.addOrder({"item": "فلافل", "price": 5})
rest.addOrder({"item": "شاورما", "price": 8})
print rest.totalOrders()    # 2
```

---

## 6️⃣ الأخطاء الشائعة (Common Mistakes)

### ❌ خطأ 1: استخدام Tensor بدون معرفة أنها لم تُطبَّق

```stract
❌ هذا لن يعمل:
tensor x[10, 10] gpu
print x

✅ بدلاً منه، استخدم lists:
let x = [[1, 2, 3], [4, 5, 6]]
print x
```

### ❌ خطأ 2: محاولة استخدام Streams بدون معالج

```stract
❌ هذا قد لا يعمل كما متوقع:
stream data = source()

✅ بدلاً منه، استخدم lists:
let data = [1, 2, 3, 4, 5]
let filtered = data.filter(lambda x: x > 2)
```

### ❌ خطأ 3: نسيان الـ return في الدالة

```stract
❌ خطأ:
func add(a, b):
    a + b

✅ صحيح:
func add(a, b):
    return a + b
```

### ❌ خطأ 4: استخدام متغير قبل تعريفه

```stract
❌ خطأ:
print x
let x = 10

✅ صحيح:
let x = 10
print x
```

---

## 7️⃣ نصائح لكتابة كود جيد (Best Practices)

### 1. استخدم أسماء واضحة

```stract
✅ جيد:
let student_age = 25
let is_valid = true

❌ سيء:
let a = 25
let x = true
```

### 2. استخدم الدوال لتنظيم الكود

```stract
✅ جيد:
func isValidAge(age):
    return age >= 0 and age <= 150

func isAdult(age):
    return isValidAge(age) and age >= 18

❌ سيء:
if age >= 0 and age <= 150:
    if age >= 18:
        print "Adult"
```

### 3. استخدم Lambda للعمليات البسيطة

```stract
✅ جيد:
let numbers = [1, 2, 3, 4, 5]
let doubled = numbers.map(lambda x: x * 2)

❌ سيء:
let numbers = [1, 2, 3, 4, 5]
let doubled = []
for num in numbers:
    doubled.push(num * 2)
```

### 4. اختبر كودك في REPL أولاً

```bash
python stract_cli.py repl
stract> let x = 10
stract> print x
10
stract> exit
```

---

## 8️⃣ خطوات البدء (Getting Started Steps)

### الخطوة 1: افتح REPL
```bash
python stract_cli.py repl
```

### الخطوة 2: اكتب كود بسيط
```stract
print "Hello World"
let x = 10
print x
```

### الخطوة 3: اختبر الدوال
```stract
func add(a, b):
    return a + b

print add(5, 3)
```

### الخطوة 4: اختبر الفئات
```stract
class Person:
    func init(name):
        this.name = name
    
    func greet():
        print "Hello " + this.name

let p = Person("Ahmed")
p.greet()
```

### الخطوة 5: احفظ الكود في ملف
```bash
# اكتب الكود في ملف hello.stract
python stract_cli.py run hello.stract
```

---

## 9️⃣ أسئلة شائعة (FAQ)

### س: لماذا Tensor لا يعمل؟
**ج:** لأن runtime implementation لم تُطبَّق بعد. استخدم lists بدلاً منها الآن.

### س: هل يمكنني استخدام AI features الآن؟
**ج:** الـ Parsing يعمل، لكن Runtime جزئي. استخدم البرمجة الأساسية الآن.

### س: متى سيتم تطبيق كل المميزات؟
**ج:** Phase 2 من الخطة - الأساسيات تعمل بكمال الآن!

### س: هل كودي آمن؟
**ج:** نعم للميزات الأساسية. للميزات المتقدمة (Refinement Types) استخدمها بحذر.

---

## 🔟 ملخص (Summary)

| النوع | الحالة | الاستخدام |
|-------|--------|----------|
| **متغيرات** | ✅ يعمل | استخدم بثقة |
| **الدوال** | ✅ يعمل | استخدم بثقة |
| **الفئات** | ✅ يعمل | استخدم بثقة |
| **الحلقات** | ✅ يعمل | استخدم بثقة |
| **الشروط** | ✅ يعمل | استخدم بثقة |
| **الأنواع** | ⚠️ جزئي | استخدم لكن قد لا تعمل checks |
| **العقود** | ⚠️ جزئي | للتطوير فقط |
| **Tensors** | ❌ لا تعمل | لا تستخدمها الآن |
| **Models** | ❌ لا تعمل | لا تستخدمها الآن |
| **Streams** | ⚠️ جزئي | استخدم بحذر |

---

## 🎯 النصيحة الذهبية

**استخدم الميزات التي تعمل بنسبة 100%:**
- متغيرات
- دوال
- فئات
- حلقات
- شروط
- معالجة أخطاء

**تجنب الميزات قيد التطوير:**
- Tensors
- Models
- Training
- Advanced Streams

**استخدم الميزات الجزئية بحذر:**
- Refinement Types (جزئي)
- Contracts (جزئي)
- Basic Streams (جزئي)

---

**نصيحة أخيرة:** ابدأ بسيط، ثم تقدم تدريجياً! 🚀

آخر تحديث: 2025-11-30
