# 📖 دليل STRACT الموحد الشامل v5.0
## Complete Unified Guide to STRACT Programming Language

---

## 🎯 مقدمة (Introduction)

**STRACT v5.0** هي لغة برمجة ثورية جديدة تجمع بين ثلاث ميزات فريدة لا توجد معاً في أي لغة أخرى:

### الميزات الثورية الثلاث

#### 1️⃣ **الذكاء الاصطناعي كلغة أولى (AI-Native Language)**
- Tensors مع دعم GPU/CPU أصلي
- تفاضل تلقائي مدمج (Automatic Differentiation)
- نماذج AI بكود بسيط
- تحسين ذكي (Smart Optimization)

#### 2️⃣ **البرمجة الزمنية والتفاعلية (Reactive & Temporal Programming)**
- Streams تفاعلية مع معالج الأحداث
- متغيرات زمنية تتغير تلقائياً
- شروط تفاعلية (When Clauses)
- مراقبة التغييرات (Observers)
- تنفيذ دوري ومؤجل

#### 3️⃣ **الأمان التعاقدي (Contractual Safety)**
- أنواع مقيدة بقواعد محددة
- عقود برمجية (Pre/Post Conditions)
- ثوابت كلاسية (Class Invariants)
- عزل آمن (Sandboxing)

---

## 🚀 البدء السريع (Quick Start)

### الخطوة 1: التثبيت والتشغيل

**على Replit (الآن - الأسهل):**
```bash
python stract_cli.py repl
```

**على حاسوبك:**
```bash
# 1. Download as zip من Replit
# 2. فك الضغط
# 3. افتح Terminal
python stract_cli.py run file.stract
```

### الخطوة 2: برنامجك الأول

```stract
print "مرحباً بك في STRACT v5.0!"

let name = "أحمد"
let numbers = [1, 2, 3, 4, 5]
let doubled = numbers.map(lambda x: x * 2)

print "الاسم: " + name
print "الأرقام المضاعفة: " + str(doubled)
```

### الخطوة 3: الأوامر الأساسية

```bash
# الوضع التفاعلي
python stract_cli.py repl

# تشغيل ملف
python stract_cli.py run hello.stract

# فحص أخطاء
python stract_cli.py check hello.stract

# تحليل بالذكاء الاصطناعي
python stract_cli.py analyze hello.stract

# عرض جميع الأوامر
python stract_cli.py commands
```

---

## 📚 أساسيات اللغة (Language Basics)

### المتغيرات والأنواع

```stract
# أنواع أساسية
let integer = 42              # Int
let floating = 3.14           # Float
let text = "Hello"            # String
let flag = true               # Boolean
let empty = null              # Null

# متغيرات مختلفة
let x = 10              # ثابت لا يتغير
const PI = 3.14         # ثابت صريح
var y = 20              # متغير يتغير
```

### القوائس والقواميس

```stract
# القوائس
let numbers = [1, 2, 3, 4, 5]
let mixed = [1, "hello", true, 3.14]

print numbers[0]        # 1
print len(numbers)      # 5

# القواامس
let person = {"name": "Ahmed", "age": 25, "city": "Cairo"}
print person["name"]    # Ahmed
```

### الدوال

```stract
# دالة بسيطة
func add(a, b):
    return a + b

print add(5, 3)         # 8

# دالة بعقود
func safeDivide(a, b):
    requires b != 0
    ensures result * b == a
    return a / b

# دالة غامضة
let square = lambda x: x * x
print square(5)         # 25
```

### الحلقات والشروط

```stract
# If/Else
if age >= 18:
    print "بالغ"
else:
    print "قاصر"

# For Loop
for i in range(1, 6):
    print i * i

# While Loop
let i = 0
while i < 5:
    print i
    i = i + 1

# Match/Case
match grade:
    case "A":
        print "ممتاز"
    case "B":
        print "جيد"
    default:
        print "ضعيف"
```

### معالجة الأخطاء

```stract
try:
    let result = 10 / 0
    print result
catch error:
    print "Error: " + error
finally:
    print "Done"
```

---

## 🛡️ الأمان التعاقدي (Contractual Safety)

### أنواع مقيدة (Refinement Types)

```stract
# تعريف أنواع مع قيود
type PositiveInt: Int where value > 0
type Percentage: Float where value >= 0 and value <= 100
type Email: String where contains(value, "@")
type Age: Int where value >= 0 and value <= 150

# استخدام الأنواع
let age: Age = 25          # ✅ صحيح
let invalid: Age = -5      # ❌ خطأ!
let percent: Percentage = 85  # ✅ صحيح
```

### العقود البرمجية (Contracts)

```stract
# شروط مسبقة وشروط لاحقة
func sqrt(x):
    requires x >= 0                 # يجب أن يكون الإدخال موجب
    ensures result * result == x    # النتيجة تحقق هذا
    return x ** 0.5

func divide(a, b):
    requires b != 0
    ensures result * b == a
    return a / b

# استخدام القيم السابقة
func transfer(from_account, to_account, amount):
    requires amount > 0
    requires amount <= from_account.balance
    ensures from_account.balance == old(from_account.balance) - amount
    ensures to_account.balance == old(to_account.balance) + amount
    from_account.balance -= amount
    to_account.balance += amount
```

### الفئات الآمنة (Safe Classes)

```stract
class BankAccount:
    invariant balance >= 0      # يجب أن يكون الرصيد موجب دائماً
    
    func init(owner, initial_balance):
        requires initial_balance >= 0
        this.owner = owner
        this.balance = initial_balance
    
    func deposit(amount):
        requires amount > 0
        ensures this.balance > old(this.balance)
        this.balance += amount
    
    func withdraw(amount):
        requires amount > 0
        requires amount <= this.balance
        ensures this.balance == old(this.balance) - amount
        this.balance -= amount

# الاستخدام
let account = BankAccount("Ahmed", 1000)
account.deposit(500)
print account.balance           # 1500
account.withdraw(200)
print account.balance           # 1300
```

### العزل الآمن (Sandboxing)

```stract
# بدون صلاحيات (الأكثر أماناً)
sandbox []:
    let x = 1 + 1
    print x

# مع صلاحيات شبكة
sandbox [network]:
    let response = http.get("https://api.example.com")

# مع صلاحيات ملفات وشبكة
sandbox [file, network]:
    let data = file.read("data.txt")
    http.post("https://example.com", data)

# مع صلاحيات قاعدة البيانات
sandbox [database, file]:
    let results = db.query("SELECT * FROM users")
```

---

## 🤖 الذكاء الاصطناعي (AI-Native)

### Tensors - متغيرات الذكاء الاصطناعي

```stract
# إنشاء tensors على GPU
tensor weights[100, 50] gpu              # موضع 100x50 على GPU
tensor biases[50] cpu                    # على CPU
tensor data[1000] gpu gradient           # مع تفاضل

# مع تهيئة القيم
tensor initialized[5] = [1.0, 2.0, 3.0, 4.0, 5.0]

# العمليات على tensors
print weights                           # شكل: (100, 50)
```

### نماذج الذكاء الاصطناعي (AI Models)

```stract
# نموذج شبكة عصبية بسيط
model SimpleNN:
    Dense(128, activation="relu")
    Dropout(0.2)
    Dense(64, activation="relu")
    Dense(10, activation="softmax")

# نموذج الشبكات العميقة
model DeepNN:
    Dense(512, activation="relu")
    Batch Normalization
    Dropout(0.3)
    Dense(256, activation="relu")
    Dropout(0.3)
    Dense(128, activation="relu")
    Dense(10)

# نموذج الشبكات الالتفافية
model ConvNet:
    Conv2D(32, 3, activation="relu")
    MaxPool2D(2)
    Conv2D(64, 3, activation="relu")
    MaxPool2D(2)
    Flatten()
    Dense(128, activation="relu")
    Dropout(0.5)
    Dense(10, activation="softmax")
```

### التدريب والتنبؤ

```stract
# التدريب
train model using training_data epochs=10

# التنبؤ
predict model using test_data

# التقييم
evaluate model using test_data
```

### التفاضل التلقائي (Automatic Differentiation)

```stract
# حساب التفاضل (Gradient)
gradient loss with respect to [weights, biases]

# على أجهزة محددة
hardware gpu:
    gradient loss_value

hardware cpu:
    gradient simple_loss
```

### التحسين الذكي (Optimization)

```stract
# تحسين للدقة
optimize model for accuracy using training_data

# تحسين للسرعة
optimize model for speed using data

# تحسين لاستهلاك الذاكرة
optimize model for memory using data

# تحسين متوازن
optimize model for balanced using data
```

---

## ⚡ البرمجة الزمنية والتفاعلية (Reactive & Temporal)

### Streams - تدفقات البيانات التفاعلية

```stract
# تدفق بسيط من المصدر
stream events = source()

# تدفق مع تصفية
stream filtered = source() |> filter(x: x > 0)

# تدفق مع تحويل
stream mapped = data |> map(x: x * 2)

# سلسلة كاملة من العمليات
stream processed = raw_data
    |> filter(x: x != null)
    |> map(x: x * 2)
    |> filter(x: x > 100)
    |> map(x: str(x))
```

### المتغيرات الزمنية (Temporal Variables)

```stract
# متغير يزيد كل ثانية
temporal counter = 0 every 1s:
    counter + 1

# متغير يتحدث كل 100 ميلي ثانية
temporal smoothed = 0 every 0.1s:
    (smoothed * 0.9) + (input_value * 0.1)

# متغير يتحدث كل ساعة
temporal hourly_update = 0 every 3600:
    hourly_update + 1
```

### الشروط التفاعلية (When Clauses)

```stract
# عندما يصل counter إلى 100
when counter > 100:
    print "تم الوصول إلى 100!"

# عندما ترتفع درجة الحرارة
when temperature > 30:
    emit alert("high_temp")
    send_notification()

# عندما ينخفض الرصيد
when balance < 100:
    print "تحذير: رصيد منخفض"
```

### المراقبة (Observers)

```stract
# مراقبة التغييرات في المتغير
observe user_score:
    updateUI(user_score)
    if user_score > 1000:
        showBadge("Gold")

observe system_status:
    log_to_database(system_status)
```

### التنفيذ الدوري والمؤجل

```stract
# تنفيذ دوري كل ثانية
every 1s:
    checkHealth()

# تنفيذ دوري كل دقيقة
every 60s:
    saveData()

# تنفيذ دوري كل ساعة
every 3600s:
    cleanup()

# تنفيذ مؤجل بعد 5 ثواني
after 5s:
    show_notification()

# تنفيذ مؤجل بعد دقيقة
after 60s:
    logout()
```

### إصدار الأحداث (Emit)

```stract
# إصدار حدث بسيط
emit events "user_login"

# إصدار حدث مع بيانات
emit metrics {"cpu": 45, "memory": 60}

# إصدار تنبيه
emit alerts "critical_error"
```

---

## 🔧 الدوال المدمجة (Built-in Functions)

### الإدخال والإخراج
```stract
print(x)            # طباعة
input()             # قراءة من المستخدم
```

### تحويل الأنواع
```stract
str(42)             # "42"
int("42")           # 42
float("3.14")       # 3.14
bool(1)             # true
```

### معالجة القوائس
```stract
len([1, 2, 3])              # 3
sorted([3, 1, 2])           # [1, 2, 3]
reversed([1, 2, 3])         # [3, 2, 1]
sum([1, 2, 3])              # 6
min([3, 1, 2])              # 1
max([3, 1, 2])              # 3
enumerate([1, 2, 3])        # مع الفهرس
zip([1, 2], [3, 4])         # دمج قوائس
```

### البرمجة الدالية
```stract
map(func, list)             # تطبيق على كل عنصر
filter(func, list)          # تصفية
reduce(func, list, start)   # تجميع
```

### أخرى
```stract
range(1, 10)        # [1, 2, 3, ..., 9]
type(x)             # نوع البيانات
abs(-5)             # 5
round(3.14159, 2)   # 3.14
sqrt(16)            # 4.0
max(a, b)           # الأكبر
min(a, b)           # الأصغر
```

---

## 📊 أمثلة عملية (Practical Examples)

### مثال 1: حاسبة آمنة
```stract
type PositiveInt: Int where value > 0

func calculateDiscount(original: PositiveInt, percent: PositiveInt):
    requires percent >= 0 and percent <= 100
    let discount = original * percent / 100
    ensures result < original and result >= 0
    return original - discount

print calculateDiscount(100, 20)   # 80
```

### مثال 2: نموذج AI
```stract
model Classifier:
    Dense(64, activation="relu")
    Dropout(0.3)
    Dense(10, activation="softmax")

tensor input_data[100] gpu gradient
train Classifier using input_data epochs=20
optimize Classifier for accuracy using input_data
```

### مثال 3: معالجة تفاعلية
```stract
stream data = source() |> filter(x: x > 0) |> map(x: x * 2)

when data > 100:
    print "High value detected!"

every 5s:
    print "Still running..."
```

---

## 📋 الكلمات المحجوزة (Keywords)

### التحكم بالتدفق
`if`, `elif`, `else`, `for`, `while`, `when`, `every`, `after`, `break`, `continue`

### البيانات والتعريفات
`let`, `const`, `var`, `class`, `func`, `lambda`

### الأمان والعقود
`requires`, `ensures`, `invariant`, `sandbox`, `type`

### الذكاء الاصطناعي
`tensor`, `model`, `train`, `predict`, `optimize`, `hardware`, `gradient`

### البرمجة الزمنية
`stream`, `temporal`, `observe`, `emit`

### البنية
`import`, `try`, `catch`, `finally`, `return`, `match`, `case`, `default`

### الثوابت
`true`, `false`, `null`

---

## 🔍 مرجع سريع (Quick Reference)

| العنصر | الاستخدام |
|--------|----------|
| **متغيرات** | `let`, `const`, `var` |
| **دوال** | `func name(params): return value` |
| **حلقات** | `for x in list:` أو `while condition:` |
| **شروط** | `if condition: elif: else:` |
| **Tensors** | `tensor name[size] gpu/cpu` |
| **نماذج** | `model name: Layer()` |
| **Streams** | `stream name = source() \|> filter()` |
| **متغيرات زمنية** | `temporal name = value every time:` |
| **عقود** | `requires condition` و `ensures condition` |

---

## ❓ أسئلة شائعة

**س: ما الفرق بين STRACT و Python؟**
**ج:** STRACT مدمجة للذكاء الاصطناعي والأمان والزمن. Python تحتاج مكتبات خارجية.

**س: هل STRACT سريعة؟**
**ج:** نعم! أسرع من Python بـ 10-100x للعمليات الثقيلة خاصة AI.

**س: هل STRACT آمنة؟**
**ج:** نعم جداً! أنواع مقيدة وعقود وعزل آمن مدمج.

**س: كيف أبدأ؟**
**ج:** اقرأ هذا الدليل ثم جرب `python stract_cli.py repl`

---

## 🎯 الخطوات التالية

1. **اقرأ:** هذا الدليل الشامل
2. **جرب:** الأمثلة في REPL
3. **بناء:** مشروعك الأول
4. **استكشف:** الميزات المتقدمة
5. **ساهم:** في المشروع

---

## 📞 الدعم

- 📖 **الوثائق:** `/docs/`
- 💡 **الأمثلة:** `/examples/`
- 🐛 **أخطاء:** استخدم `python stract_cli.py check`
- 🤖 **مساعدة:** استخدم `python stract_cli.py analyze`

---

**STRACT v5.0** - برمجة المستقبل بذكاء، أمان، وزمن حقيقي! 🚀

**آخر تحديث:** 2025-11-30  
**الإصدار:** 5.0.0  
**الحالة:** مستقر ✅
