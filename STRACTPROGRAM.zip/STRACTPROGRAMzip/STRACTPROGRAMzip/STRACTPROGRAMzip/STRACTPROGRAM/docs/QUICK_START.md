# البدء السريع - Quick Start Guide
## كيفية كتابة وتشغيل الأوامر الفعلية في STRACT

---

## ⚠️ تحذير مهم:

**هذا الملف يركز على الأوامر والدوال التي تعمل حقاً فقط!**

👉 **للمزيد من التفاصيل: [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)**

---

## 1️⃣ الوضع التفاعلي (REPL)

### الأمر:
```bash
python stract_cli.py repl
```

### أمثلة تعمل:
```
stract> print "مرحبا"
مرحبا

stract> let x = 5
stract> print x
5

stract> let numbers = [1, 2, 3]
stract> print sum(numbers)
6

stract> let doubled = map(lambda x: x * 2, numbers)
stract> print doubled
[2, 4, 6]

stract> exit
```

---

## 2️⃣ تشغيل ملف

### الخطوة 1: أنشئ ملف `test.stract`:
```stract
print "مرحبا بك!"

# دالة
func add(a, b):
    return a + b

print add(5, 3)

# قائمة ودوال
let numbers = [1, 2, 3, 4, 5]
print "المجموع: " + str(sum(numbers))
print "المتوسط: " + str(sum(numbers) / len(numbers))

# فلترة
let even = filter(lambda x: x % 2 == 0, numbers)
print "الزوجية: " + str(even)
```

### الخطوة 2: شغله
```bash
python stract_cli.py run test.stract
```

### النتيجة:
```
مرحبا بك!
8
المجموع: 15
المتوسط: 3.0
الزوجية: [2, 4]
```

---

## 3️⃣ الأمثلة المتاحة

### الشامل (يعمل ✅):
```bash
python stract_cli.py run examples/hello.stract
```

### أمثلة الويب (نظرية ⚠️):
```bash
# لا تحتوي على دوال موجودة
python stract_cli.py run examples/simple_website.stract  # ⚠️ نظري
python stract_cli.py run examples/web_example.stract     # ⚠️ نظري
```

# أضف منشور جديد
curl -X POST http://localhost:5000/posts \
  -H "Content-Type: application/json" \
  -d '{"title": "منشور جديد", "content": "محتوى المنشور"}'
```

---

## 4️⃣ تحليل الكود بالذكاء الاصطناعي

```bash
python stract_cli.py analyze examples/hello.stract
```

النتيجة:
```
STRACT AI Code Analysis: examples/hello.stract
============================================================
Total Lines: 73
Code Lines: 49
Quality Score: 90/100
```

---

## 5️⃣ فحص الأخطاء بدون تشغيل

```bash
python stract_cli.py check test.stract
```

---

## 📝 أمثلة كاملة

### مثال 1: حساب بسيط

**الملف:** `math.stract`
```stract
func calculate(x, y):
    let sum = x + y
    let product = x * y
    return {"sum": sum, "product": product}

let result = calculate(10, 5)
print result
```

**الأمر:**
```bash
python stract_cli.py run math.stract
```

**النتيجة:**
```
{sum: 15, product: 50}
```

---

### مثال 2: معالجة القوائم

**الملف:** `list.stract`
```stract
let numbers = [1, 2, 3, 4, 5]

# حساب المجموع
let total = 0
for num in numbers:
    total += num

print "المجموع: " + str(total)

# مضاعفة الأرقام
let doubled = numbers.map(lambda x: x * 2)
print "مضاعف: " + str(doubled)
```

**الأمر:**
```bash
python stract_cli.py run list.stract
```

---

### مثال 3: شروط وحلقات

**الملف:** `logic.stract`
```stract
let users = [
    {"name": "علي", "age": 25},
    {"name": "أحمد", "age": 30},
    {"name": "سارة", "age": 22}
]

print "المستخدمون البالغون 25 سنة فأكثر:"
for user in users:
    if user.age >= 25:
        print "- " + user.name + " (" + str(user.age) + ")"
```

**الأمر:**
```bash
python stract_cli.py run logic.stract
```

---

### مثال 4: موقع ويب بسيط

**الملف:** `website.stract`
```stract
import web

let app = web.create_app()

let items = [
    {"id": 1, "name": "أبل"},
    {"id": 2, "name": "برتقال"}
]

@app.get("/")
func home(request):
    return {"message": "أهلا وسهلا"}

@app.get("/items")
func get_items(request):
    return {"items": items}

@app.post("/items")
func add_item(request):
    let data = request.json_data
    items.append({"id": len(items) + 1, "name": data.name})
    return {"success": true}

app.run(port=5000)
```

**الأمر:**
```bash
python stract_cli.py run website.stract
```

**الاختبار:**
```bash
# في Terminal آخر
curl http://localhost:5000
curl http://localhost:5000/items
curl -X POST http://localhost:5000/items -H "Content-Type: application/json" -d '{"name":"موز"}'
```

---

## 🎯 ملخص الأوامر

| المهمة | الأمر |
|-------|-------|
| الوضع التفاعلي | `python stract_cli.py repl` |
| تشغيل ملف | `python stract_cli.py run file.stract` |
| تحليل الكود | `python stract_cli.py analyze file.stract` |
| فحص الأخطاء | `python stract_cli.py check file.stract` |
| عرض الأوامر | `python stract_cli.py commands` |

---

## ⚡ نصائح سريعة

✅ **ضع الملفات في مجلد `examples`**
```bash
examples/
  ├── hello.stract
  ├── simple_website.stract
  ├── my_program.stract
```

✅ **استخدم أسماء واضحة للملفات**
```bash
# جيد
python stract_cli.py run my_calculator.stract

# سيء
python stract_cli.py run file.stract
```

✅ **اختبر الموقع أثناء التشغيل**
- في Terminal الأول: شغل الموقع
- في Terminal الثاني: اختبر باستخدام `curl`

✅ **استخدم print لتتبع البيانات**
```stract
let x = 10
print "قيمة x: " + str(x)
```

---

## 🚨 رسائل الخطأ الشائعة

### خطأ: File not found
```
Error: File 'test.stract' not found
```
**الحل:** تأكد من أن الملف موجود وأنك في المجلد الصحيح

### خطأ: Syntax Error
```
Parser Error: Unexpected token
```
**الحل:** تحقق من الأقواس والفواصل

### خطأ: Port in use
```
Error: Port 5000 already in use
```
**الحل:** استخدم منفذ مختلف: `app.run(port=8000)`

---

**الآن أنت جاهز! ابدأ بـ `python stract_cli.py repl` 🚀**
