# 🎯 دليل البدء - STRACT v5.0

---

## ✅ الخطوة 1: تثبيت واستخدام

### على Replit (الأسهل - الآن!)
```bash
python stract_cli.py repl
```

### على حاسوبك
```bash
# 1. Download من Replit
# 2. فك الضغط
# 3. افتح Terminal وشغل:
python stract_cli.py run hello.stract
```

---

## 📝 الخطوة 2: برنامجك الأول

اكتب هذا الكود وحفظه كـ `hello.stract`:

```stract
print "مرحباً بك في STRACT!"

let name = "أحمد"
print "أهلاً " + name

let numbers = [1, 2, 3, 4, 5]
let doubled = numbers.map(lambda x: x * 2)
print doubled
```

شغله:
```bash
python stract_cli.py run hello.stract
```

---

## 🧠 الخطوة 3: تعلم الأساسيات

### المتغيرات
```stract
let x = 10
const PI = 3.14
var y = 20
```

### الدوال
```stract
func add(a, b):
    return a + b

print add(5, 3)  # 8
```

### الحلقات
```stract
for i in range(1, 6):
    print i * i
```

---

## 🛡️ الخطوة 4: الأمان

### أنواع مقيدة
```stract
type PositiveInt: Int where value > 0

func safeDivide(a, b):
    requires b != 0
    ensures result * b == a
    return a / b
```

---

## 🤖 الخطوة 5: الذكاء الاصطناعي

### Tensors
```stract
tensor weights[10, 5] gpu
tensor data[100] = [1.0, 2.0, 3.0, ...]
```

---

## ⏱️ الخطوة 6: البرمجة الزمنية

### Streams
```stract
stream data = source() |> filter(x: x > 0)
```

---

## 🚀 الخطوات التالية

1. اقرأ: [دليل شامل](COMPREHENSIVE_GUIDE_AR.md)
2. استكشف: [الأمثلة](EXAMPLES_AR.md)
3. ابن: مشروعك الأول

**البدء الآن!** ✨
