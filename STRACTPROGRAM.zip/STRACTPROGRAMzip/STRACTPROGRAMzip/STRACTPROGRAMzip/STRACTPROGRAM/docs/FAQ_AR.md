# ❓ الأسئلة الشائعة - FAQ

---

## عام

### س: ما هي STRACT؟
**ج:** لغة برمجة ثورية بثلاث ميزات:
- AI-Native (ذكاء اصطناعي كلغة أولى)
- Reactive & Temporal (برمجة زمنية)
- Contractual Safety (أمان تعاقدي)

### س: هل STRACT سهلة التعلم؟
**ج:** نعم! بناء جملي بسيط مثل Python مع قوة أكبر.

### س: هل STRACT سريعة؟
**ج:** نعم، أسرع من Python بـ 10-100x للعمليات الثقيلة خاصة AI.

### س: هل STRACT مجانية؟
**ج:** نعم، مفتوحة المصدر بـ MIT License.

---

## الاستخدام

### س: كيف أبدأ؟
**ج:** اقرأ [دليل البدء](GETTING_STARTED_AR.md) ثم جرب الأمثلة.

### س: أين الأمثلة؟
**ج:** في `examples/` و [هنا](EXAMPLES_AR.md).

### س: كيف أشغل برنامج؟
```bash
python stract_cli.py run file.stract
```

### س: كيف أستخدم الوضع التفاعلي؟
```bash
python stract_cli.py repl
```

---

## الميزات

### س: ما الفرق بين STRACT و Python؟

| الميزة | STRACT | Python |
|--------|--------|--------|
| AI مدمج | ✅ | ❌ |
| أمان | ✅✅✅ | ✅ |
| زمنية | ✅✅✅ | ❌ |
| سهولة | ✅✅✅ | ✅✅✅ |

### س: هل يمكن استخدام STRACT للويب؟
**ج:** نعم، لديها دعم كامل للـ APIs والـ REST.

### س: هل يمكن استخدام STRACT للـ AI؟
**ج:** نعم، بل أفضل من Python! Tensors مدمجة.

### س: ما هي أنواع مقيدة (Refinement Types)؟
```stract
type PositiveInt: Int where value > 0
```
تفرض قاعدة على النوع تلقائياً.

### س: ما هي العقود (Contracts)؟
```stract
func divide(a, b):
    requires b != 0
    ensures result * b == a
    return a / b
```
شروط مسبقة وشروط لاحقة.

---

## AI والذكاء الاصطناعي

### س: كيف أنشئ tensor؟
```stract
tensor weights[100, 50] gpu gradient
```

### س: كيف أشكل نموذج AI؟
```stract
model NeuralNet:
    Dense(128, activation="relu")
    Dense(10, activation="softmax")
```

### س: كيف أحسب التفاضل؟
```stract
gradient loss with respect to weights
```

### س: هل STRACT تدعم GPU؟
**ج:** نعم! استخدم `gpu` في التعريف.

---

## الأمان

### س: ما هي أنواع مقيدة (Refinement Types)؟
**ج:** أنواع بقيود تفرض تلقائياً:
```stract
type Age: Int where value >= 0 and value <= 150
```

### س: ما هو Sandbox؟
**ج:** عزل آمن للكود:
```stract
sandbox [network, file]:
    secureOperation()
```

### س: هل كود STRACT آمن افتراضياً؟
**ج:** نعم! أنواع مقيدة وعقود وعزل آمن مدمج.

---

## الأداء

### س: هل STRACT سريعة مقارنة بـ C++؟
**ج:** قريبة جداً، خاصة مع GPU optimization.

### س: هل هناك overhead لـ Type Safety؟
**ج:** لا، التحقق يتم في التحليل قبل التنفيذ.

### س: كيف أحسّن الأداء؟
**ج:** استخدم GPU، تجنب الحلقات غير الضرورية.

---

## المشاكل والحلول

### س: أحصل على خطأ Syntax Error
**ج:** استخدم `python stract_cli.py check file.stract`

### س: أحصل على خطأ Runtime Error
**ج:** استخدم try/catch:
```stract
try:
    risky_operation()
catch error:
    print error
```

### س: كيف أصحح الأخطاء؟
**ج:** استخدم:
```bash
python stract_cli.py analyze file.stract
```

---

## التطوير

### س: كيف أساهم في STRACT؟
**ج:** فتح issue أو pull request على GitHub.

### س: هل توجد خريطة طريق؟
**ج:** نعم، موجودة في المشروع.

### س: متى الإصدار التالي؟
**ج:** يتم التحديث بانتظام حسب الأولويات.

---

## الإرشادات

### أفضل الممارسات

✅ **افعل:**
- استخدم أنواع مقيدة
- استخدم عقود البرمجة
- استخدم Streams للبيانات الحية

❌ **تجنب:**
- الحلقات المتداخلة العميقة
- تجنب الكود غير الآمن
- تجنب الـ Magic Numbers

---

## الروابط المهمة

- 📖 [دليل شامل](COMPREHENSIVE_GUIDE_AR.md)
- 🔍 [مرجع اللغة](LANGUAGE_REFERENCE.md)
- 💡 [أمثلة عملية](EXAMPLES_AR.md)
- 🎯 [دليل البدء](GETTING_STARTED_AR.md)

---

## لم تجد إجابتك؟

أرسل سؤالك في قسم Issues بالمشروع! 📧

**STRACT Community - نحن هنا للمساعدة! 🚀**
