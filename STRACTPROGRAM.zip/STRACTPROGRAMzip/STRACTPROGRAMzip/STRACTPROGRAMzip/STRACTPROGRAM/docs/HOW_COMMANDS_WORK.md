# شرح الأوامر - كيفية عملها فعلاً
# How Commands Work - The Real Way

---

## ⚠️ تحذير مهم:

**هذا الملف يشرح الأوامر التي تعمل حقاً فقط!**

للمزيد من التفاصيل عن الدوال المدمجة: [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)

---

## 📌 الفكرة الأساسية

جميع الأوامر تبدأ بـ:
```bash
python stract_cli.py [COMMAND]
```

**الأوامر المتاحة:**
1. `repl` - وضع تفاعلي
2. `run` - تشغيل ملف
3. `check` - فحص أخطاء
4. `commands` - عرض جميع الأوامر

---

## 1️⃣ الأمر `repl` (الوضع التفاعلي)

### كيف يعمل؟
يفتح نافذة تفاعلية تستقبل أوامر STRACT مباشرة.

### الأمر:
```bash
python stract_cli.py repl
```

### مثال عملي:

**خطوة 1:** اكتب الأمر
```bash
python stract_cli.py repl
```

**خطوة 2:** ستظهر:
```
╔════════════════════════════════╗
║   STRACT v4.0                  ║
║   Programming Language         ║
╚════════════════════════════════╝

stract>
```

**خطوة 3:** اكتب الأوامر (الدوال الفعلية فقط):

```
stract> print "مرحبا"
مرحبا

stract> let x = 10
stract> let y = 20
stract> print x + y
30

stract> let numbers = [1, 2, 3, 4, 5]
stract> print sum(numbers)
15

stract> let doubled = map(lambda x: x * 2, numbers)
stract> print doubled
[2, 4, 6, 8, 10]

stract> exit
Goodbye!
```

### ✅ الأوامر التي تعمل:
- `print "نص"` - طباعة
- `let x = value` - متغير
- `const x = value` - ثابت
- `if/elif/else` - شروط
- `for x in list` - حلقة
- `while` - حلقة
- `func name()` - دالة
- `lambda` - دالة بدون اسم
- `sum(), len(), min(), max()` - دوال مدمجة
- `map(), filter(), sorted()` - دوال عالية المستوى

---

## 2️⃣ الأمر `run` (تشغيل ملف)

### كيف يعمل؟
يقرأ ملف `.stract` ويشغل جميع الأوامر بداخله.

### الأمر:
```bash
python stract_cli.py run [FILE_NAME]
```

### مثال عملي:

**خطوة 1:** أنشئ ملف `example.stract`
```stract
# حساب المتوسط
let numbers = [10, 20, 30, 40, 50]

let total = sum(numbers)
let count = len(numbers)
let average = total / count

print "الأرقام: " + str(numbers)
print "الإجمالي: " + str(total)
print "العدد: " + str(count)
print "المتوسط: " + str(average)
```

**خطوة 2:** شغّل الملف
```bash
python stract_cli.py run example.stract
```

**خطوة 3:** انظر النتيجة
```
الأرقام: [10, 20, 30, 40, 50]
الإجمالي: 150
العدد: 5
المتوسط: 30.0
```

---

## 3️⃣ الأمر `check` (فحص الأخطاء)

### كيف يعمل؟
يفحص الملف بحثاً عن أخطاء بدون تشغيله.

### الأمر:
```bash
python stract_cli.py check [FILE_NAME]
```

### مثال عملي:

**ملف صحيح:**
```bash
python stract_cli.py check example.stract
```

**النتيجة:**
```
✓ Syntax OK: example.stract
```

**ملف به خطأ:**
```stract
# خطأ: قوس غير مغلق
let list = [1, 2, 3
print list
```

**الأمر:**
```bash
python stract_cli.py check wrong.stract
```

**النتيجة:**
```
✗ Error: Missing closing bracket
```

---

## 4️⃣ الأمر `commands` (عرض الأوامر)

### كيف يعمل؟
يعرض جميع الأوامر المتاحة.

### الأمر:
```bash
python stract_cli.py commands
```

### النتيجة:
```
Available Commands:
  repl      - Interactive mode
  run       - Run a file
  check     - Check syntax
  commands  - Show this help
```

---

## 📚 أمثلة عملية كاملة

### مثال 1: حساب العاملي

**ملف `factorial.stract`:**
```stract
func factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

print "حساب العاملي"
print "5! = " + str(factorial(5))
print "6! = " + str(factorial(6))
print "10! = " + str(factorial(10))
```

**تشغيل:**
```bash
python stract_cli.py run factorial.stract
```

**النتيجة:**
```
حساب العاملي
5! = 120
6! = 720
10! = 3628800
```

---

### مثال 2: فلترة الأرقام

**ملف `filter.stract`:**
```stract
let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# الأرقام الزوجية
let even = filter(lambda x: x % 2 == 0, numbers)
print "الأرقام الزوجية: " + str(even)

# الأرقام الفردية
let odd = filter(lambda x: x % 2 != 0, numbers)
print "الأرقام الفردية: " + str(odd)

# الأرقام أكبر من 5
let big = filter(lambda x: x > 5, numbers)
print "أكبر من 5: " + str(big)
```

**تشغيل:**
```bash
python stract_cli.py run filter.stract
```

**النتيجة:**
```
الأرقام الزوجية: [2, 4, 6, 8, 10]
الأرقام الفردية: [1, 3, 5, 7, 9]
أكبر من 5: [6, 7, 8, 9, 10]
```

---

### مثال 3: جدول الضرب

**ملف `multiplication.stract`:**
```stract
func multiplication_table(n):
    print "جدول الضرب للعدد " + str(n)
    print "━━━━━━━━━━━━━━━━━"
    
    for i in range(1, 11):
        let result = n * i
        print str(n) + " × " + str(i) + " = " + str(result)

multiplication_table(5)
```

**تشغيل:**
```bash
python stract_cli.py run multiplication.stract
```

**النتيجة:**
```
جدول الضرب للعدد 5
━━━━━━━━━━━━━━━━━
5 × 1 = 5
5 × 2 = 10
5 × 3 = 15
5 × 4 = 20
5 × 5 = 25
5 × 6 = 30
5 × 7 = 35
5 × 8 = 40
5 × 9 = 45
5 × 10 = 50
```

---

### مثال 4: معالجة البيانات

**ملف `data.stract`:**
```stract
let students = [
    {"name": "أحمد", "score": 85},
    {"name": "فاطمة", "score": 92},
    {"name": "علي", "score": 78},
    {"name": "سارة", "score": 88}
]

# حساب المتوسط
let scores = map(lambda s: s["score"], students)
let total = sum(scores)
let average = total / len(scores)

print "نتائج الطلاب"
print "━━━━━━━━━━━━━━━━━━━━"

for student in students:
    print student["name"] + ": " + str(student["score"])

print "━━━━━━━━━━━━━━━━━━━━"
print "المتوسط: " + str(round(average, 2))
print "الأعلى: " + str(max(scores))
print "الأقل: " + str(min(scores))
```

**تشغيل:**
```bash
python stract_cli.py run data.stract
```

**النتيجة:**
```
نتائج الطلاب
━━━━━━━━━━━━━━━━━━━━
أحمد: 85
فاطمة: 92
علي: 78
سارة: 88
━━━━━━━━━━━━━━━━━━━━
المتوسط: 85.75
الأعلى: 92
الأقل: 78
```

---

## ✅ ملخص الأوامر

| الأمر | الاستخدام | مثال |
|------|-----------|------|
| **repl** | وضع تفاعلي | `python stract_cli.py repl` |
| **run** | تشغيل ملف | `python stract_cli.py run file.stract` |
| **check** | فحص أخطاء | `python stract_cli.py check file.stract` |
| **commands** | عرض الأوامر | `python stract_cli.py commands` |

---

## 🎯 الخطوات الأولى

### 1. جرّب REPL:
```bash
python stract_cli.py repl
stract> print "Hello"
stract> exit
```

### 2. قم بتشغيل مثال:
```bash
python stract_cli.py run examples/hello.stract
```

### 3. أنشئ ملفك الخاص:
```stract
# my_program.stract
let numbers = [1, 2, 3, 4, 5]
print "المجموع: " + str(sum(numbers))
```

### 4. شغّله:
```bash
python stract_cli.py run my_program.stract
```

---

**استخدم الأوامر الفعلية فقط! 🚀**
