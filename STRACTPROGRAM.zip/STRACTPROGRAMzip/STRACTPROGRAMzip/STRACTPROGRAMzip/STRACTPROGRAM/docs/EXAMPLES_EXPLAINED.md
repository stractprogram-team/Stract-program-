# شرح الأمثلة - الخطوة بخطوة
# Examples Explained Step by Step

---

## ⚠️ ملاحظة مهمة:

كل الأمثلة في هذا الملف **تعمل فعلاً** - جرّبها الآن!

---

## 📚 الأمثلة المتاحة

```
examples/
├── hello.stract           # مثال شامل ✅
├── simple_website.stract  # موقع بسيط (نظري ⚠️)
├── web_example.stract     # موقع متقدم (نظري ⚠️)
└── ai_example.stract      # تحليل AI (نظري ⚠️)
```

---

## 1️⃣ مثال `hello.stract` (الشامل) ✅

هذا المثال **يعمل فعلاً** - جرّبه الآن!

### تشغيله:
```bash
python stract_cli.py run examples/hello.stract
```

### السطور بالتفصيل:

#### الطباعة الأساسية:
```stract
print "Welcome to STRACT v4.0!"
print "========================================"
```
**النتيجة:**
```
Welcome to STRACT v4.0!
========================================
```

#### المتغيرات:
```stract
let greeting = "Hello, Ali!"
print greeting
```
**النتيجة:**
```
Hello, Ali!
```

#### حلقة for مع القائمة:
```stract
for name in ["Ali", "Ahmed"]:
    print "Hello, " + name
```
**النتيجة:**
```
Hello, Ali
Hello, Ahmed
```

#### جمع الأرقام:
```stract
let numbers = [1, 2, 3, 4, 5]
let sum_result = sum(numbers)
print "Sum: " + str(sum_result)
```
**النتيجة:**
```
Sum: 15
```

#### حلقة while:
```stract
let count = 1
while count <= 5:
    print count
    count = count + 1
```
**النتيجة:**
```
1
2
3
4
5
```

#### الشروط (if/elif/else):
```stract
let grade = 85
if grade >= 90:
    print "Grade: A"
elif grade >= 80:
    print "Grade: B"
else:
    print "Grade: C"
```
**النتيجة:**
```
Grade: B
```

#### الدوال:
```stract
func double(x):
    return x * 2

result = double(5)
print "Double of 5: " + str(result)
```
**النتيجة:**
```
Double of 5: 10
```

#### القوائس والدوال العالية المستوى:
```stract
let items = [10, 20, 30, 40, 50]
print "Items: " + str(items)
print "First: " + str(items[0])
print "Last: " + str(items[-1])
print "Sum: " + str(sum(items))
```
**النتيجة:**
```
Items: [10, 20, 30, 40, 50]
First: 10
Last: 50
Sum: 150
```

---

## 2️⃣ أمثلة إضافية تعمل ✅

### مثال: حساب العاملي

**الكود:**
```stract
func factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

print "5! = " + str(factorial(5))
print "6! = " + str(factorial(6))
```

**تشغيله:**
```bash
python stract_cli.py repl
stract> func factorial(n):
...     if n <= 1:
...         return 1
...     return n * factorial(n - 1)
stract> print factorial(5)
120
```

---

### مثال: فلترة البيانات

**الكود:**
```stract
let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# الأرقام الزوجية فقط
let even = filter(lambda x: x % 2 == 0, numbers)
print "Even: " + str(even)

# مضاعفة كل عنصر
let doubled = map(lambda x: x * 2, numbers)
print "Doubled: " + str(doubled)
```

**النتيجة:**
```
Even: [2, 4, 6, 8, 10]
Doubled: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
```

---

### مثال: معالجة قاموس (Dictionary)

**الكود:**
```stract
let person = {
    "name": "أحمد",
    "age": 25,
    "city": "الرياض"
}

print "Name: " + person["name"]
print "Age: " + str(person["age"])
print "City: " + person["city"]
```

**النتيجة:**
```
Name: أحمد
Age: 25
City: الرياض
```

---

### مثال: الدوال مع معاملات متعددة

**الكود:**
```stract
func add(a, b):
    return a + b

func multiply(a, b):
    return a * b

print "5 + 3 = " + str(add(5, 3))
print "5 * 3 = " + str(multiply(5, 3))
```

**النتيجة:**
```
5 + 3 = 8
5 * 3 = 15
```

---

### مثال: معالجة الأخطاء

**الكود:**
```stract
try:
    let x = 10
    let y = 0
    let result = x / y
    print result
catch error:
    print "Error: Cannot divide by zero"
```

**النتيجة:**
```
Error: Cannot divide by zero
```

---

## 3️⃣ أمثلة الويب (نظرية) ⚠️

**الملفات التالية تحتوي على أمثلة نظرية:**
- `simple_website.stract`
- `web_example.stract`
- `ai_example.stract`

**لا تحتوي على دوال موجودة مثل `import web`**

👉 **لمزيد من التفاصيل: [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)**

---

## 📋 ملخص الدوال المتاحة

| الدالة | الاستخدام | مثال |
|--------|-----------|------|
| `print` | طباعة | `print "Hello"` |
| `len` | الطول | `len([1,2,3])` → 3 |
| `sum` | الجمع | `sum([1,2,3])` → 6 |
| `max` | الأكبر | `max([1,5,3])` → 5 |
| `min` | الأصغر | `min([1,5,3])` → 1 |
| `sorted` | ترتيب | `sorted([3,1,2])` → [1,2,3] |
| `reversed` | عكس | `reversed([1,2,3])` → [3,2,1] |
| `map` | تطبيق دالة | `map(lambda x: x*2, [1,2])` → [2,4] |
| `filter` | تصفية | `filter(lambda x: x>2, [1,2,3])` → [3] |
| `enumerate` | مع الفهرس | `enumerate(["a","b"])` → [(0,"a"),(1,"b")] |
| `zip` | دمج | `zip([1,2], ["a","b"])` → [(1,"a"),(2,"b")] |
| `range` | نطاق | `range(3)` → [0,1,2] |
| `str` | نص | `str(42)` → "42" |
| `int` | عدد | `int("42")` → 42 |
| `float` | عشري | `float("3.14")` → 3.14 |

---

## 🎯 ابدأ الآن

### الخطوة 1: جرّب الأمثلة
```bash
python stract_cli.py run examples/hello.stract
```

### الخطوة 2: اكتب مثالك
```stract
let numbers = [5, 2, 8, 1, 9]
print "Original: " + str(numbers)
print "Sorted: " + str(sorted(numbers))
print "Sum: " + str(sum(numbers))
```

### الخطوة 3: شغّله
```bash
python stract_cli.py run my_example.stract
```

---

**استخدم الأمثلة الحقيقية فقط! 🚀**
