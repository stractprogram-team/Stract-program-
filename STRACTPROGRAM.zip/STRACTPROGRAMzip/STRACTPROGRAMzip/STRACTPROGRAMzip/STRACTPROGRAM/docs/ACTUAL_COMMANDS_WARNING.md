# ⚠️ تحذير مهم - اقرأ أولاً!
# Important Warning - Read First!

---

## 🔴 تحذير عاجل:

### **الملفات التالية تحتوي على أمثلة نظرية:**

| الملف | الحالة |
|------|--------|
| CYBERSECURITY_GUIDE.md | ❌ أمثلة نظرية (غير موجودة) |
| SYNTAX_GUIDE.md | ⚠️ بعض الأمثلة نظرية |
| START_HERE.md | ⚠️ بعض الأمثلة نظرية |

### **استخدم هذا الملف للدوال الفعلية فقط:**

👉 **[REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)** - الدوال التي تعمل حقاً!

---

## ❌ الأوامر التي **لا توجد** (ترمي خطأ):

```stract
scan_network()              # ❌ غير موجود
find_wifi_networks()        # ❌ غير موجود
get_public_ip_info()        # ❌ غير موجود
monitor_network()           # ❌ غير موجود
import network              # ❌ الوحدة غير موجودة
import web                  # ❌ الوحدة غير موجودة
import crypto               # ❌ الوحدة غير موجودة
```

---

## ✅ الأوامر التي **توجد فعلاً** (تعمل):

```stract
print                       # ✅ يعمل
input                       # ✅ يعمل
len()                       # ✅ يعمل
range()                     # ✅ يعمل
str, int, float            # ✅ يعمل
sum, min, max              # ✅ يعمل
map, filter, reduce        # ✅ يعمل
sorted, reversed           # ✅ يعمل
lambda                      # ✅ يعمل
if, for, while             # ✅ يعمل
func                        # ✅ يعمل
try, catch, finally        # ✅ يعمل
```

---

## 🎯 ماذا تفعل الآن:

### الخطوة 1: اقرأ الملف الصحيح
👉 **[REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)**

### الخطوة 2: جرب الأوامر المتاحة فقط
```bash
python stract_cli.py repl
```

### الخطوة 3: استخدم الأمثلة من REAL_FUNCTIONS.md
```stract
let numbers = [1, 2, 3, 4, 5]
print sum(numbers)      # ✅ يعمل
print map(lambda x: x*2, numbers)  # ✅ يعمل
```

---

## 📚 ملفات الدراسة:

| الملف | الاستخدام |
|------|-----------|
| **REAL_FUNCTIONS.md** | ✅ اقرأ هذا أولاً |
| QUICK_START.md | أمثلة بسيطة |
| SYNTAX_GUIDE.md | البناء الجملي (احذر من الأمثلة النظرية) |
| CYBERSECURITY_GUIDE.md | أمثلة نظرية (معلومات تاريخية) |

---

**الآن انتقل إلى [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md) وابدأ! 🚀**
