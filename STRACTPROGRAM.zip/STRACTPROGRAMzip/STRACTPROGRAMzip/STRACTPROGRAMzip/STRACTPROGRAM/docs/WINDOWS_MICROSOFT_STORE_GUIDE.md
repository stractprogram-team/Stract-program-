# 🪟 دليل تثبيت Python من Microsoft Store وتشغيل STRACT على Windows

> **تاريخ التحديث:** 2025-11-29
> **الهدف:** شرح معمق لاستخدام Python من Microsoft Store مع STRACT

---

## 📌 مقدمة سريعة

إذا حمّلت Python من **Microsoft Store**، فأنت اتخذت الخيار الأفضل! لأن:
- ✅ تحديثات تلقائية
- ✅ سهل التثبيت والإزالة
- ✅ لا توجد مشاكل في المسارات (PATH)
- ✅ آمن وموثوق

---

## 1️⃣ التحقق من تثبيت Python

### الخطوة 1: افتح Command Prompt

**الطريقة الأسهل:**
1. اضغط على مفتاح **Windows** ⊞
2. اكتب: `cmd`
3. اضغط **Enter**

**أو استخدم PowerShell:**
1. اضغط على مفتاح **Windows** ⊞
2. اكتب: `powershell`
3. اضغط **Enter**

---

### الخطوة 2: تحقق من الإصدار

اكتب في Terminal:
```bash
python --version
```

**النتيجة المتوقعة:**
```
Python 3.11.0
```
أو إصدار أحدث (3.12, 3.13, إلخ)

---

## 2️⃣ إذا لم يعمل `python --version`

### المشكلة 1: `python` غير معروف

**الحل:**
```bash
py --version
```

إذا نجح، استخدم `py` بدلاً من `python`:
```bash
py stract_cli.py repl
```

---

### المشكلة 2: لا توجد نتيجة

**الحل 1 - إعادة تشغيل Terminal:**
1. أغلق Terminal تماماً
2. افتحه مرة أخرى
3. اكتب: `python --version`

**الحل 2 - إضافة Python إلى PATH:**

1. افتح **Settings** (الإعدادات)
2. ابحث عن: `Environment Variables` (متغيرات البيئة)
3. اختر: `Edit the system environment variables`
4. انقر: `Environment Variables` (الزر السفلي)
5. تحت `User variables`، انقر: `New`
6. أكتب:
   - **Variable name:** `PATH`
   - **Variable value:** `C:\Users\YourUsername\AppData\Local\Microsoft\WindowsApps`
7. انقر: `OK` ثم `OK` مرة أخرى
8. أعد تشغيل Terminal

---

## 3️⃣ التحقق من pip (مدير الحزم)

`pip` هو أداة لتثبيت المكتبات الإضافية.

اكتب:
```bash
pip --version
```

**النتيجة المتوقعة:**
```
pip 23.2.1 from C:\Users\YourUsername\AppData\Local\Programs\Python\Python311\lib\site-packages\pip (python 3.11)
```

---

## 4️⃣ البيئة المثالية

بعد التثبيت من Microsoft Store، يجب أن تكون لديك:

```
✅ Python 3.11+
✅ pip
✅ في PATH (قابل للاستخدام من أي مجلد)
✅ تحديثات تلقائية
```

**تحقق من كل شيء:**
```bash
python --version
pip --version
python -m venv --help
```

جميع الأوامر السابقة يجب أن تعطيك نتائج موجبة.

---

## 5️⃣ تحميل STRACT وتشغيله

### الطريقة 1: عبر Replit (الآن)

```bash
python stract_cli.py repl
```

**النتيجة:**
```
╔════════════════════════════════╗
║   STRACT v4.0                  ║
║   Programming Language         ║
╚════════════════════════════════╝

stract>
```

### الطريقة 2: على حاسوبك

#### أ) تحميل الملفات:

1. من Replit، انقر الملفات 📁
2. انقر الثلاث نقاط ⋮
3. اختر: `Download as zip`
4. فك الضغط في: `C:\Users\YourUsername\STRACT`

#### ب) افتح Terminal في المجلد:

```bash
cd C:\Users\YourUsername\STRACT
```

#### ج) شغّل STRACT:

```bash
python stract_cli.py repl
```

---

## 6️⃣ تشغيل أمثلة STRACT

### الأمثلة المتاحة:

```bash
python stract_cli.py run examples/hello.stract
python stract_cli.py run examples/simple_website.stract
python stract_cli.py run examples/protected_app.stract
```

### إنشاء ملفك الأول:

**أنشئ ملف `test.stract`:**
```stract
print "Hello from Windows!"
let x = 10
let y = 20
print "Sum: " + str(x + y)
```

**شغّله:**
```bash
python stract_cli.py run test.stract
```

**النتيجة:**
```
Hello from Windows!
Sum: 30
```

---

## 7️⃣ مشاكل شائعة وحلولها

### مشكلة 1: `ModuleNotFoundError: No module named 'stract_cli'`

**السبب:** أنت في مجلد خاطئ

**الحل:**
```bash
cd C:\Users\YourUsername\STRACT
python stract_cli.py repl
```

---

### مشكلة 2: `python is not recognized`

**الحل 1 - استخدم `py`:**
```bash
py stract_cli.py repl
```

**الحل 2 - أضف Python إلى PATH:**
*(انظر القسم 2)*

---

### مشكلة 3: `Permission denied` أو `Access is denied`

**الحل:**
1. أغلق أي برنامج مضاد للفيروسات
2. جرّب من مجلد آخر (ليس Program Files)
3. شغّل Terminal كـ Administrator (بصلاحيات)

**كيفية تشغيل Terminal كـ Administrator:**
1. انقر بزر الماوس الأيمن على Terminal
2. اختر: `Run as administrator`

---

### مشكلة 4: `It is the same file`

**السبب:** محاولة تشغيل نفس الملف مرتين

**الحل:**
1. أغلق Terminal الأول
2. افتح Terminal جديد
3. شغّل الأمر مرة أخرى

---

## 8️⃣ نصائح إضافية

### ✅ افضل الممارسات:

1. **استخدم مجلد واحد:**
   ```bash
   C:\Users\YourUsername\STRACT
   ```

2. **افتح Terminal في المجلد:**
   - انقر على شريط العنوان
   - اكتب: `cmd`
   - اضغط: **Enter**

3. **احفظ ملفاتك بصيغة `.stract`:**
   ```
   test.stract
   hello.stract
   app.stract
   ```

4. **استخدم REPL للتجريب:**
   ```bash
   python stract_cli.py repl
   ```

5. **استخدم run للملفات:**
   ```bash
   python stract_cli.py run myfile.stract
   ```

---

### 📝 أوامر مفيدة:

```bash
# عرض الإصدار
python --version

# عرض موقع Python
python -c "import sys; print(sys.executable)"

# عرض قائمة المكتبات
pip list

# الوضع التفاعلي
python stract_cli.py repl

# تشغيل ملف
python stract_cli.py run file.stract

# عرض الأوامر المتاحة
python stract_cli.py commands
```

---

## 9️⃣ بدء سريع - خطوة بخطوة

### في 5 دقائق:

**1. افتح Command Prompt:**
```
Windows ⊞ + اكتب: cmd + Enter
```

**2. تحقق من Python:**
```bash
python --version
```

**3. انتقل إلى مجلد STRACT:**
```bash
cd C:\Users\YourUsername\STRACT
```

**4. شغّل STRACT:**
```bash
python stract_cli.py repl
```

**5. جرّب أمر:**
```
stract> print "Hello"
Hello

stract> let x = 100
stract> print x
100
```

---

## 🔟 الأوامر الكاملة

```bash
# الوضع التفاعلي
python stract_cli.py repl

# تشغيل ملف
python stract_cli.py run examples/hello.stract

# تحليل بالذكاء الاصطناعي
python stract_cli.py analyze file.stract

# فحص الأخطاء
python stract_cli.py check file.stract

# موقع ويب
python stract_cli.py web website.stract

# عرض جميع الأوامر
python stract_cli.py commands
```

---

## 1️⃣1️⃣ استكشاف الأخطاء المتقدم

### إذا استمرت المشاكل:

**اكتب هذا في Terminal:**
```bash
python -m site
```

هذا سيعطيك معلومات تفصيلية عن تثبيت Python.

---

## 1️⃣2️⃣ تحديث Python

إذا كنت على Microsoft Store:

1. افتح **Microsoft Store**
2. ابحث عن: `Python`
3. انقر: **Update** (إذا كانت متاحة)

أو:
```bash
pip install --upgrade pip
```

---

## 1️⃣3️⃣ ملخص سريع

| الخطوة | الأمر |
|------|-------|
| 1. تحقق من Python | `python --version` |
| 2. تحقق من pip | `pip --version` |
| 3. انتقل إلى المجلد | `cd C:\Users\YourUsername\STRACT` |
| 4. شغّل STRACT | `python stract_cli.py repl` |
| 5. اكتب أمر | `print "Hello"` |

---

## 🎯 الخطوات التالية

بعد التأكد من أن Python يعمل:

1. اقرأ: [docs/QUICK_START.md](QUICK_START.md)
2. جرّب: [examples/hello.stract](../examples/hello.stract)
3. ابنِ: مشروعك الأول!

---

## 📞 المساعدة

إذا استمرت المشاكل:

1. تحقق من القسم 7️⃣ (مشاكل شائعة)
2. اقرأ: [docs/INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md)
3. جرّب: Terminal جديد + إعادة تشغيل الكمبيوتر

---

**تم! أنت الآن جاهز لاستخدام STRACT على Windows مع Python من Microsoft Store! 🚀**

---

**© 2025 STUDIO VOLK - جميع الحقوق محفوظة**
