# لغة STRACT
## تصميم وتوثيق لغة البرمجة STRACT

---

## نظرة عامة

STRACT هي لغة برمجة تجمع بين:
- **بساطة Python** في القراءة والكتابة
- **تنظيم JavaScript** في الهيكلة
- **اختصار Lua** في الأوامر

---

## 1. تعريف المتغيرات

```stract
let x = 10
let name = "Stract"
let active = true
const PI = 3.14159
```

---

## 2. الدوال (Functions)

```stract
func add(a, b):
    return a + b

func greet(name):
    print("Hello, " + name)
```

---

## 3. الشروط (Conditionals)

```stract
if x > 10:
    print("big")
elif x == 10:
    print("equal")
else:
    print("small")
```

---

## 4. الحلقات (Loops)

### تكرار عددي
```stract
for i in 0..10:
    print(i)
```

### على قائمة
```stract
for item in myList:
    print(item)
```

### حلقة while
```stract
while x > 0:
    print(x)
    x = x - 1
```

---

## 5. الكائنات (Objects)

```stract
object user:
    name = "Ali"
    age = 17

print(user.name)
```

---

## 6. القوائم (Lists)

```stract
let items = [1, 2, 3, 4]
let mixed = ["text", 42, true]
```

---

## 7. الدوال المجهولة (Lambda)

```stract
let square = (x) => x * x
let add = (a, b) => a + b
```

---

## 8. الوحدات (Modules)

### استيراد
```stract
import math
import net.http as http
```

### تصدير
```stract
export func run():
    print("running...")
```

---

## 9. أوامر النظام

```stract
system.log("Hello")
system.exit()
system.time()
```

---

## 10. الفئات (Classes)

```stract
class Person:
    func init(name, age):
        self.name = name
        self.age = age

    func info():
        return self.name + " is " + self.age
```

---

## 11. Pattern Matching (Match-Case)

```stract
match x:
    case 0:
        print("zero")
    case 1:
        print("one")
    case _:
        print("other")
```

---

## 12. مثال برنامج كامل

```stract
import math

func area(r):
    return math.PI * r * r

for i in 1..5:
    print("Area:", area(i))
```

---

## أنواع Tokens

| النوع | الوصف | أمثلة |
|-------|-------|-------|
| EOF | نهاية الملف | - |
| NEWLINE | نهاية السطر | \n |
| INDENT | زيادة المسافة | - |
| DEDENT | تقليل المسافة | - |
| IDENT | معرّفات | x, name, myFunc |
| NUMBER | أرقام | 10, 3.14 |
| STRING | نصوص | "hello" |
| BOOL | قيم منطقية | true, false |
| NULL | قيمة فارغة | none |
| KEYWORD | كلمات محجوزة | let, func, if |
| OP | عوامل | +, -, ==, := |

---

## الكلمات المحجوزة

```
let, const, func, return
if, elif, else
for, in, while, break, continue
class, object
import, export
match, case
true, false, none
and, or, not
system
```

---

## العوامل

| العامل | الوصف |
|--------|-------|
| + - * / % | العمليات الحسابية |
| ** | الأس |
| == != | المقارنة |
| > >= < <= | المقارنات |
| and or not | المنطقية |
| := | التعيين التعبيري |
| .. | النطاق |
| => | Lambda |
| -> | السهم |
