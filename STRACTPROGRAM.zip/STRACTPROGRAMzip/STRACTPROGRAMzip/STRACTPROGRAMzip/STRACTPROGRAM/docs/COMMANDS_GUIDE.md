# دليل أوامر STRACT الكامل
## Complete STRACT Commands Guide

---

## ⚠️ تحذير مهم:

**بعض الأوامر في هذا الملف نظرية (لم يتم تطبيقها بعد)**

الأوامر المتاحة فعلاً:
- ✅ `repl` - الوضع التفاعلي
- ✅ `run` - تشغيل ملف
- ✅ `check` - فحص الأخطاء
- ✅ `commands` - عرض الأوامر

👉 **للأوامر الفعلية: [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)**

---

## 1. أوامر التيرمنل (Terminal Commands)

### التشغيل الأساسي

```bash
# تشغيل ملف STRACT
python stract_cli.py run program.stract

# الوضع التفاعلي (REPL)
python stract_cli.py repl

# عرض الإصدار
python stract_cli.py version

# عرض المساعدة
python stract_cli.py help

# عرض كل الأوامر
python stract_cli.py commands
```

### الفحص والتحليل

```bash
# فحص الأخطاء النحوية
python stract_cli.py check file.stract

# تحليل الكود بالذكاء الاصطناعي
python stract_cli.py analyze file.stract
```

### التطوير

```bash
# إنشاء مشروع جديد
python stract_cli.py new myproject

# تشغيل خادم الويب
python stract_cli.py web app.stract --port 5000

# وضع التصحيح
python stract_cli.py run file.stract --debug

# عرض الـ Tokens
python stract_cli.py run file.stract --tokens

# عرض شجرة AST
python stract_cli.py run file.stract --ast
```

---

## 2. التثبيت والإعداد (Installation)

### على Replit

```bash
# المشروع جاهز للتشغيل مباشرة
python stract_cli.py repl
```

### على نظامك المحلي

```bash
# 1. نسخ المشروع
git clone <repository>
cd stract

# 2. التشغيل
python stract_cli.py repl

# 3. تشغيل ملف
python stract_cli.py run examples/hello.stract
```

---

## 3. أوامر REPL التفاعلي

| الأمر | الوصف |
|-------|-------|
| `help` | عرض المساعدة |
| `exit` / `quit` | الخروج |
| `clear` | مسح الشاشة |
| `debug` | تفعيل/تعطيل وضع التصحيح |
| `tokens` | عرض/إخفاء الـ Tokens |
| `ast` | عرض/إخفاء شجرة AST |
| `version` | عرض الإصدار |
| `run FILE` | تشغيل ملف |
| `load FILE` | تحميل وتشغيل ملف |
| `multi` | وضع الكتابة متعددة الأسطر |

---

## 4. أساسيات اللغة

### المتغيرات

```stract
# تعريف متغير
let x = 10
let name = "Ali"
let active = true

# ثابت (لا يمكن تغييره)
const PI = 3.14159

# متغير بديل
var count = 0
```

### أنواع البيانات

```stract
# الأرقام
let integer = 42
let float = 3.14
let negative = -10
let hex = 0xFF
let binary = 0b1010

# النصوص
let str1 = "Hello"
let str2 = 'World'
let multiline = """
This is
multi-line
"""

# القيم المنطقية
let yes = true
let no = false

# القوائم
let list = [1, 2, 3, 4, 5]
let mixed = ["text", 42, true]

# القواميس
let dict = {"name": "Ali", "age": 25}

# القيمة الفارغة
let empty = null
```

### العمليات

```stract
# الحسابية
let sum = 10 + 5      # 15
let diff = 10 - 5     # 5
let prod = 10 * 5     # 50
let div = 10 / 5      # 2.0
let mod = 10 % 3      # 1
let power = 2 ** 3    # 8
let floor = 10 // 3   # 3

# المقارنة
let eq = 5 == 5       # true
let ne = 5 != 3       # true
let lt = 5 < 10       # true
let gt = 10 > 5       # true
let le = 5 <= 5       # true
let ge = 5 >= 5       # true

# المنطقية
let and_op = true and false   # false
let or_op = true or false     # true
let not_op = not true         # false

# التعيين المركب
x += 5    # x = x + 5
x -= 3    # x = x - 3
x *= 2    # x = x * 2
x /= 2    # x = x / 2
```

---

## 5. التحكم في التدفق

### الشروط

```stract
let x = 10

if x > 10:
    print "x is greater than 10"
elif x == 10:
    print "x equals 10"
else:
    print "x is less than 10"
```

### الحلقات

```stract
# حلقة for مع range
for i in range(5):
    print i   # 0, 1, 2, 3, 4

# حلقة for على قائمة
let items = ["a", "b", "c"]
for item in items:
    print item

# حلقة while
let count = 0
while count < 5:
    print count
    count += 1

# break و continue
for i in range(10):
    if i == 5:
        break
    if i % 2 == 0:
        continue
    print i
```

### Pattern Matching

```stract
let value = 2

match value:
    case 1:
        print "One"
    case 2:
        print "Two"
    case 3:
        print "Three"
    default:
        print "Other"
```

---

## 6. الدوال

### تعريف الدوال

```stract
func greet(name):
    print "Hello, " + name

func add(a, b):
    return a + b

# معاملات افتراضية
func greet_with_default(name="World"):
    print "Hello, " + name

# Lambda
let square = lambda x: x * x
let result = square(5)   # 25
```

### استدعاء الدوال

```stract
greet("Ali")
let sum = add(5, 3)

# arguments بالاسم
greet(name="Ahmed")
```

---

## 7. الفئات والكائنات

```stract
class Person:
    func init(name, age):
        this.name = name
        this.age = age
    
    func greet():
        print "Hello, I'm " + this.name
    
    func get_info():
        return this.name + " is " + str(this.age) + " years old"

# إنشاء كائن
let person = new Person("Ali", 25)
person.greet()
print person.get_info()

# الوراثة
class Student(Person):
    func init(name, age, grade):
        this.name = name
        this.age = age
        this.grade = grade
    
    func study():
        print this.name + " is studying"
```

---

## 8. معالجة الأخطاء

```stract
try:
    let result = 10 / 0
catch error:
    print "Error occurred:", error
finally:
    print "Cleanup complete"

# رمي استثناء
func validate(value):
    if value < 0:
        throw "Value cannot be negative"
    return value
```

---

## 9. الوحدات

```stract
# استيراد وحدة
import math
print math.sqrt(16)   # 4.0

# استيراد باسم مستعار
import http as web

# استيراد محدد
from utils import helper
```

---

## 10. تطوير المواقع

### إنشاء خادم ويب بسيط

```stract
import web

let app = web.create_app()

@app.get("/")
func index(request):
    return {"message": "Welcome to STRACT!"}

@app.get("/api/users")
func get_users(request):
    return {"users": [
        {"id": 1, "name": "Ali"},
        {"id": 2, "name": "Ahmed"}
    ]}

@app.post("/api/users")
func create_user(request):
    let data = request.json_data
    return {"id": 3, "name": data.name}

@app.get("/users/<id>")
func get_user(request, id):
    return {"user_id": id}

app.run(port=5000)
```

### تشغيل الخادم

```bash
python stract_cli.py web app.stract --port 5000
```

### REST API كاملة

```stract
import web
import json

let app = web.create_app()
let db = []

# GET all items
@app.get("/api/items")
func list_items(request):
    return {"items": db, "count": len(db)}

# GET single item
@app.get("/api/items/<id>")
func get_item(request, id):
    for item in db:
        if str(item.id) == id:
            return item
    return {"error": "Not found"}, 404

# POST new item
@app.post("/api/items")
func create_item(request):
    let data = request.json_data
    let new_id = len(db) + 1
    let item = {"id": new_id, ...data}
    db.append(item)
    return item, 201

# PUT update item
@app.put("/api/items/<id>")
func update_item(request, id):
    let data = request.json_data
    for i in range(len(db)):
        if str(db[i].id) == id:
            db[i] = {"id": int(id), ...data}
            return db[i]
    return {"error": "Not found"}, 404

# DELETE item
@app.delete("/api/items/<id>")
func delete_item(request, id):
    for i in range(len(db)):
        if str(db[i].id) == id:
            let deleted = db.pop(i)
            return {"deleted": deleted}
    return {"error": "Not found"}, 404

app.run(port=5000)
```

---

## 11. الذكاء الاصطناعي

### تحليل الكود

```bash
python stract_cli.py analyze mycode.stract
```

### استخدام AI في الكود

```stract
import ai

# تحليل كود
let code = """
func add(a, b):
    return a + b
"""
let analysis = ai.analyze(code)
print analysis.complexity
print analysis.suggestions

# شرح الأخطاء
let explanation = ai.explain_error("Undefined variable: x")
print explanation

# اقتراحات الإكمال
let suggestions = ai.suggest(code, position)
print suggestions

# إصلاح تلقائي
let fixed = ai.auto_fix(code, error)
print fixed
```

---

## 12. الدوال المدمجة الكاملة

### دوال الإدخال والإخراج

```stract
print "Hello"              # طباعة
let name = input("Name: ") # إدخال
```

### دوال التحويل

```stract
str(42)        # "42"
int("42")      # 42
float("3.14")  # 3.14
bool(1)        # true
list("abc")    # ["a", "b", "c"]
```

### دوال الحساب

```stract
len([1,2,3])          # 3
abs(-5)               # 5
min(1, 2, 3)          # 1
max(1, 2, 3)          # 3
sum([1, 2, 3])        # 6
round(3.7)            # 4
pow(2, 3)             # 8
sqrt(16)              # 4.0
```

### دوال القوائم

```stract
sorted([3, 1, 2])     # [1, 2, 3]
reversed([1, 2, 3])   # [3, 2, 1]
enumerate(list)       # [(0, a), (1, b), ...]
zip(list1, list2)     # [(a1, b1), ...]
map(func, list)       # تطبيق دالة
filter(func, list)    # تصفية
reduce(func, list)    # اختزال
any([...])            # أي عنصر صحيح
all([...])            # كل العناصر صحيحة
```

### دوال النظام

```stract
time()                # الوقت الحالي
sleep(1)              # انتظار ثانية
exit()                # خروج
type(value)           # نوع القيمة
```

---

## 13. أمثلة تطبيقية

### حاسبة بسيطة

```stract
print "Simple Calculator"
print "==================="

let a = int(input("First number: "))
let op = input("Operation (+, -, *, /): ")
let b = int(input("Second number: "))

let result = 0
match op:
    case "+":
        result = a + b
    case "-":
        result = a - b
    case "*":
        result = a * b
    case "/":
        if b != 0:
            result = a / b
        else:
            print "Error: Division by zero"
    default:
        print "Unknown operation"

print "Result:", result
```

### قائمة المهام

```stract
let tasks = []

func add_task(task):
    tasks.append({"task": task, "done": false})
    print "Added: " + task

func complete_task(index):
    if index < len(tasks):
        tasks[index].done = true
        print "Completed: " + tasks[index].task

func show_tasks():
    print "\n=== Tasks ==="
    for i in range(len(tasks)):
        let status = "[x]" if tasks[i].done else "[ ]"
        print str(i) + ". " + status + " " + tasks[i].task

# استخدام
add_task("Learn STRACT")
add_task("Build an app")
add_task("Deploy to production")
complete_task(0)
show_tasks()
```

### خادم API

```stract
import web

let app = web.create_app()
let todos = []

@app.get("/")
func home(request):
    return {"app": "Todo API", "version": "1.0"}

@app.get("/api/todos")
func list_todos(request):
    return {"todos": todos}

@app.post("/api/todos")
func add_todo(request):
    let data = request.json_data
    let todo = {
        "id": len(todos) + 1,
        "title": data.title,
        "done": false
    }
    todos.append(todo)
    return todo, 201

app.run(port=5000)
```

---

## 14. نصائح وأفضل الممارسات

1. **استخدم أسماء واضحة** للمتغيرات والدوال
2. **قسّم الكود** إلى دوال صغيرة
3. **أضف تعليقات** للكود المعقد
4. **استخدم const** للقيم الثابتة
5. **تعامل مع الأخطاء** باستخدام try/catch
6. **استخدم match/case** بدلاً من if متعددة
7. **استفد من AI** لتحليل وتحسين الكود

---

## 15. استكشاف الأخطاء

### أخطاء شائعة وحلولها

| الخطأ | السبب | الحل |
|-------|-------|------|
| Undefined variable | المتغير غير معرف | استخدم `let` لتعريفه |
| Division by zero | القسمة على صفر | تحقق قبل القسمة |
| Index out of range | فهرس خارج النطاق | تحقق من طول القائمة |
| Missing colon | نسيت النقطتين | أضف `:` بعد if/for/func |
| Unexpected token | خطأ نحوي | راجع الصياغة |

### الحصول على مساعدة

```bash
# تحليل الأخطاء
python stract_cli.py analyze file.stract

# فحص النحو
python stract_cli.py check file.stract

# وضع التصحيح
python stract_cli.py run file.stract --debug
```
