# نشر وتشغيل الموقع على أجهزة أخرى
# Deployment & Running on Other Devices

---

## ⚠️ تحذير مهم:

**أمثلة الويب في هذا الملف نظرية (غير موجودة حالياً)**

👉 **للأوامر التي تعمل فعلاً: [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)**

---

## 1️⃣ نشر الموقع على Replit (الأسهل والأسرع)

### الخطوة 1: انقر على زر "Publish"
- في أعلى نافذة Replit ستجد زر **"Publish"**
- انقر عليه

### الخطوة 2: انسخ الرابط العام
- ستحصل على رابط مثل: `https://stract-website.replit.dev`
- هذا الرابط يعمل من أي مكان في العالم!

### الخطوة 3: شارك الرابط
أرسل الرابط لأصدقائك أو افتحه على أي جهاز:
```
https://stract-website.replit.dev/
https://stract-website.replit.dev/posts
https://stract-website.replit.dev/posts/1
```

✅ **الميزات:**
- ✔️ يعمل من أي جهاز
- ✔️ لا تحتاج تثبيت أي شيء
- ✔️ الموقع مشغل 24/7

---

## 2️⃣ تشغيل على حاسوبك الشخصي

### المتطلبات:
- Python 3.11 أو أحدث
- ملفات STRACT

### الخطوات:

#### أ) تحميل ملفات المشروع

**من Replit:**
1. في Replit انقر على الملفات
2. اختر الملف → انقر **"Download"**

أو من الترمنل:
```bash
# تحميل جميع الملفات
# أو انسخ المجلد كاملاً
```

#### ب) نقل الملفات إلى حاسوبك
ضع الملفات في مجلد مثل:
```
C:\Users\YourName\stract-website\
```

#### ج) فتح الترمنل في المجلد
```bash
# في Windows
cd C:\Users\YourName\stract-website

# في Mac/Linux
cd ~/stract-website
```

#### د) تشغيل الموقع
```bash
python stract_cli.py run examples/simple_website.stract
```

#### هـ) فتح الموقع
افتح المتصفح وادخل:
```
http://localhost:5000
```

---

## 3️⃣ تشغيل على جهاز آخر في نفس الشبكة

### الحالة: أنت وصديقك على نفس الـ WiFi

#### الخطوة 1: ابحث عن عنوان IP جهازك

**في Windows:**
```bash
ipconfig
```
ابحث عن: `IPv4 Address` مثل `192.168.1.100`

**في Mac/Linux:**
```bash
ifconfig
```
ابحث عن: `inet` مثل `192.168.1.100`

#### الخطوة 2: عدّل الموقع ليستقبل اتصالات من جميع الأجهزة

افتح ملف الموقع وتأكد من آخر سطر:
```stract
app.run(port=5000)
```

#### الخطوة 3: شارك العنوان مع أصدقائك

أخبرهم بـ IP الخاص بك:
```
http://192.168.1.100:5000
```

أصدقاؤك الآن يمكنهم فتح:
```
http://192.168.1.100:5000
http://192.168.1.100:5000/posts
http://192.168.1.100:5000/items
```

---

## 4️⃣ تشغيل على VPS أو خادم (للمحترفين)

### المتطلبات:
- حساب VPS (مثل DigitalOcean, Linode)
- SSH access

### الخطوات:

#### أ) اتصل بالخادم
```bash
ssh root@your-server-ip
```

#### ب) ثبت Python
```bash
# على Ubuntu/Debian
sudo apt-get update
sudo apt-get install python3.11 python3-pip
```

#### ج) اتحمل الملفات
```bash
# استخدم Git أو SCP
git clone https://github.com/yourname/stract-website.git
cd stract-website
```

#### د) شغل الموقع
```bash
python3 stract_cli.py run examples/simple_website.stract
```

#### هـ) أضف أمان SSL (optional)
استخدم Nginx أو Apache كـ proxy

---

## 5️⃣ مشاركة الملفات (للتعاون)

### الطريقة 1: Git/GitHub

```bash
# أنشئ مستودع
git init
git add .
git commit -m "STRACT website"
git push origin main

# صديقك يستخدم:
git clone https://github.com/yourname/stract-website.git
cd stract-website
python stract_cli.py run examples/simple_website.stract
```

### الطريقة 2: Zip

```bash
# اضغط المجلد على Windows/Mac
# أو من الترمنل:
zip -r stract-website.zip stract-website/

# صديقك:
# 1. ينزل الملف
# 2. يفك الضغط
# 3. يشغله
```

### الطريقة 3: عبر Email
أرسل الملفات المهمة:
- `stract_cli.py`
- `examples/simple_website.stract`
- `STRACTPROGRAMzip/`

---

## 6️⃣ أمثلة عملية كاملة

### مثال: موقع مستضاف على Replit

```stract
import web

let app = web.create_app()

let notes = [
    {"id": 1, "title": "ملاحظة 1", "content": "المحتوى"}
]

@app.get("/")
func home(request):
    return {"message": "موقعي على الإنترنت!", "status": "online"}

@app.get("/notes")
func get_notes(request):
    return {"notes": notes}

@app.post("/notes")
func add_note(request):
    let data = request.json_data
    let new_note = {
        "id": len(notes) + 1,
        "title": data.title,
        "content": data.content
    }
    notes.append(new_note)
    return {"success": true, "note": new_note}

print "🌐 الموقع متاح الآن!"
app.run(port=5000)
```

**للنشر:**
1. احفظ كـ `my_website.stract`
2. شغله: `python stract_cli.py run my_website.stract`
3. انقر "Publish" في Replit
4. شارك الرابط!

---

## 📱 اختبار من الهاتف

### على نفس الشبكة:

```bash
# على حاسوبك:
ipconfig
# النتيجة: 192.168.1.100

# على الهاتف، افتح المتصفح وادخل:
http://192.168.1.100:5000
```

### من الإنترنت:
- استخدم Replit (أسهل حل)
- أو استأجر VPS

---

## 🔐 نصائح الأمان

إذا كنت تشغل الموقع بشكل عام:

```stract
import web

let app = web.create_app()

# تحقق من الطلبات
@app.post("/api/data")
func handle_data(request):
    let auth = request.get_header("Authorization")
    
    if not auth:
        return {"error": "غير مصرح"}
    
    # معالجة آمنة
    return {"success": true}

app.run(port=5000)
```

---

## 📊 المقارنة بين الطرق

| الطريقة | السهولة | التكلفة | السرعة | الأمان |
|--------|--------|--------|--------|--------|
| **Replit Publish** | ⭐⭐⭐⭐⭐ | مجاني | سريعة | جيد |
| **حاسوب شخصي** | ⭐⭐⭐⭐ | مجاني | محلي | متوسط |
| **شبكة محلية** | ⭐⭐⭐ | مجاني | محلي | متوسط |
| **VPS** | ⭐⭐ | بسيطة | سريعة | عالي |

---

## 🚀 البدء السريع

**الطريقة الأسهل (أنصح بها):**

1. شغل الموقع على Replit
2. انقر "Publish"
3. انسخ الرابط
4. شاركه مع أي شخص!

```bash
# أوامر سريعة:
python stract_cli.py run examples/simple_website.stract  # تشغيل محلي
# ثم Publish من الواجهة
```

---

**الآن موقعك على الإنترنت! 🌐**
