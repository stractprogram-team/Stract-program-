# 📋 أمثلة عملية STRACT v5.0
## Practical Examples - Learn by Doing

---

## 1. الأمثلة الأساسية

### مثال 1: Hello World
```stract
print "Hello, STRACT!"
```

### مثال 2: الحسابات البسيطة
```stract
let a = 10
let b = 20
print a + b      # 30
print a * b      # 200
print a ** 2     # 100
```

### مثال 3: الدوال
```stract
func multiply(x, y):
    return x * y

print multiply(5, 3)    # 15
```

### مثال 4: الحلقات
```stract
for i in range(1, 6):
    print i * i
# Output: 1, 4, 9, 16, 25
```

### مثال 5: القوائم
```stract
let numbers = [1, 2, 3, 4, 5]
let doubled = numbers.map(lambda x: x * 2)
print doubled    # [2, 4, 6, 8, 10]
```

---

## 2. أمثلة الأمان والعقود

### مثال 1: أنواع مقيدة
```stract
type PositiveInt: Int where value > 0
type Percentage: Float where value >= 0 and value <= 100

func calculateDiscount(original: PositiveInt, percent: Percentage):
    let discount = original * (percent / 100)
    return original - discount

print calculateDiscount(100, 20)     # 80
```

### مثال 2: العقود
```stract
func safeDivide(a, b):
    requires b != 0
    ensures result * b == a
    return a / b

print safeDivide(10, 2)             # 5
```

### مثال 3: الفئات الآمنة
```stract
class BankAccount:
    invariant balance >= 0
    
    func init(initialBalance):
        requires initialBalance >= 0
        this.balance = initialBalance
    
    func deposit(amount):
        requires amount > 0
        ensures this.balance > old(this.balance)
        this.balance = this.balance + amount
    
    func withdraw(amount):
        requires amount > 0
        requires amount <= this.balance
        ensures this.balance == old(this.balance) - amount
        this.balance = this.balance - amount

let account = BankAccount(1000)
account.deposit(500)
print account.balance       # 1500
account.withdraw(200)
print account.balance       # 1300
```

### مثال 4: العزل الآمن
```stract
sandbox []:
    let secure = "محلي فقط"
    print secure

sandbox [network]:
    let response = "محاكاة الاتصال"
    print response
```

---

## 3. أمثلة الذكاء الاصطناعي

### مثال 1: Tensors
```stract
# إنشاء tensors
tensor x[3, 3] gpu
tensor y[3, 3] cpu

# التعامل مع البيانات
tensor data[5] = [1.0, 2.0, 3.0, 4.0, 5.0]
print data      # [1.0, 2.0, 3.0, 4.0, 5.0]
```

### مثال 2: نموذج شبكة عصبية
```stract
model SimpleDNN:
    Dense(128, activation="relu")
    Dropout(0.2)
    Dense(64, activation="relu")
    Dense(10, activation="softmax")

# محاكاة التدريب
print "Model defined successfully"
```

### مثال 3: معالجة الصور (محاكاة)
```stract
model ImageClassifier:
    Conv2D(32, 3, activation="relu")
    MaxPool2D(2)
    Conv2D(64, 3, activation="relu")
    MaxPool2D(2)
    Flatten()
    Dense(128, activation="relu")
    Dropout(0.5)
    Dense(10, activation="softmax")

print "Image classifier model ready"
```

### مثال 4: التدريب والتحسين
```stract
# إنشاء model
model NeuralNet:
    Dense(256, activation="relu")
    Dropout(0.3)
    Dense(128, activation="relu")
    Dense(10)

# التدريب (محاكاة)
print "Training for 10 epochs..."

# التحسين
print "Optimizing for accuracy..."
```

---

## 4. أمثلة البرمجة الزمنية

### مثال 1: Streams
```stract
stream numbers = source()

stream filtered = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    |> filter(x: x > 5)
    |> map(x: x * 2)

print "Stream example completed"
```

### مثال 2: المتغيرات الزمنية
```stract
temporal clock = 0 every 1s:
    clock + 1

# محاكاة
for i in range(1, 6):
    print "Time: " + str(i) + " seconds"
```

### مثال 3: الشروط التفاعلية
```stract
temporal countdown = 10 every 1s:
    countdown - 1

when countdown == 0:
    print "Blast off!"

# محاكاة
for i in range(10, 0, -1):
    print i
print "Blast off!"
```

### مثال 4: التنفيذ الدوري
```stract
every 1s:
    print "Tick"

after 5s:
    print "Done!"

# محاكاة
for i in range(1, 6):
    print "Tick"
print "Done!"
```

---

## 5. أمثلة تطبيقات حقيقية

### مثال 1: حاسبة الفائدة
```stract
func calculateInterest(principal, rate, years):
    requires principal > 0
    requires rate > 0
    requires years > 0
    let interest = principal * rate * years / 100
    ensures interest > 0
    return interest

let p = 1000
let r = 5
let y = 2

let totalInterest = calculateInterest(p, r, y)
print "Principal: " + str(p)
print "Interest: " + str(totalInterest)
print "Total: " + str(p + totalInterest)
```

### مثال 2: معالج البيانات
```stract
func processScores(scores):
    requires scores != null and len(scores) > 0
    
    # تصفية الدرجات الصحيحة
    let valid = scores.filter(lambda x: x >= 0 and x <= 100)
    
    # الحسابات
    let total = valid.reduce(0, lambda a, b: a + b)
    let average = total / len(valid)
    let highest = valid.reduce(lambda a, b: max(a, b))
    let lowest = valid.reduce(lambda a, b: min(a, b))
    
    ensures average >= lowest and average <= highest
    
    print "Average: " + str(average)
    print "Highest: " + str(highest)
    print "Lowest: " + str(lowest)

processScores([85, 90, 78, 92, 88])
```

### مثال 3: نظام التصنيف
```stract
type Score: Int where value >= 0 and value <= 100

func getGrade(score: Score):
    requires score >= 0 and score <= 100
    
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"

let scores = [85, 92, 78, 95, 88, 65]
for score in scores:
    let grade = getGrade(score)
    print str(score) + " -> " + grade
```

### مثال 4: نظام المخزون
```stract
class Product:
    invariant quantity >= 0
    
    func init(name, price, quantity):
        requires price > 0
        requires quantity >= 0
        this.name = name
        this.price = price
        this.quantity = quantity
    
    func addStock(amount):
        requires amount > 0
        this.quantity = this.quantity + amount
    
    func removeStock(amount):
        requires amount > 0
        requires amount <= this.quantity
        this.quantity = this.quantity - amount

let product = Product("Laptop", 999.99, 10)
print "Initial: " + str(product.quantity)

product.addStock(5)
print "After adding 5: " + str(product.quantity)

product.removeStock(3)
print "After removing 3: " + str(product.quantity)
```

---

## 6. أمثلة متقدمة

### مثال 1: معالج الطلبات
```stract
class Order:
    invariant total >= 0
    
    func init(items):
        requires len(items) > 0
        this.items = items
        this.total = 0
        this.calculateTotal()
    
    func calculateTotal():
        this.total = this.items.reduce(0, lambda sum, item: sum + item["price"] * item["quantity"])
    
    func applyDiscount(discountPercent):
        requires discountPercent > 0
        requires discountPercent < 100
        this.total = this.total * (1 - discountPercent / 100)

let items = [
    {"name": "Item1", "price": 100, "quantity": 2},
    {"name": "Item2", "price": 50, "quantity": 3}
]

let order = Order(items)
print "Total before discount: " + str(order.total)

order.applyDiscount(10)
print "Total after 10% discount: " + str(order.total)
```

### مثال 2: محلل البيانات
```stract
func analyzeData(data):
    requires len(data) > 0
    
    let sorted_data = sorted(data)
    let min_val = sorted_data[0]
    let max_val = sorted_data[len(sorted_data) - 1]
    let sum_val = sorted_data.reduce(0, lambda a, b: a + b)
    let avg_val = sum_val / len(sorted_data)
    
    print "Data Analysis:"
    print "  Count: " + str(len(sorted_data))
    print "  Min: " + str(min_val)
    print "  Max: " + str(max_val)
    print "  Average: " + str(avg_val)
    print "  Sum: " + str(sum_val)

analyzeData([10, 45, 23, 98, 12, 67, 34, 89])
```

### مثال 3: نظام التقييمات
```stract
type Rating: Int where value >= 1 and value <= 5

class Review:
    invariant rating >= 1 and rating <= 5
    
    func init(author, rating, comment):
        requires rating >= 1 and rating <= 5
        requires len(comment) > 0
        this.author = author
        this.rating = rating
        this.comment = comment
    
    func display():
        print this.author + " (" + str(this.rating) + "/5)"
        print this.comment

let reviews = [
    Review("Ahmed", 5, "Excellent product!"),
    Review("Fatima", 4, "Good quality"),
    Review("Ali", 3, "Average")
]

for review in reviews:
    review.display()
    print "---"
```

---

## 7. أمثلة مع أخطاء شائعة

### ❌ خطأ: عدم الامتثال للعقد
```stract
func safeDivide(a, b):
    requires b != 0
    return a / b

print safeDivide(10, 0)     # ❌ RUNTIME ERROR!
```

### ✅ الحل: التحقق قبل الاستدعاء
```stract
let b = 0
if b != 0:
    print safeDivide(10, b)
else:
    print "Cannot divide by zero"
```

### ❌ خطأ: انتهاك النوع المقيد
```stract
type Age: Int where value >= 0 and value <= 150
let age: Age = -5     # ❌ ERROR! -5 is not valid
```

### ✅ الحل: التحقق من القيمة
```stract
type Age: Int where value >= 0 and value <= 150
let userAge = 25
if userAge >= 0 and userAge <= 150:
    let age: Age = userAge     # ✅ OK
```

---

## 8. نصائح وحيل

### ✅ استخدم الأنواع المقيدة للبيانات المهمة
```stract
type Email: String where contains(value, "@")
type Port: Int where value >= 1 and value <= 65535
```

### ✅ استخدم العقود للدوال الحرجة
```stract
func withdraw(account, amount):
    requires amount > 0
    requires amount <= account.balance
    ensures account.balance == old(account.balance) - amount
    # ...
```

### ✅ استخدم Lambda للعمليات البسيطة
```stract
let doubled = numbers.map(lambda x: x * 2)
```

### ✅ استخدم Streams للبيانات الحية
```stract
stream real_time_data = source() |> filter(x: x != null)
```

---

## 9. مشاريع عملية

### مشروع 1: آلة حاسبة
```stract
func calculate(a, operation, b):
    requires b != 0 or operation != "divide"
    
    if operation == "add":
        return a + b
    elif operation == "subtract":
        return a - b
    elif operation == "multiply":
        return a * b
    elif operation == "divide":
        ensures result * b == a
        return a / b
    else:
        return null
```

### مشروع 2: إدارة المهام
```stract
class Task:
    invariant status in ["pending", "completed"]
    
    func init(title):
        this.title = title
        this.status = "pending"
    
    func complete():
        ensures this.status == "completed"
        this.status = "completed"
```

### مشروع 3: نظام تقييم الأفلام
```stract
type MovieRating: Int where value >= 1 and value <= 10

class Movie:
    func init(title, year):
        this.title = title
        this.year = year
        this.ratings = []
    
    func addRating(rating: MovieRating):
        requires rating >= 1 and rating <= 10
        this.ratings.push(rating)
    
    func getAverageRating():
        return this.ratings.reduce(0, lambda a, b: a + b) / len(this.ratings)
```

---

**جميع الأمثلة قابلة للتشغيل والاختبار على STRACT REPL** ✅
