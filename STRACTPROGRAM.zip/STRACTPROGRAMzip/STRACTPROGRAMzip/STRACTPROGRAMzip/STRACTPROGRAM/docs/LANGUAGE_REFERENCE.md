# 🔍 مرجع اللغة STRACT v5.0
## Reference Guide - Everything You Need to Know

---

## 1. البيانات والأنواع

### الأنواع الأساسية

| النوع | الوصف | أمثلة |
|-------|-------|-------|
| `Int` | أعداد صحيحة | `42`, `-10`, `0` |
| `Float` | أعداد عشرية | `3.14`, `-2.5`, `0.0` |
| `String` | نصوص | `"Hello"`, `'World'` |
| `Boolean` | صح/خطأ | `true`, `false` |
| `Null` | لا قيمة | `null` |
| `List` | قائمة | `[1, 2, 3]` |
| `Dict` | قاموس | `{"a": 1, "b": 2}` |

### الأنواع المقيدة (Refinement Types)

```stract
type PositiveInt: Int where value > 0
type Percentage: Float where value >= 0 and value <= 100
type NonEmptyString: String where len(value) > 0
type Age: Int where value >= 0 and value <= 150
type Email: String where contains(value, "@") and contains(value, ".")
type Port: Int where value >= 1 and value <= 65535
```

---

## 2. المتغيرات والثوابت

### التعريف

```stract
let x = 10          # متغير ثابت
const PI = 3.14     # ثابت لا يتغير
var y = 20          # متغير قابل للتغيير

let name = "Ahmed"
let numbers = [1, 2, 3, 4, 5]
let person = {"name": "Ahmed", "age": 25}
```

### النطاق (Scope)

```stract
let global = 10     # نطاق عام

func example():
    let local = 20  # نطاق محلي
    print global    # ✅ يمكن الوصول
    return local

print local         # ❌ خطأ! غير موجود خارج الدالة
```

---

## 3. الدوال

### التعريف الأساسي

```stract
func add(a, b):
    return a + b

func greet(name):
    let message = "Hello " + name
    return message

func multipleReturns(x):
    if x > 0:
        return "positive"
    else:
        return "negative"
```

### دوال بدون معاملات

```stract
func sayHi():
    print "Hi!"

func getCurrentTime():
    return "12:30"
```

### دوال بقيم افتراضية

```stract
func greet(name, greeting = "Hello"):
    return greeting + " " + name

print greet("Ahmed")           # Hello Ahmed
print greet("Ahmed", "Hi")     # Hi Ahmed
```

### الدوال الغامضة (Lambda)

```stract
let square = lambda x: x * x
print square(5)             # 25

let add = lambda x, y: x + y
print add(3, 4)             # 7

let list = [1, 2, 3, 4, 5]
let doubled = list.map(lambda x: x * 2)
```

### الدوال العليا (Higher-Order)

```stract
func applyTwice(f, x):
    return f(f(x))

let double = lambda x: x * 2
print applyTwice(double, 5)     # 20 (double(double(5)))
```

---

## 4. العقود (Contracts)

### الشروط المسبقة والمسبقة

```stract
func divide(a, b):
    requires b != 0                 # شرط مسبق
    ensures result * b == a         # شرط لاحق
    return a / b

func sqrt(x):
    requires x >= 0
    ensures result >= 0
    return x ** 0.5
```

### استخدام القيم السابقة

```stract
func transfer(from_account, to_account, amount):
    requires amount > 0
    requires amount <= from_account.balance
    ensures from_account.balance == old(from_account.balance) - amount
    ensures to_account.balance == old(to_account.balance) + amount
    from_account.balance -= amount
    to_account.balance += amount
```

### الثوابت (Invariants) في الفئات

```stract
class BankAccount:
    invariant balance >= 0          # يجب أن يكون صحيح دائماً
    invariant owner != null
    
    func init(owner_name, initial_balance):
        requires initial_balance >= 0
        this.owner = owner_name
        this.balance = initial_balance
    
    func deposit(amount):
        requires amount > 0
        this.balance += amount
```

---

## 5. التحكم بتدفق البرنامج

### الشروط (If/Else)

```stract
if x > 10:
    print "Greater than 10"
elif x > 5:
    print "Greater than 5"
else:
    print "5 or less"

# Ternary
let status = "adult" if age >= 18 else "minor"
```

### المطابقة (Match/Case)

```stract
match grade:
    case "A":
        print "Excellent"
    case "B":
        print "Good"
    case "C":
        print "Fair"
    default:
        print "Poor"
```

### الحلقات (Loops)

```stract
# For loop
for i in range(1, 6):
    print i         # 1, 2, 3, 4, 5

for item in [1, 2, 3]:
    print item * 2

# While loop
let i = 0
while i < 5:
    print i
    i = i + 1

# Break و Continue
for i in range(1, 10):
    if i == 5:
        break       # توقف
    if i == 2:
        continue    # تخطي
    print i
```

### معالجة الأخطاء

```stract
try:
    let x = 10 / 0
    print x
catch error:
    print "Error: " + error
finally:
    print "Done"
```

---

## 6. الفئات (Classes)

### التعريف الأساسي

```stract
class Person:
    func init(name, age):
        this.name = name
        this.age = age
    
    func greet():
        print "Hello, I'm " + this.name
    
    func haveBirthday():
        this.age = this.age + 1

let person = Person("Ahmed", 25)
person.greet()
person.haveBirthday()
```

### الوراثة

```stract
class Animal:
    func makeSound():
        print "Some sound"

class Dog extends Animal:
    func makeSound():
        print "Woof!"

let dog = Dog()
dog.makeSound()     # Woof!
```

---

## 7. الذكاء الاصطناعي (AI Features)

### Tensors

```stract
# التعريف
tensor x[3, 3] gpu                      # على GPU
tensor weights[100, 50] cpu             # على CPU
tensor bias[50] gpu gradient            # مع تفاضل

# التهيئة
tensor data[5] = [1.0, 2.0, 3.0, 4.0, 5.0]

# العمليات
gradient loss with respect to weights
```

### النماذج (Models)

```stract
model SimpleNN:
    Dense(128, activation="relu")
    Dropout(0.2)
    Dense(10, activation="softmax")

model ConvNN:
    Conv2D(32, 3, activation="relu")
    MaxPool2D(2)
    Flatten()
    Dense(10)
```

### التدريب والتنبؤ

```stract
train model using training_data epochs=10
predict model using test_data
optimize model for accuracy using data
```

### أجهزة محددة

```stract
hardware gpu:
    # عمليات تشغل على GPU
    matrix_multiply(a, b)

hardware cpu:
    # عمليات على CPU
    simple_calculation()
```

---

## 8. البرمجة الزمنية (Temporal)

### Streams

```stract
stream events = source()

# مع تصفية
stream filtered = source() |> filter(x: x > 0)

# مع تحويل
stream mapped = data |> map(x: x * 2)

# سلسلة
stream result = data
    |> filter(x: x != null)
    |> map(x: x ** 2)
    |> filter(x: x > 100)
```

### المتغيرات الزمنية

```stract
# يزيد كل ثانية
temporal counter = 0 every 1s:
    counter + 1

# يتحدث كل 0.1 ثانية
temporal smooth = 0 every 0.1s:
    (smooth * 0.9) + (input * 0.1)
```

### الشروط التفاعلية

```stract
when counter > 100:
    print "Reached 100!"

when temperature > 30:
    emit alert("hot")

when balance < 10:
    send_notification()
```

### المراقبة والتنفيذ الدوري

```stract
observe score:
    updateDisplay(score)

every 5s:
    saveData()

after 10s:
    printMessage()

emit event_name "value"
```

---

## 9. الأمان (Security)

### الأنواع المقيدة

```stract
type SafePort: Int where value >= 1 and value <= 65535
type Email: String where contains(value, "@")
type Username: String where len(value) >= 3 and len(value) <= 20
```

### العزل الآمن (Sandbox)

```stract
# لا صلاحيات
sandbox []:
    x = 1 + 1

# شبكة فقط
sandbox [network]:
    http.get("https://example.com")

# ملفات وشبكة
sandbox [file, network]:
    data = file.read("data.txt")
```

---

## 10. الدوال المدمجة (Built-in Functions)

### الإدخال والإخراج
```stract
print(x)            # طباعة
input()             # قراءة من المستخدم
```

### تحويل الأنواع
```stract
str(42)             # "42"
int("42")           # 42
float("3.14")       # 3.14
bool(1)             # true
```

### معالجة القوائس
```stract
len([1, 2, 3])              # 3
sorted([3, 1, 2])           # [1, 2, 3]
reversed([1, 2, 3])         # [3, 2, 1]
sum([1, 2, 3])              # 6
min([3, 1, 2])              # 1
max([3, 1, 2])              # 3
```

### البرمجة الدالية
```stract
map(func, list)             # تطبيق على كل عنصر
filter(func, list)          # تصفية
reduce(func, list, start)   # تجميع
```

### أخرى
```stract
range(1, 10)        # [1, 2, 3, ..., 9]
type(x)             # نوع
abs(-5)             # 5
round(3.14159, 2)   # 3.14
```

---

## 11. المشغلات (Operators)

### الحسابية
```
+   جمع
-   طرح
*   ضرب
/   قسمة
**  قوة
%   باقي القسمة
```

### المقارنة
```
==  يساوي
!=  لا يساوي
>   أكبر من
<   أقل من
>=  أكبر أو يساوي
<=  أقل أو يساوي
```

### منطقية
```
and     و
or      أو
not     نفي
```

### الاسناد
```
=       إسناد
+=      إضافة وإسناد
-=      طرح وإسناد
*=      ضرب وإسناد
/=      قسمة وإسناد
```

---

## 12. الكلمات المحجوزة (Keywords)

### التحكم بالتدفق
`if`, `elif`, `else`, `for`, `while`, `when`, `every`, `after`

### البيانات
`let`, `const`, `var`, `class`

### الدوال
`func`, `lambda`, `return`

### الأمان والعقود
`requires`, `ensures`, `invariant`, `sandbox`, `type`

### الذكاء الاصطناعي
`tensor`, `model`, `train`, `predict`, `optimize`, `hardware`, `gradient`

### البرمجة الزمنية
`stream`, `temporal`, `observe`, `emit`

### البنية
`import`, `try`, `catch`, `finally`, `break`, `continue`

### الثوابت
`true`, `false`, `null`

---

## 13. أمثلة سريعة

### مثال 1: دالة آمنة
```stract
type Age: Int where value >= 0 and value <= 150

func celebrateBirthday(age: Age):
    requires age < 150
    ensures result == age + 1
    return age + 1
```

### مثال 2: نموذج AI
```stract
model Classifier:
    Dense(64, activation="relu")
    Dropout(0.3)
    Dense(10)

tensor input_data[100] gpu gradient
train Classifier using input_data epochs=20
```

### مثال 3: معالجة تفاعلية
```stract
stream data = source() |> filter(x: x > 0)

when data > 100:
    print "High value!"

every 5s:
    print "Still running..."
```

---

## 14. الأخطاء الشائعة

| الخطأ | السبب | الحل |
|-------|-------|-------|
| `Syntax Error` | خطأ في البناء الجملي | تحقق من الأقواس والفواصل |
| `Type Error` | نوع خاطئ | استخدم النوع الصحيح |
| `Runtime Error` | خطأ في التنفيذ | استخدم try/catch |
| `Contract Violation` | شرط مسبق فشل | تحقق من شروط الدالة |

---

**STRACT v5.0 Language Reference** - شامل وموثوق ✅
