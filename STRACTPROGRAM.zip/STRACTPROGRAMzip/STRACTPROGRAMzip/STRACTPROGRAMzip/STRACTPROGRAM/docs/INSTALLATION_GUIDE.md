# دليل التثبيت - STRACT على أجهزة مختلفة
# Installation Guide - STRACT

---

## ⚠️ ملاحظة مهمة:

**في Replit**: لا تحتاج لأي تثبيت! اكتب مباشرة:
```bash
python stract_cli.py repl
```

**على جهازك**: اتبع الخطوات التالية

---

## 1️⃣ تثبيت على Windows

### المتطلبات:
- Windows 7 أو أحدث
- تجاوز 500MB من مساحة التخزين

### الخطوات:

#### أ) تثبيت Python
1. اذهب إلى https://www.python.org/downloads/
2. حمل **Python 3.11 أو أحدث**
3. شغل الملف وتأكد من تحديد ✓ "Add Python to PATH"
4. اضغط "Install Now"

#### ب) التحقق من التثبيت
افتح PowerShell أو Command Prompt واكتب:
```bash
python --version
```
يجب أن تظهر: `Python 3.11.x`

#### ج) تحميل STRACT
1. حمل مجلد المشروع من Replit:
   - انقر الملفات في Replit
   - انقر الثلاث نقاط ⋮
   - اختر "Download as zip"

2. فك الضغط في مجلد:
```
C:\Users\YourName\STRACT\
```

#### د) فتح الترمنل في المجلد
```bash
# انقر على شريط العنوان واكتب cmd
cd C:\Users\YourName\STRACT

# أو: استخدم PowerShell
cd C:\Users\YourName\STRACT
```

#### هـ) تشغيل STRACT
```bash
# الوضع التفاعلي
python stract_cli.py repl

# تشغيل ملف
python stract_cli.py run examples/hello.stract

# تحليل الكود
python stract_cli.py analyze examples/hello.stract
```

---

## 2️⃣ تثبيت على Mac

### المتطلبات:
- macOS 10.14 أو أحدث
- Homebrew (اختياري لكن موصى به)

### الخطوات:

#### أ) تثبيت Python باستخدام Homebrew (الأسهل)
```bash
# 1. ثبت Homebrew إذا لم تكن مثبتاً
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 2. ثبت Python
brew install python@3.11

# 3. تحقق
python3 --version
```

#### ب) أو ثبت من الموقع الرسمي
1. اذهب إلى https://www.python.org/downloads/macos/
2. حمل **Python 3.11**
3. شغل الملف واتبع التعليمات

#### ج) تحميل STRACT
```bash
# من Terminal
cd ~/Downloads
# أو أي مجلد تريده
unzip stract-language.zip
cd stract-language
```

#### د) تشغيل STRACT
```bash
# الوضع التفاعلي
python3 stract_cli.py repl

# تشغيل ملف
python3 stract_cli.py run examples/hello.stract
```

---

## 3️⃣ تثبيت على Linux (Ubuntu/Debian)

### الخطوات:

#### أ) تثبيت Python
```bash
# تحديث النظام
sudo apt-get update
sudo apt-get upgrade

# تثبيت Python
sudo apt-get install python3.11 python3-pip

# التحقق
python3 --version
```

#### ب) تحميل STRACT
```bash
# انسخ الملفات أو استخدم Git
git clone https://github.com/yourname/stract-language.git
cd stract-language

# أو من Zip
unzip stract-language.zip
cd stract-language
```

#### ج) تشغيل STRACT
```bash
# الوضع التفاعلي
python3 stract_cli.py repl

# تشغيل ملف
python3 stract_cli.py run examples/hello.stract

# تشغيل مع صلاحيات
chmod +x stract_cli.py
./stract_cli.py repl
```

---

## 4️⃣ تثبيت على Linux (Fedora/RHEL)

```bash
# تثبيت Python
sudo dnf install python3.11 python3-pip

# التحقق
python3 --version

# الباقي مثل Ubuntu
```

---

## 5️⃣ مشاركة STRACT مع الآخرين

### الطريقة 1: Zip File

```bash
# على Windows/Mac
# اضغط على المجلد بزر الفأرة الأيمن → Compress

# على Linux
zip -r STRACT.zip stract-language/

# شارك الملف STRACT.zip مع أصدقائك
```

### الطريقة 2: Git/GitHub

```bash
# أنشئ مستودع على GitHub
git init
git add .
git commit -m "STRACT Programming Language"
git remote add origin https://github.com/yourname/stract-language.git
git push -u origin main

# أصدقاؤك يستخدمون:
git clone https://github.com/yourname/stract-language.git
cd stract-language
python3 stract_cli.py repl
```

### الطريقة 3: أرسل المجلد مباشرة
- Google Drive
- Dropbox
- Email (إذا كان المجلد صغيراً)

---

## 6️⃣ التحقق من التثبيت

بعد التثبيت، جرب هذه الأوامر:

```bash
# 1. عرض الإصدار
python stract_cli.py version

# 2. الوضع التفاعلي
python stract_cli.py repl
# اكتب: print "مرحبا"

# 3. تشغيل ملف
python stract_cli.py run examples/hello.stract

# 4. عرض الأوامر
python stract_cli.py commands

# 5. تحليل الكود
python stract_cli.py analyze examples/hello.stract
```

---

## 7️⃣ حل المشاكل

### مشكلة: "python: command not found"
```bash
# استخدم python3 بدلاً من python
python3 stract_cli.py repl

# أو أنشئ alias
alias python=python3
```

### مشكلة: "File not found"
```bash
# تأكد من أنك في مجلد STRACT
pwd  # على Mac/Linux
cd   # على Windows

# اعرض الملفات
ls   # على Mac/Linux
dir  # على Windows
```

### مشكلة: "Permission denied"
```bash
# على Mac/Linux
chmod +x stract_cli.py
python3 stract_cli.py repl
```

### مشكلة: المنفذ مشغول (Port 5000)
```bash
# استخدم منفذ مختلف في الملف
# غير آخر سطر من:
app.run(port=5000)
# إلى:
app.run(port=8080)
```

---

## 8️⃣ مثال: خطوات كاملة

### على Windows:

```powershell
# 1. حمل Python من https://python.org
# 2. ثبته وأضفه إلى PATH

# 3. افتح PowerShell
cd C:\Users\YourName\Downloads
unzip -Path "stract-language.zip" -DestinationPath "C:\STRACT"
cd C:\STRACT

# 4. شغل STRACT
python stract_cli.py repl
```

### على Mac:

```bash
# 1. ثبت Python
brew install python@3.11

# 2. حمل STRACT
cd ~/Downloads
unzip stract-language.zip
cd stract-language

# 3. شغله
python3 stract_cli.py repl
```

### على Linux:

```bash
# 1. ثبت Python
sudo apt-get install python3.11

# 2. حمل STRACT
git clone https://github.com/yourname/stract-language.git
cd stract-language

# 3. شغله
python3 stract_cli.py repl
```

---

## 📊 نظام التشغيل المدعوم

| النظام | الدعم | الملاحظات |
|--------|-------|----------|
| Windows 10/11 | ✅ كامل | استخدم Python 3.11+ |
| Mac Intel | ✅ كامل | استخدم Homebrew |
| Mac M1/M2 | ✅ كامل | Native support |
| Ubuntu/Debian | ✅ كامل | استخدم apt-get |
| Fedora/RHEL | ✅ كامل | استخدم dnf |
| Raspberry Pi | ✅ كامل | Linux ARM |

---

## 🚀 بعد التثبيت

```bash
# 1. جرب الوضع التفاعلي
python stract_cli.py repl

# 2. اكتب برنامجك الأول
stract> print "مرحبا بك في STRACT!"
stract> let x = 10
stract> let y = 20
stract> print x + y

# 3. اكتب exit للخروج
stract> exit
```

---

## 📝 ملف بسيط للاختبار

أنشئ ملف `test.stract`:

```stract
print "اختبار STRACT"

func greet(name):
    return "مرحبا " + name

print greet("محمد")

let numbers = [1, 2, 3, 4, 5]
let doubled = numbers.map(lambda x: x * 2)
print doubled
```

ثم شغله:
```bash
python stract_cli.py run test.stract
```

---

**الآن STRACT مثبت على جهازك! 🎉**
