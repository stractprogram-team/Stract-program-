# 📖 دليل بناء جملة الأوامر في STRACT
# Syntax Guide - How to Write Commands in STRACT

---

## ⚠️ تحذير مهم:

**الأمثلة في الأقسام 8 و 9 نظرية (خاصة أمثلة الويب والأمن السبراني)**

👉 **للأوامر الفعلية التي تعمل:** [REAL_FUNCTIONS.md](REAL_FUNCTIONS.md)

---

## 📚 المحتويات

1. **أساسيات البناء الجملي**
2. **المتغيرات والثوابت**
3. **العمليات الحسابية**
4. **الشروط والقرارات**
5. **الحلقات والتكرار**
6. **الدوال والوحدات**
7. **البيانات والقوائم**
8. **المعاجم والكائنات**
9. **المعالجة والأخطاء**
10. **أمثلة في مجالات مختلفة**

---

## 1️⃣ أساسيات البناء الجملي

### المبدأ الأساسي:
```
اسم_الأمر parameter1 parameter2 ...
```

### أنواع الأوامر الأساسية:

#### الطباعة (Print):
```stract
print "مرحبا بك"
print 42
print true
```

#### الإدخال (Input):
```stract
let name = input "أدخل اسمك: "
let age = input "كم عمرك؟ "
```

#### التعليقات:
```stract
# هذا تعليق من سطر واحد

## هذا أيضاً تعليق

/*
هذا تعليق
متعدد السطور
*/
```

---

## 2️⃣ المتغيرات والثوابت

### التعريف بالمتغيرات:

#### `let` - متغير يمكن تغييره:
```stract
let x = 10
let name = "أحمد"
let is_active = true

# يمكن تغيير القيمة
x = 20
name = "محمد"
```

#### `const` - ثابت لا يمكن تغييره:
```stract
const PI = 3.14159
const APP_NAME = "STRACT"
const MAX_USERS = 1000

# هذا سيرمي خطأ:
# PI = 3.14  ❌ Error
```

#### `var` - متغير عام (قديم):
```stract
var count = 0
var status = "running"
```

### أنواع البيانات:

```stract
# أرقام صحيحة
let integer = 42

# أرقام عشرية
let decimal = 3.14

# نصوص
let text = "Hello STRACT"

# منطق (صح/خطأ)
let is_true = true
let is_false = false

# لا شيء
let empty = null
```

---

## 3️⃣ العمليات الحسابية

### العمليات الأساسية:

```stract
let a = 10
let b = 3

# الجمع
let sum = a + b          # 13

# الطرح
let diff = a - b         # 7

# الضرب
let product = a * b      # 30

# القسمة
let division = a / b     # 3.333...

# الباقي من القسمة
let remainder = a % b    # 1

# الأس
let power = a ** b       # 1000
```

### العمليات على النصوص:

```stract
let first = "Hello"
let second = "STRACT"

# الربط
let full = first + " " + second  # "Hello STRACT"

# التكرار
let repeated = "Hi" * 3  # "HiHiHi"

# الطول
let length = len("STRACT")  # 6
```

### العمليات المنطقية:

```stract
let a = true
let b = false

# و (AND)
let result = a and b     # false

# أو (OR)
let result = a or b      # true

# ليس (NOT)
let result = not a       # false
```

### المقارنات:

```stract
let x = 10
let y = 20

x == y    # تساوي: false
x != y    # لا تساوي: true
x < y     # أقل من: true
x > y     # أكبر من: false
x <= y    # أقل من أو يساوي: true
x >= y    # أكبر من أو يساوي: false
```

---

## 4️⃣ الشروط والقرارات

### جملة `if` البسيطة:

```stract
let age = 25

if age >= 18:
    print "أنت بالغ"
```

### جملة `if-else`:

```stract
let score = 75

if score >= 80:
    print "ممتاز"
else:
    print "جيد"
```

### جملة `if-elif-else`:

```stract
let grade = 85

if grade >= 90:
    print "A"
elif grade >= 80:
    print "B"
elif grade >= 70:
    print "C"
else:
    print "F"
```

### جملة `match-case`:

```stract
let day = 3

match day:
    case 1:
        print "الاثنين"
    case 2:
        print "الثلاثاء"
    case 3:
        print "الأربعاء"
    default:
        print "يوم آخر"
```

### الشروط المركبة:

```stract
let age = 25
let has_license = true

if age >= 18 and has_license:
    print "يمكنك القيادة"

if age < 13 or age > 65:
    print "فئة عمرية خاصة"

if not is_raining:
    print "اذهب للعب"
```

---

## 5️⃣ الحلقات والتكرار

### حلقة `for`:

```stract
# من 1 إلى 5
for i in range(1, 6):
    print i

# على القائمة
let fruits = ["تفاح", "برتقال", "موز"]
for fruit in fruits:
    print fruit

# مع الفهرس
for index, fruit in enumerate(fruits):
    print index + ": " + fruit
```

### حلقة `while`:

```stract
let count = 0

while count < 5:
    print count
    count = count + 1
```

### جملة `break`:

```stract
for i in range(1, 11):
    if i == 5:
        break  # توقف الحلقة
    print i
```

### جملة `continue`:

```stract
for i in range(1, 6):
    if i == 3:
        continue  # اذهب للتكرار التالي
    print i
```

---

## 6️⃣ الدوال والوحدات

### تعريف دالة بسيطة:

```stract
func greet():
    print "مرحبا"

# استدعاء الدالة
greet()
```

### دالة بمعاملات:

```stract
func greet(name):
    print "مرحبا " + name

greet("أحمد")
greet("فاطمة")
```

### دالة بقيمة مرتجعة:

```stract
func add(a, b):
    return a + b

let result = add(5, 3)  # 8
print result
```

### دالة بمعاملات متعددة:

```stract
func calculate(x, y, operation):
    if operation == "add":
        return x + y
    elif operation == "subtract":
        return x - y
    elif operation == "multiply":
        return x * y
    else:
        return x / y

print calculate(10, 5, "add")       # 15
print calculate(10, 5, "subtract")  # 5
```

### استيراد وحدات:

```stract
import math
import web
import data
import security

let value = math.sqrt(16)  # 4
```

### دالة بدون معاملات ترجع قيمة:

```stract
func get_current_time():
    return time.now()

let now = get_current_time()
```

---

## 7️⃣ البيانات والقوائم

### إنشاء قائمة:

```stract
let numbers = [1, 2, 3, 4, 5]
let names = ["أحمد", "فاطمة", "علي"]
let mixed = [1, "hello", true, 3.14]
```

### الوصول للعناصر:

```stract
let fruits = ["تفاح", "برتقال", "موز"]

# الفهرس من 0
print fruits[0]   # "تفاح"
print fruits[1]   # "برتقال"
print fruits[-1]  # "موز" (آخر عنصر)
```

### تعديل العناصر:

```stract
let numbers = [1, 2, 3]
numbers[0] = 10
numbers[1] = 20
# الآن: [10, 20, 3]
```

### إضافة عناصر:

```stract
let list = [1, 2, 3]
list.append(4)      # أضف 4
list.insert(0, 0)   # أضف 0 في البداية
# الآن: [0, 1, 2, 3, 4]
```

### حذف عناصر:

```stract
let list = [1, 2, 3, 4, 5]
list.remove(3)      # أزل 3
list.pop()          # أزل آخر عنصر
list.pop(0)         # أزل أول عنصر
```

### عمليات القوائم:

```stract
let numbers = [1, 2, 3, 4, 5]

# الطول
len(numbers)        # 5

# الجمع
sum(numbers)        # 15

# الأصغر والأكبر
min(numbers)        # 1
max(numbers)        # 5

# الترتيب
sorted(numbers)     # [1, 2, 3, 4, 5]
reversed(numbers)   # [5, 4, 3, 2, 1]
```

### التعريف الفارغ:

```stract
let empty_list = []
let empty_dict = {}
```

---

## 8️⃣ المعاجم والكائنات

### إنشاء معجم:

```stract
let person = {
    "name": "أحمد",
    "age": 25,
    "city": "الرياض"
}
```

### الوصول للقيم:

```stract
print person["name"]    # "أحمد"
print person["age"]     # 25
print person.city       # "الرياض"
```

### تعديل القيم:

```stract
person["age"] = 26
person["job"] = "مهندس"
```

### التحقق من وجود مفتاح:

```stract
if "name" in person:
    print "الاسم موجود"

if "email" not in person:
    print "البريد غير موجود"
```

### حلقة على المعجم:

```stract
for key, value in person.items():
    print key + ": " + str(value)
```

### الكائنات (Objects):

```stract
let user = {
    "id": 1,
    "name": "أحمد",
    "email": "ahmed@example.com",
    "is_active": true,
    "address": {
        "city": "الرياض",
        "country": "السعودية"
    }
}

print user["address"]["city"]  # "الرياض"
```

---

## 9️⃣ معالجة الأخطاء

### جملة `try-catch`:

```stract
try:
    let result = 10 / 0
catch error:
    print "خطأ: لا يمكن القسمة على صفر"
```

### جملة `try-catch-finally`:

```stract
try:
    let file = open("data.txt")
    # عمل شيء
catch error:
    print "خطأ في فتح الملف"
finally:
    print "انتهى البرنامج"
```

### رفع أخطاء مخصصة:

```stract
func validate_age(age):
    if age < 0:
        raise "العمر لا يمكن أن يكون سالباً"
    if age > 150:
        raise "العمر غير صحيح"
    return true

try:
    validate_age(-5)
catch error:
    print "خطأ: " + error
```

---

## 🔟 أمثلة في مجالات مختلفة

---

## 🌐 مثال 1: تطوير الويب

```stract
import web

# إنشاء تطبيق ويب
let app = web.create_app()

# قاعدة بيانات مؤقتة
let posts = [
    {"id": 1, "title": "أول منشور", "content": "محتوى المنشور"},
    {"id": 2, "title": "منشور ثاني", "content": "محتوى آخر"}
]

# الصفحة الرئيسية
@app.get("/")
func home(request):
    return {
        "message": "أهلا وسهلا",
        "total_posts": len(posts)
    }

# الحصول على جميع المنشورات
@app.get("/posts")
func get_posts(request):
    return {"posts": posts}

# الحصول على منشور معين
@app.get("/posts/<id>")
func get_post(request, id):
    for post in posts:
        if post["id"] == int(id):
            return post
    return {"error": "المنشور غير موجود"}

# إضافة منشور جديد
@app.post("/posts")
func create_post(request):
    let data = request.json_data
    let new_post = {
        "id": len(posts) + 1,
        "title": data["title"],
        "content": data["content"]
    }
    posts.append(new_post)
    return new_post

# حذف منشور
@app.delete("/posts/<id>")
func delete_post(request, id):
    for i in range(len(posts)):
        if posts[i]["id"] == int(id):
            let deleted = posts[i]
            posts.pop(i)
            return {"message": "تم الحذف", "post": deleted}
    return {"error": "المنشور غير موجود"}

# تشغيل التطبيق
app.run(port=5000)
```

**الاستخدام:**
```bash
# تشغيل السيرفر
python stract_cli.py web app.stract

# في Terminal آخر:
curl http://localhost:5000
curl http://localhost:5000/posts
curl -X POST http://localhost:5000/posts \
  -H "Content-Type: application/json" \
  -d '{"title":"منشور جديد","content":"محتوى"}'
```

---

## 📊 مثال 2: تحليل البيانات

```stract
# قائمة بيانات
let sales = [
    {"month": "يناير", "amount": 1000},
    {"month": "فبراير", "amount": 1500},
    {"month": "مارس", "amount": 1200},
    {"month": "أبريل", "amount": 1800},
    {"month": "مايو", "amount": 2000}
]

# دالة لحساب الإجمالي
func total_sales(data):
    let total = 0
    for item in data:
        total = total + item["amount"]
    return total

# دالة لحساب المتوسط
func average_sales(data):
    let total = total_sales(data)
    return total / len(data)

# دالة لفind الشهر الأفضل
func best_month(data):
    let best = data[0]
    for item in data:
        if item["amount"] > best["amount"]:
            best = item
    return best

# دالة لفind الشهر الأسوأ
func worst_month(data):
    let worst = data[0]
    for item in data:
        if item["amount"] < worst["amount"]:
            worst = item
    return worst

# الحسابات
print "━━━━━━━━━━━━━━━━━━━━━━━━"
print "تحليل المبيعات"
print "━━━━━━━━━━━━━━━━━━━━━━━━"

let total = total_sales(sales)
let avg = average_sales(sales)
let best = best_month(sales)
let worst = worst_month(sales)

print "الإجمالي: " + str(total)
print "المتوسط: " + str(round(avg, 2))
print "أفضل شهر: " + best["month"] + " (" + str(best["amount"]) + ")"
print "أسوأ شهر: " + worst["month"] + " (" + str(worst["amount"]) + ")"
```

---

## 🎮 مثال 3: لعبة بسيطة

```stract
import random

func play_number_guessing():
    let secret = random.randint(1, 100)
    let attempts = 0
    let guessed = false
    
    print "━━━━━━━━━━━━━━━━━━━━━━━━"
    print "لعبة تخمين الرقم"
    print "━━━━━━━━━━━━━━━━━━━━━━━━"
    print "فكر في رقم من 1 إلى 100"
    
    while not guessed:
        let guess = int(input("خمن: "))
        attempts = attempts + 1
        
        if guess == secret:
            print "✅ صحيح! وجدت الرقم!"
            print "عدد المحاولات: " + str(attempts)
            guessed = true
        elif guess < secret:
            print "❌ الرقم أكبر"
        else:
            print "❌ الرقم أصغر"

play_number_guessing()
```

---

## 🔐 مثال 4: نظام تسجيل دخول

```stract
let users = {
    "ahmed": "password123",
    "fatima": "secure456",
    "ali": "mypass789"
}

let logged_in_user = null

func register(username, password):
    if username in users:
        return {"success": false, "message": "المستخدم موجود بالفعل"}
    
    if len(password) < 6:
        return {"success": false, "message": "كلمة المرور قصيرة جداً"}
    
    users[username] = password
    return {"success": true, "message": "تم التسجيل بنجاح"}

func login(username, password):
    if username not in users:
        return {"success": false, "message": "المستخدم غير موجود"}
    
    if users[username] != password:
        return {"success": false, "message": "كلمة المرور خاطئة"}
    
    return {"success": true, "message": "تم الدخول بنجاح"}

# الاستخدام
let result = login("ahmed", "password123")
if result["success"]:
    print "✅ " + result["message"]
else:
    print "❌ " + result["message"]

let result = register("sara", "sara@1234")
print result["message"]
```

---

## 📝 مثال 5: برنامج لإدارة المهام

```stract
let tasks = []

func add_task(title, priority):
    let task = {
        "id": len(tasks) + 1,
        "title": title,
        "priority": priority,
        "completed": false
    }
    tasks.append(task)
    return task

func complete_task(task_id):
    for task in tasks:
        if task["id"] == task_id:
            task["completed"] = true
            return {"success": true, "message": "تم إكمال المهمة"}
    return {"success": false, "message": "المهمة غير موجودة"}

func list_tasks():
    print "━━━━━━━━━━━━━━━━━━━━━━━━"
    print "قائمة المهام"
    print "━━━━━━━━━━━━━━━━━━━━━━━━"
    
    for task in tasks:
        let status = "✅" if task["completed"] else "⏳"
        print status + " [" + str(task["id"]) + "] " + task["title"] + " (" + task["priority"] + ")"

func get_pending_tasks():
    let pending = []
    for task in tasks:
        if not task["completed"]:
            pending.append(task)
    return pending

# الاستخدام
add_task("كتابة التقرير", "عالي")
add_task("مراجعة الكود", "متوسط")
add_task("اختبار البرنامج", "عالي")

list_tasks()

let pending = get_pending_tasks()
print "عدد المهام المتبقية: " + str(len(pending))

complete_task(1)
list_tasks()
```

---

## 📈 مثال 6: حاسبة متقدمة

```stract
func calculate(a, b, operation):
    match operation:
        case "+":
            return a + b
        case "-":
            return a - b
        case "*":
            return a * b
        case "/":
            if b == 0:
                return {"error": "لا يمكن القسمة على صفر"}
            return a / b
        case "%":
            return a % b
        case "**":
            return a ** b
        default:
            return {"error": "عملية غير معروفة"}

func scientific_calculator():
    print "━━━━━━━━━━━━━━━━━━━━━━━━"
    print "حاسبة متقدمة"
    print "━━━━━━━━━━━━━━━━━━━━━━━━"
    
    let a = float(input("الرقم الأول: "))
    let op = input("العملية (+, -, *, /, %, **): ")
    let b = float(input("الرقم الثاني: "))
    
    let result = calculate(a, b, op)
    print "النتيجة: " + str(result)

scientific_calculator()
```

---

## 🎓 مثال 7: نظام درجات الطلاب

```stract
let students = [
    {"name": "أحمد", "score": 85},
    {"name": "فاطمة", "score": 92},
    {"name": "علي", "score": 78},
    {"name": "سارة", "score": 88},
    {"name": "محمد", "score": 95}
]

func get_grade(score):
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"

func display_results():
    print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    print "نتائج الطلاب"
    print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    let total = 0
    for student in students:
        let grade = get_grade(student["score"])
        print student["name"] + ": " + str(student["score"]) + " - " + grade
        total = total + student["score"]
    
    let avg = total / len(students)
    print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    print "المتوسط: " + str(round(avg, 2))
    print "أعلى درجة: " + str(max(map(lambda s: s["score"], students)))
    print "أقل درجة: " + str(min(map(lambda s: s["score"], students)))

display_results()
```

---

## 📝 ملخص سريع

### القواعد الأساسية:

| المفهوم | الصيغة | مثال |
|--------|-------|------|
| متغير | `let x = value` | `let name = "أحمد"` |
| ثابت | `const X = value` | `const PI = 3.14` |
| شرط | `if condition: ...` | `if age >= 18: ...` |
| حلقة | `for x in list: ...` | `for i in range(5): ...` |
| دالة | `func name(): ...` | `func add(a, b): ...` |
| قائمة | `[1, 2, 3]` | `let nums = [1, 2, 3]` |
| معجم | `{"key": value}` | `let user = {"name": "أحمد"}` |
| استيراد | `import module` | `import web` |

---

## 🎯 نصائح مهمة:

✅ استخدم الأسماء الواضحة للمتغيرات
✅ اكتب تعليقات لشرح الكود
✅ استخدم الدوال لتجنب تكرار الكود
✅ تعامل مع الأخطاء بحذر
✅ اختبر برنامجك بقيم مختلفة

❌ تجنب الأسماء القصيرة والغامضة
❌ لا تكتب وظائف طويلة جداً
❌ لا تتجاهل الأخطاء

---

## 📚 ملفات إضافية

- [START_HERE.md](START_HERE.md) - البدء السريع
- [QUICK_START.md](QUICK_START.md) - أمثلة بسيطة
- [EXAMPLES_EXPLAINED.md](EXAMPLES_EXPLAINED.md) - شرح الأمثلة
- [WEB_ROUTING_GUIDE.md](WEB_ROUTING_GUIDE.md) - برمجة المواقع

---

**Happy Coding! 🚀**
