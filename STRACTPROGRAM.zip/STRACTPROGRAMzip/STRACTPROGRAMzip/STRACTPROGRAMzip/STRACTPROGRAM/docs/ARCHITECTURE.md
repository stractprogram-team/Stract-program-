# 🏗️ معمارية STRACT v5.0

---

## النظرة العامة

STRACT مقسمة إلى 3 مراحل رئيسية:

```
Source Code
    ↓
┌───────────────────────────────────┐
│  LEXER (Tokenization)             │  <-- تحويل لـ tokens
└───────────────────────────────────┘
    ↓
┌───────────────────────────────────┐
│  PARSER (AST Generation)          │  <-- بناء شجرة
└───────────────────────────────────┘
    ↓
┌───────────────────────────────────┐
│  INTERPRETER (Execution)          │  <-- التنفيذ
└───────────────────────────────────┘
    ↓
Output
```

---

## 1. Lexer (المحلل اللغوي)

**الملف:** `main.py` - Lexer class

**الوظيفة:** تحويل نص الكود إلى tokens

**الكلمات المحجوزة:** 35+ keyword

**الأنواع المدعومة:**
- Integers: `42`, `-10`
- Floats: `3.14`, `-2.5`
- Strings: `"hello"`, `'world'`
- Booleans: `true`, `false`
- Operators: `+`, `-`, `*`, `/`, etc.

---

## 2. Parser (محلل بناء الجملة)

**الملف:** `main.py` - Parser class

**الوظيفة:** بناء Abstract Syntax Tree (AST)

**22 AST Node Types:**
- Statements: Let, Const, Function, Class
- Expressions: Binary, Unary, Call
- Control Flow: If, For, While, Match
- AI Features: Tensor, Model, Stream
- Safety: Type, Contract, Sandbox

---

## 3. Interpreter (المفسر)

**الملف:** `main.py` - Interpreter class

**الوظيفة:** تنفيذ الكود

**المكونات الرئيسية:**

### Environment (البيئة)
- متغيرات محلية
- نطاقات مختلفة
- inheritance

### Runtime Classes (5)
1. **STRACTTensor** - للعمليات الرياضية
2. **STRACTStream** - للبيانات التفاعلية
3. **STRACTRefinementType** - للأنواع المقيدة
4. **STRACTContract** - للعقود
5. **STRACTModel** - لنماذج AI

### 22+ Execute Methods
- execute_tensor_node
- execute_stream_node
- execute_when_node
- execute_contract_node
- ...etc

---

## هيكل الملفات

```
STRACTPROGRAMzip/SystemRefactor/
├── main.py                      # Interpreter الرئيسي (3700+ lines)
│   ├── Token class
│   ├── Lexer class
│   ├── AST Nodes (22+)
│   ├── Parser class
│   ├── Runtime Classes (5)
│   └── Interpreter class
├── CORE_SYSTEM/
├── AI_INTEGRATION/
├── DEVELOPER_TOOLS/
└── TESTS/
```

---

## كيف يعمل الكود؟

### مثال: `print 10 + 20`

**Step 1: Lexer**
```
Input: print 10 + 20
Output: [IDENTIFIER(print), INTEGER(10), PLUS, INTEGER(20)]
```

**Step 2: Parser**
```
AST:
CallNode(
    function=IdentifierNode("print"),
    arguments=[BinaryOpNode(10, "+", 20)]
)
```

**Step 3: Interpreter**
```
1. احسب: 10 + 20 = 30
2. اطبع: 30
```

---

## الميزات الثورية

### 1. AI-Native Execution
```
Tensor Node → STRACTTensor Object → GPU/CPU Computation
```

### 2. Temporal Execution
```
Stream Node → STRACTStream Object → Auto Propagation
```

### 3. Contract Checking
```
Contract Node → Pre-condition Check → Execution → Post-condition Check
```

---

## Performance Considerations

- **Lexer:** O(n) - خطي
- **Parser:** O(n) - خطي
- **Interpreter:** O(n) - خطي

---

## المستقبل

### Phase 2: Compiler
```
STRACT Code → Bytecode → VM Execution → Machine Code
```

### Phase 3: Optimization
```
Dead Code Elimination → Constant Folding → Loop Optimization
```

---

**معمارية STRACT - بسيطة وفعالة ✅**
