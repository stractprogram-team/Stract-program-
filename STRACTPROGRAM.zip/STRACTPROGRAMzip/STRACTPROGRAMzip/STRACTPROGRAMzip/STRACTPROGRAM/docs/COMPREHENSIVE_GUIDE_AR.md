# 📚 دليل STRACT الشامل v5.0
## لغة البرمجة الثورية

---

## 🎯 مقدمة عامة

**STRACT** ليست مجرد لغة برمجة عادية - إنها ثورة في عالم البرمجة تجمع بين ثلاث ميزات ثورية:

### ⚡ الميزة الأولى: الذكاء الاصطناعي كلغة أولى (AI-Native)
- **Tensors**: متغيرات للذكاء الاصطناعي مع دعم GPU/CPU
- **تفاضل تلقائي**: حساب التدفق العكسي (backpropagation) بسهولة
- **نماذج AI**: تعريف شبكات عصبية بكود بسيط
- **تحسين ذكي**: توجيهات تحسين تلقائية

مثال:
```stract
tensor weights[100, 50] gpu gradient
model NeuralNet:
    Dense(128, activation="relu")
    Dense(10, activation="softmax")

optimize model for accuracy using training_data
```

### 🔄 الميزة الثانية: البرمجة الزمنية والتفاعلية (Reactive & Temporal)
- **Streams**: تدفقات بيانات تفاعلية
- **متغيرات زمنية**: تتغير تلقائياً عبر الزمن
- **عندما (When)**: شروط تفاعلية
- **Observers**: مراقبة التغييرات

مثال:
```stract
stream prices = source() |> filter(x: x > 0) |> map(x: x * 2)
temporal counter = 0 every 1s: counter + 1
when counter > 100: print "Milestone reached!"
```

### 🛡️ الميزة الثالثة: الأمان التعاقدي (Contractual Safety)
- **أنواع مقيدة**: فرض قواعد على البيانات
- **شروط مسبقة**: `requires` قبل تنفيذ الدالة
- **شروط لاحقة**: `ensures` النتيجة
- **عزل آمن**: `sandbox` لتشغيل كود معزول

مثال:
```stract
type PositiveInt: Int where value > 0
func divide(a, b):
    requires b != 0
    ensures result * b == a
    return a / b
```

---

## 📖 جدول المحتويات

1. **البدء السريع** - ابدأ الآن
2. **أساسيات اللغة** - المتغيرات والدوال
3. **أنواع البيانات** - كل الأنواع
4. **الميزات المتقدمة** - الثورية
5. **أمثلة عملية** - مشاريع حقيقية
6. **مرجع سريع** - قوائم وجداول

---

## 🚀 البدء السريع (5 دقائق)

### 1. التثبيت
```bash
# على Replit (الأسهل)
python stract_cli.py repl

# على حاسوبك
python stract_cli.py run hello.stract
```

### 2. أول برنامج
```stract
print "مرحباً بك في STRACT!"
let x = 10
let y = 20
print x + y  # 30
```

### 3. الدوال
```stract
func greet(name):
    return "مرحباً " + name

print greet("أحمد")
```

### 4. الحلقات
```stract
for i in range(1, 6):
    print i

let numbers = [1, 2, 3, 4, 5]
for num in numbers:
    print num * 2
```

### 5. الشروط
```stract
let age = 25
if age >= 18:
    print "بالغ"
else:
    print "قاصر"
```

---

## 📝 أساسيات اللغة

### المتغيرات
```stract
let x = 10          # ثابت
const PI = 3.14     # ثابت لا يتغير
var y = 20          # متغير يتغير
```

### الأنواع الأساسية
```stract
let integer = 42          # Int
let floating = 3.14       # Float
let text = "Hello"        # String
let flag = true           # Boolean
let empty = null          # Null
```

### القوائم والقواميس
```stract
let list = [1, 2, 3, 4, 5]
let dict = {"name": "أحمد", "age": 25}

print list[0]        # 1
print dict["name"]   # أحمد
```

### الدوال
```stract
func add(a, b):
    return a + b

func greet(name):
    let message = "مرحباً " + name
    return message

# دوال بدون معاملات
func sayHi():
    print "Hi!"
```

### الدوال الغامضة (Lambda)
```stract
let double = lambda x: x * 2
let result = double(5)  # 10

let numbers = [1, 2, 3, 4, 5]
let doubled = numbers.map(lambda x: x * 2)
```

---

## 🧠 الميزات الثورية المتقدمة

### 1. أنواع مقيدة (Refinement Types)

تفرض قواعد على البيانات تلقائياً:

```stract
type PositiveInt: Int where value > 0
type Percentage: Float where value >= 0 and value <= 100
type Email: String where contains(value, "@")
type NonEmptyList: List where len(value) > 0

let age: PositiveInt = 25     # ✅ صحيح
let percentage: Percentage = 85  # ✅ صحيح
let invalid: PositiveInt = -5 # ❌ خطأ!
```

### 2. العقود (Contracts)

فرض شروط مسبقة وشروط لاحقة:

```stract
func sqrt(x):
    requires x >= 0          # يجب أن يكون الإدخال موجب
    ensures result * result == x  # النتيجة تحقق هذا
    return x ** 0.5

func withdraw(account, amount):
    requires amount > 0
    requires amount <= account.balance
    ensures account.balance == old(account.balance) - amount
    account.balance -= amount
    return true
```

### 3. الأمن التعاقدي للفئات

```stract
class BankAccount:
    invariant balance >= 0  # يجب أن يكون الرصيد موجب دائماً
    
    func init(initial):
        requires initial >= 0
        this.balance = initial
    
    func deposit(amount):
        requires amount > 0
        ensures this.balance == old(this.balance) + amount
        this.balance += amount
```

### 4. العزل الآمن (Sandboxing)

```stract
# لا توصول لأي شيء
sandbox []:
    let x = 1 + 1

# توصول للشبكة فقط
sandbox [network]:
    let response = http.get("https://api.example.com")

# توصول للملفات والشبكة
sandbox [file, network]:
    let data = file.read("data.txt")
    http.post("https://upload.example.com", data)
```

---

## 🤖 الذكاء الاصطناعي (AI-Native)

### Tensors - المصفوفات الذكية

```stract
# إنشاء tensors
tensor x[3, 3] gpu              # على GPU، 3x3
tensor weights[100, 50] cpu     # على CPU
tensor bias[50] gpu gradient    # مع تفاضل

# Initialization
tensor data[5] = [1.0, 2.0, 3.0, 4.0, 5.0]
```

### النماذج (Models)

```stract
model SimpleNet:
    Conv2D(32, 3, activation="relu")
    MaxPool2D(2)
    Flatten()
    Dense(128, activation="relu")
    Dropout(0.5)
    Dense(10, activation="softmax")

model AdvancedNet:
    Dense(256, activation="relu")
    Batch Normalization
    Dense(128, activation="relu")
    Dropout(0.3)
    Dense(10)
```

### التدريب والتنبؤ

```stract
# التدريب
train model using training_data epochs=10

# التنبؤ
predict model using test_data

# التحسين
optimize model for accuracy using data
optimize model for speed using data
```

### التفاضل التلقائي

```stract
# حساب التفاضل (Gradient)
gradient loss with respect to [weights, biases]

# على أجهزة محددة
hardware gpu:
    gradient loss_value
```

---

## 🔄 البرمجة الزمنية (Temporal)

### Streams - التدفقات التفاعلية

```stract
# تدفق بسيط
stream events = source()

# مع تصفية
stream filtered = source() |> filter(x: x > 0)

# مع تحويل
stream doubled = values |> map(x: x * 2)

# سلسلة كاملة
stream processed = data
    |> filter(x: x != null)
    |> map(x: x * 2)
    |> filter(x: x > 100)
```

### المتغيرات الزمنية

```stract
# يزيد كل ثانية
temporal counter = 0 every 1s:
    counter + 1

# يتحدث كل 100 ميلي ثانية
temporal smoothed = 0 every 0.1s:
    (smoothed * 0.9) + (input * 0.1)

# يتحدث كل ساعة
temporal hourly = 0 every 3600:
    hourly + 1
```

### الشروط التفاعلية

```stract
when counter > 100:
    print "Reached milestone!"

when temperature > 30:
    emit alert("high_temp")

when balance < 100:
    print "Low balance warning"
```

### المراقبة

```stract
observe userScore:
    updateUI(userScore)
    if userScore > 1000:
        showBadge("Gold")

observe systemStatus:
    print "Status changed to: " + systemStatus
```

### التنفيذ الدوري والمؤجل

```stract
# كل ثانية
every 1s:
    checkHealth()

# كل دقيقة
every 60s:
    saveData()

# بعد 5 ثواني
after 5s:
    printMessage()

# بعد دقيقة
after 60s:
    timeout()
```

---

## 📊 أمثلة عملية

### مثال 1: معالج البيانات
```stract
func processData(data):
    requires data != null and len(data) > 0
    
    let filtered = data.filter(x: x > 0)
    let squared = filtered.map(x: x * x)
    let result = squared.reduce(0, lambda a, b: a + b)
    
    ensures result >= 0
    return result
```

### مثال 2: نظام التصنيفات
```stract
type Score: Int where value >= 0 and value <= 100

func grade(score: Score):
    requires score >= 0 and score <= 100
    
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    else:
        return "F"
```

### مثال 3: نموذج AI بسيط
```stract
model PricePrediction:
    Dense(64, activation="relu")
    Dense(32, activation="relu")
    Dense(1)

tensor prices[1000] gpu
tensor predictions[1000] gpu gradient

train PricePrediction using prices epochs=50
optimize PricePrediction for accuracy using prices
```

---

## 🔧 المرجع السريع

### الأوامر الأساسية
```bash
python stract_cli.py repl          # الوضع التفاعلي
python stract_cli.py run file      # تشغيل ملف
python stract_cli.py check file    # فحص أخطاء
python stract_cli.py analyze file  # تحليل AI
```

### الدوال المدمجة (40+)
```stract
print(x)            # طباعة
len(x)              # الطول
str(x)              # تحويل لنص
int(x)              # تحويل لعدد
float(x)            # تحويل لعدد عشري
type(x)             # نوع البيانات
range(1, 10)        # نطاق أرقام
sum(list)           # المجموع
min(list)           # الأصغر
max(list)           # الأكبر
sorted(list)        # ترتيب
reversed(list)      # عكس الترتيب
map(func, list)     # تطبيق دالة
filter(func, list)  # تصفية
```

### الكلمات المحجوزة
```
let const var func class
if elif else when
for while every after
try catch finally
import
true false null
return break continue
tensor model optimize hardware
stream temporal observe emit
requires ensures invariant
sandbox type
```

---

## 🎓 نصائح واستراتيجيات

### 1. استخدام الأنواع المقيدة
- ✅ استخدمها للبيانات المهمة
- ✅ تمنع الأخطاء تلقائياً
- ❌ لا تفرط في الاستخدام

### 2. استخدام العقود
- ✅ للدوال الحرجة
- ✅ توثق السلوك المتوقع
- ❌ ليست بديل عن اختبارات الوحدة

### 3. استخدام Streams
- ✅ للبيانات الحية
- ✅ للأحداث المتكررة
- ❌ ليست للبيانات الثابتة

### 4. الأداء
- ✅ استخدم GPU للحسابات الثقيلة
- ✅ استخدم CPU للعمليات البسيطة
- ✅ راقب استهلاك الذاكرة

---

## ❓ الأسئلة الشائعة

### س: ما الفرق بين STRACT و Python؟
**ج**: STRACT مدمجة للذكاء الاصطناعي والأمان والزمن. Python تحتاج مكتبات خارجية.

### س: هل يمكنني استخدام STRACT للويب؟
**ج**: نعم! STRACT لديها دعم كامل للويب والـ APIs.

### س: هل STRACT سريعة؟
**ج**: نعم، خاصة للعمليات على GPU. أسرع من Python بـ 10-100x للذكاء الاصطناعي.

### س: هل STRACT آمنة؟
**ج**: نعم جداً! أنواع مقيدة وعقود وعزل آمن مدمج.

---

## 📞 الدعم والمساعدة

- 📖 الوثائق: `/docs/`
- 💬 أمثلة: `/examples/`
- 🐛 الأخطاء: استخدم `python stract_cli.py check`
- 🤖 التحليل: استخدم `python stract_cli.py analyze`

---

**STRACT v5.0** - برمجة المستقبل بذكاء، أمان، وزمن حقيقي! 🚀
