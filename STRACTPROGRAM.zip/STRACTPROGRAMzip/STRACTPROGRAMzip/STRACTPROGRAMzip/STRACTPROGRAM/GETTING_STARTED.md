# 🎯 ابدأ الآن - STRACT v4.0

## ✅ أنت في المكان الصحيح!

هذا الملف يشرح كل شيء عن STRACT - كيفية التشغيل والتحميل والتثبيت على جميع الأجهزة.

### ⚠️ تحذير مهم:
**👉 للأوامر التي تعمل فعلاً، اقرأ: [docs/REAL_FUNCTIONS.md](docs/REAL_FUNCTIONS.md)**

---

## 📋 المحتويات السريعة

1. **الآن على Replit** ← تشغيل فوري
2. **على حاسوبك** ← تحميل وتشغيل
3. **التثبيت الكامل** ← جميع الأنظمة
4. **أول برنامج لك** ← أمثلة سريعة
5. **جميع الأوامر** ← شرح كل أمر

---

## 1️⃣ الآن على Replit (أسهل)

### شغل الوضع التفاعلي:
```bash
python stract_cli.py repl
```

### اكتب برنامجك:
```
stract> print "مرحبا"
stract> exit
```

### ✅ خلاص! يعمل!

---

## 2️⃣ على حاسوبك (4 خطوات فقط)

### الخطوة 1: حمل الملفات
- افتح Replit
- انقر على الملفات 📁
- انقر ⋮ (ثلاث نقاط)
- اختر "Download as zip"

### الخطوة 2: فك الضغط
- **Windows:** انقر يمين → "Extract All"
- **Mac:** انقر مرتين على الملف
- **Linux:** `unzip stract-language.zip`

### الخطوة 3: افتح Terminal
- **Windows:** شريط العنوان → اكتب `cmd` → Enter
- **Mac:** افتح Terminal
- **Linux:** انقر يمين "Open Terminal Here"

### الخطوة 4: شغل STRACT
```bash
python stract_cli.py repl
```

---

## 3️⃣ التثبيت على نظامك

### Windows:
```bash
# 1. ثبت Python 3.11 من https://python.org
# 2. تأكد من تحديد "Add Python to PATH"
# 3. تحقق:
python --version

# 4. استخدم STRACT:
python stract_cli.py repl
```

### Mac:
```bash
# 1. ثبت Python (إذا لم يكن موجوداً)
brew install python@3.11

# 2. استخدم STRACT:
python3 stract_cli.py repl
```

### Linux:
```bash
# 1. ثبت Python
sudo apt-get install python3.11

# 2. استخدم STRACT:
python3 stract_cli.py repl
```

---

## 4️⃣ أول برنامج لك

### في REPL (مباشر):
```bash
python stract_cli.py repl
```

```
stract> print "Hello World"
Hello World

stract> let x = 10
stract> print x
10

stract> exit
```

### في ملف:
```stract
print "برنامجي الأول!"

func add(a, b):
    return a + b

print add(5, 3)  # النتيجة: 8
```

شغله:
```bash
python stract_cli.py run my_program.stract
```

---

## 5️⃣ جميع الأوامر

| الأمر | ماذا يفعل | مثال |
|------|----------|------|
| **repl** | وضع تفاعلي | `python stract_cli.py repl` |
| **run** | تشغيل ملف | `python stract_cli.py run file.stract` |
| **check** | فحص أخطاء | `python stract_cli.py check file.stract` |
| **analyze** | تحليل AI | `python stract_cli.py analyze file.stract` |
| **web** | موقع ويب | `python stract_cli.py web site.stract` |

---

## 🎁 الأمثلة المتوفرة

```bash
# مثال شامل
python stract_cli.py run examples/hello.stract

# موقع ويب بسيط
python stract_cli.py run examples/simple_website.stract

# موقع ويب متقدم
python stract_cli.py run examples/web_example.stract

# تحليل الكود بـ AI
python stract_cli.py analyze examples/hello.stract
```

---

## 🌐 بناء موقع ويب

### ملف `website.stract`:
```stract
import web

let app = web.create_app()

@app.get("/")
func home(request):
    return {"message": "مرحبا"}

app.run(port=5000)
```

### شغله:
```bash
python stract_cli.py web website.stract
```

### اختبره:
```bash
curl http://localhost:5000
```

---

## 📚 الوثائق الكاملة

اقرأ هذه الملفات في مجلد `docs/`:

- **[START_HERE.md](docs/START_HERE.md)** ⭐ - دليل شامل كامل
- **[QUICK_START.md](docs/QUICK_START.md)** - بدء سريع
- **[HOW_COMMANDS_WORK.md](docs/HOW_COMMANDS_WORK.md)** - شرح الأوامر
- **[WEB_ROUTING_GUIDE.md](docs/WEB_ROUTING_GUIDE.md)** - برمجة المواقع
- **[INSTALLATION_GUIDE.md](docs/INSTALLATION_GUIDE.md)** - التثبيت
- **[DOWNLOAD_AND_RUN.md](docs/DOWNLOAD_AND_RUN.md)** - التحميل والتشغيل
- **[INDEX.md](docs/INDEX.md)** - فهرس الوثائق

---

## ✨ المميزات الرئيسية

✅ **لغة برمجة قوية** - متغيرات، دوال، حلقات، شروط، فئات
✅ **موقع ويب مدمج** - REST API بسهولة
✅ **ذكاء اصطناعي** - تحليل الكود التلقائي
✅ **على جميع الأنظمة** - Windows, Mac, Linux

---

## 🚀 ابدأ الآن!

```bash
# الخيار 1: وضع تفاعلي (الأسهل)
python stract_cli.py repl

# الخيار 2: تشغيل مثال
python stract_cli.py run examples/hello.stract

# الخيار 3: موقع ويب
python stract_cli.py web examples/simple_website.stract

# الخيار 4: قراءة الوثائق الكاملة
# اقرأ: docs/START_HERE.md
```

---

## ❓ أسئلة شائعة

**س: كم تكلف؟** - مجاني تماماً! ✅

**س: هل تعمل على جهازي؟** - نعم! Windows, Mac, Linux ✅

**س: كيف أنشر موقعي؟** - انقر "Publish" في Replit أو استخدم جهازك

**س: أين المزيد من المساعدة؟** - اقرأ `docs/START_HERE.md`

---

## 🎯 الخطوات التالية

1. ✅ **اقرأ هذا الملف** ← أنت هنا!
2. 👉 **اقرأ [docs/START_HERE.md](docs/START_HERE.md)** ← للتفاصيل الكاملة
3. 🎬 **ابدأ بـ REPL:** `python stract_cli.py repl`
4. 🏗️ **ابنِ أول برنامج:** `python stract_cli.py run examples/hello.stract`

---

**Happy coding! 🚀**

---

## 📊 هيكل المشروع

```
STRACT/
├── stract_cli.py          # نقطة البداية
├── README.md              # معلومات عامة
├── GETTING_STARTED.md     # هذا الملف
├── examples/              # أمثلة جاهزة
│   ├── hello.stract
│   ├── simple_website.stract
│   └── ...
├── docs/                  # وثائق شاملة
│   ├── START_HERE.md      # ⭐ ابدأ هنا
│   ├── QUICK_START.md
│   ├── HOW_COMMANDS_WORK.md
│   └── ...
└── STRACTPROGRAMzip/SystemRefactor/
    ├── main.py            # محرك STRACT
    ├── AI_INTEGRATION/    # تحليل AI
    ├── WEB_SERVER/        # بناء المواقع
    └── ...
```

---

**اختر ملفك واستمتع! 🎉**
