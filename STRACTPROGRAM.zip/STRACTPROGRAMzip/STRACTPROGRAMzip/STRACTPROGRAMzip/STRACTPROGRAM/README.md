# 🚀 STRACT v5.0 - اللغة البرمجية الثورية
## The Revolutionary Programming Language

![Version](https://img.shields.io/badge/Version-5.0.0-brightgreen)
![Status](https://img.shields.io/badge/Status-Stable-blue)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 🎯 ما هي STRACT؟

**STRACT** هي لغة برمجة حديثة ثورية تجمع بين ثلاث ميزات فريدة تجعلها الأفضل في العالم:

### 1. 🤖 الذكاء الاصطناعي كلغة أولى (AI-Native)
- Tensors مع دعم GPU/CPU
- تفاضل تلقائي مدمج
- نماذج AI بكود بسيط
- تحسين ذكي

### 2. ⚡ البرمجة الزمنية والتفاعلية (Reactive & Temporal)
- Streams تفاعلية
- متغيرات زمنية
- شروط تفاعلية (when)
- مراقبة التغييرات

### 3. 🛡️ الأمان التعاقدي (Contractual Safety)
- أنواع مقيدة
- عقود (requires/ensures)
- عزل آمن (sandbox)
- ثوابت الفئات

---

## ⚡ البدء السريع

### التثبيت والتشغيل
```bash
# على Replit الآن
python stract_cli.py repl

# تشغيل ملف
python stract_cli.py run hello.stract

# تحليل بـ AI
python stract_cli.py analyze file.stract
```

### أول برنامج
```stract
print "Hello, STRACT!"

let x = 10
let y = 20
print x + y  # 30
```

---

## 📖 الوثائق الموحدة

### 🔴 **[فحص الواقع - اقرأ هذا أولاً!](docs/REALITY_CHECK.md)** ⚠️
**الحقيقة الصريحة عن حالة STRACT:**
- ما يعمل فعلاً وما لا يعمل
- الميزات الثورية = Parsing فقط، لا runtime
- الاستخدام الواقعي الحالي
- الخطة المستقبلية

### 👉 **[الدليل الكامل الموحد](docs/COMPLETE_GUIDE.md)** - الشامل
ملف واحد يجمع كل شيء:
- مقدمة البرنامج
- البدء السريع
- أساسيات اللغة
- الميزات الثورية (النظرية)
- أمثلة وشرح
- مرجع سريع
- أسئلة شائعة

### ملفات إضافية
- 📝 [كيفية كتابة الكود - الذي يعمل فعلاً](docs/HOW_TO_WRITE_CODE.md)
- 📚 [أمثلة عملية](docs/EXAMPLES_AR.md)
- 🏗️ [معمارية اللغة](docs/ARCHITECTURE.md)
- ❓ [الأسئلة الشائعة](docs/FAQ_AR.md)
- 📋 [فهرس الوثائق](docs/INDEX.md)

---

## 📚 أمثلة الاستخدام السريع

### الدوال والأمان
```stract
type PositiveInt: Int where value > 0

func safeDivide(a, b):
    requires b != 0
    ensures result * b == a
    return a / b

print safeDivide(10, 2)  # 5
```

### الذكاء الاصطناعي
```stract
tensor weights[100, 50] gpu gradient

model NeuralNet:
    Dense(128, activation="relu")
    Dense(10, activation="softmax")

train model using training_data epochs=10
```

### البرمجة الزمنية
```stract
stream data = source() |> filter(x: x > 0) |> map(x: x * 2)

temporal counter = 0 every 1s: counter + 1

when counter > 100:
    print "Milestone!"
```

---

## 🌟 الميزات الرئيسية

| الميزة | الوصف | مثال |
|--------|-------|-------|
| **Tensors** | متغيرات AI مع GPU | `tensor x[3, 3] gpu` |
| **Models** | شبكات عصبية | `Dense(128, activation="relu")` |
| **Type Safety** | أنواع مقيدة | `type Age where value >= 0` |
| **Contracts** | عقود البرمجة | `requires x > 0` |
| **Streams** | تدفقات البيانات | `stream \|> filter \|> map` |
| **Temporal** | متغيرات زمنية | `every 1s: update()` |
| **Sandbox** | عزل آمن | `sandbox [network]:` |

---

## 📖 الوثائق الشاملة

### البدء
- 📚 [دليل شامل](docs/COMPREHENSIVE_GUIDE_AR.md) - كل ما تحتاج لمعرفته
- 🔍 [مرجع اللغة](docs/LANGUAGE_REFERENCE.md) - تفاصيل كاملة
- 💡 [أمثلة عملية](docs/EXAMPLES_AR.md) - حالات استخدام حقيقية
- ⚡ [البدء السريع](docs/QUICK_START.md) - خطوات سريعة

### التقنيات المتقدمة
- 🤖 [AI والذكاء الاصطناعي](docs/COMPREHENSIVE_GUIDE_AR.md#-الذكاء-الاصطناعي-ai-native)
- ⏱️ [البرمجة الزمنية](docs/COMPREHENSIVE_GUIDE_AR.md#-البرمجة-الزمنية-temporal)
- 🔐 [الأمان والعقود](docs/COMPREHENSIVE_GUIDE_AR.md#-الأمان-التعاقدي-contractual-safety)

---

## 🎮 الأوامر الرئيسية

```bash
# الوضع التفاعلي
python stract_cli.py repl

# تشغيل ملف
python stract_cli.py run file.stract

# فحص أخطاء
python stract_cli.py check file.stract

# تحليل الكود
python stract_cli.py analyze file.stract

# عرض جميع الأوامر
python stract_cli.py commands
```

---

## 📁 هيكل المشروع

```
STRACT/
├── stract_cli.py                    # CLI الرئيسي
├── README.md                        # هذا الملف
├── replit.md                        # معلومات المشروع
├── examples/                        # أمثلة
│   ├── revolutionary_features.stract    # كل الميزات
│   ├── ai_native.stract                 # الذكاء الاصطناعي
│   ├── reactive_temporal.stract         # البرمجة الزمنية
│   └── contractual_safety.stract        # الأمان
├── docs/                            # الوثائق
│   ├── COMPREHENSIVE_GUIDE_AR.md        # دليل شامل
│   ├── LANGUAGE_REFERENCE.md            # مرجع اللغة
│   ├── EXAMPLES_AR.md                   # أمثلة عملية
│   └── QUICK_START.md                   # البدء السريع
└── STRACTPROGRAMzip/SystemRefactor/
    ├── main.py                      # Interpreter
    ├── CORE_SYSTEM/                 # Lexer و Parser
    ├── DEVELOPER_TOOLS/             # أدوات
    └── TESTS/                       # اختبارات
```

---

## 💻 أمثلة سريعة

### Hello World
```stract
print "مرحباً بك في STRACT!"
```

### الحسابات
```stract
let result = (10 + 20) * 2
print result  # 60
```

### القوائم والتحويلات
```stract
let numbers = [1, 2, 3, 4, 5]
let doubled = numbers.map(lambda x: x * 2)
print doubled  # [2, 4, 6, 8, 10]
```

### الفئات والكائنات
```stract
class Person:
    func init(name):
        this.name = name
    
    func greet():
        print "Hello, I'm " + this.name

let person = Person("Ahmed")
person.greet()
```

---

## 🔥 الميزات التي تميزها

✨ **بسيطة مثل Python**
- بناء جملي سهل وواضح
- لا حاجة لإعلانات معقدة
- قراءة شبه طبيعية

⚡ **سريعة مثل C++**
- دعم GPU أصلي
- تجميع محسّن
- معالجة فعالة للبيانات

🛡️ **آمنة مثل Rust**
- أنواع مقيدة
- عقود البرمجة
- عزل آمن

🤖 **ذكية مثل Python + TensorFlow**
- Tensors مدمجة
- تفاضل تلقائي
- نماذج AI بسيطة

---

## 🎓 مرحلة التعلم

### المبتدئون
1. اقرأ [البدء السريع](docs/QUICK_START.md)
2. جرب [الأمثلة الأساسية](docs/EXAMPLES_AR.md)
3. اكتب برنامجك الأول

### المستوى المتوسط
1. اقرأ [دليل اللغة](docs/COMPREHENSIVE_GUIDE_AR.md)
2. استكشف الميزات المتقدمة
3. بناء تطبيقات حقيقية

### المتقدمون
1. اقرأ [مرجع اللغة](docs/LANGUAGE_REFERENCE.md)
2. استخدم الميزات الثورية
3. ساهم في التطوير

---

## 🚀 الخطوات التالية

### Phase 1: MVP (الآن) ✅
- ✅ الحد الأدنى من الميزات العاملة
- ✅ توثيق شامل
- ✅ أمثلة عملية

### Phase 2: التحسينات
- 🔄 تحسين الأداء
- 🔄 إضافة مكتبات
- 🔄 بناء المجتمع

### Phase 3: النمو
- 📈 معايير صناعية
- 📈 اعتماد واسع
- 📈 ثورة برمجية

---

## 🆘 الدعم والمساعدة

### الموارد
- 📖 [الوثائق الكاملة](docs/)
- 💡 [الأمثلة والحالات](examples/)
- 🐛 استخدم `check` للأخطاء
- 🤖 استخدم `analyze` للمساعدة

### التعليقات والاقتراحات
- اطرح أسئلة في الوثائق
- اقترح تحسينات
- أبلغ عن الأخطاء

---

## 📊 المقارنة مع اللغات الأخرى

| الميزة | STRACT | Python | JavaScript |
|--------|--------|--------|-----------|
| بساطة | ✅✅✅ | ✅✅ | ✅ |
| الأداء | ✅✅✅ | ✅ | ✅✅ |
| AI مدمج | ✅✅✅ | ❌ | ❌ |
| أمان | ✅✅✅ | ✅ | ✅ |
| زمنية | ✅✅✅ | ❌ | ✅ |
| الويب | ✅✅ | ✅✅ | ✅✅✅ |

---

## 🎯 رؤيتنا

**STRACT** تهدف لتحويل طريقة تفكير المطورين في:
- الذكاء الاصطناعي والتعلم الآلي
- الأمان والموثوقية
- التزامن والبرمجة الزمنية

---

## 📝 الترخيص

MIT License - استخدم بحرية في مشاريعك

---

## 🎉 شكر لك!

شكراً لاختيارك **STRACT**. نحن متحمسون لمشاهدة ما ستبنيه بها!

**STRACT v5.0** - برمجة المستقبل بذكاء، أمان، وزمن حقيقي! 🚀

---

### الإحصائيات
- 📚 35+ كلمة مفتاحية
- 🔧 40+ دالة مدمجة
- 📦 22 AST node جديد
- 🎯 3 ميزات ثورية
- 📖 وثائق شاملة بالعربية والإنجليزية
