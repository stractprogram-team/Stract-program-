#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STRACT Programming Language CLI v5.0
Entry point for all STRACT commands
"""

import sys
import os

# Add src to path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, 'src'))

from stract.core.lexer import Lexer, LexerError
from stract.core.tokens import TokenType

def run_file(filepath):
    """Run a STRACT file"""
    if not os.path.exists(filepath):
        print(f"Error: File '{filepath}' not found")
        return False
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            code = f.read()
    except Exception as e:
        print(f"Error reading file: {e}")
        return False
    
    try:
        lexer = Lexer(code)
        tokens = lexer.tokenize()
        print(f"✓ Tokenization successful: {len(tokens)} tokens")
        return True
    except LexerError as e:
        print(f"✗ Lexer Error: {e}")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def main():
    if len(sys.argv) < 2:
        print("""
STRACT Programming Language v5.0

Usage:
  stract run <file>       Run a STRACT file
  stract repl             Start interactive REPL
  stract version          Show version
""")
        return
    
    cmd = sys.argv[1]
    
    if cmd == "run" and len(sys.argv) > 2:
        success = run_file(sys.argv[2])
        sys.exit(0 if success else 1)
    elif cmd == "version":
        print("STRACT v5.0.0")
    else:
        print(f"Unknown command: {cmd}")

if __name__ == "__main__":
    main()
