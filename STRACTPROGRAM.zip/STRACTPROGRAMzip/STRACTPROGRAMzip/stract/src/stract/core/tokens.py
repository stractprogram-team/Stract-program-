"""
STRACT Token Definitions
All token types supported by the STRACT programming language
"""

from enum import Enum, auto
from dataclasses import dataclass
from typing import Any


class TokenType(Enum):
    """All token types supported by STRACT"""
    INTEGER = auto()
    FLOAT = auto()
    STRING = auto()
    BOOLEAN = auto()
    IDENTIFIER = auto()
    
    PLUS = auto()
    MINUS = auto()
    MULTIPLY = auto()
    DIVIDE = auto()
    FLOOR_DIVIDE = auto()
    MODULO = auto()
    POWER = auto()
    
    EQUAL = auto()
    NOT_EQUAL = auto()
    LESS = auto()
    GREATER = auto()
    LESS_EQUAL = auto()
    GREATER_EQUAL = auto()
    
    AND = auto()
    OR = auto()
    NOT = auto()
    
    ASSIGN = auto()
    PLUS_ASSIGN = auto()
    MINUS_ASSIGN = auto()
    MULTIPLY_ASSIGN = auto()
    DIVIDE_ASSIGN = auto()
    
    LPAREN = auto()
    RPAREN = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    LBRACE = auto()
    RBRACE = auto()
    COMMA = auto()
    COLON = auto()
    DOT = auto()
    SEMICOLON = auto()
    ARROW = auto()
    NEWLINE = auto()
    
    LET = auto()
    CONST = auto()
    VAR = auto()
    IF = auto()
    ELIF = auto()
    ELSE = auto()
    WHILE = auto()
    FOR = auto()
    IN = auto()
    FUNC = auto()
    RETURN = auto()
    BREAK = auto()
    CONTINUE = auto()
    PRINT = auto()
    INPUT = auto()
    TRUE = auto()
    FALSE = auto()
    NULL = auto()
    RANGE = auto()
    CLASS = auto()
    NEW = auto()
    THIS = auto()
    IMPORT = auto()
    FROM = auto()
    AS = auto()
    TRY = auto()
    CATCH = auto()
    FINALLY = auto()
    THROW = auto()
    ASYNC = auto()
    AWAIT = auto()
    LAMBDA = auto()
    MATCH = auto()
    CASE = auto()
    DEFAULT = auto()
    
    AT = auto()
    DECORATOR = auto()
    
    TYPE = auto()
    WHERE = auto()
    REQUIRES = auto()
    ENSURES = auto()
    INVARIANT = auto()
    
    TENSOR = auto()
    MODEL = auto()
    OPTIMIZE = auto()
    USING = auto()
    HARDWARE = auto()
    GPU = auto()
    CPU = auto()
    TPU = auto()
    GRADIENT = auto()
    TRAIN = auto()
    PREDICT = auto()
    
    STREAM = auto()
    REACTIVE = auto()
    TEMPORAL = auto()
    WHEN = auto()
    OBSERVE = auto()
    EMIT = auto()
    EVERY = auto()
    AFTER = auto()
    
    SANDBOX = auto()
    ISOLATED = auto()
    CAPABILITY = auto()
    
    PIPE = auto()
    
    EOF = auto()
    INDENT = auto()
    DEDENT = auto()


@dataclass
class Token:
    """Represents a single token with position information"""
    type: TokenType
    value: Any
    line: int
    column: int
    
    def __repr__(self):
        return f"Token({self.type.name}, {repr(self.value)}, line={self.line})"
    
    def __eq__(self, other):
        if isinstance(other, Token):
            return self.type == other.type and self.value == other.value
        return False
