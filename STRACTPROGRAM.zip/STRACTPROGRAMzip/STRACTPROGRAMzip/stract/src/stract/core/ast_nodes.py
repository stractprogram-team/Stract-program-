"""
STRACT AST Node Definitions
All Abstract Syntax Tree nodes for the STRACT language
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union


@dataclass
class ASTNode:
    """Base class for all AST nodes"""
    line: int = 0
    column: int = 0


@dataclass
class NumberNode(ASTNode):
    value: Union[int, float] = 0


@dataclass
class StringNode(ASTNode):
    value: str = ""


@dataclass
class BooleanNode(ASTNode):
    value: bool = False


@dataclass
class NullNode(ASTNode):
    pass


@dataclass
class IdentifierNode(ASTNode):
    name: str = ""


@dataclass
class ListNode(ASTNode):
    elements: List[ASTNode] = field(default_factory=list)


@dataclass
class DictNode(ASTNode):
    pairs: List[Tuple[ASTNode, ASTNode]] = field(default_factory=list)


@dataclass
class IndexNode(ASTNode):
    obj: Optional[ASTNode] = None
    index: Optional[ASTNode] = None


@dataclass
class SliceNode(ASTNode):
    obj: Optional[ASTNode] = None
    start: Optional[ASTNode] = None
    end: Optional[ASTNode] = None
    step: Optional[ASTNode] = None


@dataclass
class BinaryOpNode(ASTNode):
    left: Optional[ASTNode] = None
    operator: str = ""
    right: Optional[ASTNode] = None


@dataclass
class UnaryOpNode(ASTNode):
    operator: str = ""
    operand: Optional[ASTNode] = None


@dataclass
class AssignNode(ASTNode):
    name: str = ""
    value: Optional[ASTNode] = None
    is_const: bool = False
    type_annotation: Optional[str] = None


@dataclass
class CompoundAssignNode(ASTNode):
    name: str = ""
    operator: str = ""
    value: Optional[ASTNode] = None


@dataclass
class IndexAssignNode(ASTNode):
    obj: Optional[ASTNode] = None
    index: Optional[ASTNode] = None
    value: Optional[ASTNode] = None


@dataclass
class PrintNode(ASTNode):
    expressions: List[ASTNode] = field(default_factory=list)


@dataclass
class InputNode(ASTNode):
    prompt: Optional[ASTNode] = None


@dataclass
class IfNode(ASTNode):
    condition: Optional[ASTNode] = None
    then_block: List[ASTNode] = field(default_factory=list)
    elif_blocks: List[tuple] = field(default_factory=list)
    else_block: List[ASTNode] = field(default_factory=list)


@dataclass
class WhileNode(ASTNode):
    condition: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class ForNode(ASTNode):
    variable: str = ""
    iterable: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class RangeNode(ASTNode):
    start: Optional[ASTNode] = None
    end: Optional[ASTNode] = None
    step: Optional[ASTNode] = None


@dataclass
class FunctionDefNode(ASTNode):
    name: str = ""
    params: List[str] = field(default_factory=list)
    defaults: List[ASTNode] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)
    decorators: List['DecoratorNode'] = field(default_factory=list)
    param_types: Dict[str, str] = field(default_factory=dict)
    return_type: Optional[str] = None


@dataclass
class LambdaNode(ASTNode):
    params: List[str] = field(default_factory=list)
    body: Optional[ASTNode] = None


@dataclass
class FunctionCallNode(ASTNode):
    name: str = ""
    args: List[ASTNode] = field(default_factory=list)
    kwargs: Dict[str, ASTNode] = field(default_factory=dict)


@dataclass
class MethodCallNode(ASTNode):
    obj: Optional[ASTNode] = None
    method: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class ReturnNode(ASTNode):
    value: Optional[ASTNode] = None


@dataclass
class BreakNode(ASTNode):
    pass


@dataclass
class ContinueNode(ASTNode):
    pass


@dataclass
class ClassDefNode(ASTNode):
    name: str = ""
    parent: Optional[str] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class PropertyAccessNode(ASTNode):
    obj: Optional[ASTNode] = None
    property: str = ""


@dataclass
class PropertyAssignNode(ASTNode):
    obj: Optional[ASTNode] = None
    property: str = ""
    value: Optional[ASTNode] = None


@dataclass
class NewInstanceNode(ASTNode):
    class_name: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class DecoratorNode(ASTNode):
    name: str = ""
    args: List[ASTNode] = field(default_factory=list)
    target: Optional[ASTNode] = None


@dataclass
class ImportNode(ASTNode):
    module: str = ""
    alias: Optional[str] = None
    items: List[str] = field(default_factory=list)


@dataclass
class TryNode(ASTNode):
    try_block: List[ASTNode] = field(default_factory=list)
    catch_var: Optional[str] = None
    catch_block: List[ASTNode] = field(default_factory=list)
    finally_block: List[ASTNode] = field(default_factory=list)


@dataclass
class ThrowNode(ASTNode):
    value: Optional[ASTNode] = None


@dataclass
class MatchNode(ASTNode):
    value: Optional[ASTNode] = None
    cases: List[tuple] = field(default_factory=list)
    default: List[ASTNode] = field(default_factory=list)


@dataclass
class ProgramNode(ASTNode):
    statements: List[ASTNode] = field(default_factory=list)


@dataclass
class TypeDefinitionNode(ASTNode):
    name: str = ""
    base_type: str = ""
    where_condition: Optional[ASTNode] = None


@dataclass
class RequiresNode(ASTNode):
    condition: Optional[ASTNode] = None


@dataclass
class EnsuresNode(ASTNode):
    condition: Optional[ASTNode] = None


@dataclass
class InvariantNode(ASTNode):
    condition: Optional[ASTNode] = None


@dataclass
class ContractedFunctionNode(ASTNode):
    name: str = ""
    params: List[str] = field(default_factory=list)
    param_types: Dict[str, str] = field(default_factory=dict)
    return_type: Optional[str] = None
    requires: List[ASTNode] = field(default_factory=list)
    ensures: List[ASTNode] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class TensorNode(ASTNode):
    name: str = ""
    shape: List[ASTNode] = field(default_factory=list)
    dtype: str = "float32"
    device: str = "cpu"
    initial_value: Optional[ASTNode] = None
    requires_grad: bool = False


@dataclass
class ModelNode(ASTNode):
    name: str = ""
    layers: List[ASTNode] = field(default_factory=list)
    optimizer: Optional[str] = None
    loss: Optional[str] = None


@dataclass
class OptimizeDirectiveNode(ASTNode):
    target: Optional[ASTNode] = None
    goal: str = "accuracy"
    data: Optional[ASTNode] = None
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TrainNode(ASTNode):
    model: Optional[ASTNode] = None
    data: Optional[ASTNode] = None
    epochs: int = 1
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PredictNode(ASTNode):
    model: Optional[ASTNode] = None
    input_data: Optional[ASTNode] = None


@dataclass
class HardwareNode(ASTNode):
    device: str = "auto"
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class GradientNode(ASTNode):
    expression: Optional[ASTNode] = None
    with_respect_to: List[str] = field(default_factory=list)


@dataclass
class ReactiveStreamNode(ASTNode):
    name: str = ""
    source: Optional[ASTNode] = None
    transformations: List[ASTNode] = field(default_factory=list)


@dataclass
class TemporalVariableNode(ASTNode):
    name: str = ""
    initial_value: Optional[ASTNode] = None
    update_rule: Optional[ASTNode] = None
    interval: Optional[ASTNode] = None


@dataclass
class WhenNode(ASTNode):
    condition: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class ObserveNode(ASTNode):
    target: Optional[ASTNode] = None
    handler: Optional[ASTNode] = None


@dataclass
class EmitNode(ASTNode):
    stream: Optional[ASTNode] = None
    value: Optional[ASTNode] = None


@dataclass
class EveryNode(ASTNode):
    interval: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class AfterNode(ASTNode):
    delay: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class SandboxNode(ASTNode):
    name: str = ""
    capabilities: List[str] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class PipeNode(ASTNode):
    left: Optional[ASTNode] = None
    right: Optional[ASTNode] = None
