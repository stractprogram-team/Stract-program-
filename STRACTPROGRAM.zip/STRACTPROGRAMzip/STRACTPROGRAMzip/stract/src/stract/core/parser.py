"""STRACT Parser - Converts tokens to AST"""

from typing import List, Optional, Any, Dict, Tuple
from .tokens import Token, TokenType
from .ast_nodes import *

class ParserError(Exception):
    def __init__(self, message: str, line: int = 0, column: int = 0):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Parser Error at line {line}: {message}")

class ParserError(Exception):
    def __init__(self, message: str, token: Token):
        self.message = message
        self.token = token
        super().__init__(f"Parser Error at line {token.line}, column {token.column}: {message}")


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
    
    def error(self, message: str):
        raise ParserError(message, self.current())
    
    def current(self) -> Token:
        if self.pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[self.pos]
    
    def peek(self, offset: int = 0) -> Token:
        pos = self.pos + offset
        if pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[pos]
    
    def advance(self) -> Token:
        token = self.current()
        self.pos += 1
        return token
    
    def match(self, *types: TokenType) -> bool:
        return self.current().type in types
    
    def expect(self, token_type: TokenType, message: Optional[str] = None) -> Token:
        if self.current().type != token_type:
            msg = message or f"Expected {token_type.name}, got {self.current().type.name}"
            self.error(msg)
        return self.advance()
    
    def skip_newlines(self):
        while self.match(TokenType.NEWLINE):
            self.advance()
    
    def parse(self) -> ProgramNode:
        statements = []
        self.skip_newlines()
        
        while not self.match(TokenType.EOF):
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            self.skip_newlines()
        
        return ProgramNode(statements=statements)
    
    def parse_statement(self) -> Optional[ASTNode]:
        self.skip_newlines()
        
        token = self.current()
        
        if token.type == TokenType.AT:
            return self.parse_decorator()
        elif token.type == TokenType.LET or token.type == TokenType.VAR:
            return self.parse_variable_declaration(is_const=False)
        elif token.type == TokenType.CONST:
            return self.parse_variable_declaration(is_const=True)
        elif token.type == TokenType.PRINT:
            return self.parse_print()
        elif token.type == TokenType.IF:
            return self.parse_if()
        elif token.type == TokenType.WHILE:
            return self.parse_while()
        elif token.type == TokenType.FOR:
            return self.parse_for()
        elif token.type == TokenType.FUNC:
            return self.parse_function_def()
        elif token.type == TokenType.RETURN:
            return self.parse_return()
        elif token.type == TokenType.BREAK:
            self.advance()
            return BreakNode(line=token.line, column=token.column)
        elif token.type == TokenType.CONTINUE:
            self.advance()
            return ContinueNode(line=token.line, column=token.column)
        elif token.type == TokenType.CLASS:
            return self.parse_class_def()
        elif token.type == TokenType.TRY:
            return self.parse_try()
        elif token.type == TokenType.THROW:
            return self.parse_throw()
        elif token.type == TokenType.IMPORT:
            return self.parse_import()
        elif token.type == TokenType.MATCH:
            return self.parse_match()
        # ========== STRACT v5.0 Revolutionary Features ==========
        # Contractual Safety
        elif token.type == TokenType.TYPE:
            return self.parse_type_definition()
        elif token.type == TokenType.SANDBOX:
            return self.parse_sandbox()
        elif token.type == TokenType.INVARIANT:
            return self.parse_invariant()
        # AI-Native
        elif token.type == TokenType.TENSOR:
            return self.parse_tensor()
        elif token.type == TokenType.MODEL:
            return self.parse_model()
        elif token.type == TokenType.OPTIMIZE:
            return self.parse_optimize()
        elif token.type == TokenType.TRAIN:
            return self.parse_train()
        elif token.type == TokenType.PREDICT:
            return self.parse_predict()
        elif token.type == TokenType.HARDWARE:
            return self.parse_hardware()
        elif token.type == TokenType.GRADIENT:
            return self.parse_gradient()
        # Reactive & Temporal
        elif token.type == TokenType.STREAM:
            return self.parse_stream()
        elif token.type == TokenType.REACTIVE:
            return self.parse_reactive()
        elif token.type == TokenType.TEMPORAL:
            return self.parse_temporal()
        elif token.type == TokenType.WHEN:
            return self.parse_when()
        elif token.type == TokenType.OBSERVE:
            return self.parse_observe()
        elif token.type == TokenType.EMIT:
            return self.parse_emit()
        elif token.type == TokenType.EVERY:
            return self.parse_every()
        elif token.type == TokenType.AFTER:
            return self.parse_after()
        # ========== End of v5.0 Features ==========
        elif token.type == TokenType.IDENTIFIER:
            return self.parse_identifier_statement()
        elif token.type in (TokenType.INDENT, TokenType.DEDENT):
            self.advance()
            return None
        else:
            return self.parse_expression()
    
    def parse_decorator(self) -> DecoratorNode:
        token = self.advance()
        
        name = ""
        if self.match(TokenType.IDENTIFIER):
            name = self.advance().value
            while self.match(TokenType.DOT):
                self.advance()
                name += "." + self.expect(TokenType.IDENTIFIER, "Expected identifier after '.'").value
        
        args = []
        if self.match(TokenType.LPAREN):
            self.advance()
            if not self.match(TokenType.RPAREN):
                args.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    self.advance()
                    args.append(self.parse_expression())
            self.expect(TokenType.RPAREN, "Expected ')' after decorator arguments")
        
        self.skip_newlines()
        
        target = None
        if self.match(TokenType.AT):
            target = self.parse_decorator()
        elif self.match(TokenType.FUNC):
            target = self.parse_function_def()
        elif self.match(TokenType.CLASS):
            target = self.parse_class_def()
        
        return DecoratorNode(
            name=name,
            args=args,
            target=target,
            line=token.line,
            column=token.column
        )
    
    def parse_variable_declaration(self, is_const: bool) -> AssignNode:
        token = self.advance()
        name_token = self.expect(TokenType.IDENTIFIER, "Expected variable name")
        self.expect(TokenType.ASSIGN, "Expected '=' after variable name")
        value = self.parse_expression()
        
        return AssignNode(
            name=name_token.value,
            value=value,
            is_const=is_const,
            line=token.line,
            column=token.column
        )
    
    def parse_identifier_statement(self) -> ASTNode:
        expr = self.parse_expression()
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            value = self.parse_expression()
            
            if isinstance(expr, IdentifierNode):
                return AssignNode(
                    name=expr.name,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            elif isinstance(expr, IndexNode):
                return IndexAssignNode(
                    obj=expr.obj,
                    index=expr.index,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            else:
                self.error("Invalid assignment target")
        
        if self.match(TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN, 
                      TokenType.MULTIPLY_ASSIGN, TokenType.DIVIDE_ASSIGN):
            op_token = self.advance()
            value = self.parse_expression()
            
            if isinstance(expr, IdentifierNode):
                op_map = {
                    TokenType.PLUS_ASSIGN: '+=',
                    TokenType.MINUS_ASSIGN: '-=',
                    TokenType.MULTIPLY_ASSIGN: '*=',
                    TokenType.DIVIDE_ASSIGN: '/=',
                }
                return CompoundAssignNode(
                    name=expr.name,
                    operator=op_map[op_token.type],
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
        
        return expr
    
    def parse_print(self) -> PrintNode:
        token = self.advance()
        
        expressions = []
        if not self.match(TokenType.NEWLINE, TokenType.EOF):
            expressions.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                self.advance()
                expressions.append(self.parse_expression())
        
        return PrintNode(expressions=expressions, line=token.line, column=token.column)
    
    def parse_if(self) -> IfNode:
        token = self.advance()
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after if condition")
        
        then_block = self.parse_block()
        elif_blocks = []
        else_block = []
        
        self.skip_newlines()
        
        while self.match(TokenType.ELIF):
            self.advance()
            elif_condition = self.parse_expression()
            self.expect(TokenType.COLON, "Expected ':' after elif condition")
            elif_body = self.parse_block()
            elif_blocks.append((elif_condition, elif_body))
            self.skip_newlines()
        
        if s
    # ... (full parser implementation)
