"""
STRACT Standard Library
Provides built-in modules for I/O, networking, math, and more
"""

from .io_module import FileIO, Console
from .math_module import MathModule
from .string_module import StringModule
from .network_module import NetworkModule
from .json_module import JsonModule
from .time_module import TimeModule

__all__ = [
    'FileIO', 'Console',
    'MathModule',
    'StringModule', 
    'NetworkModule',
    'JsonModule',
    'TimeModule',
]
