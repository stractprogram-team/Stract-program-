"""
STRACT Programming Language v5.0
Revolutionary Programming Language with AI-Native, Reactive & Contractual Safety Features

This package provides the complete STRACT language implementation including:
- Lexer and Parser for tokenization and AST generation
- Interpreter with full runtime support (TODO)
- Type system with Refinement Types (TODO)
- Contract enforcement (requires/ensures) (TODO)
- Tensor operations with computational backend (TODO)
- Reactive programming with Event Loop (TODO)
- Automatic differentiation for AI/ML (TODO)
"""

__version__ = "5.0.0"
__author__ = "STRACT Development Team"

from .core.tokens import TokenType, Token
from .core.lexer import Lexer, LexerError
from .core.parser import Parser, ParserError
from .core.ast_nodes import (
    ASTNode, NumberNode, StringNode, BooleanNode, NullNode, IdentifierNode,
    ListNode, DictNode, IndexNode, SliceNode, BinaryOpNode, UnaryOpNode,
    AssignNode, CompoundAssignNode, IndexAssignNode, PrintNode, InputNode,
    IfNode, WhileNode, ForNode, RangeNode, FunctionDefNode, LambdaNode,
    FunctionCallNode, MethodCallNode, ReturnNode, BreakNode, ContinueNode,
    ClassDefNode, PropertyAccessNode, PropertyAssignNode, NewInstanceNode,
    DecoratorNode, ImportNode, TryNode, ThrowNode, MatchNode, ProgramNode,
    TypeDefinitionNode, RequiresNode, EnsuresNode, InvariantNode,
    ContractedFunctionNode, TensorNode, ModelNode, OptimizeDirectiveNode,
    TrainNode, PredictNode, HardwareNode, GradientNode, ReactiveStreamNode,
    TemporalVariableNode, WhenNode, ObserveNode, EmitNode, EveryNode,
    AfterNode, SandboxNode, PipeNode
)

__all__ = [
    'TokenType', 'Token',
    'Lexer', 'LexerError',
    'Parser', 'ParserError',
    'ASTNode', 'NumberNode', 'StringNode', 'BooleanNode', 'NullNode', 
    'IdentifierNode', 'ListNode', 'DictNode', 'IndexNode', 'SliceNode', 
    'BinaryOpNode', 'UnaryOpNode', 'AssignNode', 'CompoundAssignNode', 
    'IndexAssignNode', 'PrintNode', 'InputNode', 'IfNode', 'WhileNode', 
    'ForNode', 'RangeNode', 'FunctionDefNode', 'LambdaNode', 'FunctionCallNode', 
    'MethodCallNode', 'ReturnNode', 'BreakNode', 'ContinueNode', 'ClassDefNode', 
    'PropertyAccessNode', 'PropertyAssignNode', 'NewInstanceNode', 'DecoratorNode', 
    'ImportNode', 'TryNode', 'ThrowNode', 'MatchNode', 'ProgramNode',
    'TypeDefinitionNode', 'RequiresNode', 'EnsuresNode', 'InvariantNode',
    'ContractedFunctionNode', 'TensorNode', 'ModelNode', 'OptimizeDirectiveNode',
    'TrainNode', 'PredictNode', 'HardwareNode', 'GradientNode', 'ReactiveStreamNode',
    'TemporalVariableNode', 'WhenNode', 'ObserveNode', 'EmitNode', 'EveryNode',
    'AfterNode', 'SandboxNode', 'PipeNode',
]
