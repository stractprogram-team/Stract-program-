#!/usr/bin/env python3
"""
Test script for the STRACT Runtime Interpreter
"""

import sys
sys.path.insert(0, 'src')

from stract.runtime import (
    Interpreter,
    STRACTRuntimeError,
    Environment,
    STRACTFunction,
    STRACTClass,
    STRACTInstance,
    STRACTTensor,
    STRACTStream,
)
from stract.core.ast_nodes import (
    ProgramNode, NumberNode, StringNode, BooleanNode, NullNode,
    IdentifierNode, ListNode, DictNode, BinaryOpNode, UnaryOpNode,
    AssignNode, PrintNode, IfNode, WhileNode, ForNode, RangeNode,
    FunctionDefNode, FunctionCallNode, ReturnNode, ClassDefNode,
    TryNode, ThrowNode, LambdaNode, MethodCallNode, IndexNode
)

def test_basic_values():
    print("Testing basic values...")
    interp = Interpreter()
    
    assert interp.execute(NumberNode(value=42)) == 42
    assert interp.execute(NumberNode(value=3.14)) == 3.14
    assert interp.execute(StringNode(value="hello")) == "hello"
    assert interp.execute(BooleanNode(value=True)) == True
    assert interp.execute(BooleanNode(value=False)) == False
    assert interp.execute(NullNode()) == None
    print("  Basic values: PASSED")

def test_arithmetic():
    print("Testing arithmetic operations...")
    interp = Interpreter()
    
    add = BinaryOpNode(left=NumberNode(value=5), operator='+', right=NumberNode(value=3))
    assert interp.execute(add) == 8
    
    sub = BinaryOpNode(left=NumberNode(value=10), operator='-', right=NumberNode(value=4))
    assert interp.execute(sub) == 6
    
    mul = BinaryOpNode(left=NumberNode(value=6), operator='*', right=NumberNode(value=7))
    assert interp.execute(mul) == 42
    
    div = BinaryOpNode(left=NumberNode(value=15), operator='/', right=NumberNode(value=3))
    assert interp.execute(div) == 5.0
    
    mod = BinaryOpNode(left=NumberNode(value=17), operator='%', right=NumberNode(value=5))
    assert interp.execute(mod) == 2
    
    power = BinaryOpNode(left=NumberNode(value=2), operator='**', right=NumberNode(value=10))
    assert interp.execute(power) == 1024
    
    neg = UnaryOpNode(operator='-', operand=NumberNode(value=42))
    assert interp.execute(neg) == -42
    
    print("  Arithmetic operations: PASSED")

def test_comparisons():
    print("Testing comparison operations...")
    interp = Interpreter()
    
    eq = BinaryOpNode(left=NumberNode(value=5), operator='==', right=NumberNode(value=5))
    assert interp.execute(eq) == True
    
    ne = BinaryOpNode(left=NumberNode(value=5), operator='!=', right=NumberNode(value=3))
    assert interp.execute(ne) == True
    
    lt = BinaryOpNode(left=NumberNode(value=3), operator='<', right=NumberNode(value=5))
    assert interp.execute(lt) == True
    
    gt = BinaryOpNode(left=NumberNode(value=5), operator='>', right=NumberNode(value=3))
    assert interp.execute(gt) == True
    
    print("  Comparison operations: PASSED")

def test_variables():
    print("Testing variables...")
    interp = Interpreter()
    
    assign = AssignNode(name="x", value=NumberNode(value=42))
    interp.execute(assign)
    
    get = IdentifierNode(name="x")
    assert interp.execute(get) == 42
    
    assign2 = AssignNode(name="x", value=NumberNode(value=100))
    interp.execute(assign2)
    assert interp.execute(get) == 100
    
    print("  Variables: PASSED")

def test_lists():
    print("Testing lists...")
    interp = Interpreter()
    
    lst = ListNode(elements=[
        NumberNode(value=1),
        NumberNode(value=2),
        NumberNode(value=3)
    ])
    result = interp.execute(lst)
    assert result == [1, 2, 3]
    
    interp.execute(AssignNode(name="mylist", value=lst))
    
    idx = IndexNode(
        obj=IdentifierNode(name="mylist"),
        index=NumberNode(value=1)
    )
    assert interp.execute(idx) == 2
    
    print("  Lists: PASSED")

def test_dicts():
    print("Testing dictionaries...")
    interp = Interpreter()
    
    dct = DictNode(pairs=[
        (StringNode(value="a"), NumberNode(value=1)),
        (StringNode(value="b"), NumberNode(value=2))
    ])
    result = interp.execute(dct)
    assert result == {"a": 1, "b": 2}
    
    print("  Dictionaries: PASSED")

def test_if_statements():
    print("Testing if statements...")
    interp = Interpreter()
    
    if_true = IfNode(
        condition=BooleanNode(value=True),
        then_block=[AssignNode(name="result", value=NumberNode(value=1))],
        else_block=[AssignNode(name="result", value=NumberNode(value=2))]
    )
    interp.execute(if_true)
    assert interp.execute(IdentifierNode(name="result")) == 1
    
    if_false = IfNode(
        condition=BooleanNode(value=False),
        then_block=[AssignNode(name="result", value=NumberNode(value=10))],
        else_block=[AssignNode(name="result", value=NumberNode(value=20))]
    )
    interp.execute(if_false)
    assert interp.execute(IdentifierNode(name="result")) == 20
    
    print("  If statements: PASSED")

def test_while_loops():
    print("Testing while loops...")
    interp = Interpreter()
    
    interp.execute(AssignNode(name="counter", value=NumberNode(value=0)))
    interp.execute(AssignNode(name="sum", value=NumberNode(value=0)))
    
    while_node = WhileNode(
        condition=BinaryOpNode(
            left=IdentifierNode(name="counter"),
            operator='<',
            right=NumberNode(value=5)
        ),
        body=[
            AssignNode(
                name="sum",
                value=BinaryOpNode(
                    left=IdentifierNode(name="sum"),
                    operator='+',
                    right=IdentifierNode(name="counter")
                )
            ),
            AssignNode(
                name="counter",
                value=BinaryOpNode(
                    left=IdentifierNode(name="counter"),
                    operator='+',
                    right=NumberNode(value=1)
                )
            )
        ]
    )
    interp.execute(while_node)
    assert interp.execute(IdentifierNode(name="sum")) == 10
    
    print("  While loops: PASSED")

def test_for_loops():
    print("Testing for loops...")
    interp = Interpreter()
    
    interp.execute(AssignNode(name="total", value=NumberNode(value=0)))
    
    for_node = ForNode(
        variable="i",
        iterable=ListNode(elements=[
            NumberNode(value=1),
            NumberNode(value=2),
            NumberNode(value=3),
            NumberNode(value=4),
            NumberNode(value=5)
        ]),
        body=[
            AssignNode(
                name="total",
                value=BinaryOpNode(
                    left=IdentifierNode(name="total"),
                    operator='+',
                    right=IdentifierNode(name="i")
                )
            )
        ]
    )
    interp.execute(for_node)
    assert interp.execute(IdentifierNode(name="total")) == 15
    
    print("  For loops: PASSED")

def test_functions():
    print("Testing functions...")
    interp = Interpreter()
    
    func_def = FunctionDefNode(
        name="add",
        params=["a", "b"],
        defaults=[],
        body=[
            ReturnNode(
                value=BinaryOpNode(
                    left=IdentifierNode(name="a"),
                    operator='+',
                    right=IdentifierNode(name="b")
                )
            )
        ]
    )
    interp.execute(func_def)
    
    func_call = FunctionCallNode(
        name="add",
        args=[NumberNode(value=3), NumberNode(value=5)]
    )
    result = interp.execute(func_call)
    assert result == 8
    
    print("  Functions: PASSED")

def test_builtins():
    print("Testing built-in functions...")
    interp = Interpreter()
    
    len_call = FunctionCallNode(
        name="len",
        args=[ListNode(elements=[NumberNode(value=1), NumberNode(value=2), NumberNode(value=3)])]
    )
    assert interp.execute(len_call) == 3
    
    str_call = FunctionCallNode(
        name="str",
        args=[NumberNode(value=42)]
    )
    assert interp.execute(str_call) == "42"
    
    int_call = FunctionCallNode(
        name="int",
        args=[StringNode(value="123")]
    )
    assert interp.execute(int_call) == 123
    
    sum_call = FunctionCallNode(
        name="sum",
        args=[ListNode(elements=[NumberNode(value=1), NumberNode(value=2), NumberNode(value=3)])]
    )
    assert interp.execute(sum_call) == 6
    
    min_call = FunctionCallNode(
        name="min",
        args=[ListNode(elements=[NumberNode(value=5), NumberNode(value=2), NumberNode(value=8)])]
    )
    assert interp.execute(min_call) == 2
    
    max_call = FunctionCallNode(
        name="max",
        args=[ListNode(elements=[NumberNode(value=5), NumberNode(value=2), NumberNode(value=8)])]
    )
    assert interp.execute(max_call) == 8
    
    range_call = FunctionCallNode(
        name="range",
        args=[NumberNode(value=5)]
    )
    assert interp.execute(range_call) == [0, 1, 2, 3, 4]
    
    sorted_call = FunctionCallNode(
        name="sorted",
        args=[ListNode(elements=[NumberNode(value=3), NumberNode(value=1), NumberNode(value=2)])]
    )
    assert interp.execute(sorted_call) == [1, 2, 3]
    
    print("  Built-in functions: PASSED")

def test_classes():
    print("Testing classes...")
    interp = Interpreter()
    
    class_def = ClassDefNode(
        name="Counter",
        parent=None,
        body=[
            FunctionDefNode(
                name="init",
                params=["value"],
                defaults=[],
                body=[
                    AssignNode(name="this.count", value=IdentifierNode(name="value"))
                ]
            ),
            FunctionDefNode(
                name="increment",
                params=[],
                defaults=[],
                body=[
                    AssignNode(
                        name="this.count",
                        value=BinaryOpNode(
                            left=IdentifierNode(name="this.count"),
                            operator='+',
                            right=NumberNode(value=1)
                        )
                    )
                ]
            )
        ]
    )
    
    interp.execute(class_def)
    assert "Counter" in interp.classes
    
    print("  Classes: PASSED")

def test_try_catch():
    print("Testing try/catch...")
    interp = Interpreter()
    
    interp.execute(AssignNode(name="caught", value=BooleanNode(value=False)))
    
    try_node = TryNode(
        try_block=[
            ThrowNode(value=StringNode(value="test error"))
        ],
        catch_var="e",
        catch_block=[
            AssignNode(name="caught", value=BooleanNode(value=True))
        ],
        finally_block=[]
    )
    interp.execute(try_node)
    assert interp.execute(IdentifierNode(name="caught")) == True
    
    print("  Try/catch: PASSED")

def test_lambdas():
    print("Testing lambdas...")
    interp = Interpreter()
    
    lambda_node = LambdaNode(
        params=["x"],
        body=BinaryOpNode(
            left=IdentifierNode(name="x"),
            operator='*',
            right=NumberNode(value=2)
        )
    )
    
    interp.execute(AssignNode(name="double", value=lambda_node))
    
    map_call = FunctionCallNode(
        name="map",
        args=[
            IdentifierNode(name="double"),
            ListNode(elements=[NumberNode(value=1), NumberNode(value=2), NumberNode(value=3)])
        ]
    )
    result = interp.execute(map_call)
    assert result == [2, 4, 6]
    
    print("  Lambdas: PASSED")

def test_tensors():
    print("Testing tensors...")
    t = STRACTTensor(data=[1.0, 2.0, 3.0, 4.0], shape=[4])
    assert t.sum() == 10.0
    assert t.mean() == 2.5
    
    t2 = STRACTTensor(data=[1.0, 1.0, 1.0, 1.0], shape=[4])
    t3 = t + t2
    assert t3.data == [2.0, 3.0, 4.0, 5.0]
    
    print("  Tensors: PASSED")

def test_streams():
    print("Testing streams...")
    stream = STRACTStream(name="test", initial_value=0)
    
    received = []
    stream.subscribe(lambda v: received.append(v))
    
    stream.emit(1)
    stream.emit(2)
    stream.emit(3)
    
    assert received == [1, 2, 3]
    assert stream.history == [1, 2, 3]
    
    print("  Streams: PASSED")

def test_environment():
    print("Testing environment scoping...")
    parent = Environment()
    parent.define("x", 10)
    parent.define("y", 20, is_const=True)
    
    child = Environment(parent)
    child.define("z", 30)
    
    assert child.get("x") == 10
    assert child.get("y") == 20
    assert child.get("z") == 30
    
    child.set("x", 100)
    assert parent.get("x") == 100
    
    try:
        child.set("y", 200)
        assert False, "Should have raised error for constant"
    except Exception:
        pass
    
    print("  Environment scoping: PASSED")

def main():
    print("=" * 60)
    print("STRACT Runtime Interpreter Tests")
    print("=" * 60)
    
    tests = [
        test_basic_values,
        test_arithmetic,
        test_comparisons,
        test_variables,
        test_lists,
        test_dicts,
        test_if_statements,
        test_while_loops,
        test_for_loops,
        test_functions,
        test_builtins,
        test_classes,
        test_try_catch,
        test_lambdas,
        test_tensors,
        test_streams,
        test_environment,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"  FAILED: {e}")
            failed += 1
    
    print("=" * 60)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 60)
    
    if failed == 0:
        print("\nAll tests passed! STRACT interpreter is working correctly.")
    else:
        print(f"\n{failed} test(s) failed.")
        sys.exit(1)

if __name__ == "__main__":
    main()
