"""
STRACT Interpreter v5.0
Complete runtime interpreter for the STRACT programming language.
Executes all STRACT language features including AI-Native, Reactive, and Contractual Safety.
"""

from typing import Any, Dict, List, Optional, Callable, Union, Set, Tuple
import math
import random
import time
import json
import sys

from stract.src.core.ast_nodes import (
    ASTNode, NumberNode, StringNode, BooleanNode, NullNode, IdentifierNode,
    ListNode, DictNode, IndexNode, SliceNode, BinaryOpNode, UnaryOpNode,
    AssignNode, CompoundAssignNode, IndexAssignNode, PrintNode, InputNode,
    IfNode, WhileNode, ForNode, RangeNode, FunctionDefNode, LambdaNode,
    FunctionCallNode, MethodCallNode, ReturnNode, BreakNode, ContinueNode,
    ClassDefNode, PropertyAccessNode, PropertyAssignNode, NewInstanceNode,
    DecoratorNode, ImportNode, TryNode, ThrowNode, MatchNode, ProgramNode,
    RefinementTypeNode, TypeDefinitionNode, ContractNode, ContractedFunctionNode,
    RequiresNode, EnsuresNode, InvariantNode, SandboxNode,
    TensorNode, ModelNode, OptimizeDirectiveNode, GradientNode, TrainNode,
    PredictNode, HardwareNode,
    ReactiveStreamNode, TemporalVariableNode, WhenNode, ObserveNode,
    EmitNode, EveryNode, AfterNode, PipeNode,
    TypeAnnotationNode, TypedParameterNode
)


class STRACTRuntimeError(Exception):
    """Exception raised for runtime errors with line/column info"""
    def __init__(self, message: str, line: int = 0, column: int = 0):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Runtime Error at line {line}, column {column}: {message}")


class BreakException(Exception):
    """Exception used for break statements"""
    pass


class ContinueException(Exception):
    """Exception used for continue statements"""
    pass


class ReturnException(Exception):
    """Exception used for return statements"""
    def __init__(self, value: Any):
        self.value = value
        super().__init__()


class ThrowException(Exception):
    """Exception used for throw statements"""
    def __init__(self, value: Any, line: int = 0):
        self.value = value
        self.line = line
        super().__init__(str(value))


class STRACTClass:
    """Represents a STRACT class definition"""
    def __init__(self, name: str, parent: Optional['STRACTClass'], methods: Dict, properties: Dict):
        self.name = name
        self.parent = parent
        self.methods = methods
        self.properties = properties


class STRACTInstance:
    """Represents an instance of a STRACT class"""
    def __init__(self, klass: STRACTClass):
        self.klass = klass
        self.properties = dict(klass.properties)
    
    def get(self, name: str) -> Any:
        if name in self.properties:
            return self.properties[name]
        if name in self.klass.methods:
            return self.klass.methods[name]
        if self.klass.parent:
            parent_instance = STRACTInstance(self.klass.parent)
            return parent_instance.get(name)
        raise STRACTRuntimeError(f"Property '{name}' not found")
    
    def set(self, name: str, value: Any):
        self.properties[name] = value


class STRACTFunction:
    """Represents a user-defined function with closure"""
    def __init__(self, node: FunctionDefNode, closure: 'Environment'):
        self.node = node
        self.closure = closure
        self.name = node.name


class STRACTTensor:
    """Tensor type with shape, device, and gradient support for AI-native programming"""
    def __init__(self, data: Any = None, shape: List[int] = None, dtype: str = "float32", 
                 device: str = "cpu", requires_grad: bool = False):
        self.shape = shape or []
        self.dtype = dtype
        self.device = device
        self.requires_grad = requires_grad
        self.grad = None
        
        if data is not None:
            self.data = data
        else:
            size = 1
            for dim in self.shape:
                size *= dim
            self.data = [0.0] * size
    
    def __repr__(self):
        return f"STRACTTensor(shape={self.shape}, dtype={self.dtype}, device={self.device})"
    
    def __add__(self, other):
        if isinstance(other, STRACTTensor):
            if self.shape != other.shape:
                raise STRACTRuntimeError(f"Shape mismatch: {self.shape} vs {other.shape}")
            result_data = [a + b for a, b in zip(self.data, other.data)]
            return STRACTTensor(data=result_data, shape=self.shape[:], dtype=self.dtype, device=self.device)
        result_data = [x + other for x in self.data]
        return STRACTTensor(data=result_data, shape=self.shape[:], dtype=self.dtype, device=self.device)
    
    def __mul__(self, other):
        if isinstance(other, STRACTTensor):
            if self.shape != other.shape:
                raise STRACTRuntimeError(f"Shape mismatch: {self.shape} vs {other.shape}")
            result_data = [a * b for a, b in zip(self.data, other.data)]
            return STRACTTensor(data=result_data, shape=self.shape[:], dtype=self.dtype, device=self.device)
        result_data = [x * other for x in self.data]
        return STRACTTensor(data=result_data, shape=self.shape[:], dtype=self.dtype, device=self.device)
    
    def sum(self):
        return sum(self.data)
    
    def mean(self):
        return sum(self.data) / len(self.data) if self.data else 0.0
    
    def to(self, device: str):
        self.device = device
        return self
    
    def backward(self):
        if self.requires_grad:
            self.grad = STRACTTensor(data=[1.0] * len(self.data), shape=self.shape[:], dtype=self.dtype)


class STRACTStream:
    """Reactive stream type for reactive programming paradigm"""
    def __init__(self, name: str = "", initial_value: Any = None):
        self.name = name
        self.value = initial_value
        self.subscribers: List[Callable] = []
        self.transformations: List[Callable] = []
        self.history: List[Any] = []
    
    def __repr__(self):
        return f"STRACTStream(name='{self.name}', value={self.value})"
    
    def emit(self, value: Any):
        transformed_value = value
        for transform in self.transformations:
            transformed_value = transform(transformed_value)
        self.value = transformed_value
        self.history.append(transformed_value)
        for subscriber in self.subscribers:
            subscriber(transformed_value)
    
    def subscribe(self, callback: Callable):
        self.subscribers.append(callback)
    
    def unsubscribe(self, callback: Callable):
        if callback in self.subscribers:
            self.subscribers.remove(callback)
    
    def map(self, transform: Callable):
        new_stream = STRACTStream(name=f"{self.name}_mapped")
        new_stream.transformations = self.transformations + [transform]
        self.subscribe(lambda v: new_stream.emit(v))
        return new_stream
    
    def filter(self, predicate: Callable):
        new_stream = STRACTStream(name=f"{self.name}_filtered")
        def filter_fn(v):
            if predicate(v):
                new_stream.emit(v)
        self.subscribe(filter_fn)
        return new_stream


class STRACTRefinementType:
    """Refinement type with constraint validation for contractual safety"""
    def __init__(self, name: str, base_type: str, constraint: Callable = None):
        self.name = name
        self.base_type = base_type
        self.constraint = constraint
    
    def __repr__(self):
        return f"STRACTRefinementType({self.name}: {self.base_type})"
    
    def validate(self, value: Any) -> bool:
        type_valid = True
        if self.base_type == "Int":
            type_valid = isinstance(value, int)
        elif self.base_type == "Float":
            type_valid = isinstance(value, (int, float))
        elif self.base_type == "String":
            type_valid = isinstance(value, str)
        elif self.base_type == "Bool":
            type_valid = isinstance(value, bool)
        elif self.base_type == "List":
            type_valid = isinstance(value, list)
        elif self.base_type == "Dict":
            type_valid = isinstance(value, dict)
        
        if not type_valid:
            return False
        
        if self.constraint:
            return self.constraint(value)
        return True
    
    def create(self, value: Any) -> Any:
        if not self.validate(value):
            raise STRACTRuntimeError(f"Value {value} does not satisfy refinement type {self.name}")
        return value


class STRACTContract:
    """Contract with pre/post conditions for design by contract"""
    def __init__(self, requires: List[Callable] = None, ensures: List[Callable] = None):
        self.requires = requires or []
        self.ensures = ensures or []
    
    def __repr__(self):
        return f"STRACTContract(requires={len(self.requires)}, ensures={len(self.ensures)})"
    
    def check_preconditions(self, *args, **kwargs) -> bool:
        for req in self.requires:
            if not req(*args, **kwargs):
                return False
        return True
    
    def check_postconditions(self, result: Any, *args, **kwargs) -> bool:
        for ens in self.ensures:
            if not ens(result, *args, **kwargs):
                return False
        return True


class STRACTModel:
    """AI Model structure for AI-native programming"""
    def __init__(self, name: str, layers: List = None, optimizer: str = None, loss: str = None):
        self.name = name
        self.layers = layers or []
        self.optimizer = optimizer
        self.loss = loss
        self.trained = False
        self.weights = {}
    
    def __repr__(self):
        return f"STRACTModel(name='{self.name}', layers={len(self.layers)}, trained={self.trained})"
    
    def forward(self, input_data):
        result = input_data
        for layer in self.layers:
            if callable(layer):
                result = layer(result)
        return result
    
    def train(self, data, epochs: int = 1):
        self.trained = True
        return {"epochs": epochs, "status": "completed"}
    
    def predict(self, input_data):
        return self.forward(input_data)


class Environment:
    """Variable scope environment with parent chaining"""
    def __init__(self, parent: Optional['Environment'] = None):
        self.variables: Dict[str, Any] = {}
        self.constants: Set[str] = set()
        self.parent = parent
    
    def define(self, name: str, value: Any, is_const: bool = False):
        self.variables[name] = value
        if is_const:
            self.constants.add(name)
    
    def get(self, name: str) -> Any:
        if name in self.variables:
            return self.variables[name]
        if self.parent:
            return self.parent.get(name)
        raise STRACTRuntimeError(f"Undefined variable: '{name}'")
    
    def set(self, name: str, value: Any):
        if name in self.variables:
            if name in self.constants:
                raise STRACTRuntimeError(f"Cannot reassign constant: '{name}'")
            self.variables[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        raise STRACTRuntimeError(f"Undefined variable: '{name}'")
    
    def exists(self, name: str) -> bool:
        if name in self.variables:
            return True
        if self.parent:
            return self.parent.exists(name)
        return False


class Interpreter:
    """STRACT Language Interpreter - Executes all AST nodes"""
    
    def __init__(self):
        self.global_env = Environment()
        self.functions: Dict[str, FunctionDefNode] = {}
        self.classes: Dict[str, STRACTClass] = {}
        self.modules: Dict[str, Dict] = {}
        self.refinement_types: Dict[str, STRACTRefinementType] = {}
        self.streams: Dict[str, STRACTStream] = {}
        self.models: Dict[str, STRACTModel] = {}
        self.temporal_vars: Dict[str, Dict] = {}
        self.invariants: List[Callable] = []
        self.reactive_handlers: List[Callable] = []
        self.observers: Dict[str, List[Callable]] = {}
        self.scheduled_tasks: List[Dict] = []
        self.delayed_tasks: List[Dict] = []
        self.setup_builtins()
    
    def setup_builtins(self):
        """Setup all built-in functions"""
        self.builtins = {
            'len': lambda args: len(args[0]) if len(args) == 1 else self._error("len() takes 1 argument"),
            'str': lambda args: self.to_string(args[0]) if len(args) == 1 else self._error("str() takes 1 argument"),
            'int': lambda args: int(float(args[0])) if len(args) == 1 else self._error("int() takes 1 argument"),
            'float': lambda args: float(args[0]) if len(args) == 1 else self._error("float() takes 1 argument"),
            'bool': lambda args: self.is_truthy(args[0]) if len(args) == 1 else self._error("bool() takes 1 argument"),
            'type': lambda args: self.get_type(args[0]) if len(args) == 1 else self._error("type() takes 1 argument"),
            'abs': lambda args: abs(args[0]) if len(args) == 1 else self._error("abs() takes 1 argument"),
            'min': lambda args: min(args[0]) if len(args) == 1 and isinstance(args[0], list) else min(args),
            'max': lambda args: max(args[0]) if len(args) == 1 and isinstance(args[0], list) else max(args),
            'sum': lambda args: sum(args[0]) if len(args) == 1 else self._error("sum() takes 1 argument"),
            'round': lambda args: round(args[0], int(args[1])) if len(args) == 2 else round(args[0]) if len(args) == 1 else self._error("round() takes 1 or 2 arguments"),
            'sorted': lambda args: sorted(args[0]) if len(args) == 1 else self._error("sorted() takes 1 argument"),
            'reversed': lambda args: list(reversed(args[0])) if len(args) == 1 else self._error("reversed() takes 1 argument"),
            'list': lambda args: list(args[0]) if len(args) == 1 else [] if len(args) == 0 else self._error("list() takes 0 or 1 argument"),
            'dict': lambda args: dict() if len(args) == 0 else self._error("dict() takes 0 arguments"),
            'set': lambda args: set(args[0]) if len(args) == 1 else set() if len(args) == 0 else self._error("set() takes 0 or 1 argument"),
            'tuple': lambda args: tuple(args[0]) if len(args) == 1 else tuple() if len(args) == 0 else self._error("tuple() takes 0 or 1 argument"),
            'enumerate': lambda args: list(enumerate(args[0])) if len(args) == 1 else self._error("enumerate() takes 1 argument"),
            'zip': lambda args: list(zip(*args)) if len(args) >= 2 else self._error("zip() takes at least 2 arguments"),
            'map': lambda args: list(map(lambda x: self.call_function(args[0], [x]), args[1])) if len(args) == 2 else self._error("map() takes 2 arguments"),
            'filter': lambda args: list(filter(lambda x: self.is_truthy(self.call_function(args[0], [x])), args[1])) if len(args) == 2 else self._error("filter() takes 2 arguments"),
            'reduce': lambda args: self.builtin_reduce(args),
            'any': lambda args: any(self.is_truthy(x) for x in args[0]) if len(args) == 1 else self._error("any() takes 1 argument"),
            'all': lambda args: all(self.is_truthy(x) for x in args[0]) if len(args) == 1 else self._error("all() takes 1 argument"),
            'chr': lambda args: chr(int(args[0])) if len(args) == 1 else self._error("chr() takes 1 argument"),
            'ord': lambda args: ord(str(args[0])[0]) if len(args) == 1 else self._error("ord() takes 1 argument"),
            'hex': lambda args: hex(int(args[0])) if len(args) == 1 else self._error("hex() takes 1 argument"),
            'bin': lambda args: bin(int(args[0])) if len(args) == 1 else self._error("bin() takes 1 argument"),
            'oct': lambda args: oct(int(args[0])) if len(args) == 1 else self._error("oct() takes 1 argument"),
            'pow': lambda args: pow(args[0], args[1], args[2]) if len(args) == 3 else pow(args[0], args[1]) if len(args) == 2 else self._error("pow() takes 2 or 3 arguments"),
            'sqrt': lambda args: math.sqrt(args[0]) if len(args) == 1 else self._error("sqrt() takes 1 argument"),
            'sin': lambda args: math.sin(args[0]) if len(args) == 1 else self._error("sin() takes 1 argument"),
            'cos': lambda args: math.cos(args[0]) if len(args) == 1 else self._error("cos() takes 1 argument"),
            'tan': lambda args: math.tan(args[0]) if len(args) == 1 else self._error("tan() takes 1 argument"),
            'log': lambda args: math.log(args[0], args[1]) if len(args) == 2 else math.log(args[0]) if len(args) == 1 else self._error("log() takes 1 or 2 arguments"),
            'log10': lambda args: math.log10(args[0]) if len(args) == 1 else self._error("log10() takes 1 argument"),
            'exp': lambda args: math.exp(args[0]) if len(args) == 1 else self._error("exp() takes 1 argument"),
            'floor': lambda args: math.floor(args[0]) if len(args) == 1 else self._error("floor() takes 1 argument"),
            'ceil': lambda args: math.ceil(args[0]) if len(args) == 1 else self._error("ceil() takes 1 argument"),
            'random': lambda args: random.random() if len(args) == 0 else random.randint(0, int(args[0])-1) if len(args) == 1 else random.randint(int(args[0]), int(args[1])) if len(args) == 2 else self._error("random() takes 0, 1 or 2 arguments"),
            'choice': lambda args: random.choice(args[0]) if len(args) == 1 else self._error("choice() takes 1 argument"),
            'shuffle': lambda args: self.builtin_shuffle(args),
            'time': lambda args: time.time() if len(args) == 0 else self._error("time() takes 0 arguments"),
            'sleep': lambda args: time.sleep(args[0]) if len(args) == 1 else self._error("sleep() takes 1 argument"),
            'range': lambda args: list(range(int(args[0]))) if len(args) == 1 else list(range(int(args[0]), int(args[1]))) if len(args) == 2 else list(range(int(args[0]), int(args[1]), int(args[2]))) if len(args) == 3 else self._error("range() takes 1, 2 or 3 arguments"),
            'print': lambda args: print(" ".join(self.to_string(a) for a in args)),
            'input': lambda args: input(self.to_string(args[0])) if len(args) == 1 else input() if len(args) == 0 else self._error("input() takes 0 or 1 argument"),
            'print_json': lambda args: print(json.dumps(args[0], indent=2, default=str)) if len(args) == 1 else self._error("print_json() takes 1 argument"),
            'parse_json': lambda args: json.loads(args[0]) if len(args) == 1 else self._error("parse_json() takes 1 argument"),
            'to_json': lambda args: json.dumps(args[0], default=str) if len(args) == 1 else self._error("to_json() takes 1 argument"),
            'keys': lambda args: list(args[0].keys()) if len(args) == 1 and isinstance(args[0], dict) else self._error("keys() takes 1 dict argument"),
            'values': lambda args: list(args[0].values()) if len(args) == 1 and isinstance(args[0], dict) else self._error("values() takes 1 dict argument"),
            'items': lambda args: list(args[0].items()) if len(args) == 1 and isinstance(args[0], dict) else self._error("items() takes 1 dict argument"),
            'append': lambda args: self.builtin_append(args),
            'pop': lambda args: args[0].pop(int(args[1])) if len(args) == 2 else args[0].pop() if len(args) == 1 else self._error("pop() takes 1 or 2 arguments"),
            'insert': lambda args: self.builtin_insert(args),
            'remove': lambda args: self.builtin_remove(args),
            'index': lambda args: args[0].index(args[1]) if len(args) == 2 else self._error("index() takes 2 arguments"),
            'count': lambda args: args[0].count(args[1]) if len(args) == 2 else self._error("count() takes 2 arguments"),
            'extend': lambda args: self.builtin_extend(args),
            'clear': lambda args: args[0].clear() or args[0] if len(args) == 1 else self._error("clear() takes 1 argument"),
            'copy': lambda args: args[0].copy() if len(args) == 1 else self._error("copy() takes 1 argument"),
            'upper': lambda args: str(args[0]).upper() if len(args) == 1 else self._error("upper() takes 1 argument"),
            'lower': lambda args: str(args[0]).lower() if len(args) == 1 else self._error("lower() takes 1 argument"),
            'strip': lambda args: str(args[0]).strip() if len(args) == 1 else str(args[0]).strip(str(args[1])) if len(args) == 2 else self._error("strip() takes 1 or 2 arguments"),
            'split': lambda args: str(args[0]).split() if len(args) == 1 else str(args[0]).split(str(args[1])) if len(args) == 2 else self._error("split() takes 1 or 2 arguments"),
            'join': lambda args: str(args[0]).join(str(x) for x in args[1]) if len(args) == 2 else self._error("join() takes 2 arguments"),
            'replace': lambda args: str(args[0]).replace(str(args[1]), str(args[2])) if len(args) == 3 else self._error("replace() takes 3 arguments"),
            'find': lambda args: str(args[0]).find(str(args[1])) if len(args) == 2 else self._error("find() takes 2 arguments"),
            'startswith': lambda args: str(args[0]).startswith(str(args[1])) if len(args) == 2 else self._error("startswith() takes 2 arguments"),
            'endswith': lambda args: str(args[0]).endswith(str(args[1])) if len(args) == 2 else self._error("endswith() takes 2 arguments"),
            'contains': lambda args: args[1] in args[0] if len(args) == 2 else self._error("contains() takes 2 arguments"),
            'capitalize': lambda args: str(args[0]).capitalize() if len(args) == 1 else self._error("capitalize() takes 1 argument"),
            'title': lambda args: str(args[0]).title() if len(args) == 1 else self._error("title() takes 1 argument"),
            'isdigit': lambda args: str(args[0]).isdigit() if len(args) == 1 else self._error("isdigit() takes 1 argument"),
            'isalpha': lambda args: str(args[0]).isalpha() if len(args) == 1 else self._error("isalpha() takes 1 argument"),
            'isalnum': lambda args: str(args[0]).isalnum() if len(args) == 1 else self._error("isalnum() takes 1 argument"),
            'format': lambda args: str(args[0]).format(*args[1:]) if len(args) >= 1 else self._error("format() takes at least 1 argument"),
            'substring': lambda args: str(args[0])[int(args[1]):int(args[2])] if len(args) == 3 else str(args[0])[int(args[1]):] if len(args) == 2 else self._error("substring() takes 2 or 3 arguments"),
            'reverse': lambda args: args[0][::-1] if len(args) == 1 else self._error("reverse() takes 1 argument"),
            'sort': lambda args: sorted(args[0]) if len(args) == 1 else self._error("sort() takes 1 argument"),
            'unique': lambda args: list(dict.fromkeys(args[0])) if len(args) == 1 else self._error("unique() takes 1 argument"),
            'flatten': lambda args: self.builtin_flatten(args[0]) if len(args) == 1 else self._error("flatten() takes 1 argument"),
            'exit': lambda args: sys.exit(int(args[0])) if len(args) == 1 else sys.exit(0),
            'assert': lambda args: None if self.is_truthy(args[0]) else self._error(str(args[1]) if len(args) > 1 else "Assertion failed"),
        }
        
        self.global_env.define('PI', math.pi, is_const=True)
        self.global_env.define('E', math.e, is_const=True)
        self.global_env.define('TAU', math.tau, is_const=True)
        self.global_env.define('INF', float('inf'), is_const=True)
        self.global_env.define('NAN', float('nan'), is_const=True)
        self.global_env.define('VERSION', "5.0.0", is_const=True)
    
    def _error(self, msg: str):
        raise STRACTRuntimeError(msg)
    
    def builtin_reduce(self, args):
        if len(args) < 2:
            raise STRACTRuntimeError("reduce() takes at least 2 arguments")
        func = args[0]
        iterable = args[1]
        if len(args) == 3:
            result = args[2]
            for item in iterable:
                result = self.call_function(func, [result, item])
            return result
        else:
            it = iter(iterable)
            try:
                result = next(it)
            except StopIteration:
                raise STRACTRuntimeError("reduce() of empty sequence with no initial value")
            for item in it:
                result = self.call_function(func, [result, item])
            return result
    
    def builtin_shuffle(self, args):
        if len(args) != 1:
            raise STRACTRuntimeError("shuffle() takes 1 argument")
        lst = list(args[0])
        random.shuffle(lst)
        return lst
    
    def builtin_append(self, args):
        if len(args) != 2:
            raise STRACTRuntimeError("append() takes 2 arguments")
        args[0].append(args[1])
        return args[0]
    
    def builtin_insert(self, args):
        if len(args) != 3:
            raise STRACTRuntimeError("insert() takes 3 arguments")
        args[0].insert(int(args[1]), args[2])
        return args[0]
    
    def builtin_remove(self, args):
        if len(args) != 2:
            raise STRACTRuntimeError("remove() takes 2 arguments")
        args[0].remove(args[1])
        return args[0]
    
    def builtin_extend(self, args):
        if len(args) != 2:
            raise STRACTRuntimeError("extend() takes 2 arguments")
        args[0].extend(args[1])
        return args[0]
    
    def builtin_flatten(self, lst):
        result = []
        for item in lst:
            if isinstance(item, list):
                result.extend(self.builtin_flatten(item))
            else:
                result.append(item)
        return result
    
    def call_function(self, func, args):
        if isinstance(func, LambdaNode):
            return self.execute_lambda_call(func, args)
        elif isinstance(func, STRACTFunction):
            return self.execute_user_function(func.node, args, func.closure)
        elif callable(func):
            return func(args)
        else:
            raise STRACTRuntimeError(f"Cannot call {type(func).__name__}")
    
    def execute_lambda_call(self, node: LambdaNode, args: List[Any]) -> Any:
        if len(args) != len(node.params):
            raise STRACTRuntimeError(f"Lambda expects {len(node.params)} arguments, got {len(args)}")
        
        lambda_env = Environment(self.global_env)
        for param, arg in zip(node.params, args):
            lambda_env.define(param, arg)
        
        if node.body is not None:
            return self.execute(node.body, lambda_env)
        return None
    
    def execute_user_function(self, func: FunctionDefNode, args: List[Any], closure: Optional[Environment] = None) -> Any:
        func_env = Environment(closure or self.global_env)
        
        for i, param in enumerate(func.params):
            if i < len(args):
                func_env.define(param, args[i])
            elif i - (len(func.params) - len(func.defaults)) >= 0:
                default_idx = i - (len(func.params) - len(func.defaults))
                func_env.define(param, self.execute(func.defaults[default_idx], func_env))
            else:
                raise STRACTRuntimeError(f"Missing argument for parameter '{param}'")
        
        try:
            for stmt in func.body:
                self.execute(stmt, func_env)
        except ReturnException as ret:
            return ret.value
        
        return None
    
    def get_type(self, value: Any) -> str:
        if isinstance(value, bool):
            return "boolean"
        elif isinstance(value, int):
            return "integer"
        elif isinstance(value, float):
            return "float"
        elif isinstance(value, str):
            return "string"
        elif isinstance(value, list):
            return "list"
        elif isinstance(value, dict):
            return "dict"
        elif isinstance(value, tuple):
            return "tuple"
        elif isinstance(value, set):
            return "set"
        elif isinstance(value, STRACTInstance):
            return f"instance<{value.klass.name}>"
        elif isinstance(value, STRACTClass):
            return f"class<{value.name}>"
        elif isinstance(value, STRACTTensor):
            return "tensor"
        elif isinstance(value, STRACTStream):
            return "stream"
        elif isinstance(value, STRACTModel):
            return "model"
        elif isinstance(value, (STRACTFunction, LambdaNode)):
            return "function"
        elif value is None:
            return "null"
        return "unknown"
    
    def to_string(self, value: Any) -> str:
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, list):
            return "[" + ", ".join(self.to_string(x) for x in value) + "]"
        if isinstance(value, dict):
            pairs = [f"{self.to_string(k)}: {self.to_string(v)}" for k, v in value.items()]
            return "{" + ", ".join(pairs) + "}"
        if isinstance(value, STRACTInstance):
            return f"<{value.klass.name} instance>"
        if isinstance(value, STRACTFunction):
            return f"<function {value.name}>"
        if isinstance(value, LambdaNode):
            return "<lambda>"
        if isinstance(value, STRACTTensor):
            return str(value)
        if isinstance(value, STRACTStream):
            return str(value)
        if isinstance(value, STRACTModel):
            return str(value)
        return str(value)
    
    def is_truthy(self, value: Any) -> bool:
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, (str, list, dict, tuple, set)):
            return len(value) > 0
        return True
    
    def execute(self, node: Optional[ASTNode], env: Optional[Environment] = None) -> Any:
        if node is None:
            return None
        if env is None:
            env = self.global_env
        
        method_name = f"execute_{type(node).__name__}"
        executor = getattr(self, method_name, None)
        
        if executor is None:
            raise STRACTRuntimeError(f"Unknown node type: {type(node).__name__}", getattr(node, 'line', 0), getattr(node, 'column', 0))
        
        try:
            return executor(node, env)
        except (STRACTRuntimeError, ReturnException, BreakException, ContinueException, ThrowException):
            raise
        except Exception as e:
            raise STRACTRuntimeError(str(e), getattr(node, 'line', 0), getattr(node, 'column', 0))
    
    def execute_ProgramNode(self, node: ProgramNode, env: Environment) -> Any:
        result = None
        for stmt in node.statements:
            result = self.execute(stmt, env)
        return result
    
    def execute_NumberNode(self, node: NumberNode, env: Environment) -> Union[int, float]:
        return node.value
    
    def execute_StringNode(self, node: StringNode, env: Environment) -> str:
        return node.value
    
    def execute_BooleanNode(self, node: BooleanNode, env: Environment) -> bool:
        return node.value
    
    def execute_NullNode(self, node: NullNode, env: Environment) -> None:
        return None
    
    def execute_IdentifierNode(self, node: IdentifierNode, env: Environment) -> Any:
        try:
            return env.get(node.name)
        except STRACTRuntimeError as e:
            raise STRACTRuntimeError(e.message, node.line, node.column)
    
    def execute_ListNode(self, node: ListNode, env: Environment) -> list:
        return [self.execute(elem, env) for elem in node.elements]
    
    def execute_DictNode(self, node: DictNode, env: Environment) -> dict:
        result = {}
        for key, value in node.pairs:
            k = self.execute(key, env)
            v = self.execute(value, env)
            result[k] = v
        return result
    
    def execute_IndexNode(self, node: IndexNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        index = self.execute(node.index, env)
        
        if isinstance(obj, dict):
            if index in obj:
                return obj[index]
            raise STRACTRuntimeError(f"Key not found: {index}", node.line, node.column)
        
        if isinstance(obj, (list, str, tuple)):
            try:
                return obj[int(index)]
            except IndexError:
                raise STRACTRuntimeError(f"Index {index} out of range", node.line, node.column)
        
        raise STRACTRuntimeError("Cannot index this type", node.line, node.column)
    
    def execute_SliceNode(self, node: SliceNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        start = self.execute(node.start, env) if node.start else None
        end = self.execute(node.end, env) if node.end else None
        step = self.execute(node.step, env) if node.step else None
        
        if isinstance(obj, (list, str, tuple)):
            if start is not None:
                start = int(start)
            if end is not None:
                end = int(end)
            if step is not None:
                step = int(step)
            return obj[start:end:step]
        
        raise STRACTRuntimeError("Cannot slice this type", node.line, node.column)
    
    def execute_BinaryOpNode(self, node: BinaryOpNode, env: Environment) -> Any:
        left = self.execute(node.left, env)
        
        if node.operator == 'and':
            if not self.is_truthy(left):
                return left
            return self.execute(node.right, env)
        
        if node.operator == 'or':
            if self.is_truthy(left):
                return left
            return self.execute(node.right, env)
        
        right = self.execute(node.right, env)
        
        if node.operator == '+':
            if isinstance(left, str) or isinstance(right, str):
                return self.to_string(left) + self.to_string(right)
            if isinstance(left, list) and isinstance(right, list):
                return left + right
            if isinstance(left, dict) and isinstance(right, dict):
                return {**left, **right}
            return left + right
        elif node.operator == '-':
            return left - right
        elif node.operator == '*':
            if isinstance(left, str) and isinstance(right, int):
                return left * right
            if isinstance(left, list) and isinstance(right, int):
                return left * right
            return left * right
        elif node.operator == '/':
            if right == 0:
                raise STRACTRuntimeError("Division by zero", node.line, node.column)
            return left / right
        elif node.operator == '//':
            if right == 0:
                raise STRACTRuntimeError("Division by zero", node.line, node.column)
            return left // right
        elif node.operator == '%':
            if right == 0:
                raise STRACTRuntimeError("Modulo by zero", node.line, node.column)
            return left % right
        elif node.operator == '**':
            return left ** right
        elif node.operator == '==':
            return left == right
        elif node.operator == '!=':
            return left != right
        elif node.operator == '<':
            return left < right
        elif node.operator == '>':
            return left > right
        elif node.operator == '<=':
            return left <= right
        elif node.operator == '>=':
            return left >= right
        elif node.operator == 'in':
            return left in right
        
        raise STRACTRuntimeError(f"Unknown operator: {node.operator}", node.line, node.column)
    
    def execute_UnaryOpNode(self, node: UnaryOpNode, env: Environment) -> Any:
        operand = self.execute(node.operand, env)
        
        if node.operator == '-':
            return -operand
        elif node.operator == '+':
            return +operand
        elif node.operator == 'not':
            return not self.is_truthy(operand)
        
        raise STRACTRuntimeError(f"Unknown unary operator: {node.operator}", node.line, node.column)
    
    def execute_AssignNode(self, node: AssignNode, env: Environment) -> Any:
        value = self.execute(node.value, env)
        
        if env.exists(node.name):
            env.set(node.name, value)
        else:
            env.define(node.name, value, node.is_const)
        
        return value
    
    def execute_CompoundAssignNode(self, node: CompoundAssignNode, env: Environment) -> Any:
        current = env.get(node.name)
        value = self.execute(node.value, env)
        
        if node.operator == '+=':
            if isinstance(current, str):
                new_value = current + self.to_string(value)
            elif isinstance(current, list):
                new_value = current + [value]
            else:
                new_value = current + value
        elif node.operator == '-=':
            new_value = current - value
        elif node.operator == '*=':
            new_value = current * value
        elif node.operator == '/=':
            new_value = current / value
        else:
            raise STRACTRuntimeError(f"Unknown compound operator: {node.operator}", node.line, node.column)
        
        env.set(node.name, new_value)
        return new_value
    
    def execute_IndexAssignNode(self, node: IndexAssignNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        index = self.execute(node.index, env)
        value = self.execute(node.value, env)
        
        if isinstance(obj, list):
            try:
                obj[int(index)] = value
                return value
            except IndexError:
                raise STRACTRuntimeError(f"Index {index} out of range", node.line, node.column)
        elif isinstance(obj, dict):
            obj[index] = value
            return value
        
        raise STRACTRuntimeError("Cannot index assign to this type", node.line, node.column)
    
    def execute_PrintNode(self, node: PrintNode, env: Environment) -> None:
        values = [self.to_string(self.execute(expr, env)) for expr in node.expressions]
        print(" ".join(values))
    
    def execute_InputNode(self, node: InputNode, env: Environment) -> str:
        prompt = ""
        if node.prompt:
            prompt = self.to_string(self.execute(node.prompt, env))
        return input(prompt)
    
    def execute_IfNode(self, node: IfNode, env: Environment) -> Any:
        condition = self.execute(node.condition, env)
        
        if self.is_truthy(condition):
            result = None
            for stmt in node.then_block:
                result = self.execute(stmt, env)
            return result
        
        for elif_condition, elif_body in node.elif_blocks:
            if self.is_truthy(self.execute(elif_condition, env)):
                result = None
                for stmt in elif_body:
                    result = self.execute(stmt, env)
                return result
        
        if node.else_block:
            result = None
            for stmt in node.else_block:
                result = self.execute(stmt, env)
            return result
        
        return None
    
    def execute_WhileNode(self, node: WhileNode, env: Environment) -> Any:
        result = None
        while self.is_truthy(self.execute(node.condition, env)):
            try:
                for stmt in node.body:
                    result = self.execute(stmt, env)
            except BreakException:
                break
            except ContinueException:
                continue
        return result
    
    def execute_ForNode(self, node: ForNode, env: Environment) -> Any:
        iterable = self.execute(node.iterable, env)
        result = None
        
        if isinstance(iterable, range):
            iterable = list(iterable)
        
        if not isinstance(iterable, (list, str, tuple, dict, set)):
            raise STRACTRuntimeError("For loop requires an iterable", node.line, node.column)
        
        for item in iterable:
            env.define(node.variable, item)
            try:
                for stmt in node.body:
                    result = self.execute(stmt, env)
            except BreakException:
                break
            except ContinueException:
                continue
        
        return result
    
    def execute_RangeNode(self, node: RangeNode, env: Environment) -> range:
        start = int(self.execute(node.start, env))
        end = int(self.execute(node.end, env))
        
        if node.step:
            step = int(self.execute(node.step, env))
            return range(start, end, step)
        
        return range(start, end)
    
    def execute_FunctionDefNode(self, node: FunctionDefNode, env: Environment) -> None:
        self.functions[node.name] = node
        func = STRACTFunction(node, env)
        env.define(node.name, func)
    
    def execute_LambdaNode(self, node: LambdaNode, env: Environment) -> LambdaNode:
        return node
    
    def execute_FunctionCallNode(self, node: FunctionCallNode, env: Environment) -> Any:
        if node.name in self.builtins:
            args = [self.execute(arg, env) for arg in node.args]
            return self.builtins[node.name](args)
        
        if node.name in self.classes:
            return self.instantiate_class(node.name, [self.execute(arg, env) for arg in node.args], env)
        
        try:
            func = env.get(node.name)
            if isinstance(func, STRACTFunction):
                args = [self.execute(arg, env) for arg in node.args]
                return self.execute_user_function(func.node, args, func.closure)
            elif isinstance(func, LambdaNode):
                args = [self.execute(arg, env) for arg in node.args]
                return self.execute_lambda_call(func, args)
            elif callable(func):
                args = [self.execute(arg, env) for arg in node.args]
                return func(args)
        except STRACTRuntimeError:
            pass
        
        if node.name in self.functions:
            func = self.functions[node.name]
            args = [self.execute(arg, env) for arg in node.args]
            return self.execute_user_function(func, args, self.global_env)
        
        raise STRACTRuntimeError(f"Undefined function: '{node.name}'", node.line, node.column)
    
    def execute_MethodCallNode(self, node: MethodCallNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        args = [self.execute(arg, env) for arg in node.args]
        
        if isinstance(obj, STRACTInstance):
            method = obj.klass.methods.get(node.method)
            if method:
                method_env = Environment(self.global_env)
                method_env.define('this', obj)
                return self.execute_user_function(method, args, method_env)
            raise STRACTRuntimeError(f"Method '{node.method}' not found", node.line, node.column)
        
        if isinstance(obj, str):
            string_methods = {
                'upper': lambda: obj.upper(),
                'lower': lambda: obj.lower(),
                'strip': lambda: obj.strip() if not args else obj.strip(args[0]),
                'split': lambda: obj.split() if not args else obj.split(args[0]),
                'replace': lambda: obj.replace(args[0], args[1]) if len(args) >= 2 else self._error("replace() needs 2 args"),
                'find': lambda: obj.find(args[0]) if args else self._error("find() needs 1 arg"),
                'startswith': lambda: obj.startswith(args[0]) if args else self._error("startswith() needs 1 arg"),
                'endswith': lambda: obj.endswith(args[0]) if args else self._error("endswith() needs 1 arg"),
                'capitalize': lambda: obj.capitalize(),
                'title': lambda: obj.title(),
                'isdigit': lambda: obj.isdigit(),
                'isalpha': lambda: obj.isalpha(),
                'isalnum': lambda: obj.isalnum(),
                'len': lambda: len(obj),
                'length': lambda: len(obj),
                'reverse': lambda: obj[::-1],
                'contains': lambda: args[0] in obj if args else self._error("contains() needs 1 arg"),
                'count': lambda: obj.count(args[0]) if args else self._error("count() needs 1 arg"),
                'index': lambda: obj.index(args[0]) if args else self._error("index() needs 1 arg"),
                'format': lambda: obj.format(*args),
                'join': lambda: obj.join(str(x) for x in args[0]) if args else self._error("join() needs 1 arg"),
                'lstrip': lambda: obj.lstrip() if not args else obj.lstrip(args[0]),
                'rstrip': lambda: obj.rstrip() if not args else obj.rstrip(args[0]),
                'center': lambda: obj.center(int(args[0])) if args else self._error("center() needs 1 arg"),
                'zfill': lambda: obj.zfill(int(args[0])) if args else self._error("zfill() needs 1 arg"),
            }
            if node.method in string_methods:
                return string_methods[node.method]()
        
        elif isinstance(obj, list):
            list_methods = {
                'append': lambda: (obj.append(args[0]), obj)[1] if args else self._error("append() needs 1 arg"),
                'pop': lambda: obj.pop(int(args[0])) if args else obj.pop(),
                'insert': lambda: (obj.insert(int(args[0]), args[1]), obj)[1] if len(args) >= 2 else self._error("insert() needs 2 args"),
                'remove': lambda: (obj.remove(args[0]), obj)[1] if args else self._error("remove() needs 1 arg"),
                'extend': lambda: (obj.extend(args[0]), obj)[1] if args else self._error("extend() needs 1 arg"),
                'clear': lambda: (obj.clear(), obj)[1],
                'copy': lambda: obj.copy(),
                'index': lambda: obj.index(args[0]) if args else self._error("index() needs 1 arg"),
                'count': lambda: obj.count(args[0]) if args else self._error("count() needs 1 arg"),
                'sort': lambda: sorted(obj),
                'reverse': lambda: obj[::-1],
                'len': lambda: len(obj),
                'length': lambda: len(obj),
                'first': lambda: obj[0] if obj else None,
                'last': lambda: obj[-1] if obj else None,
                'sum': lambda: sum(obj),
                'min': lambda: min(obj),
                'max': lambda: max(obj),
                'avg': lambda: sum(obj) / len(obj) if obj else 0,
                'contains': lambda: args[0] in obj if args else self._error("contains() needs 1 arg"),
                'join': lambda: str(args[0]).join(str(x) for x in obj) if args else self._error("join() needs 1 arg"),
                'map': lambda: [self.call_function(args[0], [x]) for x in obj] if args else self._error("map() needs 1 arg"),
                'filter': lambda: [x for x in obj if self.is_truthy(self.call_function(args[0], [x]))] if args else self._error("filter() needs 1 arg"),
                'reduce': lambda: self.builtin_reduce([args[0], obj] + list(args[1:])) if args else self._error("reduce() needs at least 1 arg"),
                'slice': lambda: obj[int(args[0]):int(args[1])] if len(args) >= 2 else obj[int(args[0]):] if args else obj[:],
                'take': lambda: obj[:int(args[0])] if args else self._error("take() needs 1 arg"),
                'drop': lambda: obj[int(args[0]):] if args else self._error("drop() needs 1 arg"),
                'unique': lambda: list(dict.fromkeys(obj)),
                'flatten': lambda: self.builtin_flatten(obj),
                'zip': lambda: list(zip(obj, *args)) if args else self._error("zip() needs at least 1 arg"),
            }
            if node.method in list_methods:
                return list_methods[node.method]()
        
        elif isinstance(obj, dict):
            dict_methods = {
                'keys': lambda: list(obj.keys()),
                'values': lambda: list(obj.values()),
                'items': lambda: list(obj.items()),
                'get': lambda: obj.get(args[0], args[1] if len(args) > 1 else None) if args else self._error("get() needs 1 arg"),
                'pop': lambda: obj.pop(args[0], args[1] if len(args) > 1 else None) if args else self._error("pop() needs 1 arg"),
                'update': lambda: (obj.update(args[0]), obj)[1] if args else self._error("update() needs 1 arg"),
                'clear': lambda: (obj.clear(), obj)[1],
                'copy': lambda: obj.copy(),
                'len': lambda: len(obj),
                'length': lambda: len(obj),
                'contains': lambda: args[0] in obj if args else self._error("contains() needs 1 arg"),
                'has': lambda: args[0] in obj if args else self._error("has() needs 1 arg"),
            }
            if node.method in dict_methods:
                return dict_methods[node.method]()
        
        raise STRACTRuntimeError(f"Unknown method '{node.method}' for type {self.get_type(obj)}", node.line, node.column)
    
    def execute_PropertyAccessNode(self, node: PropertyAccessNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        
        if isinstance(obj, STRACTInstance):
            return obj.get(node.property)
        
        if isinstance(obj, dict):
            if node.property in obj:
                return obj[node.property]
            raise STRACTRuntimeError(f"Key '{node.property}' not found", node.line, node.column)
        
        if node.property == 'length' or node.property == 'len':
            if isinstance(obj, (str, list, dict, tuple, set)):
                return len(obj)
        
        raise STRACTRuntimeError(f"Cannot access property '{node.property}' on {self.get_type(obj)}", node.line, node.column)
    
    def execute_PropertyAssignNode(self, node: PropertyAssignNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        value = self.execute(node.value, env)
        
        if isinstance(obj, STRACTInstance):
            obj.set(node.property, value)
            return value
        
        if isinstance(obj, dict):
            obj[node.property] = value
            return value
        
        raise STRACTRuntimeError(f"Cannot assign property '{node.property}' on {self.get_type(obj)}", node.line, node.column)
    
    def execute_ReturnNode(self, node: ReturnNode, env: Environment) -> None:
        value = None
        if node.value:
            value = self.execute(node.value, env)
        raise ReturnException(value)
    
    def execute_BreakNode(self, node: BreakNode, env: Environment) -> None:
        raise BreakException()
    
    def execute_ContinueNode(self, node: ContinueNode, env: Environment) -> None:
        raise ContinueException()
    
    def execute_TryNode(self, node: TryNode, env: Environment) -> Any:
        try:
            result = None
            for stmt in node.try_block:
                result = self.execute(stmt, env)
            return result
        except ThrowException as e:
            catch_env = Environment(env)
            if node.catch_var:
                catch_env.define(node.catch_var, e.value)
            result = None
            for stmt in node.catch_block:
                result = self.execute(stmt, catch_env)
            return result
        except STRACTRuntimeError as e:
            catch_env = Environment(env)
            if node.catch_var:
                catch_env.define(node.catch_var, e.message)
            result = None
            for stmt in node.catch_block:
                result = self.execute(stmt, catch_env)
            return result
        finally:
            for stmt in node.finally_block:
                self.execute(stmt, env)
    
    def execute_ThrowNode(self, node: ThrowNode, env: Environment) -> None:
        value = self.execute(node.value, env)
        raise ThrowException(value, node.line)
    
    def execute_ClassDefNode(self, node: ClassDefNode, env: Environment) -> None:
        parent = None
        if node.parent and node.parent in self.classes:
            parent = self.classes[node.parent]
        
        methods = {}
        properties = {}
        
        for item in node.body:
            if isinstance(item, FunctionDefNode):
                methods[item.name] = item
            elif isinstance(item, AssignNode):
                properties[item.name] = self.execute(item.value, env)
        
        klass = STRACTClass(node.name, parent, methods, properties)
        self.classes[node.name] = klass
        env.define(node.name, klass)
    
    def execute_NewInstanceNode(self, node: NewInstanceNode, env: Environment) -> STRACTInstance:
        return self.instantiate_class(node.class_name, [self.execute(arg, env) for arg in node.args], env)
    
    def instantiate_class(self, class_name: str, args: List[Any], env: Environment) -> STRACTInstance:
        if class_name not in self.classes:
            raise STRACTRuntimeError(f"Undefined class: '{class_name}'")
        
        klass = self.classes[class_name]
        instance = STRACTInstance(klass)
        
        if 'init' in klass.methods:
            init_env = Environment(self.global_env)
            init_env.define('this', instance)
            self.execute_user_function(klass.methods['init'], args, init_env)
        
        return instance
    
    def execute_ImportNode(self, node: ImportNode, env: Environment) -> None:
        pass
    
    def execute_DecoratorNode(self, node: DecoratorNode, env: Environment) -> Any:
        if node.target is not None:
            result = self.execute(node.target, env)
            return result
        return None
    
    def execute_MatchNode(self, node: MatchNode, env: Environment) -> Any:
        value = self.execute(node.value, env)
        
        for case_value, case_body in node.cases:
            if self.execute(case_value, env) == value:
                result = None
                for stmt in case_body:
                    result = self.execute(stmt, env)
                return result
        
        if node.default:
            result = None
            for stmt in node.default:
                result = self.execute(stmt, env)
            return result
        
        return None
    
    def execute_RefinementTypeNode(self, node: RefinementTypeNode, env: Environment) -> STRACTRefinementType:
        constraint_fn = None
        if node.constraint:
            constraint_node = node.constraint
            constraint_fn = lambda value: self.is_truthy(
                self.execute(constraint_node, self._create_constraint_env(env, value))
            )
        
        refinement_type = STRACTRefinementType(
            name=node.name,
            base_type=node.base_type,
            constraint=constraint_fn
        )
        
        self.refinement_types[node.name] = refinement_type
        env.define(node.name, refinement_type)
        
        return refinement_type
    
    def _create_constraint_env(self, parent_env: Environment, value: Any) -> Environment:
        constraint_env = Environment(parent_env)
        constraint_env.define('value', value)
        return constraint_env
    
    def execute_TypeDefinitionNode(self, node: TypeDefinitionNode, env: Environment) -> STRACTRefinementType:
        constraint_fn = None
        if node.where_condition:
            constraint_node = node.where_condition
            constraint_fn = lambda value: self.is_truthy(
                self.execute(constraint_node, self._create_constraint_env(env, value))
            )
        
        refinement_type = STRACTRefinementType(
            name=node.name,
            base_type=node.base_type,
            constraint=constraint_fn
        )
        
        self.refinement_types[node.name] = refinement_type
        env.define(node.name, refinement_type)
        
        return refinement_type
    
    def execute_ContractNode(self, node: ContractNode, env: Environment) -> STRACTContract:
        requires_fns = []
        ensures_fns = []
        
        for req in node.requires:
            req_node = req
            requires_fns.append(lambda *args, req_n=req_node: self.is_truthy(self.execute(req_n, env)))
        
        for ens in node.ensures:
            ens_node = ens
            ensures_fns.append(lambda result, *args, ens_n=ens_node: self.is_truthy(
                self.execute(ens_n, self._create_result_env(env, result))
            ))
        
        return STRACTContract(requires=requires_fns, ensures=ensures_fns)
    
    def _create_result_env(self, parent_env: Environment, result: Any) -> Environment:
        result_env = Environment(parent_env)
        result_env.define('result', result)
        return result_env
    
    def execute_ContractedFunctionNode(self, node: ContractedFunctionNode, env: Environment) -> None:
        def contracted_function(*args):
            func_env = Environment(self.global_env)
            
            for i, param in enumerate(node.params):
                if i < len(args):
                    func_env.define(param, args[i])
                    
                    if param in node.param_types:
                        expected_type = node.param_types[param]
                        if not self._check_type(args[i], expected_type):
                            raise STRACTRuntimeError(
                                f"Type error: parameter '{param}' expected {expected_type}",
                                node.line, node.column
                            )
            
            for req in node.requires:
                if not self.is_truthy(self.execute(req, func_env)):
                    raise STRACTRuntimeError(
                        f"Contract violation: precondition failed in function '{node.name}'",
                        node.line, node.column
                    )
            
            result = None
            try:
                for stmt in node.body:
                    result = self.execute(stmt, func_env)
            except ReturnException as e:
                result = e.value
            
            result_env = Environment(func_env)
            result_env.define('result', result)
            for ens in node.ensures:
                if not self.is_truthy(self.execute(ens, result_env)):
                    raise STRACTRuntimeError(
                        f"Contract violation: postcondition failed in function '{node.name}'",
                        node.line, node.column
                    )
            
            return result
        
        self.functions[node.name] = node
        env.define(node.name, contracted_function)
    
    def _check_type(self, value: Any, type_name: str) -> bool:
        type_map = {
            'Int': (int,),
            'Float': (int, float),
            'String': (str,),
            'Bool': (bool,),
            'List': (list,),
            'Dict': (dict,),
            'Any': (object,),
        }
        expected_types = type_map.get(type_name, (object,))
        return isinstance(value, expected_types)
    
    def execute_RequiresNode(self, node: RequiresNode, env: Environment) -> bool:
        return self.is_truthy(self.execute(node.condition, env))
    
    def execute_EnsuresNode(self, node: EnsuresNode, env: Environment) -> bool:
        return self.is_truthy(self.execute(node.condition, env))
    
    def execute_SandboxNode(self, node: SandboxNode, env: Environment) -> Any:
        sandbox_env = Environment(None)
        
        allowed_capabilities = set(node.capabilities)
        
        safe_builtins = {}
        if 'io' in allowed_capabilities:
            safe_builtins['print'] = self.builtins.get('print', lambda args: print(" ".join(str(a) for a in args)))
            safe_builtins['input'] = self.builtins.get('input')
        if 'math' in allowed_capabilities:
            for name in ['abs', 'min', 'max', 'sum', 'round', 'sqrt', 'sin', 'cos', 'pow', 'log']:
                if name in self.builtins:
                    safe_builtins[name] = self.builtins[name]
        if 'list' in allowed_capabilities:
            for name in ['len', 'sorted', 'reversed', 'list', 'range']:
                if name in self.builtins:
                    safe_builtins[name] = self.builtins[name]
        if 'string' in allowed_capabilities:
            for name in ['str', 'chr', 'ord']:
                if name in self.builtins:
                    safe_builtins[name] = self.builtins[name]
        
        for name, func in safe_builtins.items():
            sandbox_env.define(name, func)
        
        result = None
        try:
            for stmt in node.body:
                result = self.execute(stmt, sandbox_env)
        except Exception as e:
            raise STRACTRuntimeError(f"Sandbox execution error: {e}", node.line, node.column)
        
        return result
    
    def execute_InvariantNode(self, node: InvariantNode, env: Environment) -> Callable:
        invariant_condition = node.condition
        
        def check_invariant(instance: STRACTInstance) -> bool:
            inv_env = Environment(self.global_env)
            inv_env.define('this', instance)
            return self.is_truthy(self.execute(invariant_condition, inv_env))
        
        self.invariants.append(check_invariant)
        
        return check_invariant
    
    def execute_TensorNode(self, node: TensorNode, env: Environment) -> STRACTTensor:
        shape = [self.execute(dim, env) for dim in node.shape]
        
        value_data = None
        if node.initial_value:
            value_data = self.execute(node.initial_value, env)
            if isinstance(value_data, list):
                pass
            else:
                value_data = [value_data]
        
        tensor = STRACTTensor(
            data=value_data,
            shape=shape,
            dtype=node.dtype,
            device=node.device,
            requires_grad=node.requires_grad
        )
        
        if node.name:
            env.define(node.name, tensor)
        
        return tensor
    
    def execute_ModelNode(self, node: ModelNode, env: Environment) -> STRACTModel:
        layers = []
        for layer_node in node.layers:
            layer = self.execute(layer_node, env)
            layers.append(layer)
        
        model = STRACTModel(
            name=node.name,
            layers=layers,
            optimizer=node.optimizer,
            loss=node.loss
        )
        
        self.models[node.name] = model
        env.define(node.name, model)
        
        return model
    
    def execute_OptimizeDirectiveNode(self, node: OptimizeDirectiveNode, env: Environment) -> Any:
        target = self.execute(node.target, env) if node.target else None
        data = self.execute(node.data, env) if node.data else None
        
        optimization_result = {
            'target': target,
            'goal': node.goal,
            'data': data,
            'config': node.config,
            'status': 'optimized',
            'improvements': {
                'accuracy': 0.0,
                'speed': 0.0,
                'memory': 0.0
            }
        }
        
        if node.goal == 'accuracy':
            optimization_result['improvements']['accuracy'] = 0.05
        elif node.goal == 'speed':
            optimization_result['improvements']['speed'] = 0.20
        elif node.goal == 'memory':
            optimization_result['improvements']['memory'] = 0.15
        
        return optimization_result
    
    def execute_GradientNode(self, node: GradientNode, env: Environment) -> Dict[str, Any]:
        expression = self.execute(node.expression, env)
        
        gradients = {}
        for var_name in node.with_respect_to:
            var_value = env.get(var_name)
            
            if isinstance(var_value, STRACTTensor):
                grad_tensor = STRACTTensor(
                    data=[1.0] * len(var_value.data),
                    shape=var_value.shape[:],
                    dtype=var_value.dtype
                )
                gradients[var_name] = grad_tensor
            elif isinstance(var_value, (int, float)):
                gradients[var_name] = 1.0
            else:
                gradients[var_name] = None
        
        return gradients
    
    def execute_TrainNode(self, node: TrainNode, env: Environment) -> Dict[str, Any]:
        model = self.execute(node.model, env) if node.model else None
        data = self.execute(node.data, env) if node.data else None
        
        if model is None:
            raise STRACTRuntimeError("Train requires a model", node.line, node.column)
        
        training_result = {
            'model': model.name if isinstance(model, STRACTModel) else str(model),
            'epochs': node.epochs,
            'config': node.config,
            'status': 'completed',
            'metrics': {
                'loss': 0.01,
                'accuracy': 0.95
            }
        }
        
        if isinstance(model, STRACTModel):
            model.trained = True
        
        return training_result
    
    def execute_PredictNode(self, node: PredictNode, env: Environment) -> Any:
        model = self.execute(node.model, env) if node.model else None
        input_data = self.execute(node.input_data, env) if node.input_data else None
        
        if model is None:
            raise STRACTRuntimeError("Predict requires a model", node.line, node.column)
        
        if isinstance(model, STRACTModel):
            return model.predict(input_data)
        elif callable(model):
            return model(input_data)
        else:
            return input_data
    
    def execute_HardwareNode(self, node: HardwareNode, env: Environment) -> Any:
        device = node.device
        
        hardware_env = Environment(env)
        hardware_env.define('__device__', device)
        
        result = None
        for stmt in node.body:
            result = self.execute(stmt, hardware_env)
            
            if isinstance(result, STRACTTensor):
                result.device = device
        
        return result
    
    def execute_ReactiveStreamNode(self, node: ReactiveStreamNode, env: Environment) -> STRACTStream:
        initial_value = None
        if node.source:
            initial_value = self.execute(node.source, env)
        
        stream = STRACTStream(name=node.name, initial_value=initial_value)
        
        for transform_node in node.transformations:
            transform = self.execute(transform_node, env)
            if callable(transform):
                stream.transformations.append(transform)
        
        self.streams[node.name] = stream
        env.define(node.name, stream)
        
        return stream
    
    def execute_TemporalVariableNode(self, node: TemporalVariableNode, env: Environment) -> Dict[str, Any]:
        initial_value = None
        if node.initial_value:
            initial_value = self.execute(node.initial_value, env)
        
        interval = None
        if node.interval:
            interval = self.execute(node.interval, env)
        
        temporal_var = {
            'name': node.name,
            'value': initial_value,
            'history': [initial_value],
            'interval': interval,
            'update_rule': node.update_rule,
            'created_at': time.time()
        }
        
        self.temporal_vars[node.name] = temporal_var
        env.define(node.name, temporal_var)
        
        return temporal_var
    
    def execute_WhenNode(self, node: WhenNode, env: Environment) -> Callable:
        condition = node.condition
        body = node.body
        
        def handler():
            if self.is_truthy(self.execute(condition, env)):
                result = None
                for stmt in body:
                    result = self.execute(stmt, env)
                return result
            return None
        
        self.reactive_handlers.append(handler)
        
        return handler
    
    def execute_ObserveNode(self, node: ObserveNode, env: Environment) -> Any:
        target = self.execute(node.target, env)
        handler = None
        if node.handler:
            handler = self.execute(node.handler, env)
        
        if isinstance(target, STRACTStream) and handler:
            target.subscribe(handler)
        elif isinstance(target, dict) and 'history' in target:
            if handler:
                target_name = target.get('name', str(id(target)))
                if target_name not in self.observers:
                    self.observers[target_name] = []
                self.observers[target_name].append(handler)
        
        return target
    
    def execute_EmitNode(self, node: EmitNode, env: Environment) -> Any:
        stream = self.execute(node.stream, env) if node.stream else None
        value = self.execute(node.value, env) if node.value else None
        
        if isinstance(stream, STRACTStream):
            stream.emit(value)
            return value
        elif isinstance(stream, dict) and 'history' in stream:
            stream['value'] = value
            stream['history'].append(value)
            
            stream_name = stream.get('name', '')
            if stream_name in self.observers:
                for observer in self.observers[stream_name]:
                    if callable(observer):
                        observer(value)
            return value
        else:
            raise STRACTRuntimeError("Cannot emit to non-stream target", node.line, node.column)
    
    def execute_EveryNode(self, node: EveryNode, env: Environment) -> Dict[str, Any]:
        interval = self.execute(node.interval, env) if node.interval else 1.0
        
        if isinstance(interval, str):
            if interval.endswith('s'):
                interval = float(interval[:-1])
            elif interval.endswith('ms'):
                interval = float(interval[:-2]) / 1000.0
            elif interval.endswith('m'):
                interval = float(interval[:-1]) * 60.0
        
        scheduled_task = {
            'type': 'every',
            'interval': interval,
            'body': node.body,
            'env': env,
            'active': True
        }
        
        self.scheduled_tasks.append(scheduled_task)
        
        return scheduled_task
    
    def execute_AfterNode(self, node: AfterNode, env: Environment) -> Dict[str, Any]:
        delay = self.execute(node.delay, env) if node.delay else 0.0
        
        if isinstance(delay, str):
            if delay.endswith('s'):
                delay = float(delay[:-1])
            elif delay.endswith('ms'):
                delay = float(delay[:-2]) / 1000.0
            elif delay.endswith('m'):
                delay = float(delay[:-1]) * 60.0
        
        delayed_task = {
            'type': 'after',
            'delay': delay,
            'body': node.body,
            'env': env,
            'scheduled_at': time.time(),
            'executed': False
        }
        
        self.delayed_tasks.append(delayed_task)
        
        return delayed_task
    
    def execute_PipeNode(self, node: PipeNode, env: Environment) -> Any:
        left_value = self.execute(node.left, env)
        
        right = node.right
        
        if isinstance(right, FunctionCallNode):
            func_name = right.name
            func = env.get(func_name) if env.exists(func_name) else self.builtins.get(func_name)
            
            if func is None and func_name in self.functions:
                func_node = self.functions[func_name]
                args = [left_value] + [self.execute(arg, env) for arg in right.args]
                return self.execute_user_function(func_node, args)
            
            if callable(func):
                args = [left_value] + [self.execute(arg, env) for arg in right.args]
                if func_name in self.builtins:
                    return func(args)
                return func(*args)
        elif isinstance(right, LambdaNode):
            return self.execute_lambda_call(right, [left_value])
        elif isinstance(right, IdentifierNode):
            func = env.get(right.name) if env.exists(right.name) else self.builtins.get(right.name)
            if callable(func):
                if right.name in self.builtins:
                    return func([left_value])
                return func(left_value)
            if right.name in self.functions:
                return self.execute_user_function(self.functions[right.name], [left_value])
        
        raise STRACTRuntimeError(f"Invalid pipe target", node.line, node.column)
    
    def execute_TypeAnnotationNode(self, node: TypeAnnotationNode, env: Environment) -> Dict[str, Any]:
        type_info = {
            'name': node.name,
            'type_name': node.type_name,
            'is_optional': node.is_optional,
            'generic_params': node.generic_params
        }
        return type_info
    
    def execute_TypedParameterNode(self, node: TypedParameterNode, env: Environment) -> Dict[str, Any]:
        type_annotation = None
        if node.type_annotation:
            type_annotation = self.execute(node.type_annotation, env)
        
        default_value = None
        if node.default_value:
            default_value = self.execute(node.default_value, env)
        
        param_info = {
            'name': node.name,
            'type_annotation': type_annotation,
            'default_value': default_value
        }
        return param_info
