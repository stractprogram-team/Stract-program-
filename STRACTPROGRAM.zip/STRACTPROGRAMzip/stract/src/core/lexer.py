"""
STRACT Lexer (Tokenizer) v5.0
Converts source code into a stream of tokens
"""

from typing import List
from .tokens import TokenType, Token


class LexerError(Exception):
    """Exception raised for lexer errors"""
    def __init__(self, message: str, line: int, column: int):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Lexer Error at line {line}, column {column}: {message}")


class Lexer:
    """Tokenizes STRACT source code"""
    
    KEYWORDS = {
        'let': TokenType.LET,
        'const': TokenType.CONST,
        'var': TokenType.VAR,
        'if': TokenType.IF,
        'elif': TokenType.ELIF,
        'else': TokenType.ELSE,
        'while': TokenType.WHILE,
        'for': TokenType.FOR,
        'in': TokenType.IN,
        'func': TokenType.FUNC,
        'return': TokenType.RETURN,
        'break': TokenType.BREAK,
        'continue': TokenType.CONTINUE,
        'print': TokenType.PRINT,
        'input': TokenType.INPUT,
        'true': TokenType.TRUE,
        'false': TokenType.FALSE,
        'null': TokenType.NULL,
        'and': TokenType.AND,
        'or': TokenType.OR,
        'not': TokenType.NOT,
        'range': TokenType.RANGE,
        'class': TokenType.CLASS,
        'new': TokenType.NEW,
        'this': TokenType.THIS,
        'import': TokenType.IMPORT,
        'from': TokenType.FROM,
        'as': TokenType.AS,
        'try': TokenType.TRY,
        'catch': TokenType.CATCH,
        'finally': TokenType.FINALLY,
        'throw': TokenType.THROW,
        'async': TokenType.ASYNC,
        'await': TokenType.AWAIT,
        'lambda': TokenType.LAMBDA,
        'match': TokenType.MATCH,
        'case': TokenType.CASE,
        'default': TokenType.DEFAULT,
        'type': TokenType.TYPE,
        'where': TokenType.WHERE,
        'requires': TokenType.REQUIRES,
        'ensures': TokenType.ENSURES,
        'invariant': TokenType.INVARIANT,
        'tensor': TokenType.TENSOR,
        'model': TokenType.MODEL,
        'optimize': TokenType.OPTIMIZE,
        'using': TokenType.USING,
        'hardware': TokenType.HARDWARE,
        'gpu': TokenType.GPU,
        'cpu': TokenType.CPU,
        'tpu': TokenType.TPU,
        'gradient': TokenType.GRADIENT,
        'train': TokenType.TRAIN,
        'predict': TokenType.PREDICT,
        'stream': TokenType.STREAM,
        'reactive': TokenType.REACTIVE,
        'temporal': TokenType.TEMPORAL,
        'when': TokenType.WHEN,
        'observe': TokenType.OBSERVE,
        'emit': TokenType.EMIT,
        'every': TokenType.EVERY,
        'after': TokenType.AFTER,
        'sandbox': TokenType.SANDBOX,
        'isolated': TokenType.ISOLATED,
        'capability': TokenType.CAPABILITY,
    }
    
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.indent_stack = [0]
        
    def error(self, message: str):
        raise LexerError(message, self.line, self.column)
    
    def peek(self, offset: int = 0) -> str:
        pos = self.pos + offset
        if pos >= len(self.source):
            return '\0'
        return self.source[pos]
    
    def advance(self) -> str:
        char = self.peek()
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char
    
    def skip_whitespace(self):
        while self.peek() in ' \t' and self.peek() != '\0':
            self.advance()
    
    def skip_comment(self):
        if self.peek() == '#':
            while self.peek() != '\n' and self.peek() != '\0':
                self.advance()
        elif self.peek() == '/' and self.peek(1) == '/':
            while self.peek() != '\n' and self.peek() != '\0':
                self.advance()
        elif self.peek() == '/' and self.peek(1) == '*':
            self.advance()
            self.advance()
            while not (self.peek() == '*' and self.peek(1) == '/'):
                if self.peek() == '\0':
                    self.error("Unterminated multi-line comment")
                self.advance()
            self.advance()
            self.advance()
    
    def read_string(self) -> Token:
        quote = self.advance()
        start_line = self.line
        start_col = self.column - 1
        value = ""
        
        if self.peek() == quote and self.peek(1) == quote:
            self.advance()
            self.advance()
            while not (self.peek() == quote and self.peek(1) == quote and self.peek(2) == quote):
                if self.peek() == '\0':
                    self.error("Unterminated multi-line string")
                value += self.advance()
            self.advance()
            self.advance()
            self.advance()
            return Token(TokenType.STRING, value, start_line, start_col)
        
        while self.peek() != quote:
            if self.peek() == '\0' or self.peek() == '\n':
                self.error("Unterminated string")
            if self.peek() == '\\':
                self.advance()
                escape_char = self.advance()
                escape_map = {
                    'n': '\n', 't': '\t', 'r': '\r', '\\': '\\',
                    '"': '"', "'": "'", '0': '\0', 'b': '\b'
                }
                value += escape_map.get(escape_char, escape_char)
            else:
                value += self.advance()
        
        self.advance()
        return Token(TokenType.STRING, value, start_line, start_col)
    
    def read_number(self) -> Token:
        start_line = self.line
        start_col = self.column
        value = ""
        is_float = False
        
        if self.peek() == '0' and self.peek(1) in 'xXbBoO':
            value += self.advance()
            base_char = self.advance()
            value += base_char
            
            if base_char in 'xX':
                while self.peek() in '0123456789abcdefABCDEF_':
                    if self.peek() != '_':
                        value += self.advance()
                    else:
                        self.advance()
                return Token(TokenType.INTEGER, int(value, 16), start_line, start_col)
            elif base_char in 'bB':
                while self.peek() in '01_':
                    if self.peek() != '_':
                        value += self.advance()
                    else:
                        self.advance()
                return Token(TokenType.INTEGER, int(value, 2), start_line, start_col)
            elif base_char in 'oO':
                while self.peek() in '01234567_':
                    if self.peek() != '_':
                        value += self.advance()
                    else:
                        self.advance()
                return Token(TokenType.INTEGER, int(value, 8), start_line, start_col)
        
        while self.peek().isdigit() or self.peek() in '._':
            if self.peek() == '_':
                self.advance()
                continue
            if self.peek() == '.':
                if is_float or not self.peek(1).isdigit():
                    break
                is_float = True
            value += self.advance()
        
        if self.peek() in 'eE':
            is_float = True
            value += self.advance()
            if self.peek() in '+-':
                value += self.advance()
            while self.peek().isdigit():
                value += self.advance()
        
        if is_float:
            return Token(TokenType.FLOAT, float(value), start_line, start_col)
        return Token(TokenType.INTEGER, int(value), start_line, start_col)
    
    def read_identifier(self) -> Token:
        start_line = self.line
        start_col = self.column
        value = ""
        
        while self.peek().isalnum() or self.peek() == '_':
            value += self.advance()
        
        token_type = self.KEYWORDS.get(value.lower())
        if token_type:
            if token_type == TokenType.TRUE:
                return Token(TokenType.BOOLEAN, True, start_line, start_col)
            elif token_type == TokenType.FALSE:
                return Token(TokenType.BOOLEAN, False, start_line, start_col)
            return Token(token_type, value.lower(), start_line, start_col)
        
        return Token(TokenType.IDENTIFIER, value, start_line, start_col)
    
    def handle_indentation(self):
        if self.column != 1:
            return
        
        indent = 0
        while self.peek() == ' ':
            self.advance()
            indent += 1
        while self.peek() == '\t':
            self.advance()
            indent += 4
        
        if self.peek() == '\n' or self.peek() == '#' or (self.peek() == '/' and self.peek(1) in '/*'):
            return
        
        current_indent = self.indent_stack[-1]
        
        if indent > current_indent:
            self.indent_stack.append(indent)
            self.tokens.append(Token(TokenType.INDENT, indent, self.line, 1))
        elif indent < current_indent:
            while self.indent_stack and self.indent_stack[-1] > indent:
                self.indent_stack.pop()
                self.tokens.append(Token(TokenType.DEDENT, indent, self.line, 1))
    
    def tokenize(self) -> List[Token]:
        while self.pos < len(self.source):
            if self.column == 1:
                self.handle_indentation()
            
            char = self.peek()
            
            if char in ' \t':
                self.skip_whitespace()
                continue
            
            if char == '#' or (char == '/' and self.peek(1) in '/*'):
                self.skip_comment()
                continue
            
            if char == '\n':
                self.tokens.append(Token(TokenType.NEWLINE, '\\n', self.line, self.column))
                self.advance()
                continue
            
            if char in '"\'':
                self.tokens.append(self.read_string())
                continue
            
            if char.isdigit():
                self.tokens.append(self.read_number())
                continue
            
            if char.isalpha() or char == '_':
                self.tokens.append(self.read_identifier())
                continue
            
            start_line = self.line
            start_col = self.column
            
            three_char = self.peek() + self.peek(1) + self.peek(2)
            if three_char == '//=':
                self.advance()
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.DIVIDE_ASSIGN, '//=', start_line, start_col))
                continue
            
            two_char = self.peek() + self.peek(1)
            two_char_ops = {
                '**': TokenType.POWER,
                '//': TokenType.FLOOR_DIVIDE,
                '==': TokenType.EQUAL,
                '!=': TokenType.NOT_EQUAL,
                '<=': TokenType.LESS_EQUAL,
                '>=': TokenType.GREATER_EQUAL,
                '+=': TokenType.PLUS_ASSIGN,
                '-=': TokenType.MINUS_ASSIGN,
                '*=': TokenType.MULTIPLY_ASSIGN,
                '/=': TokenType.DIVIDE_ASSIGN,
                '->': TokenType.ARROW,
                '|>': TokenType.PIPE,
            }
            
            if two_char in two_char_ops:
                self.advance()
                self.advance()
                self.tokens.append(Token(two_char_ops[two_char], two_char, start_line, start_col))
                continue
            
            single_char_ops = {
                '+': TokenType.PLUS,
                '-': TokenType.MINUS,
                '*': TokenType.MULTIPLY,
                '/': TokenType.DIVIDE,
                '%': TokenType.MODULO,
                '=': TokenType.ASSIGN,
                '<': TokenType.LESS,
                '>': TokenType.GREATER,
                '(': TokenType.LPAREN,
                ')': TokenType.RPAREN,
                '[': TokenType.LBRACKET,
                ']': TokenType.RBRACKET,
                '{': TokenType.LBRACE,
                '}': TokenType.RBRACE,
                ',': TokenType.COMMA,
                ':': TokenType.COLON,
                '.': TokenType.DOT,
                ';': TokenType.SEMICOLON,
                '@': TokenType.AT,
            }
            
            if char in single_char_ops:
                self.advance()
                self.tokens.append(Token(single_char_ops[char], char, start_line, start_col))
                continue
            
            self.error(f"Unexpected character: '{char}'")
        
        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self.tokens.append(Token(TokenType.DEDENT, 0, self.line, self.column))
        
        self.tokens.append(Token(TokenType.EOF, None, self.line, self.column))
        return self.tokens
