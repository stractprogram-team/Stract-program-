"""
STRACT Parser v5.0
Converts tokens to Abstract Syntax Tree (AST)
Supports all basic constructs and v5.0 Revolutionary Features
"""

from typing import List, Optional, Dict, Tuple, Any
from .tokens import Token, TokenType
from .ast_nodes import (
    ASTNode, NumberNode, StringNode, BooleanNode, NullNode, IdentifierNode,
    ListNode, DictNode, IndexNode, SliceNode, BinaryOpNode, UnaryOpNode,
    AssignNode, CompoundAssignNode, IndexAssignNode, PrintNode, InputNode,
    IfNode, WhileNode, ForNode, RangeNode, FunctionDefNode, LambdaNode,
    FunctionCallNode, MethodCallNode, ReturnNode, BreakNode, ContinueNode,
    ClassDefNode, PropertyAccessNode, PropertyAssignNode, NewInstanceNode,
    DecoratorNode, ImportNode, TryNode, ThrowNode, MatchNode, ProgramNode,
    RefinementTypeNode, TypeDefinitionNode, ContractNode, ContractedFunctionNode,
    RequiresNode, EnsuresNode, InvariantNode, SandboxNode,
    TensorNode, ModelNode, OptimizeDirectiveNode, GradientNode,
    TrainNode, PredictNode, HardwareNode,
    ReactiveStreamNode, TemporalVariableNode, WhenNode, ObserveNode,
    EmitNode, EveryNode, AfterNode, PipeNode, TypeAnnotationNode, TypedParameterNode
)


class ParserError(Exception):
    """Exception raised for parser errors"""
    def __init__(self, message: str, token: Token):
        self.message = message
        self.token = token
        self.line = token.line
        self.column = token.column
        super().__init__(f"Parser Error at line {token.line}, column {token.column}: {message}")


class Parser:
    """
    STRACT Parser - Converts tokens to AST
    
    Supports:
    - Basic constructs: variables, expressions, control flow, functions, classes
    - Error handling: try/catch/finally/throw
    - Pattern matching: match/case/default
    - Lambda expressions
    - Decorators
    - STRACT v5.0 Revolutionary Features:
        - Contractual Safety: type refinements, sandbox, invariants
        - AI-Native: tensor, model, optimize, train, predict, hardware, gradient
        - Reactive & Temporal: stream, temporal, when, observe, emit, every, after
    """
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
    
    def error(self, message: str) -> None:
        """Raise a parser error at current position"""
        raise ParserError(message, self.current())
    
    def current(self) -> Token:
        """Get current token"""
        if self.pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[self.pos]
    
    def peek(self, offset: int = 0) -> Token:
        """Peek at token with offset from current position"""
        pos = self.pos + offset
        if pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[pos]
    
    def advance(self) -> Token:
        """Advance to next token and return current"""
        token = self.current()
        self.pos += 1
        return token
    
    def match(self, *types: TokenType) -> bool:
        """Check if current token matches any of the given types"""
        return self.current().type in types
    
    def expect(self, token_type: TokenType, message: Optional[str] = None) -> Token:
        """Expect current token to be of given type, advance and return it"""
        if self.current().type != token_type:
            msg = message or f"Expected {token_type.name}, got {self.current().type.name}"
            self.error(msg)
        return self.advance()
    
    def skip_newlines(self) -> None:
        """Skip all newline tokens"""
        while self.match(TokenType.NEWLINE):
            self.advance()
    
    def parse(self) -> ProgramNode:
        """Parse entire program and return ProgramNode"""
        statements = []
        self.skip_newlines()
        
        while not self.match(TokenType.EOF):
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            self.skip_newlines()
        
        return ProgramNode(statements=statements)
    
    def parse_statement(self) -> Optional[ASTNode]:
        """Parse a single statement"""
        self.skip_newlines()
        
        token = self.current()
        
        if token.type == TokenType.AT:
            return self.parse_decorator()
        elif token.type == TokenType.LET or token.type == TokenType.VAR:
            return self.parse_variable_declaration(is_const=False)
        elif token.type == TokenType.CONST:
            return self.parse_variable_declaration(is_const=True)
        elif token.type == TokenType.PRINT:
            return self.parse_print()
        elif token.type == TokenType.IF:
            return self.parse_if()
        elif token.type == TokenType.WHILE:
            return self.parse_while()
        elif token.type == TokenType.FOR:
            return self.parse_for()
        elif token.type == TokenType.FUNC:
            return self.parse_function_def()
        elif token.type == TokenType.RETURN:
            return self.parse_return()
        elif token.type == TokenType.BREAK:
            self.advance()
            return BreakNode(line=token.line, column=token.column)
        elif token.type == TokenType.CONTINUE:
            self.advance()
            return ContinueNode(line=token.line, column=token.column)
        elif token.type == TokenType.CLASS:
            return self.parse_class_def()
        elif token.type == TokenType.TRY:
            return self.parse_try()
        elif token.type == TokenType.THROW:
            return self.parse_throw()
        elif token.type == TokenType.IMPORT:
            return self.parse_import()
        elif token.type == TokenType.MATCH:
            return self.parse_match()
        elif token.type == TokenType.TYPE:
            return self.parse_type_definition()
        elif token.type == TokenType.SANDBOX:
            return self.parse_sandbox()
        elif token.type == TokenType.INVARIANT:
            return self.parse_invariant()
        elif token.type == TokenType.TENSOR:
            return self.parse_tensor()
        elif token.type == TokenType.MODEL:
            return self.parse_model()
        elif token.type == TokenType.OPTIMIZE:
            return self.parse_optimize()
        elif token.type == TokenType.TRAIN:
            return self.parse_train()
        elif token.type == TokenType.PREDICT:
            return self.parse_predict()
        elif token.type == TokenType.HARDWARE:
            return self.parse_hardware()
        elif token.type == TokenType.GRADIENT:
            return self.parse_gradient()
        elif token.type == TokenType.STREAM:
            return self.parse_stream()
        elif token.type == TokenType.REACTIVE:
            return self.parse_reactive()
        elif token.type == TokenType.TEMPORAL:
            return self.parse_temporal()
        elif token.type == TokenType.WHEN:
            return self.parse_when()
        elif token.type == TokenType.OBSERVE:
            return self.parse_observe()
        elif token.type == TokenType.EMIT:
            return self.parse_emit()
        elif token.type == TokenType.EVERY:
            return self.parse_every()
        elif token.type == TokenType.AFTER:
            return self.parse_after()
        elif token.type == TokenType.IDENTIFIER:
            return self.parse_identifier_statement()
        elif token.type in (TokenType.INDENT, TokenType.DEDENT):
            self.advance()
            return None
        else:
            return self.parse_expression()
    
    def parse_decorator(self) -> DecoratorNode:
        """Parse: @decorator or @decorator(args)"""
        token = self.advance()
        
        name = ""
        if self.match(TokenType.IDENTIFIER):
            name = self.advance().value
            while self.match(TokenType.DOT):
                self.advance()
                name += "." + self.expect(TokenType.IDENTIFIER, "Expected identifier after '.'").value
        
        args = []
        if self.match(TokenType.LPAREN):
            self.advance()
            if not self.match(TokenType.RPAREN):
                args.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    self.advance()
                    args.append(self.parse_expression())
            self.expect(TokenType.RPAREN, "Expected ')' after decorator arguments")
        
        self.skip_newlines()
        
        target = None
        if self.match(TokenType.AT):
            target = self.parse_decorator()
        elif self.match(TokenType.FUNC):
            target = self.parse_function_def()
        elif self.match(TokenType.CLASS):
            target = self.parse_class_def()
        
        return DecoratorNode(
            name=name,
            args=args,
            target=target,
            line=token.line,
            column=token.column
        )
    
    def parse_variable_declaration(self, is_const: bool) -> AssignNode:
        """Parse: let/const/var name = value"""
        token = self.advance()
        name_token = self.expect(TokenType.IDENTIFIER, "Expected variable name")
        
        type_annotation = None
        if self.match(TokenType.COLON):
            self.advance()
            type_annotation = self.expect(TokenType.IDENTIFIER, "Expected type name").value
        
        self.expect(TokenType.ASSIGN, "Expected '=' after variable name")
        value = self.parse_expression()
        
        return AssignNode(
            name=name_token.value,
            value=value,
            is_const=is_const,
            type_annotation=type_annotation,
            line=token.line,
            column=token.column
        )
    
    def parse_identifier_statement(self) -> ASTNode:
        """Parse identifier-based statement (assignment, compound assignment, or expression)"""
        expr = self.parse_expression()
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            value = self.parse_expression()
            
            if isinstance(expr, IdentifierNode):
                return AssignNode(
                    name=expr.name,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            elif isinstance(expr, IndexNode):
                return IndexAssignNode(
                    obj=expr.obj,
                    index=expr.index,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            elif isinstance(expr, PropertyAccessNode):
                return PropertyAssignNode(
                    obj=expr.obj,
                    property=expr.property,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            else:
                self.error("Invalid assignment target")
        
        if self.match(TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN,
                      TokenType.MULTIPLY_ASSIGN, TokenType.DIVIDE_ASSIGN):
            op_token = self.advance()
            value = self.parse_expression()
            
            if isinstance(expr, IdentifierNode):
                op_map = {
                    TokenType.PLUS_ASSIGN: '+=',
                    TokenType.MINUS_ASSIGN: '-=',
                    TokenType.MULTIPLY_ASSIGN: '*=',
                    TokenType.DIVIDE_ASSIGN: '/=',
                }
                return CompoundAssignNode(
                    name=expr.name,
                    operator=op_map[op_token.type],
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
        
        return expr
    
    def parse_print(self) -> PrintNode:
        """Parse: print expr1, expr2, ..."""
        token = self.advance()
        
        expressions = []
        if not self.match(TokenType.NEWLINE, TokenType.EOF):
            expressions.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                self.advance()
                expressions.append(self.parse_expression())
        
        return PrintNode(expressions=expressions, line=token.line, column=token.column)
    
    def parse_if(self) -> IfNode:
        """Parse: if condition: block [elif condition: block]* [else: block]"""
        token = self.advance()
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after if condition")
        
        then_block = self.parse_block()
        elif_blocks = []
        else_block = []
        
        self.skip_newlines()
        
        while self.match(TokenType.ELIF):
            self.advance()
            elif_condition = self.parse_expression()
            self.expect(TokenType.COLON, "Expected ':' after elif condition")
            elif_body = self.parse_block()
            elif_blocks.append((elif_condition, elif_body))
            self.skip_newlines()
        
        if self.match(TokenType.ELSE):
            self.advance()
            self.expect(TokenType.COLON, "Expected ':' after else")
            else_block = self.parse_block()
        
        return IfNode(
            condition=condition,
            then_block=then_block,
            elif_blocks=elif_blocks,
            else_block=else_block,
            line=token.line,
            column=token.column
        )
    
    def parse_while(self) -> WhileNode:
        """Parse: while condition: block"""
        token = self.advance()
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after while condition")
        body = self.parse_block()
        
        return WhileNode(
            condition=condition,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_for(self) -> ForNode:
        """Parse: for variable in iterable: block"""
        token = self.advance()
        var_token = self.expect(TokenType.IDENTIFIER, "Expected variable name in for loop")
        self.expect(TokenType.IN, "Expected 'in' after variable in for loop")
        iterable = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after for loop declaration")
        body = self.parse_block()
        
        return ForNode(
            variable=var_token.value,
            iterable=iterable,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_function_def(self) -> FunctionDefNode:
        """Parse: func name(params): block"""
        token = self.advance()
        name_token = self.expect(TokenType.IDENTIFIER, "Expected function name")
        self.expect(TokenType.LPAREN, "Expected '(' after function name")
        
        params = []
        defaults = []
        param_types = {}
        
        if not self.match(TokenType.RPAREN):
            param = self.expect(TokenType.IDENTIFIER, "Expected parameter name").value
            params.append(param)
            
            if self.match(TokenType.COLON):
                self.advance()
                param_types[param] = self.expect(TokenType.IDENTIFIER, "Expected type name").value
            
            if self.match(TokenType.ASSIGN):
                self.advance()
                defaults.append(self.parse_expression())
            
            while self.match(TokenType.COMMA):
                self.advance()
                param = self.expect(TokenType.IDENTIFIER, "Expected parameter name").value
                params.append(param)
                
                if self.match(TokenType.COLON):
                    self.advance()
                    param_types[param] = self.expect(TokenType.IDENTIFIER, "Expected type name").value
                
                if self.match(TokenType.ASSIGN):
                    self.advance()
                    defaults.append(self.parse_expression())
        
        self.expect(TokenType.RPAREN, "Expected ')' after parameters")
        
        return_type = None
        if self.match(TokenType.ARROW):
            self.advance()
            return_type = self.expect(TokenType.IDENTIFIER, "Expected return type").value
        
        self.expect(TokenType.COLON, "Expected ':' after function declaration")
        body = self.parse_block()
        
        return FunctionDefNode(
            name=name_token.value,
            params=params,
            defaults=defaults,
            body=body,
            param_types=param_types,
            return_type=return_type,
            line=token.line,
            column=token.column
        )
    
    def parse_class_def(self) -> ClassDefNode:
        """Parse: class Name(Parent): body"""
        token = self.advance()
        name_token = self.expect(TokenType.IDENTIFIER, "Expected class name")
        
        parent = None
        if self.match(TokenType.LPAREN):
            self.advance()
            if not self.match(TokenType.RPAREN):
                parent = self.expect(TokenType.IDENTIFIER, "Expected parent class name").value
            self.expect(TokenType.RPAREN, "Expected ')' after parent class")
        
        self.expect(TokenType.COLON, "Expected ':' after class declaration")
        
        body = []
        
        self.skip_newlines()
        if self.match(TokenType.INDENT):
            self.advance()
            
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                
                stmt = self.parse_statement()
                if stmt:
                    body.append(stmt)
                self.skip_newlines()
            
            if self.match(TokenType.DEDENT):
                self.advance()
        
        return ClassDefNode(
            name=name_token.value,
            parent=parent,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_try(self) -> TryNode:
        """Parse: try: block catch [var]: block [finally: block]"""
        token = self.advance()
        self.expect(TokenType.COLON, "Expected ':' after try")
        try_block = self.parse_block()
        
        catch_var = None
        catch_block = []
        finally_block = []
        
        self.skip_newlines()
        if self.match(TokenType.CATCH):
            self.advance()
            if self.match(TokenType.IDENTIFIER):
                catch_var = self.advance().value
            self.expect(TokenType.COLON, "Expected ':' after catch")
            catch_block = self.parse_block()
        
        self.skip_newlines()
        if self.match(TokenType.FINALLY):
            self.advance()
            self.expect(TokenType.COLON, "Expected ':' after finally")
            finally_block = self.parse_block()
        
        return TryNode(
            try_block=try_block,
            catch_var=catch_var,
            catch_block=catch_block,
            finally_block=finally_block,
            line=token.line,
            column=token.column
        )
    
    def parse_throw(self) -> ThrowNode:
        """Parse: throw expression"""
        token = self.advance()
        value = self.parse_expression()
        return ThrowNode(value=value, line=token.line, column=token.column)
    
    def parse_import(self) -> ImportNode:
        """Parse: import module [as alias] or import {names} from module"""
        token = self.advance()
        
        items = []
        if self.match(TokenType.LBRACE):
            self.advance()
            items.append(self.expect(TokenType.IDENTIFIER, "Expected import name").value)
            while self.match(TokenType.COMMA):
                self.advance()
                items.append(self.expect(TokenType.IDENTIFIER, "Expected import name").value)
            self.expect(TokenType.RBRACE, "Expected '}' after import names")
            self.expect(TokenType.FROM, "Expected 'from' after import names")
        
        module = self.expect(TokenType.IDENTIFIER, "Expected module name").value
        while self.match(TokenType.DOT):
            self.advance()
            module += "." + self.expect(TokenType.IDENTIFIER, "Expected module name").value
        
        alias = None
        if self.match(TokenType.AS):
            self.advance()
            alias = self.expect(TokenType.IDENTIFIER, "Expected alias").value
        
        return ImportNode(module=module, alias=alias, items=items, line=token.line, column=token.column)
    
    def parse_match(self) -> MatchNode:
        """Parse: match value: case pattern: block [default: block]"""
        token = self.advance()
        value = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after match value")
        
        cases = []
        default = []
        
        self.skip_newlines()
        if self.match(TokenType.INDENT):
            self.advance()
            
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                
                if self.match(TokenType.CASE):
                    self.advance()
                    case_value = self.parse_expression()
                    self.expect(TokenType.COLON, "Expected ':' after case value")
                    case_body = self.parse_block()
                    cases.append((case_value, case_body))
                elif self.match(TokenType.DEFAULT):
                    self.advance()
                    self.expect(TokenType.COLON, "Expected ':' after default")
                    default = self.parse_block()
                else:
                    self.skip_newlines()
                    if self.match(TokenType.DEDENT, TokenType.EOF):
                        break
                    self.advance()
            
            if self.match(TokenType.DEDENT):
                self.advance()
        
        return MatchNode(value=value, cases=cases, default=default, line=token.line, column=token.column)
    
    def parse_return(self) -> ReturnNode:
        """Parse: return [expression]"""
        token = self.advance()
        
        value = None
        if not self.match(TokenType.NEWLINE, TokenType.EOF, TokenType.DEDENT):
            value = self.parse_expression()
        
        return ReturnNode(value=value, line=token.line, column=token.column)
    
    def parse_block(self) -> List[ASTNode]:
        """Parse indented block of statements"""
        statements = []
        self.skip_newlines()
        
        if self.match(TokenType.INDENT):
            self.advance()
            
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                stmt = self.parse_statement()
                if stmt:
                    statements.append(stmt)
                self.skip_newlines()
            
            if self.match(TokenType.DEDENT):
                self.advance()
        else:
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
        
        return statements
    
    def parse_expression(self) -> ASTNode:
        """Parse expression with proper precedence"""
        if self.match(TokenType.LAMBDA):
            return self.parse_lambda()
        return self.parse_ternary()
    
    def parse_lambda(self) -> LambdaNode:
        """Parse: lambda params: body or lambda params -> body"""
        token = self.advance()
        
        params = []
        if not self.match(TokenType.COLON, TokenType.ARROW):
            params.append(self.expect(TokenType.IDENTIFIER, "Expected parameter name").value)
            while self.match(TokenType.COMMA):
                self.advance()
                params.append(self.expect(TokenType.IDENTIFIER, "Expected parameter name").value)
        
        if self.match(TokenType.COLON):
            self.advance()
        elif self.match(TokenType.ARROW):
            self.advance()
        
        body = self.parse_expression()
        
        return LambdaNode(params=params, body=body, line=token.line, column=token.column)
    
    def parse_ternary(self) -> ASTNode:
        """Parse ternary expression: value if condition else alternative"""
        condition = self.parse_pipe()
        
        if self.match(TokenType.IF):
            self.advance()
            then_expr = self.parse_pipe()
            self.expect(TokenType.ELSE, "Expected 'else' in ternary expression")
            else_expr = self.parse_ternary()
            return IfNode(
                condition=condition,
                then_block=[then_expr],
                else_block=[else_expr],
                line=condition.line,
                column=condition.column
            )
        
        return condition
    
    def parse_pipe(self) -> ASTNode:
        """Parse pipe operator: expr |> transform"""
        left = self.parse_or()
        
        while self.match(TokenType.PIPE):
            op = self.advance()
            right = self.parse_or()
            left = PipeNode(left=left, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_or(self) -> ASTNode:
        """Parse logical OR: expr or expr"""
        left = self.parse_and()
        
        while self.match(TokenType.OR):
            op = self.advance()
            right = self.parse_and()
            left = BinaryOpNode(left=left, operator='or', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_and(self) -> ASTNode:
        """Parse logical AND: expr and expr"""
        left = self.parse_not()
        
        while self.match(TokenType.AND):
            op = self.advance()
            right = self.parse_not()
            left = BinaryOpNode(left=left, operator='and', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_not(self) -> ASTNode:
        """Parse logical NOT: not expr"""
        if self.match(TokenType.NOT):
            op = self.advance()
            operand = self.parse_not()
            return UnaryOpNode(operator='not', operand=operand, line=op.line, column=op.column)
        
        return self.parse_comparison()
    
    def parse_comparison(self) -> ASTNode:
        """Parse comparison: expr (==|!=|<|>|<=|>=|in) expr"""
        left = self.parse_additive()
        
        while self.match(TokenType.EQUAL, TokenType.NOT_EQUAL, TokenType.LESS,
                         TokenType.GREATER, TokenType.LESS_EQUAL, TokenType.GREATER_EQUAL,
                         TokenType.IN):
            op = self.advance()
            right = self.parse_additive()
            op_str = {
                TokenType.EQUAL: '==',
                TokenType.NOT_EQUAL: '!=',
                TokenType.LESS: '<',
                TokenType.GREATER: '>',
                TokenType.LESS_EQUAL: '<=',
                TokenType.GREATER_EQUAL: '>=',
                TokenType.IN: 'in',
            }[op.type]
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_additive(self) -> ASTNode:
        """Parse addition/subtraction: expr (+|-) expr"""
        left = self.parse_multiplicative()
        
        while self.match(TokenType.PLUS, TokenType.MINUS):
            op = self.advance()
            right = self.parse_multiplicative()
            op_str = '+' if op.type == TokenType.PLUS else '-'
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_multiplicative(self) -> ASTNode:
        """Parse multiplication/division: expr (*|/|//|%) expr"""
        left = self.parse_power()
        
        while self.match(TokenType.MULTIPLY, TokenType.DIVIDE, TokenType.FLOOR_DIVIDE, TokenType.MODULO):
            op = self.advance()
            right = self.parse_power()
            op_str = {
                TokenType.MULTIPLY: '*',
                TokenType.DIVIDE: '/',
                TokenType.FLOOR_DIVIDE: '//',
                TokenType.MODULO: '%',
            }[op.type]
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_power(self) -> ASTNode:
        """Parse power: expr ** expr (right associative)"""
        left = self.parse_unary()
        
        if self.match(TokenType.POWER):
            op = self.advance()
            right = self.parse_power()
            left = BinaryOpNode(left=left, operator='**', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_unary(self) -> ASTNode:
        """Parse unary operators: -expr, +expr"""
        if self.match(TokenType.MINUS):
            op = self.advance()
            operand = self.parse_unary()
            return UnaryOpNode(operator='-', operand=operand, line=op.line, column=op.column)
        if self.match(TokenType.PLUS):
            op = self.advance()
            operand = self.parse_unary()
            return UnaryOpNode(operator='+', operand=operand, line=op.line, column=op.column)
        
        return self.parse_postfix()
    
    def parse_postfix(self) -> ASTNode:
        """Parse postfix operations: function calls, indexing, property access"""
        left = self.parse_primary()
        
        while True:
            if self.match(TokenType.LPAREN):
                self.advance()
                args = []
                kwargs = {}
                if not self.match(TokenType.RPAREN):
                    arg = self.parse_expression()
                    if self.match(TokenType.ASSIGN) and isinstance(arg, IdentifierNode):
                        self.advance()
                        kwargs[arg.name] = self.parse_expression()
                    else:
                        args.append(arg)
                    
                    while self.match(TokenType.COMMA):
                        self.advance()
                        arg = self.parse_expression()
                        if self.match(TokenType.ASSIGN) and isinstance(arg, IdentifierNode):
                            self.advance()
                            kwargs[arg.name] = self.parse_expression()
                        else:
                            args.append(arg)
                
                self.expect(TokenType.RPAREN, "Expected ')' after arguments")
                
                if isinstance(left, IdentifierNode):
                    left = FunctionCallNode(name=left.name, args=args, kwargs=kwargs, line=left.line, column=left.column)
                elif isinstance(left, PropertyAccessNode):
                    left = MethodCallNode(obj=left.obj, method=left.property, args=args, line=left.line, column=left.column)
                else:
                    self.error("Invalid function call")
            
            elif self.match(TokenType.LBRACKET):
                self.advance()
                
                start = None
                end = None
                step = None
                is_slice = False
                
                if not self.match(TokenType.COLON, TokenType.RBRACKET):
                    start = self.parse_expression()
                
                if self.match(TokenType.COLON):
                    is_slice = True
                    self.advance()
                    if not self.match(TokenType.COLON, TokenType.RBRACKET):
                        end = self.parse_expression()
                    if self.match(TokenType.COLON):
                        self.advance()
                        if not self.match(TokenType.RBRACKET):
                            step = self.parse_expression()
                
                self.expect(TokenType.RBRACKET, "Expected ']' after index")
                
                if is_slice:
                    left = SliceNode(obj=left, start=start, end=end, step=step, line=left.line, column=left.column)
                else:
                    left = IndexNode(obj=left, index=start, line=left.line, column=left.column)
            
            elif self.match(TokenType.DOT):
                self.advance()
                prop_token = self.expect(TokenType.IDENTIFIER, "Expected property name")
                
                if self.match(TokenType.LPAREN):
                    self.advance()
                    args = []
                    if not self.match(TokenType.RPAREN):
                        args.append(self.parse_expression())
                        while self.match(TokenType.COMMA):
                            self.advance()
                            args.append(self.parse_expression())
                    self.expect(TokenType.RPAREN, "Expected ')' after method arguments")
                    left = MethodCallNode(obj=left, method=prop_token.value, args=args, line=left.line, column=left.column)
                else:
                    left = PropertyAccessNode(obj=left, property=prop_token.value, line=left.line, column=left.column)
            
            else:
                break
        
        return left
    
    def parse_primary(self) -> ASTNode:
        """Parse primary expressions: literals, identifiers, grouped expressions"""
        token = self.current()
        
        if token.type == TokenType.INTEGER or token.type == TokenType.FLOAT:
            self.advance()
            return NumberNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.STRING:
            self.advance()
            return StringNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.BOOLEAN:
            self.advance()
            return BooleanNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.NULL:
            self.advance()
            return NullNode(line=token.line, column=token.column)
        
        elif token.type == TokenType.IDENTIFIER:
            self.advance()
            return IdentifierNode(name=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.THIS:
            self.advance()
            return IdentifierNode(name="this", line=token.line, column=token.column)
        
        elif token.type == TokenType.RANGE:
            return self.parse_range()
        
        elif token.type == TokenType.INPUT:
            return self.parse_input()
        
        elif token.type == TokenType.NEW:
            return self.parse_new()
        
        elif token.type == TokenType.LPAREN:
            self.advance()
            expr = self.parse_expression()
            self.expect(TokenType.RPAREN, "Expected ')' after expression")
            return expr
        
        elif token.type == TokenType.LBRACKET:
            return self.parse_list()
        
        elif token.type == TokenType.LBRACE:
            return self.parse_dict()
        
        else:
            self.error(f"Unexpected token: {token.type.name}")
            raise ParserError(f"Unexpected token: {token.type.name}", token)
    
    def parse_range(self) -> RangeNode:
        """Parse: range(end) or range(start, end) or range(start, end, step)"""
        token = self.advance()
        self.expect(TokenType.LPAREN, "Expected '(' after range")
        
        start = self.parse_expression()
        
        if self.match(TokenType.RPAREN):
            self.advance()
            return RangeNode(
                start=NumberNode(value=0, line=token.line, column=token.column),
                end=start,
                line=token.line,
                column=token.column
            )
        
        self.expect(TokenType.COMMA, "Expected ',' in range")
        end = self.parse_expression()
        
        step = None
        if self.match(TokenType.COMMA):
            self.advance()
            step = self.parse_expression()
        
        self.expect(TokenType.RPAREN, "Expected ')' after range")
        
        return RangeNode(start=start, end=end, step=step, line=token.line, column=token.column)
    
    def parse_input(self) -> InputNode:
        """Parse: input() or input(prompt)"""
        token = self.advance()
        self.expect(TokenType.LPAREN, "Expected '(' after input")
        
        prompt = None
        if not self.match(TokenType.RPAREN):
            prompt = self.parse_expression()
        
        self.expect(TokenType.RPAREN, "Expected ')' after input")
        
        return InputNode(prompt=prompt, line=token.line, column=token.column)
    
    def parse_new(self) -> NewInstanceNode:
        """Parse: new ClassName() or new ClassName(args)"""
        token = self.advance()
        class_name = self.expect(TokenType.IDENTIFIER, "Expected class name after 'new'").value
        
        args = []
        if self.match(TokenType.LPAREN):
            self.advance()
            if not self.match(TokenType.RPAREN):
                args.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    self.advance()
                    args.append(self.parse_expression())
            self.expect(TokenType.RPAREN, "Expected ')' after constructor arguments")
        
        return NewInstanceNode(class_name=class_name, args=args, line=token.line, column=token.column)
    
    def parse_list(self) -> ListNode:
        """Parse: [elem1, elem2, ...]"""
        token = self.advance()
        
        elements = []
        if not self.match(TokenType.RBRACKET):
            elements.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                self.advance()
                if self.match(TokenType.RBRACKET):
                    break
                elements.append(self.parse_expression())
        
        self.expect(TokenType.RBRACKET, "Expected ']' after list elements")
        
        return ListNode(elements=elements, line=token.line, column=token.column)
    
    def parse_dict(self) -> DictNode:
        """Parse: {key: value, ...}"""
        token = self.advance()
        
        pairs = []
        if not self.match(TokenType.RBRACE):
            key = self.parse_expression()
            self.expect(TokenType.COLON, "Expected ':' after dict key")
            value = self.parse_expression()
            pairs.append((key, value))
            
            while self.match(TokenType.COMMA):
                self.advance()
                if self.match(TokenType.RBRACE):
                    break
                key = self.parse_expression()
                self.expect(TokenType.COLON, "Expected ':' after dict key")
                value = self.parse_expression()
                pairs.append((key, value))
        
        self.expect(TokenType.RBRACE, "Expected '}' after dict pairs")
        
        return DictNode(pairs=pairs, line=token.line, column=token.column)
    
    def parse_type_definition(self) -> TypeDefinitionNode:
        """Parse: type TypeName: BaseType where condition"""
        token = self.advance()
        name = self.expect(TokenType.IDENTIFIER, "Expected type name").value
        self.expect(TokenType.COLON, "Expected ':' after type name")
        base_type = self.expect(TokenType.IDENTIFIER, "Expected base type").value
        
        where_condition = None
        if self.match(TokenType.WHERE):
            self.advance()
            where_condition = self.parse_expression()
        
        return TypeDefinitionNode(
            name=name,
            base_type=base_type,
            where_condition=where_condition,
            line=token.line,
            column=token.column
        )
    
    def parse_sandbox(self) -> SandboxNode:
        """Parse: sandbox [capabilities]: block"""
        token = self.advance()
        
        name = ""
        if self.match(TokenType.IDENTIFIER):
            name = self.advance().value
        
        capabilities = []
        if self.match(TokenType.LBRACKET):
            self.advance()
            if not self.match(TokenType.RBRACKET):
                capabilities.append(self.expect(TokenType.IDENTIFIER, "Expected capability").value)
                while self.match(TokenType.COMMA):
                    self.advance()
                    capabilities.append(self.expect(TokenType.IDENTIFIER, "Expected capability").value)
            self.expect(TokenType.RBRACKET, "Expected ']' after capabilities")
        
        self.expect(TokenType.COLON, "Expected ':' after sandbox declaration")
        body = self.parse_block()
        
        return SandboxNode(
            name=name,
            capabilities=capabilities,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_invariant(self) -> InvariantNode:
        """Parse: invariant condition"""
        token = self.advance()
        condition = self.parse_expression()
        
        return InvariantNode(
            condition=condition,
            line=token.line,
            column=token.column
        )
    
    def parse_tensor(self) -> TensorNode:
        """Parse: tensor name[shape] gpu/cpu gradient = value"""
        token = self.advance()
        name = self.expect(TokenType.IDENTIFIER, "Expected tensor name").value
        
        shape = []
        if self.match(TokenType.LBRACKET):
            self.advance()
            if not self.match(TokenType.RBRACKET):
                shape.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    self.advance()
                    shape.append(self.parse_expression())
            self.expect(TokenType.RBRACKET, "Expected ']' after tensor shape")
        
        dtype = "float32"
        device = "auto"
        requires_grad = False
        initial_value = None
        
        while self.match(TokenType.IDENTIFIER, TokenType.GPU, TokenType.CPU, TokenType.TPU, TokenType.GRADIENT):
            if self.current().type == TokenType.GPU:
                self.advance()
                device = "gpu"
            elif self.current().type == TokenType.CPU:
                self.advance()
                device = "cpu"
            elif self.current().type == TokenType.TPU:
                self.advance()
                device = "tpu"
            elif self.current().type == TokenType.GRADIENT:
                self.advance()
                requires_grad = True
            elif self.current().value in ("float32", "float64", "int32", "int64"):
                dtype = self.advance().value
            else:
                break
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            initial_value = self.parse_expression()
        
        return TensorNode(
            name=name,
            shape=shape,
            dtype=dtype,
            device=device,
            requires_grad=requires_grad,
            initial_value=initial_value,
            line=token.line,
            column=token.column
        )
    
    def parse_model(self) -> ModelNode:
        """Parse: model Name: layers..."""
        token = self.advance()
        name = self.expect(TokenType.IDENTIFIER, "Expected model name").value
        self.expect(TokenType.COLON, "Expected ':' after model name")
        
        layers = []
        optimizer = None
        loss = None
        
        self.skip_newlines()
        if self.match(TokenType.INDENT):
            self.advance()
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                layer = self.parse_expression()
                layers.append(layer)
                self.skip_newlines()
            if self.match(TokenType.DEDENT):
                self.advance()
        
        return ModelNode(
            name=name,
            layers=layers,
            optimizer=optimizer,
            loss=loss,
            line=token.line,
            column=token.column
        )
    
    def parse_optimize(self) -> OptimizeDirectiveNode:
        """Parse: optimize target for goal using data"""
        token = self.advance()
        target = self.parse_expression()
        
        goal = "accuracy"
        data = None
        config = {}
        
        if self.match(TokenType.FOR):
            self.advance()
            goal = self.expect(TokenType.IDENTIFIER, "Expected optimization goal").value
        
        if self.match(TokenType.USING):
            self.advance()
            data = self.parse_expression()
        
        return OptimizeDirectiveNode(
            target=target,
            goal=goal,
            data=data,
            config=config,
            line=token.line,
            column=token.column
        )
    
    def parse_train(self) -> TrainNode:
        """Parse: train model using data epochs=N"""
        token = self.advance()
        model = self.parse_expression()
        
        data = None
        epochs = 1
        config = {}
        
        if self.match(TokenType.USING):
            self.advance()
            data = self.parse_expression()
        
        while self.match(TokenType.IDENTIFIER):
            key = self.current().value
            if key == "epochs":
                self.advance()
                self.expect(TokenType.ASSIGN, "Expected '=' after 'epochs'")
                epochs = int(self.expect(TokenType.INTEGER, "Expected integer for epochs").value)
            else:
                break
        
        return TrainNode(
            model=model,
            data=data,
            epochs=epochs,
            config=config,
            line=token.line,
            column=token.column
        )
    
    def parse_predict(self) -> PredictNode:
        """Parse: predict model using input"""
        token = self.advance()
        model = self.parse_expression()
        
        input_data = None
        if self.match(TokenType.USING):
            self.advance()
            input_data = self.parse_expression()
        
        return PredictNode(
            model=model,
            input_data=input_data,
            line=token.line,
            column=token.column
        )
    
    def parse_hardware(self) -> HardwareNode:
        """Parse: hardware gpu/cpu/tpu: block"""
        token = self.advance()
        
        device = "auto"
        if self.match(TokenType.GPU):
            self.advance()
            device = "gpu"
        elif self.match(TokenType.CPU):
            self.advance()
            device = "cpu"
        elif self.match(TokenType.TPU):
            self.advance()
            device = "tpu"
        elif self.match(TokenType.IDENTIFIER):
            device = self.advance().value
        
        self.expect(TokenType.COLON, "Expected ':' after hardware specification")
        body = self.parse_block()
        
        return HardwareNode(
            device=device,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_gradient(self) -> GradientNode:
        """Parse: gradient expr wrt [vars]"""
        token = self.advance()
        expression = self.parse_expression()
        
        with_respect_to = []
        if self.match(TokenType.IDENTIFIER) and self.current().value in ("wrt", "with"):
            self.advance()
            if self.match(TokenType.IDENTIFIER) and self.current().value == "respect":
                self.advance()
            if self.match(TokenType.IDENTIFIER) and self.current().value == "to":
                self.advance()
            
            if self.match(TokenType.LBRACKET):
                self.advance()
                if not self.match(TokenType.RBRACKET):
                    with_respect_to.append(self.expect(TokenType.IDENTIFIER, "Expected variable name").value)
                    while self.match(TokenType.COMMA):
                        self.advance()
                        with_respect_to.append(self.expect(TokenType.IDENTIFIER, "Expected variable name").value)
                self.expect(TokenType.RBRACKET, "Expected ']'")
            else:
                with_respect_to.append(self.expect(TokenType.IDENTIFIER, "Expected variable name").value)
        
        return GradientNode(
            expression=expression,
            with_respect_to=with_respect_to,
            line=token.line,
            column=token.column
        )
    
    def parse_stream(self) -> ReactiveStreamNode:
        """Parse: stream name = source |> transforms"""
        token = self.advance()
        name = self.expect(TokenType.IDENTIFIER, "Expected stream name").value
        
        source = None
        transformations = []
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            source = self.parse_expression()
            
            while self.match(TokenType.PIPE):
                self.advance()
                transformations.append(self.parse_expression())
        
        return ReactiveStreamNode(
            name=name,
            source=source,
            transformations=transformations,
            line=token.line,
            column=token.column
        )
    
    def parse_reactive(self) -> ReactiveStreamNode:
        """Parse: reactive name = expr"""
        token = self.advance()
        name = self.expect(TokenType.IDENTIFIER, "Expected variable name").value
        
        source = None
        if self.match(TokenType.ASSIGN):
            self.advance()
            source = self.parse_expression()
        
        return ReactiveStreamNode(
            name=name,
            source=source,
            transformations=[],
            line=token.line,
            column=token.column
        )
    
    def parse_temporal(self) -> TemporalVariableNode:
        """Parse: temporal name = initial every interval: update"""
        token = self.advance()
        name = self.expect(TokenType.IDENTIFIER, "Expected variable name").value
        
        initial_value = None
        update_rule = None
        interval = None
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            initial_value = self.parse_expression()
        
        if self.match(TokenType.EVERY):
            self.advance()
            interval = self.parse_expression()
            self.expect(TokenType.COLON, "Expected ':' after interval")
            update_rule = self.parse_expression()
        
        return TemporalVariableNode(
            name=name,
            initial_value=initial_value,
            update_rule=update_rule,
            interval=interval,
            line=token.line,
            column=token.column
        )
    
    def parse_when(self) -> WhenNode:
        """Parse: when condition: block"""
        token = self.advance()
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after when condition")
        body = self.parse_block()
        
        return WhenNode(
            condition=condition,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_observe(self) -> ObserveNode:
        """Parse: observe target handler"""
        token = self.advance()
        target = self.parse_expression()
        
        handler = None
        if self.match(TokenType.COLON):
            self.advance()
            self.skip_newlines()
            if self.match(TokenType.INDENT):
                self.advance()
                handler = self.parse_statement()
                while self.match(TokenType.DEDENT):
                    self.advance()
            else:
                handler = self.parse_expression()
        elif not self.match(TokenType.NEWLINE, TokenType.EOF):
            handler = self.parse_expression()
        
        return ObserveNode(
            target=target,
            handler=handler,
            line=token.line,
            column=token.column
        )
    
    def parse_emit(self) -> EmitNode:
        """Parse: emit stream value"""
        token = self.advance()
        stream = self.parse_expression()
        
        value = None
        if not self.match(TokenType.NEWLINE, TokenType.EOF):
            value = self.parse_expression()
        
        return EmitNode(
            stream=stream,
            value=value,
            line=token.line,
            column=token.column
        )
    
    def parse_every(self) -> EveryNode:
        """Parse: every interval: block"""
        token = self.advance()
        interval = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after interval")
        body = self.parse_block()
        
        return EveryNode(
            interval=interval,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_after(self) -> AfterNode:
        """Parse: after delay: block"""
        token = self.advance()
        delay = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after delay")
        body = self.parse_block()
        
        return AfterNode(
            delay=delay,
            body=body,
            line=token.line,
            column=token.column
        )
