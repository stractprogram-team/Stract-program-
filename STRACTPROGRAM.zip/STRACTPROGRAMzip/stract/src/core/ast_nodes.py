"""
STRACT AST Node Definitions v5.0
All Abstract Syntax Tree nodes for the STRACT language
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union


@dataclass
class ASTNode:
    """Base class for all AST nodes"""
    line: int = 0
    column: int = 0


@dataclass
class NumberNode(ASTNode):
    """Numeric literal (int or float)"""
    value: Union[int, float] = 0


@dataclass
class StringNode(ASTNode):
    """String literal"""
    value: str = ""


@dataclass
class BooleanNode(ASTNode):
    """Boolean literal (true/false)"""
    value: bool = False


@dataclass
class NullNode(ASTNode):
    """Null literal"""
    pass


@dataclass
class IdentifierNode(ASTNode):
    """Variable or function name reference"""
    name: str = ""


@dataclass
class ListNode(ASTNode):
    """List literal: [1, 2, 3]"""
    elements: List[ASTNode] = field(default_factory=list)


@dataclass
class DictNode(ASTNode):
    """Dictionary literal: {key: value}"""
    pairs: List[Tuple[ASTNode, ASTNode]] = field(default_factory=list)


@dataclass
class IndexNode(ASTNode):
    """Index access: obj[index]"""
    obj: Optional[ASTNode] = None
    index: Optional[ASTNode] = None


@dataclass
class SliceNode(ASTNode):
    """Slice access: obj[start:end:step]"""
    obj: Optional[ASTNode] = None
    start: Optional[ASTNode] = None
    end: Optional[ASTNode] = None
    step: Optional[ASTNode] = None


@dataclass
class BinaryOpNode(ASTNode):
    """Binary operation: left op right"""
    left: Optional[ASTNode] = None
    operator: str = ""
    right: Optional[ASTNode] = None


@dataclass
class UnaryOpNode(ASTNode):
    """Unary operation: op operand"""
    operator: str = ""
    operand: Optional[ASTNode] = None


@dataclass
class AssignNode(ASTNode):
    """Variable assignment: name = value"""
    name: str = ""
    value: Optional[ASTNode] = None
    is_const: bool = False
    type_annotation: Optional[str] = None


@dataclass
class CompoundAssignNode(ASTNode):
    """Compound assignment: name += value"""
    name: str = ""
    operator: str = ""
    value: Optional[ASTNode] = None


@dataclass
class IndexAssignNode(ASTNode):
    """Index assignment: obj[index] = value"""
    obj: Optional[ASTNode] = None
    index: Optional[ASTNode] = None
    value: Optional[ASTNode] = None


@dataclass
class PrintNode(ASTNode):
    """Print statement: print(expressions)"""
    expressions: List[ASTNode] = field(default_factory=list)


@dataclass
class InputNode(ASTNode):
    """Input expression: input(prompt)"""
    prompt: Optional[ASTNode] = None


@dataclass
class IfNode(ASTNode):
    """If statement with optional elif and else blocks"""
    condition: Optional[ASTNode] = None
    then_block: List[ASTNode] = field(default_factory=list)
    elif_blocks: List[Tuple[ASTNode, List[ASTNode]]] = field(default_factory=list)
    else_block: List[ASTNode] = field(default_factory=list)


@dataclass
class WhileNode(ASTNode):
    """While loop: while condition: body"""
    condition: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class ForNode(ASTNode):
    """For loop: for variable in iterable: body"""
    variable: str = ""
    iterable: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class RangeNode(ASTNode):
    """Range expression: range(start, end, step)"""
    start: Optional[ASTNode] = None
    end: Optional[ASTNode] = None
    step: Optional[ASTNode] = None


@dataclass
class FunctionDefNode(ASTNode):
    """Function definition: func name(params): body"""
    name: str = ""
    params: List[str] = field(default_factory=list)
    defaults: List[ASTNode] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)
    decorators: List['DecoratorNode'] = field(default_factory=list)
    param_types: Dict[str, str] = field(default_factory=dict)
    return_type: Optional[str] = None


@dataclass
class LambdaNode(ASTNode):
    """Lambda expression: lambda params: body"""
    params: List[str] = field(default_factory=list)
    body: Optional[ASTNode] = None


@dataclass
class FunctionCallNode(ASTNode):
    """Function call: name(args)"""
    name: str = ""
    args: List[ASTNode] = field(default_factory=list)
    kwargs: Dict[str, ASTNode] = field(default_factory=dict)


@dataclass
class MethodCallNode(ASTNode):
    """Method call: obj.method(args)"""
    obj: Optional[ASTNode] = None
    method: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class ReturnNode(ASTNode):
    """Return statement: return value"""
    value: Optional[ASTNode] = None


@dataclass
class BreakNode(ASTNode):
    """Break statement"""
    pass


@dataclass
class ContinueNode(ASTNode):
    """Continue statement"""
    pass


@dataclass
class ClassDefNode(ASTNode):
    """Class definition: class Name(Parent): body"""
    name: str = ""
    parent: Optional[str] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class PropertyAccessNode(ASTNode):
    """Property access: obj.property"""
    obj: Optional[ASTNode] = None
    property: str = ""


@dataclass
class PropertyAssignNode(ASTNode):
    """Property assignment: obj.property = value"""
    obj: Optional[ASTNode] = None
    property: str = ""
    value: Optional[ASTNode] = None


@dataclass
class NewInstanceNode(ASTNode):
    """New instance creation: new ClassName(args)"""
    class_name: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class DecoratorNode(ASTNode):
    """Decorator: @name(args)"""
    name: str = ""
    args: List[ASTNode] = field(default_factory=list)
    target: Optional[ASTNode] = None


@dataclass
class ImportNode(ASTNode):
    """Import statement: import module or from module import items"""
    module: str = ""
    alias: Optional[str] = None
    items: List[str] = field(default_factory=list)


@dataclass
class TryNode(ASTNode):
    """Try-catch-finally statement"""
    try_block: List[ASTNode] = field(default_factory=list)
    catch_var: Optional[str] = None
    catch_block: List[ASTNode] = field(default_factory=list)
    finally_block: List[ASTNode] = field(default_factory=list)


@dataclass
class ThrowNode(ASTNode):
    """Throw statement: throw value"""
    value: Optional[ASTNode] = None


@dataclass
class MatchNode(ASTNode):
    """Match statement: match value: case pattern: body"""
    value: Optional[ASTNode] = None
    cases: List[Tuple[ASTNode, List[ASTNode]]] = field(default_factory=list)
    default: List[ASTNode] = field(default_factory=list)


@dataclass
class ProgramNode(ASTNode):
    """Root node containing all statements"""
    statements: List[ASTNode] = field(default_factory=list)


@dataclass
class RefinementTypeNode(ASTNode):
    """Refinement type: type PositiveInt: Int where value > 0"""
    name: str = ""
    base_type: str = ""
    constraint: Optional[ASTNode] = None


@dataclass
class TypeDefinitionNode(ASTNode):
    """Type definition with optional constraint"""
    name: str = ""
    base_type: str = ""
    where_condition: Optional[ASTNode] = None


@dataclass
class ContractNode(ASTNode):
    """Pre/Post condition contract"""
    requires: List[ASTNode] = field(default_factory=list)
    ensures: List[ASTNode] = field(default_factory=list)


@dataclass
class ContractedFunctionNode(ASTNode):
    """Function with contracts (requires/ensures)"""
    name: str = ""
    params: List[str] = field(default_factory=list)
    param_types: Dict[str, str] = field(default_factory=dict)
    return_type: Optional[str] = None
    requires: List[ASTNode] = field(default_factory=list)
    ensures: List[ASTNode] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class RequiresNode(ASTNode):
    """Precondition: requires condition"""
    condition: Optional[ASTNode] = None


@dataclass
class EnsuresNode(ASTNode):
    """Postcondition: ensures condition"""
    condition: Optional[ASTNode] = None


@dataclass
class InvariantNode(ASTNode):
    """Class invariant that must hold at all times"""
    condition: Optional[ASTNode] = None


@dataclass
class SandboxNode(ASTNode):
    """Sandboxed code block with capability restrictions"""
    name: str = ""
    capabilities: List[str] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class TensorNode(ASTNode):
    """Tensor declaration with shape and device"""
    name: str = ""
    shape: List[ASTNode] = field(default_factory=list)
    dtype: str = "float32"
    device: str = "auto"
    requires_grad: bool = False
    initial_value: Optional[ASTNode] = None


@dataclass
class ModelNode(ASTNode):
    """AI Model definition"""
    name: str = ""
    layers: List[ASTNode] = field(default_factory=list)
    optimizer: Optional[str] = None
    loss: Optional[str] = None


@dataclass
class OptimizeDirectiveNode(ASTNode):
    """Optimize directive: optimize model for accuracy using data"""
    target: Optional[ASTNode] = None
    goal: str = "accuracy"
    data: Optional[ASTNode] = None
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GradientNode(ASTNode):
    """Gradient computation: gradient of expr with respect to var"""
    expression: Optional[ASTNode] = None
    with_respect_to: List[str] = field(default_factory=list)


@dataclass
class TrainNode(ASTNode):
    """Training directive for models"""
    model: Optional[ASTNode] = None
    data: Optional[ASTNode] = None
    epochs: int = 1
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PredictNode(ASTNode):
    """Prediction using trained model"""
    model: Optional[ASTNode] = None
    input_data: Optional[ASTNode] = None


@dataclass
class HardwareNode(ASTNode):
    """Hardware placement directive"""
    device: str = "auto"
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class ReactiveStreamNode(ASTNode):
    """Reactive stream declaration"""
    name: str = ""
    source: Optional[ASTNode] = None
    transformations: List[ASTNode] = field(default_factory=list)


@dataclass
class TemporalVariableNode(ASTNode):
    """Time-aware variable that changes over time"""
    name: str = ""
    initial_value: Optional[ASTNode] = None
    update_rule: Optional[ASTNode] = None
    interval: Optional[ASTNode] = None


@dataclass
class WhenNode(ASTNode):
    """Reactive when clause: when condition: action"""
    condition: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class ObserveNode(ASTNode):
    """Observe changes to a variable"""
    target: Optional[ASTNode] = None
    handler: Optional[ASTNode] = None


@dataclass
class EmitNode(ASTNode):
    """Emit a value to a stream"""
    stream: Optional[ASTNode] = None
    value: Optional[ASTNode] = None


@dataclass
class EveryNode(ASTNode):
    """Execute action every interval: every 1s: action"""
    interval: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class AfterNode(ASTNode):
    """Execute action after delay: after 5s: action"""
    delay: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class PipeNode(ASTNode):
    """Pipe operator: value |> transform1 |> transform2"""
    left: Optional[ASTNode] = None
    right: Optional[ASTNode] = None


@dataclass
class TypeAnnotationNode(ASTNode):
    """Type annotation for variables and parameters"""
    name: str = ""
    type_name: str = ""
    is_optional: bool = False
    generic_params: List[str] = field(default_factory=list)


@dataclass
class TypedParameterNode(ASTNode):
    """Function parameter with type annotation"""
    name: str = ""
    type_annotation: Optional[TypeAnnotationNode] = None
    default_value: Optional[ASTNode] = None
