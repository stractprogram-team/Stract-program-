#!/usr/bin/env python3
"""STRACT Language CLI - Entry Point"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'tools'))
from stract_interpreter import Lexer, Parser, Interpreter

def run_file(filepath):
    """Run a STRACT file"""
    try:
        with open(filepath, 'r') as f:
            code = f.read()
        lexer = Lexer(code)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        interpreter = Interpreter()
        result = interpreter.execute(ast)
        return result
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return None

def main():
    if len(sys.argv) < 2:
        print("Usage: python stract_cli.py <file.stract>")
        sys.exit(1)
    
    filepath = sys.argv[1]
    run_file(filepath)

if __name__ == "__main__":
    main()
