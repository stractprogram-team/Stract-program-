#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STRACT Programming Language Interpreter v3.0
A modern, powerful, and extensible programming language for 2027 and beyond.
Designed with AI integration capabilities in mind.

Author: STRACT Development Team
License: MIT
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Callable, Union, Set, Tuple
import re
import sys
import os
import time
import math
import random
import json

# ============================================================================
# PART 1: TOKEN DEFINITIONS
# ============================================================================

class TokenType(Enum):
    """All token types supported by STRACT"""
    INTEGER = auto()
    FLOAT = auto()
    STRING = auto()
    BOOLEAN = auto()
    IDENTIFIER = auto()
    
    PLUS = auto()
    MINUS = auto()
    MULTIPLY = auto()
    DIVIDE = auto()
    FLOOR_DIVIDE = auto()
    MODULO = auto()
    POWER = auto()
    
    EQUAL = auto()
    NOT_EQUAL = auto()
    LESS = auto()
    GREATER = auto()
    LESS_EQUAL = auto()
    GREATER_EQUAL = auto()
    
    AND = auto()
    OR = auto()
    NOT = auto()
    
    ASSIGN = auto()
    PLUS_ASSIGN = auto()
    MINUS_ASSIGN = auto()
    MULTIPLY_ASSIGN = auto()
    DIVIDE_ASSIGN = auto()
    
    LPAREN = auto()
    RPAREN = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    LBRACE = auto()
    RBRACE = auto()
    COMMA = auto()
    COLON = auto()
    DOT = auto()
    SEMICOLON = auto()
    ARROW = auto()
    NEWLINE = auto()
    
    LET = auto()
    CONST = auto()
    VAR = auto()
    IF = auto()
    ELIF = auto()
    ELSE = auto()
    WHILE = auto()
    FOR = auto()
    IN = auto()
    FUNC = auto()
    RETURN = auto()
    BREAK = auto()
    CONTINUE = auto()
    PRINT = auto()
    INPUT = auto()
    TRUE = auto()
    FALSE = auto()
    NULL = auto()
    RANGE = auto()
    CLASS = auto()
    NEW = auto()
    THIS = auto()
    IMPORT = auto()
    FROM = auto()
    AS = auto()
    TRY = auto()
    CATCH = auto()
    FINALLY = auto()
    THROW = auto()
    ASYNC = auto()
    AWAIT = auto()
    LAMBDA = auto()
    MATCH = auto()
    CASE = auto()
    DEFAULT = auto()
    
    AT = auto()
    DECORATOR = auto()
    
    # ========== STRACT v5.0 Revolutionary Features ==========
    # Contractual Safety Tokens
    TYPE = auto()
    WHERE = auto()
    REQUIRES = auto()
    ENSURES = auto()
    INVARIANT = auto()
    
    # AI-Native Language Tokens
    TENSOR = auto()
    MODEL = auto()
    OPTIMIZE = auto()
    USING = auto()
    HARDWARE = auto()
    GPU = auto()
    CPU = auto()
    TPU = auto()
    GRADIENT = auto()
    TRAIN = auto()
    PREDICT = auto()
    
    # Reactive & Temporal Programming Tokens
    STREAM = auto()
    REACTIVE = auto()
    TEMPORAL = auto()
    WHEN = auto()
    OBSERVE = auto()
    EMIT = auto()
    EVERY = auto()
    AFTER = auto()
    
    # Sandboxing Tokens
    SANDBOX = auto()
    ISOLATED = auto()
    CAPABILITY = auto()
    
    # Pipe operator for functional chaining
    PIPE = auto()
    
    EOF = auto()
    INDENT = auto()
    DEDENT = auto()


@dataclass
class Token:
    """Represents a single token with position information"""
    type: TokenType
    value: Any
    line: int
    column: int
    
    def __repr__(self):
        return f"Token({self.type.name}, {repr(self.value)}, line={self.line})"


# ============================================================================
# PART 2: LEXER (Tokenizer)
# ============================================================================

class LexerError(Exception):
    """Exception raised for lexer errors"""
    def __init__(self, message: str, line: int, column: int):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Lexer Error at line {line}, column {column}: {message}")


class Lexer:
    """Tokenizes STRACT source code"""
    
    KEYWORDS = {
        'let': TokenType.LET,
        'const': TokenType.CONST,
        'var': TokenType.VAR,
        'if': TokenType.IF,
        'elif': TokenType.ELIF,
        'else': TokenType.ELSE,
        'while': TokenType.WHILE,
        'for': TokenType.FOR,
        'in': TokenType.IN,
        'func': TokenType.FUNC,
        'return': TokenType.RETURN,
        'break': TokenType.BREAK,
        'continue': TokenType.CONTINUE,
        'print': TokenType.PRINT,
        'input': TokenType.INPUT,
        'true': TokenType.TRUE,
        'false': TokenType.FALSE,
        'null': TokenType.NULL,
        'and': TokenType.AND,
        'or': TokenType.OR,
        'not': TokenType.NOT,
        'range': TokenType.RANGE,
        'class': TokenType.CLASS,
        'new': TokenType.NEW,
        'this': TokenType.THIS,
        'import': TokenType.IMPORT,
        'from': TokenType.FROM,
        'as': TokenType.AS,
        'try': TokenType.TRY,
        'catch': TokenType.CATCH,
        'finally': TokenType.FINALLY,
        'throw': TokenType.THROW,
        'async': TokenType.ASYNC,
        'await': TokenType.AWAIT,
        'lambda': TokenType.LAMBDA,
        'match': TokenType.MATCH,
        'case': TokenType.CASE,
        'default': TokenType.DEFAULT,
        # STRACT v5.0 Revolutionary Keywords
        # Contractual Safety
        'type': TokenType.TYPE,
        'where': TokenType.WHERE,
        'requires': TokenType.REQUIRES,
        'ensures': TokenType.ENSURES,
        'invariant': TokenType.INVARIANT,
        # AI-Native
        'tensor': TokenType.TENSOR,
        'model': TokenType.MODEL,
        'optimize': TokenType.OPTIMIZE,
        'using': TokenType.USING,
        'hardware': TokenType.HARDWARE,
        'gpu': TokenType.GPU,
        'cpu': TokenType.CPU,
        'tpu': TokenType.TPU,
        'gradient': TokenType.GRADIENT,
        'train': TokenType.TRAIN,
        'predict': TokenType.PREDICT,
        # Reactive & Temporal
        'stream': TokenType.STREAM,
        'reactive': TokenType.REACTIVE,
        'temporal': TokenType.TEMPORAL,
        'when': TokenType.WHEN,
        'observe': TokenType.OBSERVE,
        'emit': TokenType.EMIT,
        'every': TokenType.EVERY,
        'after': TokenType.AFTER,
        # Sandboxing
        'sandbox': TokenType.SANDBOX,
        'isolated': TokenType.ISOLATED,
        'capability': TokenType.CAPABILITY,
    }
    
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
        self.indent_stack = [0]
        
    def error(self, message: str):
        raise LexerError(message, self.line, self.column)
    
    def peek(self, offset: int = 0) -> str:
        pos = self.pos + offset
        if pos >= len(self.source):
            return '\0'
        return self.source[pos]
    
    def advance(self) -> str:
        char = self.peek()
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char
    
    def skip_whitespace(self):
        while self.peek() in ' \t' and self.peek() != '\0':
            self.advance()
    
    def skip_comment(self):
        if self.peek() == '#':
            while self.peek() != '\n' and self.peek() != '\0':
                self.advance()
        elif self.peek() == '/' and self.peek(1) == '/':
            while self.peek() != '\n' and self.peek() != '\0':
                self.advance()
        elif self.peek() == '/' and self.peek(1) == '*':
            self.advance()
            self.advance()
            while not (self.peek() == '*' and self.peek(1) == '/'):
                if self.peek() == '\0':
                    self.error("Unterminated multi-line comment")
                self.advance()
            self.advance()
            self.advance()
    
    def read_string(self) -> Token:
        quote = self.advance()
        start_line = self.line
        start_col = self.column - 1
        value = ""
        
        if self.peek() == quote and self.peek(1) == quote:
            self.advance()
            self.advance()
            while not (self.peek() == quote and self.peek(1) == quote and self.peek(2) == quote):
                if self.peek() == '\0':
                    self.error("Unterminated multi-line string")
                value += self.advance()
            self.advance()
            self.advance()
            self.advance()
            return Token(TokenType.STRING, value, start_line, start_col)
        
        while self.peek() != quote:
            if self.peek() == '\0' or self.peek() == '\n':
                self.error("Unterminated string")
            if self.peek() == '\\':
                self.advance()
                escape_char = self.advance()
                escape_map = {
                    'n': '\n', 't': '\t', 'r': '\r', '\\': '\\',
                    '"': '"', "'": "'", '0': '\0', 'b': '\b'
                }
                value += escape_map.get(escape_char, escape_char)
            else:
                value += self.advance()
        
        self.advance()
        return Token(TokenType.STRING, value, start_line, start_col)
    
    def read_number(self) -> Token:
        start_line = self.line
        start_col = self.column
        value = ""
        is_float = False
        
        if self.peek() == '0' and self.peek(1) in 'xXbBoO':
            value += self.advance()
            base_char = self.advance()
            value += base_char
            
            if base_char in 'xX':
                while self.peek() in '0123456789abcdefABCDEF_':
                    if self.peek() != '_':
                        value += self.advance()
                    else:
                        self.advance()
                return Token(TokenType.INTEGER, int(value, 16), start_line, start_col)
            elif base_char in 'bB':
                while self.peek() in '01_':
                    if self.peek() != '_':
                        value += self.advance()
                    else:
                        self.advance()
                return Token(TokenType.INTEGER, int(value, 2), start_line, start_col)
            elif base_char in 'oO':
                while self.peek() in '01234567_':
                    if self.peek() != '_':
                        value += self.advance()
                    else:
                        self.advance()
                return Token(TokenType.INTEGER, int(value, 8), start_line, start_col)
        
        while self.peek().isdigit() or self.peek() in '._':
            if self.peek() == '_':
                self.advance()
                continue
            if self.peek() == '.':
                if is_float or not self.peek(1).isdigit():
                    break
                is_float = True
            value += self.advance()
        
        if self.peek() in 'eE':
            is_float = True
            value += self.advance()
            if self.peek() in '+-':
                value += self.advance()
            while self.peek().isdigit():
                value += self.advance()
        
        if is_float:
            return Token(TokenType.FLOAT, float(value), start_line, start_col)
        return Token(TokenType.INTEGER, int(value), start_line, start_col)
    
    def read_identifier(self) -> Token:
        start_line = self.line
        start_col = self.column
        value = ""
        
        while self.peek().isalnum() or self.peek() == '_':
            value += self.advance()
        
        token_type = self.KEYWORDS.get(value.lower())
        if token_type:
            if token_type == TokenType.TRUE:
                return Token(TokenType.BOOLEAN, True, start_line, start_col)
            elif token_type == TokenType.FALSE:
                return Token(TokenType.BOOLEAN, False, start_line, start_col)
            return Token(token_type, value.lower(), start_line, start_col)
        
        return Token(TokenType.IDENTIFIER, value, start_line, start_col)
    
    def handle_indentation(self):
        if self.column != 1:
            return
        
        indent = 0
        while self.peek() == ' ':
            self.advance()
            indent += 1
        while self.peek() == '\t':
            self.advance()
            indent += 4
        
        if self.peek() == '\n' or self.peek() == '#' or (self.peek() == '/' and self.peek(1) in '/*'):
            return
        
        current_indent = self.indent_stack[-1]
        
        if indent > current_indent:
            self.indent_stack.append(indent)
            self.tokens.append(Token(TokenType.INDENT, indent, self.line, 1))
        elif indent < current_indent:
            while self.indent_stack and self.indent_stack[-1] > indent:
                self.indent_stack.pop()
                self.tokens.append(Token(TokenType.DEDENT, indent, self.line, 1))
    
    def tokenize(self) -> List[Token]:
        while self.pos < len(self.source):
            if self.column == 1:
                self.handle_indentation()
            
            char = self.peek()
            
            if char in ' \t':
                self.skip_whitespace()
                continue
            
            if char == '#' or (char == '/' and self.peek(1) in '/*'):
                self.skip_comment()
                continue
            
            if char == '\n':
                self.tokens.append(Token(TokenType.NEWLINE, '\\n', self.line, self.column))
                self.advance()
                continue
            
            if char in '"\'':
                self.tokens.append(self.read_string())
                continue
            
            if char.isdigit():
                self.tokens.append(self.read_number())
                continue
            
            if char.isalpha() or char == '_':
                self.tokens.append(self.read_identifier())
                continue
            
            start_line = self.line
            start_col = self.column
            
            three_char = self.peek() + self.peek(1) + self.peek(2)
            if three_char == '//=':
                self.advance()
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.DIVIDE_ASSIGN, '//=', start_line, start_col))
                continue
            
            two_char = self.peek() + self.peek(1)
            two_char_ops = {
                '**': TokenType.POWER,
                '//': TokenType.FLOOR_DIVIDE,
                '==': TokenType.EQUAL,
                '!=': TokenType.NOT_EQUAL,
                '<=': TokenType.LESS_EQUAL,
                '>=': TokenType.GREATER_EQUAL,
                '+=': TokenType.PLUS_ASSIGN,
                '-=': TokenType.MINUS_ASSIGN,
                '*=': TokenType.MULTIPLY_ASSIGN,
                '/=': TokenType.DIVIDE_ASSIGN,
                '->': TokenType.ARROW,
                '|>': TokenType.PIPE,  # Pipe operator for functional chaining
            }
            
            if two_char in two_char_ops:
                self.advance()
                self.advance()
                self.tokens.append(Token(two_char_ops[two_char], two_char, start_line, start_col))
                continue
            
            single_char_ops = {
                '+': TokenType.PLUS,
                '-': TokenType.MINUS,
                '*': TokenType.MULTIPLY,
                '/': TokenType.DIVIDE,
                '%': TokenType.MODULO,
                '=': TokenType.ASSIGN,
                '<': TokenType.LESS,
                '>': TokenType.GREATER,
                '(': TokenType.LPAREN,
                ')': TokenType.RPAREN,
                '[': TokenType.LBRACKET,
                ']': TokenType.RBRACKET,
                '{': TokenType.LBRACE,
                '}': TokenType.RBRACE,
                ',': TokenType.COMMA,
                ':': TokenType.COLON,
                '.': TokenType.DOT,
                ';': TokenType.SEMICOLON,
                '@': TokenType.AT,
            }
            
            if char in single_char_ops:
                self.advance()
                self.tokens.append(Token(single_char_ops[char], char, start_line, start_col))
                continue
            
            self.error(f"Unexpected character: '{char}'")
        
        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self.tokens.append(Token(TokenType.DEDENT, 0, self.line, 1))
        
        self.tokens.append(Token(TokenType.EOF, None, self.line, self.column))
        return self.tokens


# ============================================================================
# PART 3: AST NODES
# ============================================================================

@dataclass
class ASTNode:
    line: int = 0
    column: int = 0


@dataclass
class NumberNode(ASTNode):
    value: Union[int, float] = 0


@dataclass
class StringNode(ASTNode):
    value: str = ""


@dataclass
class BooleanNode(ASTNode):
    value: bool = False


@dataclass
class NullNode(ASTNode):
    pass


@dataclass
class IdentifierNode(ASTNode):
    name: str = ""  # Empty string


@dataclass
class ListNode(ASTNode):
    elements: List[ASTNode] = field(default_factory=list)


@dataclass
class DictNode(ASTNode):
    pairs: List[Tuple[ASTNode, ASTNode]] = field(default_factory=list)


@dataclass
class IndexNode(ASTNode):
    obj: Optional[ASTNode] = None
    index: Optional[ASTNode] = None


@dataclass
class SliceNode(ASTNode):
    obj: Optional[ASTNode] = None
    start: Optional[ASTNode] = None
    end: Optional[ASTNode] = None
    step: Optional[ASTNode] = None


@dataclass
class BinaryOpNode(ASTNode):
    left: Optional[ASTNode] = None
    operator: str = ""
    right: Optional[ASTNode] = None


@dataclass
class UnaryOpNode(ASTNode):
    operator: str = ""
    operand: Optional[ASTNode] = None


@dataclass
class AssignNode(ASTNode):
    name: str = ""
    value: Optional[ASTNode] = None
    is_const: bool = False


@dataclass
class CompoundAssignNode(ASTNode):
    name: str = ""
    operator: str = ""
    value: Optional[ASTNode] = None


@dataclass
class IndexAssignNode(ASTNode):
    obj: Optional[ASTNode] = None
    index: Optional[ASTNode] = None
    value: Optional[ASTNode] = None


@dataclass
class PrintNode(ASTNode):
    expressions: List[ASTNode] = field(default_factory=list)


@dataclass
class InputNode(ASTNode):
    prompt: Optional[ASTNode] = None


@dataclass
class IfNode(ASTNode):
    condition: Optional[ASTNode] = None
    then_block: List[ASTNode] = field(default_factory=list)
    elif_blocks: List[tuple] = field(default_factory=list)
    else_block: List[ASTNode] = field(default_factory=list)


@dataclass
class WhileNode(ASTNode):
    condition: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class ForNode(ASTNode):
    variable: str = ""
    iterable: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class RangeNode(ASTNode):
    start: Optional[ASTNode] = None
    end: Optional[ASTNode] = None
    step: Optional[ASTNode] = None


@dataclass
class FunctionDefNode(ASTNode):
    name: str = ""  # Empty string
    params: List[str] = field(default_factory=list)
    defaults: List[ASTNode] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class LambdaNode(ASTNode):
    params: List[str] = field(default_factory=list)
    body: Optional[ASTNode] = None


@dataclass
class FunctionCallNode(ASTNode):
    name: str = ""
    args: List[ASTNode] = field(default_factory=list)
    kwargs: Dict[str, ASTNode] = field(default_factory=dict)


@dataclass
class MethodCallNode(ASTNode):
    obj: Optional[ASTNode] = None
    method: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class ReturnNode(ASTNode):
    value: Optional[ASTNode] = None


@dataclass
class BreakNode(ASTNode):
    pass


@dataclass
class ContinueNode(ASTNode):
    pass


@dataclass
class TryNode(ASTNode):
    try_block: List[ASTNode] = field(default_factory=list)
    catch_var: str = ""
    catch_block: List[ASTNode] = field(default_factory=list)
    finally_block: List[ASTNode] = field(default_factory=list)


@dataclass
class ThrowNode(ASTNode):
    value: Optional[ASTNode] = None


@dataclass
class ClassDefNode(ASTNode):
    name: str = ""
    parent: Optional[str] = None
    methods: List[FunctionDefNode] = field(default_factory=list)
    properties: List[AssignNode] = field(default_factory=list)


@dataclass
class NewNode(ASTNode):
    class_name: str = ""
    args: List[ASTNode] = field(default_factory=list)


@dataclass
class PropertyAccessNode(ASTNode):
    obj: Optional[ASTNode] = None
    property: str = ""


@dataclass
class ImportNode(ASTNode):
    module: str = ""
    alias: Optional[str] = None
    names: List[str] = field(default_factory=list)


@dataclass
class MatchNode(ASTNode):
    value: Optional[ASTNode] = None
    cases: List[Tuple[ASTNode, List[ASTNode]]] = field(default_factory=list)
    default: List[ASTNode] = field(default_factory=list)


@dataclass
class DecoratorNode(ASTNode):
    name: str = ""
    args: List[ASTNode] = field(default_factory=list)
    target: Optional[ASTNode] = None


# ============================================================================
# STRACT v5.0 REVOLUTIONARY AST NODES
# ============================================================================

# ==================== Contractual Safety Nodes ====================

@dataclass
class RefinementTypeNode(ASTNode):
    """Refinement type: type PositiveInt: Int where value > 0"""
    name: str = ""
    base_type: str = ""
    constraint: Optional[ASTNode] = None


@dataclass
class ContractNode(ASTNode):
    """Pre/Post condition contract"""
    requires: List[ASTNode] = field(default_factory=list)
    ensures: List[ASTNode] = field(default_factory=list)


@dataclass
class ContractedFunctionNode(ASTNode):
    """Function with contracts (requires/ensures)"""
    name: str = ""
    params: List[str] = field(default_factory=list)
    param_types: Dict[str, str] = field(default_factory=dict)
    return_type: Optional[str] = None
    requires: List[ASTNode] = field(default_factory=list)
    ensures: List[ASTNode] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class SandboxNode(ASTNode):
    """Sandboxed code block with capability restrictions"""
    capabilities: List[str] = field(default_factory=list)
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class InvariantNode(ASTNode):
    """Class invariant that must hold at all times"""
    condition: Optional[ASTNode] = None


# ==================== AI-Native Language Nodes ====================

@dataclass
class TensorNode(ASTNode):
    """Tensor declaration with shape and device"""
    name: str = ""
    shape: List[ASTNode] = field(default_factory=list)
    dtype: str = "float32"
    device: str = "auto"  # cpu, gpu, tpu, auto
    requires_grad: bool = False
    value: Optional[ASTNode] = None


@dataclass
class ModelNode(ASTNode):
    """AI Model definition"""
    name: str = ""
    layers: List[ASTNode] = field(default_factory=list)
    optimizer: Optional[str] = None
    loss: Optional[str] = None


@dataclass
class OptimizeDirectiveNode(ASTNode):
    """Optimize directive: optimize model for accuracy using data"""
    target: Optional[ASTNode] = None
    goal: str = ""  # accuracy, speed, memory, etc.
    data: Optional[ASTNode] = None
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GradientNode(ASTNode):
    """Gradient computation: gradient of expr with respect to var"""
    expression: Optional[ASTNode] = None
    with_respect_to: List[str] = field(default_factory=list)


@dataclass
class TrainNode(ASTNode):
    """Training directive for models"""
    model: Optional[ASTNode] = None
    data: Optional[ASTNode] = None
    epochs: int = 1
    config: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PredictNode(ASTNode):
    """Prediction using trained model"""
    model: Optional[ASTNode] = None
    input_data: Optional[ASTNode] = None


@dataclass
class HardwareNode(ASTNode):
    """Hardware placement directive"""
    device: str = "auto"  # cpu, gpu, tpu, auto
    body: List[ASTNode] = field(default_factory=list)


# ==================== Reactive & Temporal Programming Nodes ====================

@dataclass
class ReactiveStreamNode(ASTNode):
    """Reactive stream declaration"""
    name: str = ""
    source: Optional[ASTNode] = None
    transformations: List[ASTNode] = field(default_factory=list)


@dataclass
class TemporalVariableNode(ASTNode):
    """Time-aware variable that changes over time"""
    name: str = ""
    initial_value: Optional[ASTNode] = None
    update_rule: Optional[ASTNode] = None
    interval: Optional[ASTNode] = None  # Time interval for updates


@dataclass
class WhenNode(ASTNode):
    """Reactive when clause: when condition: action"""
    condition: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class ObserveNode(ASTNode):
    """Observe changes to a variable"""
    target: Optional[ASTNode] = None
    handler: Optional[ASTNode] = None


@dataclass
class EmitNode(ASTNode):
    """Emit a value to a stream"""
    stream: Optional[ASTNode] = None
    value: Optional[ASTNode] = None


@dataclass
class EveryNode(ASTNode):
    """Execute action every interval: every 1s: action"""
    interval: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class AfterNode(ASTNode):
    """Execute action after delay: after 5s: action"""
    delay: Optional[ASTNode] = None
    body: List[ASTNode] = field(default_factory=list)


@dataclass
class PipeNode(ASTNode):
    """Pipe operator: value |> transform1 |> transform2"""
    left: Optional[ASTNode] = None
    right: Optional[ASTNode] = None


# ==================== Type Annotation Nodes ====================

@dataclass
class TypeAnnotationNode(ASTNode):
    """Type annotation for variables and parameters"""
    name: str = ""
    type_name: str = ""
    is_optional: bool = False
    generic_params: List[str] = field(default_factory=list)


@dataclass
class TypedParameterNode(ASTNode):
    """Function parameter with type annotation"""
    name: str = ""
    type_annotation: Optional[TypeAnnotationNode] = None
    default_value: Optional[ASTNode] = None


@dataclass
class ProgramNode(ASTNode):
    statements: List[ASTNode] = field(default_factory=list)


# ============================================================================
# PART 4: PARSER
# ============================================================================

class ParserError(Exception):
    def __init__(self, message: str, token: Token):
        self.message = message
        self.token = token
        super().__init__(f"Parser Error at line {token.line}, column {token.column}: {message}")


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
    
    def error(self, message: str):
        raise ParserError(message, self.current())
    
    def current(self) -> Token:
        if self.pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[self.pos]
    
    def peek(self, offset: int = 0) -> Token:
        pos = self.pos + offset
        if pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[pos]
    
    def advance(self) -> Token:
        token = self.current()
        self.pos += 1
        return token
    
    def match(self, *types: TokenType) -> bool:
        return self.current().type in types
    
    def expect(self, token_type: TokenType, message: Optional[str] = None) -> Token:
        if self.current().type != token_type:
            msg = message or f"Expected {token_type.name}, got {self.current().type.name}"
            self.error(msg)
        return self.advance()
    
    def skip_newlines(self):
        while self.match(TokenType.NEWLINE):
            self.advance()
    
    def parse(self) -> ProgramNode:
        statements = []
        self.skip_newlines()
        
        while not self.match(TokenType.EOF):
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            self.skip_newlines()
        
        return ProgramNode(statements=statements)
    
    def parse_statement(self) -> Optional[ASTNode]:
        self.skip_newlines()
        
        token = self.current()
        
        if token.type == TokenType.AT:
            return self.parse_decorator()
        elif token.type == TokenType.LET or token.type == TokenType.VAR:
            return self.parse_variable_declaration(is_const=False)
        elif token.type == TokenType.CONST:
            return self.parse_variable_declaration(is_const=True)
        elif token.type == TokenType.PRINT:
            return self.parse_print()
        elif token.type == TokenType.IF:
            return self.parse_if()
        elif token.type == TokenType.WHILE:
            return self.parse_while()
        elif token.type == TokenType.FOR:
            return self.parse_for()
        elif token.type == TokenType.FUNC:
            return self.parse_function_def()
        elif token.type == TokenType.RETURN:
            return self.parse_return()
        elif token.type == TokenType.BREAK:
            self.advance()
            return BreakNode(line=token.line, column=token.column)
        elif token.type == TokenType.CONTINUE:
            self.advance()
            return ContinueNode(line=token.line, column=token.column)
        elif token.type == TokenType.CLASS:
            return self.parse_class_def()
        elif token.type == TokenType.TRY:
            return self.parse_try()
        elif token.type == TokenType.THROW:
            return self.parse_throw()
        elif token.type == TokenType.IMPORT:
            return self.parse_import()
        elif token.type == TokenType.MATCH:
            return self.parse_match()
        # ========== STRACT v5.0 Revolutionary Features ==========
        # Contractual Safety
        elif token.type == TokenType.TYPE:
            return self.parse_type_definition()
        elif token.type == TokenType.SANDBOX:
            return self.parse_sandbox()
        elif token.type == TokenType.INVARIANT:
            return self.parse_invariant()
        # AI-Native
        elif token.type == TokenType.TENSOR:
            return self.parse_tensor()
        elif token.type == TokenType.MODEL:
            return self.parse_model()
        elif token.type == TokenType.OPTIMIZE:
            return self.parse_optimize()
        elif token.type == TokenType.TRAIN:
            return self.parse_train()
        elif token.type == TokenType.PREDICT:
            return self.parse_predict()
        elif token.type == TokenType.HARDWARE:
            return self.parse_hardware()
        elif token.type == TokenType.GRADIENT:
            return self.parse_gradient()
        # Reactive & Temporal
        elif token.type == TokenType.STREAM:
            return self.parse_stream()
        elif token.type == TokenType.REACTIVE:
            return self.parse_reactive()
        elif token.type == TokenType.TEMPORAL:
            return self.parse_temporal()
        elif token.type == TokenType.WHEN:
            return self.parse_when()
        elif token.type == TokenType.OBSERVE:
            return self.parse_observe()
        elif token.type == TokenType.EMIT:
            return self.parse_emit()
        elif token.type == TokenType.EVERY:
            return self.parse_every()
        elif token.type == TokenType.AFTER:
            return self.parse_after()
        # ========== End of v5.0 Features ==========
        elif token.type == TokenType.IDENTIFIER:
            return self.parse_identifier_statement()
        elif token.type in (TokenType.INDENT, TokenType.DEDENT):
            self.advance()
            return None
        else:
            return self.parse_expression()
    
    def parse_decorator(self) -> DecoratorNode:
        token = self.advance()
        
        name = ""
        if self.match(TokenType.IDENTIFIER):
            name = self.advance().value
            while self.match(TokenType.DOT):
                self.advance()
                name += "." + self.expect(TokenType.IDENTIFIER, "Expected identifier after '.'").value
        
        args = []
        if self.match(TokenType.LPAREN):
            self.advance()
            if not self.match(TokenType.RPAREN):
                args.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    self.advance()
                    args.append(self.parse_expression())
            self.expect(TokenType.RPAREN, "Expected ')' after decorator arguments")
        
        self.skip_newlines()
        
        target = None
        if self.match(TokenType.AT):
            target = self.parse_decorator()
        elif self.match(TokenType.FUNC):
            target = self.parse_function_def()
        elif self.match(TokenType.CLASS):
            target = self.parse_class_def()
        
        return DecoratorNode(
            name=name,
            args=args,
            target=target,
            line=token.line,
            column=token.column
        )
    
    def parse_variable_declaration(self, is_const: bool) -> AssignNode:
        token = self.advance()
        name_token = self.expect(TokenType.IDENTIFIER, "Expected variable name")
        self.expect(TokenType.ASSIGN, "Expected '=' after variable name")
        value = self.parse_expression()
        
        return AssignNode(
            name=name_token.value,
            value=value,
            is_const=is_const,
            line=token.line,
            column=token.column
        )
    
    def parse_identifier_statement(self) -> ASTNode:
        expr = self.parse_expression()
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            value = self.parse_expression()
            
            if isinstance(expr, IdentifierNode):
                return AssignNode(
                    name=expr.name,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            elif isinstance(expr, IndexNode):
                return IndexAssignNode(
                    obj=expr.obj,
                    index=expr.index,
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
            else:
                self.error("Invalid assignment target")
        
        if self.match(TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN, 
                      TokenType.MULTIPLY_ASSIGN, TokenType.DIVIDE_ASSIGN):
            op_token = self.advance()
            value = self.parse_expression()
            
            if isinstance(expr, IdentifierNode):
                op_map = {
                    TokenType.PLUS_ASSIGN: '+=',
                    TokenType.MINUS_ASSIGN: '-=',
                    TokenType.MULTIPLY_ASSIGN: '*=',
                    TokenType.DIVIDE_ASSIGN: '/=',
                }
                return CompoundAssignNode(
                    name=expr.name,
                    operator=op_map[op_token.type],
                    value=value,
                    line=expr.line,
                    column=expr.column
                )
        
        return expr
    
    def parse_print(self) -> PrintNode:
        token = self.advance()
        
        expressions = []
        if not self.match(TokenType.NEWLINE, TokenType.EOF):
            expressions.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                self.advance()
                expressions.append(self.parse_expression())
        
        return PrintNode(expressions=expressions, line=token.line, column=token.column)
    
    def parse_if(self) -> IfNode:
        token = self.advance()
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after if condition")
        
        then_block = self.parse_block()
        elif_blocks = []
        else_block = []
        
        self.skip_newlines()
        
        while self.match(TokenType.ELIF):
            self.advance()
            elif_condition = self.parse_expression()
            self.expect(TokenType.COLON, "Expected ':' after elif condition")
            elif_body = self.parse_block()
            elif_blocks.append((elif_condition, elif_body))
            self.skip_newlines()
        
        if self.match(TokenType.ELSE):
            self.advance()
            self.expect(TokenType.COLON, "Expected ':' after else")
            else_block = self.parse_block()
        
        return IfNode(
            condition=condition,
            then_block=then_block,
            elif_blocks=elif_blocks,
            else_block=else_block,
            line=token.line,
            column=token.column
        )
    
    def parse_while(self) -> WhileNode:
        token = self.advance()
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after while condition")
        body = self.parse_block()
        
        return WhileNode(
            condition=condition,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_for(self) -> ForNode:
        token = self.advance()
        var_token = self.expect(TokenType.IDENTIFIER, "Expected variable name in for loop")
        self.expect(TokenType.IN, "Expected 'in' after variable in for loop")
        iterable = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after for loop declaration")
        body = self.parse_block()
        
        return ForNode(
            variable=var_token.value,
            iterable=iterable,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_function_def(self) -> FunctionDefNode:
        token = self.advance()
        name_token = self.expect(TokenType.IDENTIFIER, "Expected function name")
        self.expect(TokenType.LPAREN, "Expected '(' after function name")
        
        params = []
        defaults = []
        if not self.match(TokenType.RPAREN):
            param = self.expect(TokenType.IDENTIFIER, "Expected parameter name").value
            params.append(param)
            if self.match(TokenType.ASSIGN):
                self.advance()
                defaults.append(self.parse_expression())
            
            while self.match(TokenType.COMMA):
                self.advance()
                param = self.expect(TokenType.IDENTIFIER, "Expected parameter name").value
                params.append(param)
                if self.match(TokenType.ASSIGN):
                    self.advance()
                    defaults.append(self.parse_expression())
        
        self.expect(TokenType.RPAREN, "Expected ')' after parameters")
        self.expect(TokenType.COLON, "Expected ':' after function declaration")
        body = self.parse_block()
        
        return FunctionDefNode(
            name=name_token.value,
            params=params,
            defaults=defaults,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_class_def(self) -> ClassDefNode:
        token = self.advance()
        name_token = self.expect(TokenType.IDENTIFIER, "Expected class name")
        
        parent = None
        if self.match(TokenType.LPAREN):
            self.advance()
            if not self.match(TokenType.RPAREN):
                parent = self.expect(TokenType.IDENTIFIER, "Expected parent class name").value
            self.expect(TokenType.RPAREN, "Expected ')' after parent class")
        
        self.expect(TokenType.COLON, "Expected ':' after class declaration")
        
        methods = []
        properties = []
        
        self.skip_newlines()
        if self.match(TokenType.INDENT):
            self.advance()
            
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                
                if self.match(TokenType.FUNC):
                    methods.append(self.parse_function_def())
                elif self.match(TokenType.LET, TokenType.CONST, TokenType.VAR):
                    properties.append(self.parse_variable_declaration(
                        is_const=self.current().type == TokenType.CONST
                    ))
                else:
                    self.skip_newlines()
                    if self.match(TokenType.DEDENT, TokenType.EOF):
                        break
                    self.advance()
            
            if self.match(TokenType.DEDENT):
                self.advance()
        
        return ClassDefNode(
            name=name_token.value,
            parent=parent,
            methods=methods,
            properties=properties,
            line=token.line,
            column=token.column
        )
    
    def parse_try(self) -> TryNode:
        token = self.advance()
        self.expect(TokenType.COLON, "Expected ':' after try")
        try_block = self.parse_block()
        
        catch_var = "error"
        catch_block = []
        finally_block = []
        
        self.skip_newlines()
        if self.match(TokenType.CATCH):
            self.advance()
            if self.match(TokenType.IDENTIFIER):
                catch_var = self.advance().value
            self.expect(TokenType.COLON, "Expected ':' after catch")
            catch_block = self.parse_block()
        
        self.skip_newlines()
        if self.match(TokenType.FINALLY):
            self.advance()
            self.expect(TokenType.COLON, "Expected ':' after finally")
            finally_block = self.parse_block()
        
        return TryNode(
            try_block=try_block,
            catch_var=catch_var,
            catch_block=catch_block,
            finally_block=finally_block,
            line=token.line,
            column=token.column
        )
    
    def parse_throw(self) -> ThrowNode:
        token = self.advance()
        value = self.parse_expression()
        return ThrowNode(value=value, line=token.line, column=token.column)
    
    def parse_import(self) -> ImportNode:
        token = self.advance()
        
        names = []
        if self.match(TokenType.LBRACE):
            self.advance()
            names.append(self.expect(TokenType.IDENTIFIER, "Expected import name").value)
            while self.match(TokenType.COMMA):
                self.advance()
                names.append(self.expect(TokenType.IDENTIFIER, "Expected import name").value)
            self.expect(TokenType.RBRACE, "Expected '}' after import names")
            self.expect(TokenType.FROM, "Expected 'from' after import names")
        
        module = self.expect(TokenType.IDENTIFIER, "Expected module name").value
        while self.match(TokenType.DOT):
            self.advance()
            module += "." + self.expect(TokenType.IDENTIFIER, "Expected module name").value
        
        alias = None
        if self.match(TokenType.AS):
            self.advance()
            alias = self.expect(TokenType.IDENTIFIER, "Expected alias").value
        
        return ImportNode(module=module, alias=alias, names=names, line=token.line, column=token.column)
    
    def parse_match(self) -> MatchNode:
        token = self.advance()
        value = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after match value")
        
        cases = []
        default = []
        
        self.skip_newlines()
        if self.match(TokenType.INDENT):
            self.advance()
            
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                
                if self.match(TokenType.CASE):
                    self.advance()
                    case_value = self.parse_expression()
                    self.expect(TokenType.COLON, "Expected ':' after case value")
                    case_body = self.parse_block()
                    cases.append((case_value, case_body))
                elif self.match(TokenType.DEFAULT):
                    self.advance()
                    self.expect(TokenType.COLON, "Expected ':' after default")
                    default = self.parse_block()
                else:
                    self.skip_newlines()
                    if self.match(TokenType.DEDENT, TokenType.EOF):
                        break
                    self.advance()
            
            if self.match(TokenType.DEDENT):
                self.advance()
        
        return MatchNode(value=value, cases=cases, default=default, line=token.line, column=token.column)
    
    def parse_return(self) -> ReturnNode:
        token = self.advance()
        
        value = None
        if not self.match(TokenType.NEWLINE, TokenType.EOF, TokenType.DEDENT):
            value = self.parse_expression()
        
        return ReturnNode(value=value, line=token.line, column=token.column)
    
    def parse_block(self) -> List[ASTNode]:
        statements = []
        self.skip_newlines()
        
        if self.match(TokenType.INDENT):
            self.advance()
            
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                stmt = self.parse_statement()
                if stmt:
                    statements.append(stmt)
                self.skip_newlines()
            
            if self.match(TokenType.DEDENT):
                self.advance()
        else:
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
        
        return statements
    
    def parse_expression(self) -> ASTNode:
        if self.match(TokenType.LAMBDA):
            return self.parse_lambda()
        return self.parse_ternary()
    
    def parse_lambda(self) -> LambdaNode:
        token = self.advance()
        
        params = []
        if not self.match(TokenType.COLON, TokenType.ARROW):
            params.append(self.expect(TokenType.IDENTIFIER, "Expected parameter name").value)
            while self.match(TokenType.COMMA):
                self.advance()
                params.append(self.expect(TokenType.IDENTIFIER, "Expected parameter name").value)
        
        if self.match(TokenType.COLON):
            self.advance()
        elif self.match(TokenType.ARROW):
            self.advance()
        
        body = self.parse_expression()
        
        return LambdaNode(params=params, body=body, line=token.line, column=token.column)
    
    def parse_ternary(self) -> ASTNode:
        condition = self.parse_or()
        
        if self.match(TokenType.IF):
            self.advance()
            then_expr = self.parse_or()
            self.expect(TokenType.ELSE, "Expected 'else' in ternary expression")
            else_expr = self.parse_ternary()
            return IfNode(
                condition=condition,
                then_block=[then_expr],
                else_block=[else_expr],
                line=condition.line,
                column=condition.column
            )
        
        return condition
    
    def parse_or(self) -> ASTNode:
        left = self.parse_and()
        
        while self.match(TokenType.OR):
            op = self.advance()
            right = self.parse_and()
            left = BinaryOpNode(left=left, operator='or', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_and(self) -> ASTNode:
        left = self.parse_not()
        
        while self.match(TokenType.AND):
            op = self.advance()
            right = self.parse_not()
            left = BinaryOpNode(left=left, operator='and', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_not(self) -> ASTNode:
        if self.match(TokenType.NOT):
            op = self.advance()
            operand = self.parse_not()
            return UnaryOpNode(operator='not', operand=operand, line=op.line, column=op.column)
        
        return self.parse_comparison()
    
    def parse_comparison(self) -> ASTNode:
        left = self.parse_additive()
        
        while self.match(TokenType.EQUAL, TokenType.NOT_EQUAL, TokenType.LESS,
                        TokenType.GREATER, TokenType.LESS_EQUAL, TokenType.GREATER_EQUAL,
                        TokenType.IN):
            op = self.advance()
            right = self.parse_additive()
            op_str = {
                TokenType.EQUAL: '==',
                TokenType.NOT_EQUAL: '!=',
                TokenType.LESS: '<',
                TokenType.GREATER: '>',
                TokenType.LESS_EQUAL: '<=',
                TokenType.GREATER_EQUAL: '>=',
                TokenType.IN: 'in',
            }[op.type]
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_additive(self) -> ASTNode:
        left = self.parse_multiplicative()
        
        while self.match(TokenType.PLUS, TokenType.MINUS):
            op = self.advance()
            right = self.parse_multiplicative()
            op_str = '+' if op.type == TokenType.PLUS else '-'
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_multiplicative(self) -> ASTNode:
        left = self.parse_power()
        
        while self.match(TokenType.MULTIPLY, TokenType.DIVIDE, TokenType.FLOOR_DIVIDE, TokenType.MODULO):
            op = self.advance()
            right = self.parse_power()
            op_str = {
                TokenType.MULTIPLY: '*',
                TokenType.DIVIDE: '/',
                TokenType.FLOOR_DIVIDE: '//',
                TokenType.MODULO: '%',
            }[op.type]
            left = BinaryOpNode(left=left, operator=op_str, right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_power(self) -> ASTNode:
        left = self.parse_unary()
        
        if self.match(TokenType.POWER):
            op = self.advance()
            right = self.parse_power()
            left = BinaryOpNode(left=left, operator='**', right=right, line=op.line, column=op.column)
        
        return left
    
    def parse_unary(self) -> ASTNode:
        if self.match(TokenType.MINUS):
            op = self.advance()
            operand = self.parse_unary()
            return UnaryOpNode(operator='-', operand=operand, line=op.line, column=op.column)
        if self.match(TokenType.PLUS):
            op = self.advance()
            operand = self.parse_unary()
            return UnaryOpNode(operator='+', operand=operand, line=op.line, column=op.column)
        
        return self.parse_postfix()
    
    def parse_postfix(self) -> ASTNode:
        left = self.parse_primary()
        
        while True:
            if self.match(TokenType.LPAREN):
                self.advance()
                args = []
                kwargs = {}
                if not self.match(TokenType.RPAREN):
                    arg = self.parse_expression()
                    if self.match(TokenType.ASSIGN) and isinstance(arg, IdentifierNode):
                        self.advance()
                        kwargs[arg.name] = self.parse_expression()
                    else:
                        args.append(arg)
                    
                    while self.match(TokenType.COMMA):
                        self.advance()
                        arg = self.parse_expression()
                        if self.match(TokenType.ASSIGN) and isinstance(arg, IdentifierNode):
                            self.advance()
                            kwargs[arg.name] = self.parse_expression()
                        else:
                            args.append(arg)
                
                self.expect(TokenType.RPAREN, "Expected ')' after arguments")
                
                if isinstance(left, IdentifierNode):
                    left = FunctionCallNode(name=left.name, args=args, kwargs=kwargs, line=left.line, column=left.column)
                elif isinstance(left, PropertyAccessNode):
                    left = MethodCallNode(obj=left.obj, method=left.property, args=args, line=left.line, column=left.column)
                else:
                    self.error("Invalid function call")
            
            elif self.match(TokenType.LBRACKET):
                self.advance()
                
                start = None
                end = None
                step = None
                is_slice = False
                
                if not self.match(TokenType.COLON, TokenType.RBRACKET):
                    start = self.parse_expression()
                
                if self.match(TokenType.COLON):
                    is_slice = True
                    self.advance()
                    if not self.match(TokenType.COLON, TokenType.RBRACKET):
                        end = self.parse_expression()
                    if self.match(TokenType.COLON):
                        self.advance()
                        if not self.match(TokenType.RBRACKET):
                            step = self.parse_expression()
                
                self.expect(TokenType.RBRACKET, "Expected ']' after index")
                
                if is_slice:
                    left = SliceNode(obj=left, start=start, end=end, step=step, line=left.line, column=left.column)
                else:
                    left = IndexNode(obj=left, index=start, line=left.line, column=left.column)
            
            elif self.match(TokenType.DOT):
                self.advance()
                prop_token = self.expect(TokenType.IDENTIFIER, "Expected property name")
                
                if self.match(TokenType.LPAREN):
                    self.advance()
                    args = []
                    if not self.match(TokenType.RPAREN):
                        args.append(self.parse_expression())
                        while self.match(TokenType.COMMA):
                            self.advance()
                            args.append(self.parse_expression())
                    self.expect(TokenType.RPAREN, "Expected ')' after method arguments")
                    left = MethodCallNode(obj=left, method=prop_token.value, args=args, line=left.line, column=left.column)
                else:
                    left = PropertyAccessNode(obj=left, property=prop_token.value, line=left.line, column=left.column)
            
            else:
                break
        
        return left
    
    def parse_primary(self) -> ASTNode:
        token = self.current()
        
        if token.type == TokenType.INTEGER or token.type == TokenType.FLOAT:
            self.advance()
            return NumberNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.STRING:
            self.advance()
            return StringNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.BOOLEAN:
            self.advance()
            return BooleanNode(value=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.NULL:
            self.advance()
            return NullNode(line=token.line, column=token.column)
        
        elif token.type == TokenType.IDENTIFIER:
            self.advance()
            return IdentifierNode(name=token.value, line=token.line, column=token.column)
        
        elif token.type == TokenType.RANGE:
            return self.parse_range()
        
        elif token.type == TokenType.INPUT:
            return self.parse_input()
        
        elif token.type == TokenType.NEW:
            return self.parse_new()
        
        elif token.type == TokenType.LPAREN:
            self.advance()
            expr = self.parse_expression()
            self.expect(TokenType.RPAREN, "Expected ')' after expression")
            return expr
        
        elif token.type == TokenType.LBRACKET:
            return self.parse_list()
        
        elif token.type == TokenType.LBRACE:
            return self.parse_dict()
        
        else:
            self.error(f"Unexpected token: {token.type.name}")
            raise ParserError(f"Unexpected token: {token.type.name}", token)
    
    def parse_range(self) -> RangeNode:
        token = self.advance()
        self.expect(TokenType.LPAREN, "Expected '(' after range")
        
        start = self.parse_expression()
        
        if self.match(TokenType.RPAREN):
            self.advance()
            return RangeNode(start=NumberNode(value=0), end=start, line=token.line, column=token.column)
        
        self.expect(TokenType.COMMA, "Expected ',' in range")
        end = self.parse_expression()
        
        step = None
        if self.match(TokenType.COMMA):
            self.advance()
            step = self.parse_expression()
        
        self.expect(TokenType.RPAREN, "Expected ')' after range")
        
        return RangeNode(start=start, end=end, step=step, line=token.line, column=token.column)
    
    def parse_input(self) -> InputNode:
        token = self.advance()
        self.expect(TokenType.LPAREN, "Expected '(' after input")
        
        prompt = None
        if not self.match(TokenType.RPAREN):
            prompt = self.parse_expression()
        
        self.expect(TokenType.RPAREN, "Expected ')' after input")
        
        return InputNode(prompt=prompt, line=token.line, column=token.column)
    
    def parse_new(self) -> NewNode:
        token = self.advance()
        class_name = self.expect(TokenType.IDENTIFIER, "Expected class name after 'new'").value
        
        args = []
        if self.match(TokenType.LPAREN):
            self.advance()
            if not self.match(TokenType.RPAREN):
                args.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    self.advance()
                    args.append(self.parse_expression())
            self.expect(TokenType.RPAREN, "Expected ')' after constructor arguments")
        
        return NewNode(class_name=class_name, args=args, line=token.line, column=token.column)
    
    def parse_list(self) -> ListNode:
        token = self.advance()
        
        elements = []
        if not self.match(TokenType.RBRACKET):
            elements.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                self.advance()
                if self.match(TokenType.RBRACKET):
                    break
                elements.append(self.parse_expression())
        
        self.expect(TokenType.RBRACKET, "Expected ']' after list elements")
        
        return ListNode(elements=elements, line=token.line, column=token.column)
    
    def parse_dict(self) -> DictNode:
        token = self.advance()
        
        pairs = []
        if not self.match(TokenType.RBRACE):
            key = self.parse_expression()
            self.expect(TokenType.COLON, "Expected ':' after dict key")
            value = self.parse_expression()
            pairs.append((key, value))
            
            while self.match(TokenType.COMMA):
                self.advance()
                if self.match(TokenType.RBRACE):
                    break
                key = self.parse_expression()
                self.expect(TokenType.COLON, "Expected ':' after dict key")
                value = self.parse_expression()
                pairs.append((key, value))
        
        self.expect(TokenType.RBRACE, "Expected '}' after dict pairs")
        
        return DictNode(pairs=pairs, line=token.line, column=token.column)

    # ========================================================================
    # STRACT v5.0 REVOLUTIONARY PARSING METHODS
    # ========================================================================

    # ==================== Contractual Safety Parsing ====================
    
    def parse_type_definition(self) -> RefinementTypeNode:
        """Parse: type PositiveInt: Int where value > 0"""
        token = self.advance()  # consume 'type'
        name = self.expect(TokenType.IDENTIFIER, "Expected type name").value
        self.expect(TokenType.COLON, "Expected ':' after type name")
        base_type = self.expect(TokenType.IDENTIFIER, "Expected base type").value
        
        constraint = None
        if self.match(TokenType.WHERE):
            self.advance()
            constraint = self.parse_expression()
        
        return RefinementTypeNode(
            name=name,
            base_type=base_type,
            constraint=constraint,
            line=token.line,
            column=token.column
        )
    
    def parse_sandbox(self) -> SandboxNode:
        """Parse: sandbox [capability1, capability2]: block"""
        token = self.advance()  # consume 'sandbox'
        
        capabilities = []
        if self.match(TokenType.LBRACKET):
            self.advance()
            if not self.match(TokenType.RBRACKET):
                capabilities.append(self.expect(TokenType.IDENTIFIER, "Expected capability").value)
                while self.match(TokenType.COMMA):
                    self.advance()
                    capabilities.append(self.expect(TokenType.IDENTIFIER, "Expected capability").value)
            self.expect(TokenType.RBRACKET, "Expected ']' after capabilities")
        
        self.expect(TokenType.COLON, "Expected ':' after sandbox declaration")
        body = self.parse_block()
        
        return SandboxNode(
            capabilities=capabilities,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_invariant(self) -> InvariantNode:
        """Parse: invariant condition"""
        token = self.advance()  # consume 'invariant'
        condition = self.parse_expression()
        
        return InvariantNode(
            condition=condition,
            line=token.line,
            column=token.column
        )

    # ==================== AI-Native Language Parsing ====================
    
    def parse_tensor(self) -> TensorNode:
        """Parse: tensor x[3, 4] on gpu requires_grad"""
        token = self.advance()  # consume 'tensor'
        name = self.expect(TokenType.IDENTIFIER, "Expected tensor name").value
        
        shape = []
        if self.match(TokenType.LBRACKET):
            self.advance()
            if not self.match(TokenType.RBRACKET):
                shape.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    self.advance()
                    shape.append(self.parse_expression())
            self.expect(TokenType.RBRACKET, "Expected ']' after tensor shape")
        
        dtype = "float32"
        device = "auto"
        requires_grad = False
        value = None
        
        while self.match(TokenType.IDENTIFIER, TokenType.GPU, TokenType.CPU, TokenType.TPU, TokenType.GRADIENT):
            if self.current().type == TokenType.GPU:
                self.advance()
                device = "gpu"
            elif self.current().type == TokenType.CPU:
                self.advance()
                device = "cpu"
            elif self.current().type == TokenType.TPU:
                self.advance()
                device = "tpu"
            elif self.current().type == TokenType.GRADIENT:
                self.advance()
                requires_grad = True
            elif self.current().value == "float32" or self.current().value == "float64" or self.current().value == "int32":
                dtype = self.advance().value
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            value = self.parse_expression()
        
        return TensorNode(
            name=name,
            shape=shape,
            dtype=dtype,
            device=device,
            requires_grad=requires_grad,
            value=value,
            line=token.line,
            column=token.column
        )
    
    def parse_model(self) -> ModelNode:
        """Parse: model MyNet: layers = [...] optimizer = 'adam' loss = 'mse'"""
        token = self.advance()  # consume 'model'
        name = self.expect(TokenType.IDENTIFIER, "Expected model name").value
        self.expect(TokenType.COLON, "Expected ':' after model name")
        
        layers = []
        optimizer = None
        loss = None
        
        self.skip_newlines()
        if self.match(TokenType.INDENT):
            self.advance()
            while not self.match(TokenType.DEDENT, TokenType.EOF):
                self.skip_newlines()
                if self.match(TokenType.DEDENT, TokenType.EOF):
                    break
                layer = self.parse_expression()
                layers.append(layer)
                self.skip_newlines()
            if self.match(TokenType.DEDENT):
                self.advance()
        
        return ModelNode(
            name=name,
            layers=layers,
            optimizer=optimizer,
            loss=loss,
            line=token.line,
            column=token.column
        )
    
    def parse_optimize(self) -> OptimizeDirectiveNode:
        """Parse: optimize model for accuracy using data"""
        token = self.advance()  # consume 'optimize'
        target = self.parse_expression()
        
        goal = "accuracy"
        data = None
        config = {}
        
        if self.match(TokenType.FOR):
            self.advance()
            goal = self.expect(TokenType.IDENTIFIER, "Expected optimization goal").value
        
        if self.match(TokenType.USING):
            self.advance()
            data = self.parse_expression()
        
        return OptimizeDirectiveNode(
            target=target,
            goal=goal,
            data=data,
            config=config,
            line=token.line,
            column=token.column
        )
    
    def parse_train(self) -> TrainNode:
        """Parse: train model using data epochs=10"""
        token = self.advance()  # consume 'train'
        model = self.parse_expression()
        
        data = None
        epochs = 1
        config = {}
        
        if self.match(TokenType.USING):
            self.advance()
            data = self.parse_expression()
        
        # Parse optional config
        while self.match(TokenType.IDENTIFIER):
            key = self.current().value
            if key == "epochs":
                self.advance()
                self.expect(TokenType.ASSIGN, "Expected '=' after 'epochs'")
                epochs = int(self.expect(TokenType.INTEGER, "Expected integer for epochs").value)
            else:
                break
        
        return TrainNode(
            model=model,
            data=data,
            epochs=epochs,
            config=config,
            line=token.line,
            column=token.column
        )
    
    def parse_predict(self) -> PredictNode:
        """Parse: predict model using input"""
        token = self.advance()  # consume 'predict'
        model = self.parse_expression()
        
        input_data = None
        if self.match(TokenType.USING):
            self.advance()
            input_data = self.parse_expression()
        
        return PredictNode(
            model=model,
            input_data=input_data,
            line=token.line,
            column=token.column
        )
    
    def parse_hardware(self) -> HardwareNode:
        """Parse: hardware gpu: block"""
        token = self.advance()  # consume 'hardware'
        
        device = "auto"
        if self.match(TokenType.GPU):
            self.advance()
            device = "gpu"
        elif self.match(TokenType.CPU):
            self.advance()
            device = "cpu"
        elif self.match(TokenType.TPU):
            self.advance()
            device = "tpu"
        elif self.match(TokenType.IDENTIFIER):
            device = self.advance().value
        
        self.expect(TokenType.COLON, "Expected ':' after hardware specification")
        body = self.parse_block()
        
        return HardwareNode(
            device=device,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_gradient(self) -> GradientNode:
        """Parse: gradient expr with respect to [x, y]"""
        token = self.advance()  # consume 'gradient'
        expression = self.parse_expression()
        
        with_respect_to = []
        # Look for "with" keyword (using identifier)
        if self.match(TokenType.IDENTIFIER) and self.current().value == "with":
            self.advance()
            # Expect "respect" and "to"
            if self.match(TokenType.IDENTIFIER) and self.current().value == "respect":
                self.advance()
            if self.match(TokenType.IDENTIFIER) and self.current().value == "to":
                self.advance()
            
            if self.match(TokenType.LBRACKET):
                self.advance()
                if not self.match(TokenType.RBRACKET):
                    with_respect_to.append(self.expect(TokenType.IDENTIFIER, "Expected variable name").value)
                    while self.match(TokenType.COMMA):
                        self.advance()
                        with_respect_to.append(self.expect(TokenType.IDENTIFIER, "Expected variable name").value)
                self.expect(TokenType.RBRACKET, "Expected ']'")
            else:
                with_respect_to.append(self.expect(TokenType.IDENTIFIER, "Expected variable name").value)
        
        return GradientNode(
            expression=expression,
            with_respect_to=with_respect_to,
            line=token.line,
            column=token.column
        )

    # ==================== Reactive & Temporal Parsing ====================
    
    def parse_stream(self) -> ReactiveStreamNode:
        """Parse: stream events = source |> transform1 |> transform2"""
        token = self.advance()  # consume 'stream'
        name = self.expect(TokenType.IDENTIFIER, "Expected stream name").value
        
        source = None
        transformations = []
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            source = self.parse_expression()
            
            # Parse pipe chain
            while self.match(TokenType.PIPE):
                self.advance()
                transformations.append(self.parse_expression())
        
        return ReactiveStreamNode(
            name=name,
            source=source,
            transformations=transformations,
            line=token.line,
            column=token.column
        )
    
    def parse_reactive(self) -> ReactiveStreamNode:
        """Parse: reactive var = expr"""
        token = self.advance()  # consume 'reactive'
        name = self.expect(TokenType.IDENTIFIER, "Expected variable name").value
        
        source = None
        if self.match(TokenType.ASSIGN):
            self.advance()
            source = self.parse_expression()
        
        return ReactiveStreamNode(
            name=name,
            source=source,
            transformations=[],
            line=token.line,
            column=token.column
        )
    
    def parse_temporal(self) -> TemporalVariableNode:
        """Parse: temporal counter = 0 every 1s: counter + 1"""
        token = self.advance()  # consume 'temporal'
        name = self.expect(TokenType.IDENTIFIER, "Expected variable name").value
        
        initial_value = None
        update_rule = None
        interval = None
        
        if self.match(TokenType.ASSIGN):
            self.advance()
            initial_value = self.parse_expression()
        
        if self.match(TokenType.EVERY):
            self.advance()
            interval = self.parse_expression()
            self.expect(TokenType.COLON, "Expected ':' after interval")
            update_rule = self.parse_expression()
        
        return TemporalVariableNode(
            name=name,
            initial_value=initial_value,
            update_rule=update_rule,
            interval=interval,
            line=token.line,
            column=token.column
        )
    
    def parse_when(self) -> WhenNode:
        """Parse: when condition: action"""
        token = self.advance()  # consume 'when'
        condition = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after when condition")
        body = self.parse_block()
        
        return WhenNode(
            condition=condition,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_observe(self) -> ObserveNode:
        """Parse: observe variable: handler"""
        token = self.advance()  # consume 'observe'
        target = self.parse_expression()
        
        handler = None
        if self.match(TokenType.COLON):
            self.advance()
            self.skip_newlines()
            if self.match(TokenType.INDENT):
                self.advance()
                handler = self.parse_statement()
                while self.match(TokenType.DEDENT):
                    self.advance()
            else:
                handler = self.parse_expression()
        
        return ObserveNode(
            target=target,
            handler=handler,
            line=token.line,
            column=token.column
        )
    
    def parse_emit(self) -> EmitNode:
        """Parse: emit stream value"""
        token = self.advance()  # consume 'emit'
        stream = self.parse_expression()
        
        value = None
        if not self.match(TokenType.NEWLINE, TokenType.EOF):
            value = self.parse_expression()
        
        return EmitNode(
            stream=stream,
            value=value,
            line=token.line,
            column=token.column
        )
    
    def parse_every(self) -> EveryNode:
        """Parse: every 1s: action"""
        token = self.advance()  # consume 'every'
        interval = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after interval")
        body = self.parse_block()
        
        return EveryNode(
            interval=interval,
            body=body,
            line=token.line,
            column=token.column
        )
    
    def parse_after(self) -> AfterNode:
        """Parse: after 5s: action"""
        token = self.advance()  # consume 'after'
        delay = self.parse_expression()
        self.expect(TokenType.COLON, "Expected ':' after delay")
        body = self.parse_block()
        
        return AfterNode(
            delay=delay,
            body=body,
            line=token.line,
            column=token.column
        )

    # ==================== Contract-Enhanced Function Parsing ====================
    
    def parse_contracted_function(self) -> ContractedFunctionNode:
        """Parse function with requires/ensures contracts"""
        token = self.advance()  # consume 'func'
        name = self.expect(TokenType.IDENTIFIER, "Expected function name").value
        
        self.expect(TokenType.LPAREN, "Expected '(' after function name")
        params = []
        param_types = {}
        
        if not self.match(TokenType.RPAREN):
            param = self.expect(TokenType.IDENTIFIER, "Expected parameter name").value
            params.append(param)
            if self.match(TokenType.COLON):
                self.advance()
                param_types[param] = self.expect(TokenType.IDENTIFIER, "Expected type name").value
            
            while self.match(TokenType.COMMA):
                self.advance()
                param = self.expect(TokenType.IDENTIFIER, "Expected parameter name").value
                params.append(param)
                if self.match(TokenType.COLON):
                    self.advance()
                    param_types[param] = self.expect(TokenType.IDENTIFIER, "Expected type name").value
        
        self.expect(TokenType.RPAREN, "Expected ')' after parameters")
        
        return_type = None
        if self.match(TokenType.ARROW):
            self.advance()
            return_type = self.expect(TokenType.IDENTIFIER, "Expected return type").value
        
        requires = []
        ensures = []
        
        # Parse contracts
        self.skip_newlines()
        while self.match(TokenType.REQUIRES, TokenType.ENSURES):
            if self.match(TokenType.REQUIRES):
                self.advance()
                requires.append(self.parse_expression())
            elif self.match(TokenType.ENSURES):
                self.advance()
                ensures.append(self.parse_expression())
            self.skip_newlines()
        
        self.expect(TokenType.COLON, "Expected ':' before function body")
        body = self.parse_block()
        
        return ContractedFunctionNode(
            name=name,
            params=params,
            param_types=param_types,
            return_type=return_type,
            requires=requires,
            ensures=ensures,
            body=body,
            line=token.line,
            column=token.column
        )


# ============================================================================
# PART 5: RUNTIME ENVIRONMENT
# ============================================================================

class RuntimeError(Exception):
    def __init__(self, message: str, line: int = 0, column: int = 0):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Runtime Error at line {line}: {message}")


class BreakException(Exception):
    pass


class ContinueException(Exception):
    pass


class ReturnException(Exception):
    def __init__(self, value: Any):
        self.value = value
        super().__init__()


class ThrowException(Exception):
    def __init__(self, value: Any, line: int = 0):
        self.value = value
        self.line = line
        super().__init__(str(value))


class STRACTClass:
    def __init__(self, name: str, parent: Optional['STRACTClass'], methods: Dict, properties: Dict):
        self.name = name
        self.parent = parent
        self.methods = methods
        self.properties = properties


class STRACTInstance:
    def __init__(self, klass: STRACTClass):
        self.klass = klass
        self.properties = dict(klass.properties)
    
    def get(self, name: str) -> Any:
        if name in self.properties:
            return self.properties[name]
        if name in self.klass.methods:
            return self.klass.methods[name]
        if self.klass.parent:
            parent_instance = STRACTInstance(self.klass.parent)
            return parent_instance.get(name)
        raise RuntimeError(f"Property '{name}' not found")
    
    def set(self, name: str, value: Any):
        self.properties[name] = value


class STRACTFunction:
    def __init__(self, node: FunctionDefNode, closure: 'Environment'):
        self.node = node
        self.closure = closure
        self.name = node.name


# ============================================================================
# STRACT v5.0 REVOLUTIONARY RUNTIME CLASSES
# ============================================================================

class STRACTTensor:
    """Tensor type with shape, device, and gradient support for AI-native programming"""
    def __init__(self, data: Any = None, shape: List[int] = None, dtype: str = "float32", 
                 device: str = "cpu", requires_grad: bool = False):
        self.shape = shape or []
        self.dtype = dtype
        self.device = device
        self.requires_grad = requires_grad
        self.grad = None
        
        if data is not None:
            self.data = data
        else:
            import math
            size = 1
            for dim in self.shape:
                size *= dim
            self.data = [0.0] * size
    
    def __repr__(self):
        return f"STRACTTensor(shape={self.shape}, dtype={self.dtype}, device={self.device})"
    
    def __add__(self, other):
        if isinstance(other, STRACTTensor):
            if self.shape != other.shape:
                raise RuntimeError(f"Shape mismatch: {self.shape} vs {other.shape}")
            result_data = [a + b for a, b in zip(self.data, other.data)]
            return STRACTTensor(data=result_data, shape=self.shape[:], dtype=self.dtype, device=self.device)
        result_data = [x + other for x in self.data]
        return STRACTTensor(data=result_data, shape=self.shape[:], dtype=self.dtype, device=self.device)
    
    def __mul__(self, other):
        if isinstance(other, STRACTTensor):
            if self.shape != other.shape:
                raise RuntimeError(f"Shape mismatch: {self.shape} vs {other.shape}")
            result_data = [a * b for a, b in zip(self.data, other.data)]
            return STRACTTensor(data=result_data, shape=self.shape[:], dtype=self.dtype, device=self.device)
        result_data = [x * other for x in self.data]
        return STRACTTensor(data=result_data, shape=self.shape[:], dtype=self.dtype, device=self.device)
    
    def sum(self):
        return sum(self.data)
    
    def mean(self):
        return sum(self.data) / len(self.data) if self.data else 0.0
    
    def to(self, device: str):
        self.device = device
        return self
    
    def backward(self):
        if self.requires_grad:
            self.grad = STRACTTensor(data=[1.0] * len(self.data), shape=self.shape[:], dtype=self.dtype)


class STRACTStream:
    """Reactive stream type for reactive programming paradigm"""
    def __init__(self, name: str = "", initial_value: Any = None):
        self.name = name
        self.value = initial_value
        self.subscribers: List[Callable] = []
        self.transformations: List[Callable] = []
        self.history: List[Any] = []
    
    def __repr__(self):
        return f"STRACTStream(name='{self.name}', value={self.value})"
    
    def emit(self, value: Any):
        transformed_value = value
        for transform in self.transformations:
            transformed_value = transform(transformed_value)
        self.value = transformed_value
        self.history.append(transformed_value)
        for subscriber in self.subscribers:
            subscriber(transformed_value)
    
    def subscribe(self, callback: Callable):
        self.subscribers.append(callback)
    
    def unsubscribe(self, callback: Callable):
        if callback in self.subscribers:
            self.subscribers.remove(callback)
    
    def map(self, transform: Callable):
        new_stream = STRACTStream(name=f"{self.name}_mapped")
        new_stream.transformations = self.transformations + [transform]
        self.subscribe(lambda v: new_stream.emit(v))
        return new_stream
    
    def filter(self, predicate: Callable):
        new_stream = STRACTStream(name=f"{self.name}_filtered")
        def filter_fn(v):
            if predicate(v):
                new_stream.emit(v)
        self.subscribe(filter_fn)
        return new_stream


class STRACTRefinementType:
    """Refinement type with constraint validation for contractual safety"""
    def __init__(self, name: str, base_type: str, constraint: Callable = None):
        self.name = name
        self.base_type = base_type
        self.constraint = constraint
    
    def __repr__(self):
        return f"STRACTRefinementType({self.name}: {self.base_type})"
    
    def validate(self, value: Any) -> bool:
        type_valid = True
        if self.base_type == "Int":
            type_valid = isinstance(value, int)
        elif self.base_type == "Float":
            type_valid = isinstance(value, (int, float))
        elif self.base_type == "String":
            type_valid = isinstance(value, str)
        elif self.base_type == "Bool":
            type_valid = isinstance(value, bool)
        elif self.base_type == "List":
            type_valid = isinstance(value, list)
        elif self.base_type == "Dict":
            type_valid = isinstance(value, dict)
        
        if not type_valid:
            return False
        
        if self.constraint:
            return self.constraint(value)
        return True
    
    def create(self, value: Any) -> Any:
        if not self.validate(value):
            raise RuntimeError(f"Value {value} does not satisfy refinement type {self.name}")
        return value


class STRACTContract:
    """Contract with pre/post conditions for design by contract"""
    def __init__(self, requires: List[Callable] = None, ensures: List[Callable] = None):
        self.requires = requires or []
        self.ensures = ensures or []
    
    def __repr__(self):
        return f"STRACTContract(requires={len(self.requires)}, ensures={len(self.ensures)})"
    
    def check_preconditions(self, *args, **kwargs) -> bool:
        for req in self.requires:
            if not req(*args, **kwargs):
                return False
        return True
    
    def check_postconditions(self, result: Any, *args, **kwargs) -> bool:
        for ens in self.ensures:
            if not ens(result, *args, **kwargs):
                return False
        return True


class STRACTModel:
    """AI Model structure for AI-native programming"""
    def __init__(self, name: str, layers: List = None, optimizer: str = None, loss: str = None):
        self.name = name
        self.layers = layers or []
        self.optimizer = optimizer
        self.loss = loss
        self.trained = False
        self.weights = {}
    
    def __repr__(self):
        return f"STRACTModel(name='{self.name}', layers={len(self.layers)}, trained={self.trained})"
    
    def forward(self, input_data):
        result = input_data
        for layer in self.layers:
            if callable(layer):
                result = layer(result)
        return result
    
    def train(self, data, epochs: int = 1):
        self.trained = True
        return {"epochs": epochs, "status": "completed"}
    
    def predict(self, input_data):
        return self.forward(input_data)


class Environment:
    def __init__(self, parent: Optional['Environment'] = None):
        self.variables: Dict[str, Any] = {}
        self.constants: Set[str] = set()
        self.parent = parent
    
    def define(self, name: str, value: Any, is_const: bool = False):
        self.variables[name] = value
        if is_const:
            self.constants.add(name)
    
    def get(self, name: str) -> Any:
        if name in self.variables:
            return self.variables[name]
        if self.parent:
            return self.parent.get(name)
        raise RuntimeError(f"Undefined variable: '{name}'")
    
    def set(self, name: str, value: Any):
        if name in self.variables:
            if name in self.constants:
                raise RuntimeError(f"Cannot reassign constant: '{name}'")
            self.variables[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        raise RuntimeError(f"Undefined variable: '{name}'")
    
    def exists(self, name: str) -> bool:
        if name in self.variables:
            return True
        if self.parent:
            return self.parent.exists(name)
        return False


# ============================================================================
# PART 6: INTERPRETER
# ============================================================================

class Interpreter:
    def __init__(self):
        self.global_env = Environment()
        self.functions: Dict[str, FunctionDefNode] = {}
        self.classes: Dict[str, STRACTClass] = {}
        self.modules: Dict[str, Dict] = {}
        self.setup_builtins()
    
    def setup_builtins(self):
        self.builtins = {
            'len': lambda args: len(args[0]) if len(args) == 1 else self._error("len() takes 1 argument"),
            'str': lambda args: self.to_string(args[0]) if len(args) == 1 else self._error("str() takes 1 argument"),
            'int': lambda args: int(float(args[0])) if len(args) == 1 else self._error("int() takes 1 argument"),
            'float': lambda args: float(args[0]) if len(args) == 1 else self._error("float() takes 1 argument"),
            'bool': lambda args: self.is_truthy(args[0]) if len(args) == 1 else self._error("bool() takes 1 argument"),
            'type': lambda args: self.get_type(args[0]) if len(args) == 1 else self._error("type() takes 1 argument"),
            'abs': lambda args: abs(args[0]) if len(args) == 1 else self._error("abs() takes 1 argument"),
            'min': lambda args: min(args[0]) if len(args) == 1 and isinstance(args[0], list) else min(args),
            'max': lambda args: max(args[0]) if len(args) == 1 and isinstance(args[0], list) else max(args),
            'sum': lambda args: sum(args[0]) if len(args) == 1 else self._error("sum() takes 1 argument"),
            'round': lambda args: round(args[0], int(args[1])) if len(args) == 2 else round(args[0]) if len(args) == 1 else self._error("round() takes 1 or 2 arguments"),
            'sorted': lambda args: sorted(args[0]) if len(args) == 1 else self._error("sorted() takes 1 argument"),
            'reversed': lambda args: list(reversed(args[0])) if len(args) == 1 else self._error("reversed() takes 1 argument"),
            'list': lambda args: list(args[0]) if len(args) == 1 else [] if len(args) == 0 else self._error("list() takes 0 or 1 argument"),
            'dict': lambda args: dict() if len(args) == 0 else self._error("dict() takes 0 arguments"),
            'set': lambda args: set(args[0]) if len(args) == 1 else set() if len(args) == 0 else self._error("set() takes 0 or 1 argument"),
            'tuple': lambda args: tuple(args[0]) if len(args) == 1 else tuple() if len(args) == 0 else self._error("tuple() takes 0 or 1 argument"),
            'enumerate': lambda args: list(enumerate(args[0])) if len(args) == 1 else self._error("enumerate() takes 1 argument"),
            'zip': lambda args: list(zip(*args)) if len(args) >= 2 else self._error("zip() takes at least 2 arguments"),
            'map': lambda args: list(map(lambda x: self.call_function(args[0], [x]), args[1])) if len(args) == 2 else self._error("map() takes 2 arguments"),
            'filter': lambda args: list(filter(lambda x: self.is_truthy(self.call_function(args[0], [x])), args[1])) if len(args) == 2 else self._error("filter() takes 2 arguments"),
            'reduce': lambda args: self.builtin_reduce(args),
            'any': lambda args: any(self.is_truthy(x) for x in args[0]) if len(args) == 1 else self._error("any() takes 1 argument"),
            'all': lambda args: all(self.is_truthy(x) for x in args[0]) if len(args) == 1 else self._error("all() takes 1 argument"),
            'chr': lambda args: chr(int(args[0])) if len(args) == 1 else self._error("chr() takes 1 argument"),
            'ord': lambda args: ord(str(args[0])[0]) if len(args) == 1 else self._error("ord() takes 1 argument"),
            'hex': lambda args: hex(int(args[0])) if len(args) == 1 else self._error("hex() takes 1 argument"),
            'bin': lambda args: bin(int(args[0])) if len(args) == 1 else self._error("bin() takes 1 argument"),
            'oct': lambda args: oct(int(args[0])) if len(args) == 1 else self._error("oct() takes 1 argument"),
            'pow': lambda args: pow(args[0], args[1], args[2]) if len(args) == 3 else pow(args[0], args[1]) if len(args) == 2 else self._error("pow() takes 2 or 3 arguments"),
            'sqrt': lambda args: math.sqrt(args[0]) if len(args) == 1 else self._error("sqrt() takes 1 argument"),
            'sin': lambda args: math.sin(args[0]) if len(args) == 1 else self._error("sin() takes 1 argument"),
            'cos': lambda args: math.cos(args[0]) if len(args) == 1 else self._error("cos() takes 1 argument"),
            'tan': lambda args: math.tan(args[0]) if len(args) == 1 else self._error("tan() takes 1 argument"),
            'log': lambda args: math.log(args[0], args[1]) if len(args) == 2 else math.log(args[0]) if len(args) == 1 else self._error("log() takes 1 or 2 arguments"),
            'log10': lambda args: math.log10(args[0]) if len(args) == 1 else self._error("log10() takes 1 argument"),
            'exp': lambda args: math.exp(args[0]) if len(args) == 1 else self._error("exp() takes 1 argument"),
            'floor': lambda args: math.floor(args[0]) if len(args) == 1 else self._error("floor() takes 1 argument"),
            'ceil': lambda args: math.ceil(args[0]) if len(args) == 1 else self._error("ceil() takes 1 argument"),
            'random': lambda args: random.random() if len(args) == 0 else random.randint(0, int(args[0])-1) if len(args) == 1 else random.randint(int(args[0]), int(args[1])) if len(args) == 2 else self._error("random() takes 0, 1 or 2 arguments"),
            'choice': lambda args: random.choice(args[0]) if len(args) == 1 else self._error("choice() takes 1 argument"),
            'shuffle': lambda args: self.builtin_shuffle(args),
            'time': lambda args: time.time() if len(args) == 0 else self._error("time() takes 0 arguments"),
            'sleep': lambda args: time.sleep(args[0]) if len(args) == 1 else self._error("sleep() takes 1 argument"),
            'range': lambda args: list(range(int(args[0]))) if len(args) == 1 else list(range(int(args[0]), int(args[1]))) if len(args) == 2 else list(range(int(args[0]), int(args[1]), int(args[2]))) if len(args) == 3 else self._error("range() takes 1, 2 or 3 arguments"),
            'print_json': lambda args: print(json.dumps(args[0], indent=2, default=str)) if len(args) == 1 else self._error("print_json() takes 1 argument"),
            'parse_json': lambda args: json.loads(args[0]) if len(args) == 1 else self._error("parse_json() takes 1 argument"),
            'to_json': lambda args: json.dumps(args[0], default=str) if len(args) == 1 else self._error("to_json() takes 1 argument"),
            'keys': lambda args: list(args[0].keys()) if len(args) == 1 and isinstance(args[0], dict) else self._error("keys() takes 1 dict argument"),
            'values': lambda args: list(args[0].values()) if len(args) == 1 and isinstance(args[0], dict) else self._error("values() takes 1 dict argument"),
            'items': lambda args: list(args[0].items()) if len(args) == 1 and isinstance(args[0], dict) else self._error("items() takes 1 dict argument"),
            'append': lambda args: self.builtin_append(args),
            'pop': lambda args: args[0].pop(int(args[1])) if len(args) == 2 else args[0].pop() if len(args) == 1 else self._error("pop() takes 1 or 2 arguments"),
            'insert': lambda args: self.builtin_insert(args),
            'remove': lambda args: self.builtin_remove(args),
            'index': lambda args: args[0].index(args[1]) if len(args) == 2 else self._error("index() takes 2 arguments"),
            'count': lambda args: args[0].count(args[1]) if len(args) == 2 else self._error("count() takes 2 arguments"),
            'extend': lambda args: self.builtin_extend(args),
            'clear': lambda args: args[0].clear() or args[0] if len(args) == 1 else self._error("clear() takes 1 argument"),
            'copy': lambda args: args[0].copy() if len(args) == 1 else self._error("copy() takes 1 argument"),
            'upper': lambda args: str(args[0]).upper() if len(args) == 1 else self._error("upper() takes 1 argument"),
            'lower': lambda args: str(args[0]).lower() if len(args) == 1 else self._error("lower() takes 1 argument"),
            'strip': lambda args: str(args[0]).strip() if len(args) == 1 else str(args[0]).strip(str(args[1])) if len(args) == 2 else self._error("strip() takes 1 or 2 arguments"),
            'split': lambda args: str(args[0]).split() if len(args) == 1 else str(args[0]).split(str(args[1])) if len(args) == 2 else self._error("split() takes 1 or 2 arguments"),
            'join': lambda args: str(args[0]).join(str(x) for x in args[1]) if len(args) == 2 else self._error("join() takes 2 arguments"),
            'replace': lambda args: str(args[0]).replace(str(args[1]), str(args[2])) if len(args) == 3 else self._error("replace() takes 3 arguments"),
            'find': lambda args: str(args[0]).find(str(args[1])) if len(args) == 2 else self._error("find() takes 2 arguments"),
            'startswith': lambda args: str(args[0]).startswith(str(args[1])) if len(args) == 2 else self._error("startswith() takes 2 arguments"),
            'endswith': lambda args: str(args[0]).endswith(str(args[1])) if len(args) == 2 else self._error("endswith() takes 2 arguments"),
            'contains': lambda args: args[1] in args[0] if len(args) == 2 else self._error("contains() takes 2 arguments"),
            'capitalize': lambda args: str(args[0]).capitalize() if len(args) == 1 else self._error("capitalize() takes 1 argument"),
            'title': lambda args: str(args[0]).title() if len(args) == 1 else self._error("title() takes 1 argument"),
            'isdigit': lambda args: str(args[0]).isdigit() if len(args) == 1 else self._error("isdigit() takes 1 argument"),
            'isalpha': lambda args: str(args[0]).isalpha() if len(args) == 1 else self._error("isalpha() takes 1 argument"),
            'isalnum': lambda args: str(args[0]).isalnum() if len(args) == 1 else self._error("isalnum() takes 1 argument"),
            'format': lambda args: str(args[0]).format(*args[1:]) if len(args) >= 1 else self._error("format() takes at least 1 argument"),
            'substring': lambda args: str(args[0])[int(args[1]):int(args[2])] if len(args) == 3 else str(args[0])[int(args[1]):] if len(args) == 2 else self._error("substring() takes 2 or 3 arguments"),
            'reverse': lambda args: args[0][::-1] if len(args) == 1 else self._error("reverse() takes 1 argument"),
            'sort': lambda args: sorted(args[0]) if len(args) == 1 else self._error("sort() takes 1 argument"),
            'unique': lambda args: list(dict.fromkeys(args[0])) if len(args) == 1 else self._error("unique() takes 1 argument"),
            'flatten': lambda args: self.builtin_flatten(args[0]) if len(args) == 1 else self._error("flatten() takes 1 argument"),
            'exit': lambda args: sys.exit(int(args[0])) if len(args) == 1 else sys.exit(0),
            'assert': lambda args: None if self.is_truthy(args[0]) else self._error(str(args[1]) if len(args) > 1 else "Assertion failed"),
        }
        
        self.global_env.define('PI', math.pi, is_const=True)
        self.global_env.define('E', math.e, is_const=True)
        self.global_env.define('TAU', math.tau, is_const=True)
        self.global_env.define('INF', float('inf'), is_const=True)
        self.global_env.define('NAN', float('nan'), is_const=True)
        self.global_env.define('VERSION', "3.0.0", is_const=True)
        
        self._setup_ai_module()
    
    def _error(self, msg):
        raise RuntimeError(msg)
    
    def _setup_ai_module(self):
        """Setup AI module with all advanced features"""
        try:
            from stract_ai_core import get_ai_core
            ai_core = get_ai_core()
            
            class AIModule:
                """AI Module for STRACT - Provides AI capabilities"""
                
                @staticmethod
                def generate_text(prompt: str, max_tokens: int = 1000) -> str:
                    return ai_core.generate_text(prompt, max_tokens)
                
                @staticmethod
                def analyze(code_or_data):
                    if isinstance(code_or_data, str):
                        return ai_core.analyze_code(code_or_data)
                    elif isinstance(code_or_data, list):
                        return ai_core.detect_patterns(code_or_data)
                    return {"error": "Invalid input type"}
                
                @staticmethod
                def analyze_code(code: str):
                    return ai_core.analyze_code(code)
                
                @staticmethod
                def explain_error(error: str, code: str = ""):
                    return ai_core.explain_error(error, code)
                
                @staticmethod
                def generate_code(description: str):
                    return ai_core.generate_code(description)
                
                @staticmethod
                def generate_app(description: str):
                    return ai_core.generate_app(description)
                
                @staticmethod
                def train(data_path: str, model_type: str = "classifier", **kwargs):
                    return ai_core.train_model(data_path, model_type, **kwargs)
                
                @staticmethod
                def classify_text(text: str):
                    return ai_core.classify_text(text)
                
                @staticmethod
                def detect_patterns(data: list):
                    return ai_core.detect_patterns(data)
                
                @staticmethod
                def recommend(preferences: dict, items: list):
                    return ai_core.recommend(preferences, items)
                
                @staticmethod
                def optimize(code: str):
                    return ai_core.optimizer.auto_optimize(code)
                
                @staticmethod
                def predict_errors(code: str):
                    result = ai_core.optimizer.analyze_code(code)
                    return result.predicted_errors
                
                @staticmethod
                def suggest_improvements(code: str):
                    result = ai_core.optimizer.analyze_code(code)
                    return {
                        "suggestions": result.suggestions,
                        "performance_tips": result.performance_tips,
                        "optimizations": result.optimization_opportunities
                    }
                
                @staticmethod
                def init():
                    return ai_core.get_status()
                
                @staticmethod
                def status():
                    return ai_core.get_status()
            
            class MemoryModule:
                """Adaptive Memory Management Module"""
                
                @staticmethod
                def allocate(name: str, value, priority: int = 1):
                    return ai_core.memory.allocate(name, value, priority)
                
                @staticmethod
                def access(name: str):
                    return ai_core.memory.access(name)
                
                @staticmethod
                def free(name: str):
                    return ai_core.memory.deallocate(name)
                
                @staticmethod
                def stats():
                    return ai_core.memory.get_stats()
            
            class ProjectModule:
                """Intelligent Project Handling Module"""
                
                @staticmethod
                def create(name: str, template: str = "basic"):
                    return ai_core.project_handler.create_project(name, template)
                
                @staticmethod
                def analyze(path: str = "."):
                    return ai_core.project_handler.analyze_project(path)
            
            class OptimizerModule:
                """Self-Optimizing Language Module"""
                
                @staticmethod
                def analyze(code: str):
                    result = ai_core.optimizer.analyze_code(code)
                    return {
                        "issues": result.issues,
                        "suggestions": result.suggestions,
                        "complexity": result.complexity_score,
                        "performance_tips": result.performance_tips,
                        "predicted_errors": result.predicted_errors
                    }
                
                @staticmethod
                def auto_optimize(code: str):
                    return ai_core.optimizer.auto_optimize(code)
            
            class ProactiveModule:
                """Proactive Intelligence Module"""
                
                @staticmethod
                def predict_errors(code: str, variables: dict = None):
                    return ai_core.proactive.predict_runtime_errors(code, variables or {})
                
                @staticmethod
                def suggest_improvements(code: str, execution_time: float = 0.0):
                    return ai_core.proactive.suggest_improvements(code, execution_time)
                
                @staticmethod
                def recommend_libraries(code: str):
                    return ai_core.proactive.recommend_libraries(code)
            
            self.global_env.define('AI', AIModule, is_const=True)
            self.global_env.define('Memory', MemoryModule, is_const=True)
            self.global_env.define('Project', ProjectModule, is_const=True)
            self.global_env.define('Optimizer', OptimizerModule, is_const=True)
            self.global_env.define('Proactive', ProactiveModule, is_const=True)
            
        except ImportError as e:
            class AIModuleFallback:
                @staticmethod
                def generate_text(prompt: str, max_tokens: int = 1000):
                    return f"[AI not available] Prompt: {prompt}"
                
                @staticmethod
                def analyze(data):
                    return {"status": "AI module not loaded"}
                
                @staticmethod
                def status():
                    return {"available": False, "error": str(e)}
            
            self.global_env.define('AI', AIModuleFallback, is_const=True)
    
    def builtin_reduce(self, args):
        if len(args) < 2:
            raise RuntimeError("reduce() takes at least 2 arguments")
        func = args[0]
        iterable = args[1]
        if len(args) == 3:
            result = args[2]
            for item in iterable:
                result = self.call_function(func, [result, item])
            return result
        else:
            it = iter(iterable)
            try:
                result = next(it)
            except StopIteration:
                raise RuntimeError("reduce() of empty sequence with no initial value")
            for item in it:
                result = self.call_function(func, [result, item])
            return result
    
    def builtin_shuffle(self, args):
        if len(args) != 1:
            raise RuntimeError("shuffle() takes 1 argument")
        lst = list(args[0])
        random.shuffle(lst)
        return lst
    
    def builtin_append(self, args):
        if len(args) != 2:
            raise RuntimeError("append() takes 2 arguments")
        args[0].append(args[1])
        return args[0]
    
    def builtin_insert(self, args):
        if len(args) != 3:
            raise RuntimeError("insert() takes 3 arguments")
        args[0].insert(int(args[1]), args[2])
        return args[0]
    
    def builtin_remove(self, args):
        if len(args) != 2:
            raise RuntimeError("remove() takes 2 arguments")
        args[0].remove(args[1])
        return args[0]
    
    def builtin_extend(self, args):
        if len(args) != 2:
            raise RuntimeError("extend() takes 2 arguments")
        args[0].extend(args[1])
        return args[0]
    
    def builtin_flatten(self, lst):
        result = []
        for item in lst:
            if isinstance(item, list):
                result.extend(self.builtin_flatten(item))
            else:
                result.append(item)
        return result
    
    def call_function(self, func, args):
        if isinstance(func, LambdaNode):
            return self.execute_lambda_call(func, args)
        elif isinstance(func, STRACTFunction):
            return self.execute_user_function(func.node, args, func.closure)
        elif callable(func):
            return func(args)
        else:
            raise RuntimeError(f"Cannot call {type(func).__name__}")
    
    def execute_lambda_call(self, node: LambdaNode, args: List[Any]) -> Any:
        if len(args) != len(node.params):
            raise RuntimeError(f"Lambda expects {len(node.params)} arguments, got {len(args)}")
        
        lambda_env = Environment(self.global_env)
        for param, arg in zip(node.params, args):
            lambda_env.define(param, arg)
        
        if node.body is not None:
            return self.execute(node.body, lambda_env)
        return None
    
    def execute_user_function(self, func: FunctionDefNode, args: List[Any], closure: Optional[Environment] = None) -> Any:
        func_env = Environment(closure or self.global_env)
        
        for i, param in enumerate(func.params):
            if i < len(args):
                func_env.define(param, args[i])
            elif i - (len(func.params) - len(func.defaults)) >= 0:
                default_idx = i - (len(func.params) - len(func.defaults))
                func_env.define(param, self.execute(func.defaults[default_idx], func_env))
            else:
                raise RuntimeError(f"Missing argument for parameter '{param}'")
        
        try:
            for stmt in func.body:
                self.execute(stmt, func_env)
        except ReturnException as ret:
            return ret.value
        
        return None
    
    def get_type(self, value: Any) -> str:
        if isinstance(value, bool):
            return "boolean"
        elif isinstance(value, int):
            return "integer"
        elif isinstance(value, float):
            return "float"
        elif isinstance(value, str):
            return "string"
        elif isinstance(value, list):
            return "list"
        elif isinstance(value, dict):
            return "dict"
        elif isinstance(value, tuple):
            return "tuple"
        elif isinstance(value, set):
            return "set"
        elif isinstance(value, STRACTInstance):
            return f"instance<{value.klass.name}>"
        elif isinstance(value, STRACTClass):
            return f"class<{value.name}>"
        elif isinstance(value, (STRACTFunction, LambdaNode)):
            return "function"
        elif value is None:
            return "null"
        return "unknown"
    
    def to_string(self, value: Any) -> str:
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, list):
            return "[" + ", ".join(self.to_string(x) for x in value) + "]"
        if isinstance(value, dict):
            pairs = [f"{self.to_string(k)}: {self.to_string(v)}" for k, v in value.items()]
            return "{" + ", ".join(pairs) + "}"
        if isinstance(value, STRACTInstance):
            return f"<{value.klass.name} instance>"
        if isinstance(value, STRACTFunction):
            return f"<function {value.name}>"
        if isinstance(value, LambdaNode):
            return "<lambda>"
        return str(value)
    
    def is_truthy(self, value: Any) -> bool:
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, (str, list, dict, tuple, set)):
            return len(value) > 0
        return True
    
    def execute(self, node: Optional[ASTNode], env: Optional[Environment] = None) -> Any:
        if node is None:
            return None
        if env is None:
            env = self.global_env
        
        method_name = f"execute_{type(node).__name__}"
        executor = getattr(self, method_name, None)
        
        if executor is None:
            raise RuntimeError(f"Unknown node type: {type(node).__name__}", getattr(node, 'line', 0), getattr(node, 'column', 0))
        
        try:
            return executor(node, env)
        except (RuntimeError, ReturnException, BreakException, ContinueException, ThrowException):
            raise
        except Exception as e:
            raise RuntimeError(str(e), getattr(node, 'line', 0), getattr(node, 'column', 0))
    
    def execute_ProgramNode(self, node: ProgramNode, env: Environment) -> Any:
        result = None
        for stmt in node.statements:
            result = self.execute(stmt, env)
        return result
    
    def execute_NumberNode(self, node: NumberNode, env: Environment) -> Union[int, float]:
        return node.value
    
    def execute_StringNode(self, node: StringNode, env: Environment) -> str:
        return node.value
    
    def execute_BooleanNode(self, node: BooleanNode, env: Environment) -> bool:
        return node.value
    
    def execute_NullNode(self, node: NullNode, env: Environment) -> None:
        return None
    
    def execute_IdentifierNode(self, node: IdentifierNode, env: Environment) -> Any:
        try:
            return env.get(node.name)
        except RuntimeError as e:
            raise RuntimeError(e.message, node.line, node.column)
    
    def execute_ListNode(self, node: ListNode, env: Environment) -> list:
        return [self.execute(elem, env) for elem in node.elements]
    
    def execute_DictNode(self, node: DictNode, env: Environment) -> dict:
        result = {}
        for key, value in node.pairs:
            k = self.execute(key, env)
            v = self.execute(value, env)
            result[k] = v
        return result
    
    def execute_IndexNode(self, node: IndexNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        index = self.execute(node.index, env)
        
        if isinstance(obj, dict):
            if index in obj:
                return obj[index]
            raise RuntimeError(f"Key not found: {index}", node.line, node.column)
        
        if isinstance(obj, (list, str, tuple)):
            try:
                return obj[int(index)]
            except IndexError:
                raise RuntimeError(f"Index {index} out of range", node.line, node.column)
        
        raise RuntimeError("Cannot index this type", node.line, node.column)
    
    def execute_SliceNode(self, node: SliceNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        start = self.execute(node.start, env) if node.start else None
        end = self.execute(node.end, env) if node.end else None
        step = self.execute(node.step, env) if node.step else None
        
        if isinstance(obj, (list, str, tuple)):
            if start is not None:
                start = int(start)
            if end is not None:
                end = int(end)
            if step is not None:
                step = int(step)
            return obj[start:end:step]
        
        raise RuntimeError("Cannot slice this type", node.line, node.column)
    
    def execute_BinaryOpNode(self, node: BinaryOpNode, env: Environment) -> Any:
        left = self.execute(node.left, env)
        
        if node.operator == 'and':
            if not self.is_truthy(left):
                return left
            return self.execute(node.right, env)
        
        if node.operator == 'or':
            if self.is_truthy(left):
                return left
            return self.execute(node.right, env)
        
        right = self.execute(node.right, env)
        
        if node.operator == '+':
            if isinstance(left, str) or isinstance(right, str):
                return self.to_string(left) + self.to_string(right)
            if isinstance(left, list) and isinstance(right, list):
                return left + right
            if isinstance(left, dict) and isinstance(right, dict):
                return {**left, **right}
            return left + right
        elif node.operator == '-':
            return left - right
        elif node.operator == '*':
            if isinstance(left, str) and isinstance(right, int):
                return left * right
            if isinstance(left, list) and isinstance(right, int):
                return left * right
            return left * right
        elif node.operator == '/':
            if right == 0:
                raise RuntimeError("Division by zero", node.line, node.column)
            return left / right
        elif node.operator == '//':
            if right == 0:
                raise RuntimeError("Division by zero", node.line, node.column)
            return left // right
        elif node.operator == '%':
            if right == 0:
                raise RuntimeError("Modulo by zero", node.line, node.column)
            return left % right
        elif node.operator == '**':
            return left ** right
        elif node.operator == '==':
            return left == right
        elif node.operator == '!=':
            return left != right
        elif node.operator == '<':
            return left < right
        elif node.operator == '>':
            return left > right
        elif node.operator == '<=':
            return left <= right
        elif node.operator == '>=':
            return left >= right
        elif node.operator == 'in':
            return left in right
        
        raise RuntimeError(f"Unknown operator: {node.operator}", node.line, node.column)
    
    def execute_UnaryOpNode(self, node: UnaryOpNode, env: Environment) -> Any:
        operand = self.execute(node.operand, env)
        
        if node.operator == '-':
            return -operand
        elif node.operator == '+':
            return +operand
        elif node.operator == 'not':
            return not self.is_truthy(operand)
        
        raise RuntimeError(f"Unknown unary operator: {node.operator}", node.line, node.column)
    
    def execute_AssignNode(self, node: AssignNode, env: Environment) -> Any:
        value = self.execute(node.value, env)
        
        if env.exists(node.name):
            env.set(node.name, value)
        else:
            env.define(node.name, value, node.is_const)
        
        return value
    
    def execute_CompoundAssignNode(self, node: CompoundAssignNode, env: Environment) -> Any:
        current = env.get(node.name)
        value = self.execute(node.value, env)
        
        if node.operator == '+=':
            if isinstance(current, str):
                new_value = current + self.to_string(value)
            elif isinstance(current, list):
                new_value = current + [value]
            else:
                new_value = current + value
        elif node.operator == '-=':
            new_value = current - value
        elif node.operator == '*=':
            new_value = current * value
        elif node.operator == '/=':
            new_value = current / value
        else:
            raise RuntimeError(f"Unknown compound operator: {node.operator}", node.line, node.column)
        
        env.set(node.name, new_value)
        return new_value
    
    def execute_IndexAssignNode(self, node: IndexAssignNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        index = self.execute(node.index, env)
        value = self.execute(node.value, env)
        
        if isinstance(obj, list):
            try:
                obj[int(index)] = value
                return value
            except IndexError:
                raise RuntimeError(f"Index {index} out of range", node.line, node.column)
        elif isinstance(obj, dict):
            obj[index] = value
            return value
        
        raise RuntimeError("Cannot index assign to this type", node.line, node.column)
    
    def execute_PrintNode(self, node: PrintNode, env: Environment) -> None:
        values = [self.to_string(self.execute(expr, env)) for expr in node.expressions]
        print(" ".join(values))
    
    def execute_InputNode(self, node: InputNode, env: Environment) -> str:
        prompt = ""
        if node.prompt:
            prompt = self.to_string(self.execute(node.prompt, env))
        return input(prompt)
    
    def execute_IfNode(self, node: IfNode, env: Environment) -> Any:
        condition = self.execute(node.condition, env)
        
        if self.is_truthy(condition):
            result = None
            for stmt in node.then_block:
                result = self.execute(stmt, env)
            return result
        
        for elif_condition, elif_body in node.elif_blocks:
            if self.is_truthy(self.execute(elif_condition, env)):
                result = None
                for stmt in elif_body:
                    result = self.execute(stmt, env)
                return result
        
        if node.else_block:
            result = None
            for stmt in node.else_block:
                result = self.execute(stmt, env)
            return result
        
        return None
    
    def execute_WhileNode(self, node: WhileNode, env: Environment) -> Any:
        result = None
        while self.is_truthy(self.execute(node.condition, env)):
            try:
                for stmt in node.body:
                    result = self.execute(stmt, env)
            except BreakException:
                break
            except ContinueException:
                continue
        return result
    
    def execute_ForNode(self, node: ForNode, env: Environment) -> Any:
        iterable = self.execute(node.iterable, env)
        result = None
        
        if isinstance(iterable, range):
            iterable = list(iterable)
        
        if not isinstance(iterable, (list, str, tuple, dict, set)):
            raise RuntimeError("For loop requires an iterable", node.line, node.column)
        
        for item in iterable:
            env.define(node.variable, item)
            try:
                for stmt in node.body:
                    result = self.execute(stmt, env)
            except BreakException:
                break
            except ContinueException:
                continue
        
        return result
    
    def execute_RangeNode(self, node: RangeNode, env: Environment) -> range:
        start = int(self.execute(node.start, env))
        end = int(self.execute(node.end, env))
        
        if node.step:
            step = int(self.execute(node.step, env))
            return range(start, end, step)
        
        return range(start, end)
    
    def execute_FunctionDefNode(self, node: FunctionDefNode, env: Environment) -> None:
        self.functions[node.name] = node
        func = STRACTFunction(node, env)
        env.define(node.name, func)
    
    def execute_LambdaNode(self, node: LambdaNode, env: Environment) -> LambdaNode:
        return node
    
    def execute_FunctionCallNode(self, node: FunctionCallNode, env: Environment) -> Any:
        if node.name in self.builtins:
            args = [self.execute(arg, env) for arg in node.args]
            return self.builtins[node.name](args)
        
        if node.name in self.classes:
            return self.instantiate_class(node.name, [self.execute(arg, env) for arg in node.args], env)
        
        try:
            func = env.get(node.name)
            if isinstance(func, STRACTFunction):
                args = [self.execute(arg, env) for arg in node.args]
                return self.execute_user_function(func.node, args, func.closure)
            elif isinstance(func, LambdaNode):
                args = [self.execute(arg, env) for arg in node.args]
                return self.execute_lambda_call(func, args)
            elif callable(func):
                args = [self.execute(arg, env) for arg in node.args]
                return func(args)
        except RuntimeError:
            pass
        
        if node.name in self.functions:
            func = self.functions[node.name]
            args = [self.execute(arg, env) for arg in node.args]
            return self.execute_user_function(func, args, self.global_env)
        
        raise RuntimeError(f"Undefined function: '{node.name}'", node.line, node.column)
    
    def execute_MethodCallNode(self, node: MethodCallNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        args = [self.execute(arg, env) for arg in node.args]
        
        if isinstance(obj, STRACTInstance):
            method = obj.klass.methods.get(node.method)
            if method:
                method_env = Environment(self.global_env)
                method_env.define('this', obj)
                return self.execute_user_function(method, args, method_env)
            raise RuntimeError(f"Method '{node.method}' not found", node.line, node.column)
        
        if isinstance(obj, str):
            string_methods = {
                'upper': lambda: obj.upper(),
                'lower': lambda: obj.lower(),
                'strip': lambda: obj.strip() if not args else obj.strip(args[0]),
                'split': lambda: obj.split() if not args else obj.split(args[0]),
                'replace': lambda: obj.replace(args[0], args[1]) if len(args) >= 2 else self._error("replace() needs 2 args"),
                'find': lambda: obj.find(args[0]) if args else self._error("find() needs 1 arg"),
                'startswith': lambda: obj.startswith(args[0]) if args else self._error("startswith() needs 1 arg"),
                'endswith': lambda: obj.endswith(args[0]) if args else self._error("endswith() needs 1 arg"),
                'capitalize': lambda: obj.capitalize(),
                'title': lambda: obj.title(),
                'isdigit': lambda: obj.isdigit(),
                'isalpha': lambda: obj.isalpha(),
                'isalnum': lambda: obj.isalnum(),
                'len': lambda: len(obj),
                'length': lambda: len(obj),
                'reverse': lambda: obj[::-1],
                'contains': lambda: args[0] in obj if args else self._error("contains() needs 1 arg"),
                'count': lambda: obj.count(args[0]) if args else self._error("count() needs 1 arg"),
                'index': lambda: obj.index(args[0]) if args else self._error("index() needs 1 arg"),
                'format': lambda: obj.format(*args),
                'join': lambda: obj.join(str(x) for x in args[0]) if args else self._error("join() needs 1 arg"),
                'lstrip': lambda: obj.lstrip() if not args else obj.lstrip(args[0]),
                'rstrip': lambda: obj.rstrip() if not args else obj.rstrip(args[0]),
                'center': lambda: obj.center(int(args[0])) if args else self._error("center() needs 1 arg"),
                'zfill': lambda: obj.zfill(int(args[0])) if args else self._error("zfill() needs 1 arg"),
            }
            if node.method in string_methods:
                return string_methods[node.method]()
        
        elif isinstance(obj, list):
            list_methods = {
                'append': lambda: (obj.append(args[0]), obj)[1] if args else self._error("append() needs 1 arg"),
                'pop': lambda: obj.pop(int(args[0])) if args else obj.pop(),
                'insert': lambda: (obj.insert(int(args[0]), args[1]), obj)[1] if len(args) >= 2 else self._error("insert() needs 2 args"),
                'remove': lambda: (obj.remove(args[0]), obj)[1] if args else self._error("remove() needs 1 arg"),
                'extend': lambda: (obj.extend(args[0]), obj)[1] if args else self._error("extend() needs 1 arg"),
                'clear': lambda: (obj.clear(), obj)[1],
                'copy': lambda: obj.copy(),
                'index': lambda: obj.index(args[0]) if args else self._error("index() needs 1 arg"),
                'count': lambda: obj.count(args[0]) if args else self._error("count() needs 1 arg"),
                'sort': lambda: sorted(obj),
                'reverse': lambda: obj[::-1],
                'len': lambda: len(obj),
                'length': lambda: len(obj),
                'first': lambda: obj[0] if obj else None,
                'last': lambda: obj[-1] if obj else None,
                'sum': lambda: sum(obj),
                'min': lambda: min(obj),
                'max': lambda: max(obj),
                'avg': lambda: sum(obj) / len(obj) if obj else 0,
                'contains': lambda: args[0] in obj if args else self._error("contains() needs 1 arg"),
                'join': lambda: str(args[0]).join(str(x) for x in obj) if args else self._error("join() needs 1 arg"),
                'map': lambda: [self.call_function(args[0], [x]) for x in obj] if args else self._error("map() needs 1 arg"),
                'filter': lambda: [x for x in obj if self.is_truthy(self.call_function(args[0], [x]))] if args else self._error("filter() needs 1 arg"),
                'reduce': lambda: self.builtin_reduce([args[0], obj] + list(args[1:])) if args else self._error("reduce() needs at least 1 arg"),
                'slice': lambda: obj[int(args[0]):int(args[1])] if len(args) >= 2 else obj[int(args[0]):] if args else obj[:],
                'take': lambda: obj[:int(args[0])] if args else self._error("take() needs 1 arg"),
                'drop': lambda: obj[int(args[0]):] if args else self._error("drop() needs 1 arg"),
                'unique': lambda: list(dict.fromkeys(obj)),
                'flatten': lambda: self.builtin_flatten(obj),
                'zip': lambda: list(zip(obj, *args)) if args else self._error("zip() needs at least 1 arg"),
            }
            if node.method in list_methods:
                return list_methods[node.method]()
        
        elif isinstance(obj, dict):
            dict_methods = {
                'keys': lambda: list(obj.keys()),
                'values': lambda: list(obj.values()),
                'items': lambda: list(obj.items()),
                'get': lambda: obj.get(args[0], args[1] if len(args) > 1 else None) if args else self._error("get() needs 1 arg"),
                'pop': lambda: obj.pop(args[0], args[1] if len(args) > 1 else None) if args else self._error("pop() needs 1 arg"),
                'update': lambda: (obj.update(args[0]), obj)[1] if args else self._error("update() needs 1 arg"),
                'clear': lambda: (obj.clear(), obj)[1],
                'copy': lambda: obj.copy(),
                'len': lambda: len(obj),
                'length': lambda: len(obj),
                'contains': lambda: args[0] in obj if args else self._error("contains() needs 1 arg"),
                'has': lambda: args[0] in obj if args else self._error("has() needs 1 arg"),
            }
            if node.method in dict_methods:
                return dict_methods[node.method]()
        
        raise RuntimeError(f"Unknown method '{node.method}' for type {self.get_type(obj)}", node.line, node.column)
    
    def execute_PropertyAccessNode(self, node: PropertyAccessNode, env: Environment) -> Any:
        obj = self.execute(node.obj, env)
        
        if isinstance(obj, STRACTInstance):
            return obj.get(node.property)
        
        if isinstance(obj, dict):
            if node.property in obj:
                return obj[node.property]
            raise RuntimeError(f"Key '{node.property}' not found", node.line, node.column)
        
        if node.property == 'length' or node.property == 'len':
            if isinstance(obj, (str, list, dict, tuple, set)):
                return len(obj)
        
        raise RuntimeError(f"Cannot access property '{node.property}' on {self.get_type(obj)}", node.line, node.column)
    
    def execute_ReturnNode(self, node: ReturnNode, env: Environment) -> None:
        value = None
        if node.value:
            value = self.execute(node.value, env)
        raise ReturnException(value)
    
    def execute_BreakNode(self, node: BreakNode, env: Environment) -> None:
        raise BreakException()
    
    def execute_ContinueNode(self, node: ContinueNode, env: Environment) -> None:
        raise ContinueException()
    
    def execute_TryNode(self, node: TryNode, env: Environment) -> Any:
        try:
            result = None
            for stmt in node.try_block:
                result = self.execute(stmt, env)
            return result
        except ThrowException as e:
            catch_env = Environment(env)
            catch_env.define(node.catch_var, e.value)
            result = None
            for stmt in node.catch_block:
                result = self.execute(stmt, catch_env)
            return result
        except RuntimeError as e:
            catch_env = Environment(env)
            catch_env.define(node.catch_var, e.message)
            result = None
            for stmt in node.catch_block:
                result = self.execute(stmt, catch_env)
            return result
        finally:
            for stmt in node.finally_block:
                self.execute(stmt, env)
    
    def execute_ThrowNode(self, node: ThrowNode, env: Environment) -> None:
        value = self.execute(node.value, env)
        raise ThrowException(value, node.line)
    
    def execute_ClassDefNode(self, node: ClassDefNode, env: Environment) -> None:
        parent = None
        if node.parent and node.parent in self.classes:
            parent = self.classes[node.parent]
        
        methods = {}
        for method in node.methods:
            methods[method.name] = method
        
        properties = {}
        for prop in node.properties:
            properties[prop.name] = self.execute(prop.value, env)
        
        klass = STRACTClass(node.name, parent, methods, properties)
        self.classes[node.name] = klass
        env.define(node.name, klass)
    
    def execute_NewNode(self, node: NewNode, env: Environment) -> STRACTInstance:
        return self.instantiate_class(node.class_name, [self.execute(arg, env) for arg in node.args], env)
    
    def instantiate_class(self, class_name: str, args: List[Any], env: Environment) -> STRACTInstance:
        if class_name not in self.classes:
            raise RuntimeError(f"Undefined class: '{class_name}'")
        
        klass = self.classes[class_name]
        instance = STRACTInstance(klass)
        
        if 'init' in klass.methods:
            init_env = Environment(self.global_env)
            init_env.define('this', instance)
            self.execute_user_function(klass.methods['init'], args, init_env)
        
        return instance
    
    def execute_ImportNode(self, node: ImportNode, env: Environment) -> None:
        pass
    
    def execute_DecoratorNode(self, node: DecoratorNode, env: Environment) -> Any:
        if node.target is not None:
            result = self.execute(node.target, env)
            return result
        return None
    
    def execute_MatchNode(self, node: MatchNode, env: Environment) -> Any:
        value = self.execute(node.value, env)
        
        for case_value, case_body in node.cases:
            if self.execute(case_value, env) == value:
                result = None
                for stmt in case_body:
                    result = self.execute(stmt, env)
                return result
        
        if node.default:
            result = None
            for stmt in node.default:
                result = self.execute(stmt, env)
            return result
        
        return None

    # ========================================================================
    # STRACT v5.0 REVOLUTIONARY EXECUTION METHODS
    # ========================================================================
    
    # ==================== Contractual Safety Execution ====================
    
    def execute_RefinementTypeNode(self, node: RefinementTypeNode, env: Environment) -> STRACTRefinementType:
        """Register refinement type with constraint validation"""
        constraint_fn = None
        if node.constraint:
            constraint_node = node.constraint
            constraint_fn = lambda value: self.is_truthy(
                self.execute(constraint_node, self._create_constraint_env(env, value))
            )
        
        refinement_type = STRACTRefinementType(
            name=node.name,
            base_type=node.base_type,
            constraint=constraint_fn
        )
        
        if not hasattr(self, 'refinement_types'):
            self.refinement_types = {}
        self.refinement_types[node.name] = refinement_type
        env.define(node.name, refinement_type)
        
        return refinement_type
    
    def _create_constraint_env(self, parent_env: Environment, value: Any) -> Environment:
        """Create environment for constraint evaluation with 'value' bound"""
        constraint_env = Environment(parent_env)
        constraint_env.define('value', value)
        return constraint_env
    
    def execute_ContractNode(self, node: ContractNode, env: Environment) -> STRACTContract:
        """Store contract conditions"""
        requires_fns = []
        ensures_fns = []
        
        for req in node.requires:
            req_node = req
            requires_fns.append(lambda *args, req_n=req_node: self.is_truthy(self.execute(req_n, env)))
        
        for ens in node.ensures:
            ens_node = ens
            ensures_fns.append(lambda result, *args, ens_n=ens_node: self.is_truthy(
                self.execute(ens_n, self._create_result_env(env, result))
            ))
        
        return STRACTContract(requires=requires_fns, ensures=ensures_fns)
    
    def _create_result_env(self, parent_env: Environment, result: Any) -> Environment:
        """Create environment with 'result' bound for postcondition evaluation"""
        result_env = Environment(parent_env)
        result_env.define('result', result)
        return result_env
    
    def execute_ContractedFunctionNode(self, node: ContractedFunctionNode, env: Environment) -> None:
        """Execute function with requires/ensures checking"""
        def contracted_function(*args):
            func_env = Environment(self.global_env)
            
            for i, param in enumerate(node.params):
                if i < len(args):
                    func_env.define(param, args[i])
                    
                    if param in node.param_types:
                        expected_type = node.param_types[param]
                        if not self._check_type(args[i], expected_type):
                            raise RuntimeError(
                                f"Type error: parameter '{param}' expected {expected_type}",
                                node.line, node.column
                            )
            
            for req in node.requires:
                if not self.is_truthy(self.execute(req, func_env)):
                    raise RuntimeError(
                        f"Contract violation: precondition failed in function '{node.name}'",
                        node.line, node.column
                    )
            
            result = None
            try:
                for stmt in node.body:
                    result = self.execute(stmt, func_env)
            except ReturnException as e:
                result = e.value
            
            result_env = Environment(func_env)
            result_env.define('result', result)
            for ens in node.ensures:
                if not self.is_truthy(self.execute(ens, result_env)):
                    raise RuntimeError(
                        f"Contract violation: postcondition failed in function '{node.name}'",
                        node.line, node.column
                    )
            
            return result
        
        self.functions[node.name] = node
        env.define(node.name, contracted_function)
    
    def _check_type(self, value: Any, type_name: str) -> bool:
        """Check if value matches expected type"""
        type_map = {
            'Int': (int,),
            'Float': (int, float),
            'String': (str,),
            'Bool': (bool,),
            'List': (list,),
            'Dict': (dict,),
            'Any': (object,),
        }
        expected_types = type_map.get(type_name, (object,))
        return isinstance(value, expected_types)
    
    def execute_SandboxNode(self, node: SandboxNode, env: Environment) -> Any:
        """Execute code in isolated environment with capability restrictions"""
        sandbox_env = Environment(None)
        
        allowed_capabilities = set(node.capabilities)
        
        safe_builtins = {}
        if 'io' in allowed_capabilities:
            safe_builtins['print'] = self.builtins.get('print', lambda args: print(" ".join(str(a) for a in args)))
            safe_builtins['input'] = self.builtins.get('input')
        if 'math' in allowed_capabilities:
            for name in ['abs', 'min', 'max', 'sum', 'round', 'sqrt', 'sin', 'cos', 'pow', 'log']:
                if name in self.builtins:
                    safe_builtins[name] = self.builtins[name]
        if 'list' in allowed_capabilities:
            for name in ['len', 'sorted', 'reversed', 'list', 'range']:
                if name in self.builtins:
                    safe_builtins[name] = self.builtins[name]
        if 'string' in allowed_capabilities:
            for name in ['str', 'chr', 'ord']:
                if name in self.builtins:
                    safe_builtins[name] = self.builtins[name]
        
        for name, func in safe_builtins.items():
            sandbox_env.define(name, func)
        
        result = None
        try:
            for stmt in node.body:
                result = self.execute(stmt, sandbox_env)
        except Exception as e:
            raise RuntimeError(f"Sandbox execution error: {e}", node.line, node.column)
        
        return result
    
    def execute_InvariantNode(self, node: InvariantNode, env: Environment) -> Callable:
        """Register class invariant"""
        invariant_condition = node.condition
        
        def check_invariant(instance: STRACTInstance) -> bool:
            inv_env = Environment(self.global_env)
            inv_env.define('this', instance)
            return self.is_truthy(self.execute(invariant_condition, inv_env))
        
        if not hasattr(self, 'invariants'):
            self.invariants = []
        self.invariants.append(check_invariant)
        
        return check_invariant
    
    # ==================== AI-Native Language Execution ====================
    
    def execute_TensorNode(self, node: TensorNode, env: Environment) -> STRACTTensor:
        """Create tensor with shape, device, and gradient tracking"""
        shape = [self.execute(dim, env) for dim in node.shape]
        
        value_data = None
        if node.value:
            value_data = self.execute(node.value, env)
            if isinstance(value_data, list):
                pass
            else:
                value_data = [value_data]
        
        tensor = STRACTTensor(
            data=value_data,
            shape=shape,
            dtype=node.dtype,
            device=node.device,
            requires_grad=node.requires_grad
        )
        
        if node.name:
            env.define(node.name, tensor)
        
        return tensor
    
    def execute_ModelNode(self, node: ModelNode, env: Environment) -> STRACTModel:
        """Define AI model structure"""
        layers = []
        for layer_node in node.layers:
            layer = self.execute(layer_node, env)
            layers.append(layer)
        
        model = STRACTModel(
            name=node.name,
            layers=layers,
            optimizer=node.optimizer,
            loss=node.loss
        )
        
        if not hasattr(self, 'models'):
            self.models = {}
        self.models[node.name] = model
        env.define(node.name, model)
        
        return model
    
    def execute_OptimizeDirectiveNode(self, node: OptimizeDirectiveNode, env: Environment) -> Any:
        """Perform automatic optimization"""
        target = self.execute(node.target, env) if node.target else None
        data = self.execute(node.data, env) if node.data else None
        
        optimization_result = {
            'target': target,
            'goal': node.goal,
            'data': data,
            'config': node.config,
            'status': 'optimized',
            'improvements': {
                'accuracy': 0.0,
                'speed': 0.0,
                'memory': 0.0
            }
        }
        
        if node.goal == 'accuracy':
            optimization_result['improvements']['accuracy'] = 0.05
        elif node.goal == 'speed':
            optimization_result['improvements']['speed'] = 0.20
        elif node.goal == 'memory':
            optimization_result['improvements']['memory'] = 0.15
        
        return optimization_result
    
    def execute_GradientNode(self, node: GradientNode, env: Environment) -> Dict[str, Any]:
        """Compute gradients via automatic differentiation"""
        expression = self.execute(node.expression, env)
        
        gradients = {}
        for var_name in node.with_respect_to:
            var_value = env.get(var_name)
            
            if isinstance(var_value, STRACTTensor):
                grad_tensor = STRACTTensor(
                    data=[1.0] * len(var_value.data),
                    shape=var_value.shape[:],
                    dtype=var_value.dtype
                )
                gradients[var_name] = grad_tensor
            elif isinstance(var_value, (int, float)):
                gradients[var_name] = 1.0
            else:
                gradients[var_name] = None
        
        return gradients
    
    def execute_TrainNode(self, node: TrainNode, env: Environment) -> Dict[str, Any]:
        """Train AI model"""
        model = self.execute(node.model, env) if node.model else None
        data = self.execute(node.data, env) if node.data else None
        
        if model is None:
            raise RuntimeError("Train requires a model", node.line, node.column)
        
        training_result = {
            'model': model.name if isinstance(model, STRACTModel) else str(model),
            'epochs': node.epochs,
            'config': node.config,
            'status': 'completed',
            'metrics': {
                'loss': 0.01,
                'accuracy': 0.95
            }
        }
        
        if isinstance(model, STRACTModel):
            model.trained = True
        
        return training_result
    
    def execute_PredictNode(self, node: PredictNode, env: Environment) -> Any:
        """Make predictions"""
        model = self.execute(node.model, env) if node.model else None
        input_data = self.execute(node.input_data, env) if node.input_data else None
        
        if model is None:
            raise RuntimeError("Predict requires a model", node.line, node.column)
        
        if isinstance(model, STRACTModel):
            return model.predict(input_data)
        elif callable(model):
            return model(input_data)
        else:
            return input_data
    
    def execute_HardwareNode(self, node: HardwareNode, env: Environment) -> Any:
        """Execute on specified hardware"""
        device = node.device
        
        hardware_env = Environment(env)
        hardware_env.define('__device__', device)
        
        result = None
        for stmt in node.body:
            result = self.execute(stmt, hardware_env)
            
            if isinstance(result, STRACTTensor):
                result.device = device
        
        return result
    
    # ==================== Reactive & Temporal Execution ====================
    
    def execute_ReactiveStreamNode(self, node: ReactiveStreamNode, env: Environment) -> STRACTStream:
        """Create reactive stream with transformations"""
        initial_value = None
        if node.source:
            initial_value = self.execute(node.source, env)
        
        stream = STRACTStream(name=node.name, initial_value=initial_value)
        
        for transform_node in node.transformations:
            transform = self.execute(transform_node, env)
            if callable(transform):
                stream.transformations.append(transform)
        
        if not hasattr(self, 'streams'):
            self.streams = {}
        self.streams[node.name] = stream
        env.define(node.name, stream)
        
        return stream
    
    def execute_TemporalVariableNode(self, node: TemporalVariableNode, env: Environment) -> Dict[str, Any]:
        """Create time-changing variable"""
        initial_value = None
        if node.initial_value:
            initial_value = self.execute(node.initial_value, env)
        
        interval = None
        if node.interval:
            interval = self.execute(node.interval, env)
        
        temporal_var = {
            'name': node.name,
            'value': initial_value,
            'history': [initial_value],
            'interval': interval,
            'update_rule': node.update_rule,
            'created_at': time.time()
        }
        
        if not hasattr(self, 'temporal_vars'):
            self.temporal_vars = {}
        self.temporal_vars[node.name] = temporal_var
        env.define(node.name, temporal_var)
        
        return temporal_var
    
    def execute_WhenNode(self, node: WhenNode, env: Environment) -> Callable:
        """Register reactive condition handler"""
        condition = node.condition
        body = node.body
        
        def handler():
            if self.is_truthy(self.execute(condition, env)):
                result = None
                for stmt in body:
                    result = self.execute(stmt, env)
                return result
            return None
        
        if not hasattr(self, 'reactive_handlers'):
            self.reactive_handlers = []
        self.reactive_handlers.append(handler)
        
        return handler
    
    def execute_ObserveNode(self, node: ObserveNode, env: Environment) -> Any:
        """Observe variable changes"""
        target = self.execute(node.target, env)
        handler = None
        if node.handler:
            handler = self.execute(node.handler, env)
        
        if isinstance(target, STRACTStream) and handler:
            target.subscribe(handler)
        elif isinstance(target, dict) and 'history' in target:
            if handler:
                if not hasattr(self, 'observers'):
                    self.observers = {}
                target_name = target.get('name', str(id(target)))
                if target_name not in self.observers:
                    self.observers[target_name] = []
                self.observers[target_name].append(handler)
        
        return target
    
    def execute_EmitNode(self, node: EmitNode, env: Environment) -> Any:
        """Emit value to stream"""
        stream = self.execute(node.stream, env) if node.stream else None
        value = self.execute(node.value, env) if node.value else None
        
        if isinstance(stream, STRACTStream):
            stream.emit(value)
            return value
        elif isinstance(stream, dict) and 'history' in stream:
            stream['value'] = value
            stream['history'].append(value)
            
            stream_name = stream.get('name', '')
            if hasattr(self, 'observers') and stream_name in self.observers:
                for observer in self.observers[stream_name]:
                    if callable(observer):
                        observer(value)
            return value
        else:
            raise RuntimeError("Cannot emit to non-stream target", node.line, node.column)
    
    def execute_EveryNode(self, node: EveryNode, env: Environment) -> Dict[str, Any]:
        """Schedule periodic execution"""
        interval = self.execute(node.interval, env) if node.interval else 1.0
        
        if isinstance(interval, str):
            if interval.endswith('s'):
                interval = float(interval[:-1])
            elif interval.endswith('ms'):
                interval = float(interval[:-2]) / 1000.0
            elif interval.endswith('m'):
                interval = float(interval[:-1]) * 60.0
        
        scheduled_task = {
            'type': 'every',
            'interval': interval,
            'body': node.body,
            'env': env,
            'active': True
        }
        
        if not hasattr(self, 'scheduled_tasks'):
            self.scheduled_tasks = []
        self.scheduled_tasks.append(scheduled_task)
        
        return scheduled_task
    
    def execute_AfterNode(self, node: AfterNode, env: Environment) -> Dict[str, Any]:
        """Schedule delayed execution"""
        delay = self.execute(node.delay, env) if node.delay else 0.0
        
        if isinstance(delay, str):
            if delay.endswith('s'):
                delay = float(delay[:-1])
            elif delay.endswith('ms'):
                delay = float(delay[:-2]) / 1000.0
            elif delay.endswith('m'):
                delay = float(delay[:-1]) * 60.0
        
        delayed_task = {
            'type': 'after',
            'delay': delay,
            'body': node.body,
            'env': env,
            'scheduled_at': time.time(),
            'executed': False
        }
        
        if not hasattr(self, 'delayed_tasks'):
            self.delayed_tasks = []
        self.delayed_tasks.append(delayed_task)
        
        return delayed_task
    
    def execute_PipeNode(self, node: PipeNode, env: Environment) -> Any:
        """Execute pipe chain (value |> transform)"""
        left_value = self.execute(node.left, env)
        
        right = node.right
        
        if isinstance(right, FunctionCallNode):
            func_name = right.name
            func = env.get(func_name) if env.exists(func_name) else self.builtins.get(func_name)
            
            if func is None and func_name in self.functions:
                func_node = self.functions[func_name]
                args = [left_value] + [self.execute(arg, env) for arg in right.args]
                return self.execute_user_function(func_node, args)
            
            if callable(func):
                args = [left_value] + [self.execute(arg, env) for arg in right.args]
                if func_name in self.builtins:
                    return func(args)
                return func(*args)
        elif isinstance(right, LambdaNode):
            return self.execute_lambda_call(right, [left_value])
        elif isinstance(right, IdentifierNode):
            func = env.get(right.name) if env.exists(right.name) else self.builtins.get(right.name)
            if callable(func):
                if right.name in self.builtins:
                    return func([left_value])
                return func(left_value)
            if right.name in self.functions:
                return self.execute_user_function(self.functions[right.name], [left_value])
        
        raise RuntimeError(f"Invalid pipe target", node.line, node.column)
    
    # ==================== Type Annotation Execution ====================
    
    def execute_TypeAnnotationNode(self, node: TypeAnnotationNode, env: Environment) -> Dict[str, Any]:
        """Process type annotation"""
        type_info = {
            'name': node.name,
            'type_name': node.type_name,
            'is_optional': node.is_optional,
            'generic_params': node.generic_params
        }
        return type_info
    
    def execute_TypedParameterNode(self, node: TypedParameterNode, env: Environment) -> Dict[str, Any]:
        """Process typed parameter"""
        type_annotation = None
        if node.type_annotation:
            type_annotation = self.execute(node.type_annotation, env)
        
        default_value = None
        if node.default_value:
            default_value = self.execute(node.default_value, env)
        
        param_info = {
            'name': node.name,
            'type_annotation': type_annotation,
            'default_value': default_value
        }
        return param_info


# ============================================================================
# PART 7: STRACT INTERPRETER FACADE
# ============================================================================

class STRACT:
    VERSION = "3.0.0"
    
    def __init__(self):
        self.interpreter = Interpreter()
    
    def run_source(self, source: str) -> Any:
        try:
            lexer = Lexer(source)
            tokens = lexer.tokenize()
            
            parser = Parser(tokens)
            ast = parser.parse()
            
            return self.interpreter.execute(ast)
        
        except (LexerError, ParserError, RuntimeError, ThrowException) as e:
            print(f"\n{'='*60}")
            print(f"STRACT Error: {e}")
            print(f"{'='*60}\n")
            return None
    
    def run_file(self, filename: str) -> Any:
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                source = f.read()
            return self.run_source(source)
        except FileNotFoundError:
            print(f"Error: File not found: {filename}")
            return None
        except Exception as e:
            print(f"Error reading file: {e}")
            return None
    
    def repl(self):
        print(f"""
╔══════════════════════════════════════════════════════════════════════╗
║     ███████╗████████╗██████╗  █████╗  ██████╗████████╗               ║
║     ██╔════╝╚══██╔══╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝               ║
║     ███████╗   ██║   ██████╔╝███████║██║        ██║                  ║
║     ╚════██║   ██║   ██╔══██╗██╔══██║██║        ██║                  ║
║     ███████║   ██║   ██║  ██║██║  ██║╚██████╗   ██║                  ║
║     ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝   ╚═╝                  ║
╠══════════════════════════════════════════════════════════════════════╣
║  STRACT Programming Language v{self.VERSION}                                ║
║  A Modern Language for 2027 and Beyond - AI Ready                   ║
║  Type 'help' for commands, 'exit' to quit                            ║
╚══════════════════════════════════════════════════════════════════════╝
""")
        
        multiline_buffer = []
        in_block = False
        
        while True:
            try:
                prompt = "... " if in_block else ">>> "
                line = input(prompt)
                
                if line.strip().lower() == 'exit' and not in_block:
                    print("Goodbye! Thanks for using STRACT.")
                    break
                
                if line.strip().lower() == 'help' and not in_block:
                    self.show_help()
                    continue
                
                if line.strip().lower() == 'examples' and not in_block:
                    self.show_examples()
                    continue
                
                if line.strip().lower() == 'clear' and not in_block:
                    self.interpreter = Interpreter()
                    print("Environment cleared.")
                    continue
                
                if line.endswith(':') or in_block:
                    multiline_buffer.append(line)
                    if line.endswith(':'):
                        in_block = True
                    elif line.strip() == '' and in_block:
                        source = '\n'.join(multiline_buffer)
                        multiline_buffer = []
                        in_block = False
                        self.run_source(source)
                    continue
                
                if line.strip():
                    self.run_source(line)
            
            except EOFError:
                print("\nGoodbye!")
                break
            except KeyboardInterrupt:
                print("\nUse 'exit' to quit.")
                multiline_buffer = []
                in_block = False
    
    def show_help(self):
        print("""
STRACT Language v3.0 - Quick Reference
════════════════════════════════════════════════════════════════════════

VARIABLES:
    let x = 10              # Mutable variable
    const PI = 3.14         # Constant
    var y = 20              # Alternative syntax

DATA TYPES:
    42, 3.14, 0xFF, 0b101   # Numbers (int, float, hex, binary)
    "hello", 'world'        # Strings (escape: \\n, \\t, etc.)
    true, false             # Booleans
    null                    # Null value
    [1, 2, 3]               # Lists
    {"a": 1, "b": 2}        # Dictionaries

OPERATORS:
    +, -, *, /, //, %, **   # Arithmetic
    ==, !=, <, >, <=, >=    # Comparison
    and, or, not, in        # Logical
    +=, -=, *=, /=          # Compound assignment

CONTROL FLOW:
    if condition:           # Conditionals
    elif condition:
    else:

    while condition:        # While loop
    for i in range(10):     # For loop
    for item in list:       # For-each
    break, continue         # Loop control

    match value:            # Pattern matching
        case 1: ...
        case 2: ...
        default: ...

FUNCTIONS:
    func name(arg1, arg2=default):
        return value

    lambda x, y: x + y      # Lambda expressions

CLASSES:
    class Animal:
        func init(name):
            this.name = name
        func speak():
            print this.name

    let dog = new Animal("Rex")

ERROR HANDLING:
    try:
        ...
    catch error:
        ...
    finally:
        ...
    throw "error message"

BUILT-IN FUNCTIONS:
    I/O: print, input
    Types: str, int, float, bool, type, len
    Math: abs, min, max, sum, round, sqrt, sin, cos, pow, log
    Random: random, choice, shuffle
    Lists: sorted, reversed, append, pop, insert, extend, unique
    Strings: upper, lower, split, join, replace, find, strip
    Functional: map, filter, reduce, zip, enumerate
    JSON: parse_json, to_json
    Other: time, sleep, range, assert, exit

REPL Commands: help, examples, clear, exit
════════════════════════════════════════════════════════════════════════
""")
    
    def show_examples(self):
        print("""
STRACT Examples
════════════════════════════════════════════════════════════════════════

# 1. Basic Variables
let name = "STRACT"
let version = 3.0
print "Welcome to", name, "v" + str(version)

# 2. Functions with defaults
func greet(name, greeting="Hello"):
    return greeting + ", " + name + "!"

print greet("World")
print greet("STRACT", "Welcome to")

# 3. Lambda and Higher-Order Functions
let numbers = [1, 2, 3, 4, 5]
let doubled = numbers.map(lambda x: x * 2)
let evens = numbers.filter(lambda x: x % 2 == 0)
print "Doubled:", doubled
print "Evens:", evens

# 4. Classes
class Counter:
    func init(start=0):
        this.value = start
    func increment():
        this.value += 1
        return this.value

let counter = new Counter(10)
print counter.increment()
print counter.increment()

# 5. Pattern Matching
let status = 200
match status:
    case 200:
        print "OK"
    case 404:
        print "Not Found"
    default:
        print "Unknown"

# 6. Error Handling
try:
    let x = 1 / 0
catch error:
    print "Error:", error
finally:
    print "Cleanup done"

# 7. Dictionary Operations
let person = {"name": "Alice", "age": 30}
print person.keys()
print person.get("name")
person["city"] = "NYC"

# 8. List Comprehension-like Operations
let squares = range(1, 6).map(lambda x: x ** 2)
print "Squares:", squares

════════════════════════════════════════════════════════════════════════
""")


# ============================================================================
# PART 8: MAIN ENTRY POINT
# ============================================================================

def main():
    stract = STRACT()
    
    if len(sys.argv) > 1:
        filename = sys.argv[1]
        stract.run_file(filename)
    else:
        stract.repl()


if __name__ == "__main__":
    main()
